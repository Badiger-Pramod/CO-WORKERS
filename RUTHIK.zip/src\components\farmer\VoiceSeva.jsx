import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Volume2, VolumeX, RotateCcw, Play, Square, CheckCircle, Loader2, AlertTriangle, Globe } from 'lucide-react';
import { processVoiceInput, startListening, speakText, stopSpeaking, getDemoScript } from '../../utils/voiceSeva';
import { LANGUAGES } from '../../data/translations';

// Voice button states
const VOICE_STATES = {
  IDLE: 'idle',
  LISTENING: 'listening',
  PROCESSING: 'processing',
  RESPONSE_READY: 'response_ready',
  SPEAKING: 'speaking',
  NOT_UNDERSTOOD: 'not_understood',
  OFFLINE: 'offline',
};

const STATE_CONFIG = {
  [VOICE_STATES.IDLE]: {
    label: { en: 'Tap to Speak', kn: 'ಮಾತನಾಡಲು ಒತ್ತಿ', hi: 'बोलने के लिए दबाएं', te: 'మాట్లాడటానికి నొక్కండి', ta: 'பேச அழுத்துங்கள்', mr: 'बोलण्यासाठी दाबा', bn: 'কথা বলতে চাপুন' },
    icon: Mic,
    bgClass: 'bg-emerald-600 hover:bg-emerald-500',
    ringClass: '',
    textClass: 'text-white',
  },
  [VOICE_STATES.LISTENING]: {
    label: { en: 'Listening…', kn: 'ಆಲಿಸುತ್ತಿದ್ದೇನೆ…', hi: 'सुन रहा हूं…', te: 'వింటున్నాను…', ta: 'கேட்கிறேன்…', mr: 'ऐकत आहे…', bn: 'শুনছি…' },
    icon: Mic,
    bgClass: 'bg-red-500',
    ringClass: 'animate-ping',
    textClass: 'text-white',
  },
  [VOICE_STATES.PROCESSING]: {
    label: { en: 'Processing…', kn: 'ಸಂಸ್ಕರಿಸುತ್ತಿದ್ದೇನೆ…', hi: 'प्रोसेस हो रहा है…', te: 'ప్రాసెస్ అవుతోంది…', ta: 'செயலாக்குகிறேன்…', mr: 'प्रक्रिया होत आहे…', bn: 'প্রক্রিয়া করছি…' },
    icon: Loader2,
    bgClass: 'bg-amber-500',
    ringClass: '',
    textClass: 'text-white',
    spin: true,
  },
  [VOICE_STATES.RESPONSE_READY]: {
    label: { en: 'Response Ready', kn: 'ಉತ್ತರ ಸಿದ್ಧ', hi: 'जवाब तैयार', te: 'సమాధానం సిద్ధం', ta: 'பதில் தயார்', mr: 'उत्तर तयार', bn: 'উত্তর প্রস্তুত' },
    icon: CheckCircle,
    bgClass: 'bg-emerald-700',
    ringClass: '',
    textClass: 'text-white',
  },
  [VOICE_STATES.SPEAKING]: {
    label: { en: '🔊 Playing…', kn: '🔊 ಕೇಳಿ…', hi: '🔊 सुनें…', te: '🔊 వింటోంది…', ta: '🔊 இயங்குகிறது…', mr: '🔊 ऐका…', bn: '🔊 শুনছে…' },
    icon: Volume2,
    bgClass: 'bg-blue-600',
    ringClass: '',
    textClass: 'text-white',
  },
  [VOICE_STATES.NOT_UNDERSTOOD]: {
    label: { en: 'Try Again', kn: 'ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ', hi: 'फिर कोशिश करें', te: 'మళ్ళీ ప్రయత్నించండి', ta: 'மீண்டும் முயற்சி', mr: 'पुन्हा प्रयत्न करा', bn: 'আবার চেষ্টা করুন' },
    icon: RotateCcw,
    bgClass: 'bg-slate-600 hover:bg-slate-500',
    ringClass: '',
    textClass: 'text-white',
  },
};

export const VoiceSeva = ({ lang = 'en', isLowConnectivity = false, isOnline = true, onRequestWorker }) => {
  const [voiceState, setVoiceState] = useState(VOICE_STATES.IDLE);
  const [transcript, setTranscript] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [selectedLang, setSelectedLang] = useState(lang);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const recognitionRef = useRef(null);
  const supportedLangs = LANGUAGES.filter(l => ['en','kn','hi','te','ta','mr','bn'].includes(l.code));

  // STT not supported → auto-use demo mode
  const hasSpeechRecognition = typeof window !== 'undefined' &&
    (window.SpeechRecognition || window.webkitSpeechRecognition);

  const getLabel = (stateKey) => {
    const cfg = STATE_CONFIG[stateKey];
    return cfg?.label?.[selectedLang] || cfg?.label?.en || '';
  };

  const handleMicTap = () => {
    if (!isOnline) {
      setVoiceState(VOICE_STATES.OFFLINE);
      return;
    }
    if (voiceState === VOICE_STATES.LISTENING) {
      // Stop early
      recognitionRef.current?.stop();
      setVoiceState(VOICE_STATES.IDLE);
      return;
    }
    if (voiceState === VOICE_STATES.SPEAKING) {
      stopSpeaking();
      setIsSpeaking(false);
      setVoiceState(VOICE_STATES.RESPONSE_READY);
      return;
    }
    if (!hasSpeechRecognition || isDemoMode) {
      runDemoMode();
    } else {
      runRealSTT();
    }
  };

  const runDemoMode = () => {
    setVoiceState(VOICE_STATES.LISTENING);
    setTimeout(() => {
      const script = getDemoScript(selectedLang);
      setTranscript(script.text);
      setVoiceState(VOICE_STATES.PROCESSING);
      setTimeout(() => {
        const result = processVoiceInput(script.text, selectedLang);
        setResponseData(result);
        setVoiceState(VOICE_STATES.RESPONSE_READY);
      }, 1200);
    }, 2000);
  };

  const runRealSTT = () => {
    setVoiceState(VOICE_STATES.LISTENING);
    setTranscript('');
    setResponseData(null);

    recognitionRef.current = startListening(
      selectedLang,
      (text) => {
        setTranscript(text);
        setVoiceState(VOICE_STATES.PROCESSING);
        setTimeout(() => {
          const result = processVoiceInput(text, selectedLang);
          setResponseData(result);
          setVoiceState(VOICE_STATES.RESPONSE_READY);
        }, 800);
      },
      () => {
        if (voiceState === VOICE_STATES.LISTENING) setVoiceState(VOICE_STATES.IDLE);
      },
      (err) => {
        if (err === 'not_supported') {
          setIsDemoMode(true);
          runDemoMode();
        } else {
          setVoiceState(VOICE_STATES.NOT_UNDERSTOOD);
        }
      }
    );
  };

  const handlePlayResponse = async () => {
    if (!responseData) return;
    setVoiceState(VOICE_STATES.SPEAKING);
    setIsSpeaking(true);
    await speakText(responseData.text, selectedLang);
    setIsSpeaking(false);
    setVoiceState(VOICE_STATES.RESPONSE_READY);
  };

  const handleReset = () => {
    stopSpeaking();
    recognitionRef.current?.stop();
    setVoiceState(VOICE_STATES.IDLE);
    setTranscript('');
    setResponseData(null);
    setIsSpeaking(false);
  };

  // Auto-play TTS on response
  useEffect(() => {
    if (voiceState === VOICE_STATES.RESPONSE_READY && responseData && !isSpeaking) {
      handlePlayResponse();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [voiceState, responseData]);

  const currentStateConfig = STATE_CONFIG[voiceState] || STATE_CONFIG[VOICE_STATES.IDLE];
  const IconComponent = currentStateConfig.icon;

  return (
    <div className={`flex flex-col items-center gap-6 w-full max-w-lg mx-auto ${isLowConnectivity ? 'p-4' : 'p-6'}`}>

      {/* Offline Banner */}
      {!isOnline && (
        <div className="w-full bg-red-950 border border-red-700 text-red-200 rounded-2xl px-4 py-3 flex items-center gap-3">
          <span className="text-xl">📵</span>
          <div>
            <p className="font-bold text-sm">You are offline</p>
            <p className="text-xs opacity-80">Voice Seva cannot generate responses without a connection. No simulated responses will be shown.</p>
          </div>
        </div>
      )}

      {/* Demo Mode Notice */}
      {isDemoMode && isOnline && (
        <div className="w-full bg-amber-950/80 border border-amber-700 text-amber-200 rounded-xl px-3 py-2 text-xs flex items-center gap-2">
          <span>🎯</span>
          <span><strong>Demo Mode:</strong> Simulating speech. Real mic not available in this browser.</span>
        </div>
      )}

      {/* Language Selector */}
      <div className="flex items-center gap-2 flex-wrap justify-center">
        <Globe className="w-4 h-4 text-slate-400" />
        {supportedLangs.map(l => (
          <button
            key={l.code}
            onClick={() => { setSelectedLang(l.code); handleReset(); }}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
              selectedLang === l.code
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {l.nativeName}
          </button>
        ))}
      </div>

      {/* Main Mic Button */}
      <div className="relative flex flex-col items-center gap-3">
        {/* Ping ring for listening */}
        {voiceState === VOICE_STATES.LISTENING && (
          <>
            <span className="absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-30 animate-ping" style={{ top: 0, left: 0, width: '100%', height: '100%' }} />
            <span className="absolute inline-flex h-full w-full rounded-full bg-red-300 opacity-20 animate-ping" style={{ top: -12, left: -12, right: -12, bottom: -12 }} />
          </>
        )}
        <button
          onClick={handleMicTap}
          disabled={!isOnline && voiceState !== VOICE_STATES.IDLE}
          className={`relative z-10 flex flex-col items-center justify-center rounded-full shadow-2xl transition-all transform active:scale-95 focus:outline-none focus:ring-4 focus:ring-emerald-400/50 ${
            isLowConnectivity ? 'w-36 h-36' : 'w-28 h-28'
          } ${currentStateConfig.bgClass} ${!isOnline ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
          aria-label={getLabel(voiceState)}
        >
          <IconComponent
            className={`${isLowConnectivity ? 'w-14 h-14' : 'w-10 h-10'} text-white ${currentStateConfig.spin ? 'animate-spin' : ''}`}
          />
        </button>

        {/* State Label */}
        <p className={`font-black text-center text-lg ${isLowConnectivity ? 'text-2xl' : ''} text-white`}>
          {getLabel(voiceState)}
        </p>
      </div>

      {/* Transcript Display */}
      {transcript && (
        <div className="w-full bg-slate-800 border border-slate-700 rounded-2xl px-4 py-3">
          <p className="text-xs text-slate-400 mb-1 font-semibold">You said:</p>
          <p className="text-white font-medium text-sm leading-relaxed">"{transcript}"</p>
        </div>
      )}

      {/* Response Card */}
      {responseData && (
        <div className="w-full bg-emerald-950 border border-emerald-800 rounded-2xl px-5 py-4 space-y-3">
          <div className="flex items-start gap-3">
            <span className="text-2xl mt-0.5">🎙️</span>
            <p className="text-emerald-100 text-sm leading-relaxed font-medium">
              {responseData.text}
            </p>
          </div>

          {/* Disclaimer */}
          {responseData.disclaimer && (
            <div className="bg-amber-950/80 border border-amber-700 rounded-xl px-3 py-2 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
              <p className="text-amber-200 text-xs leading-relaxed">{responseData.disclaimer}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2 pt-1">
            {/* Replay TTS */}
            <button
              onClick={handlePlayResponse}
              disabled={voiceState === VOICE_STATES.SPEAKING}
              className="flex items-center gap-1.5 px-3 py-2 bg-blue-700 hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition disabled:opacity-50"
            >
              {voiceState === VOICE_STATES.SPEAKING
                ? <><Square className="w-3 h-3" /> Stop</>
                : <><Play className="w-3 h-3" /> Play Response</>
              }
            </button>

            {/* Find Worker */}
            {responseData.requiresWorker && responseData.serviceCategory && (
              <button
                onClick={() => onRequestWorker?.(responseData.serviceCategory)}
                className={`flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition ${isLowConnectivity ? 'text-base' : 'text-xs'}`}
              >
                👨‍🌾 Find Worker
              </button>
            )}

            {/* Speak Again */}
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold transition"
            >
              <RotateCcw className="w-3 h-3" /> Speak Again
            </button>
          </div>
        </div>
      )}

      {/* Not Understood State */}
      {voiceState === VOICE_STATES.NOT_UNDERSTOOD && (
        <button onClick={handleReset} className="px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-2xl font-bold text-sm transition">
          🔄 Try Again
        </button>
      )}

      {/* Demo mode trigger for browsers without mic support */}
      {!hasSpeechRecognition && voiceState === VOICE_STATES.IDLE && !isDemoMode && isOnline && (
        <p className="text-xs text-slate-400 text-center">
          Your browser doesn't support live microphone. <button onClick={() => setIsDemoMode(true)} className="text-emerald-400 underline">Run Demo Simulation</button>
        </p>
      )}
    </div>
  );
};
