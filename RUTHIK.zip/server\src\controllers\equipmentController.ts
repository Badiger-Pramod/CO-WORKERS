import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';
import { Equipment, EquipmentBooking, Notification } from '../types';
import { broadcastEvent } from '../services/socketService';

// GET /api/equipment
export const getEquipmentList = async (req: Request, res: Response): Promise<void> => {
  try {
    const { type, availability, maxRate } = req.query;

    let items = [...localStore.equipment];

    if (type) {
      const t = String(type).toLowerCase();
      items = items.filter(e => e.type.toLowerCase().includes(t) || e.name.toLowerCase().includes(t));
    }

    if (availability) {
      items = items.filter(e => e.availability.toLowerCase() === String(availability).toLowerCase());
    }

    if (maxRate) {
      items = items.filter(e => e.daily_rate <= Number(maxRate));
    }

    res.json({ success: true, count: items.length, equipment: items });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch equipment listings.' });
  }
};

// POST /api/equipment
export const createEquipmentListing = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      owner_id,
      owner_name,
      name,
      type,
      daily_rate,
      location = 'Tumakuru Rural',
      operator_provided = false,
      condition = 'Good',
      description = '',
      image_url = 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=800&q=80'
    } = req.body;

    if (!name || !type || !daily_rate) {
      res.status(400).json({ success: false, message: 'Name, equipment type, and daily rate are required.' });
      return;
    }

    const nextId = localStore.equipment.length ? Math.max(...localStore.equipment.map(e => e.id)) + 1 : 1;

    const newEquip: Equipment = {
      id: nextId,
      owner_id: Number(owner_id) || 7,
      owner_name: owner_name || 'Farmer',
      name,
      type,
      daily_rate: Number(daily_rate),
      location,
      availability: 'Available',
      operator_provided: Boolean(operator_provided),
      condition,
      image_url,
      rating: 5.0,
      description,
      created_at: new Date().toISOString()
    };

    localStore.equipment.unshift(newEquip);
    persistLocalStore();

    broadcastEvent('role_FARMER', 'new_equipment_listed', newEquip);

    res.status(201).json({
      success: true,
      message: 'Equipment listed successfully for community sharing!',
      equipment: newEquip
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to list equipment.' });
  }
};

// POST /api/equipment/:id/book
export const bookEquipment = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const { farmer_id, farmer_name, start_date, end_date, days = 1 } = req.body;

    const equip = localStore.equipment.find(e => e.id === id);
    if (!equip) {
      res.status(404).json({ success: false, message: 'Equipment not found.' });
      return;
    }

    if (equip.availability !== 'Available') {
      res.status(400).json({ success: false, message: 'This equipment is currently booked or undergoing maintenance.' });
      return;
    }

    const numDays = Math.max(1, Number(days));
    const totalPrice = equip.daily_rate * numDays;

    const nextId = localStore.equipment_bookings.length
      ? Math.max(...localStore.equipment_bookings.map(b => b.id)) + 1
      : 1;

    const booking: EquipmentBooking = {
      id: nextId,
      equipment_id: equip.id,
      equipment_name: equip.name,
      farmer_id: Number(farmer_id),
      farmer_name: farmer_name || 'Farmer',
      start_date: start_date || 'Today',
      end_date: end_date || 'Tomorrow',
      days: numDays,
      total_price: totalPrice,
      status: 'CONFIRMED',
      created_at: new Date().toISOString()
    };

    localStore.equipment_bookings.unshift(booking);
    equip.availability = 'Rented';

    // Notify owner
    const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
    const ownerNotif: Notification = {
      id: notifId,
      user_id: equip.owner_id,
      title: 'Equipment Booking Confirmed 🚜',
      message: `${farmer_name || 'A farmer'} booked your ${equip.name} for ${numDays} days (₹${totalPrice}).`,
      type: 'booking',
      is_read: false,
      link: '/farmer-dashboard',
      created_at: new Date().toISOString()
    };
    localStore.notifications.unshift(ownerNotif);

    persistLocalStore();

    broadcastEvent(`user_${equip.owner_id}`, 'equipment_booked', booking);
    broadcastEvent(`user_${equip.owner_id}`, 'new_notification', ownerNotif);

    res.status(201).json({
      success: true,
      message: `Equipment '${equip.name}' booked successfully!`,
      booking
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to book equipment.' });
  }
};
