# 🤝 CoWork Connect — Cooperative Gig Services & Agricultural Platform

[![React](https://img.shields.io/badge/Frontend-React%2018%20%2B%20Vite-blue)](https://react.dev/)
[![Node](https://img.shields.io/badge/Backend-Node.js%20%2B%20Express-green)](https://nodejs.org/)
[![Socket.io](https://img.shields.io/badge/Realtime-Socket.io-black)](https://socket.io/)
[![TailwindCSS](https://img.shields.io/badge/Styling-TailwindCSS-38bdf8)](https://tailwindcss.com/)
[![Multilingual](https://img.shields.io/badge/Languages-8%20Indian%20Languages-orange)](https://en.wikipedia.org/wiki/Languages_of_India)

A modern, full-stack, democratic cooperative gig platform connecting households, urban service professionals, and agricultural communities across Karnataka and India.

---

## 🌟 Key Platform Portals & Features

1. **👤 Customer Portal**:
   - On-demand service booking (Plumbing, Electrical, Carpentry, Painting, Cleaning, AC, Mechanic, Gardening).
   - SmartMatch algorithmic provider recommendation.
   - Real-time status tracker (`Requested -> Accepted -> On The Way -> Work Started -> Completed -> Paid`).
   - Integrated transparent pricing with 8% capped cooperative fee.
   - Ratings, reviews, and dispute resolution.

2. **🛠️ Worker Portal**:
   - Transparent earnings dashboard and democratic profit dividend tracker.
   - Live job dispatch requests with accept/decline controls.
   - Dynamic trade management & availability toggle.
   - Worker Skill Exchange & Peer Mentorship Guilds.
   - "One Worker = One Vote" cooperative governance voting.

3. **🌾 Farmer Portal (CoWork Agri)**:
   - Dynamic farmer profile (Ravi Gowda, Cauvery Valley Orchards, etc.).
   - Agricultural labour dispatch & crew bookings.
   - Farm equipment sharing & rentals (Tractors, Tillers, Harvesters) with optional verified operators.
   - Crop Camera with AI visual disease detection.
   - Community Crop & Idea Sharing Feed with likes, comments, and agronomist peer advice.
   - Farmer Skill Exchange & Agronomy Mentorship.

4. **🏛️ Cooperative / Admin Portal**:
   - Live platform analytics: active workers, total jobs, gross revenue, cooperative welfare reserve.
   - Member e-KYC and trade credential verification.
   - 2-hour Peer Review Committee dispute mediation panel.

5. **🤖 Autonomous AI Assistant & Voice Seva**:
   - Hands-free Live Voice Orb powered by Gemini Live Audio in Kannada, Hindi, and English.
   - Multimodal Visual Defect Scanner for electrical faults and crop diseases.

6. **🇮🇳 India-First Architecture**:
   - Full multilingual support across 8 Indian languages (English, Kannada, Hindi, Tamil, Telugu, Malayalam, Marathi, Bengali).
   - Low-connectivity offline sync mode.

---

## 📁 Repository Structure

```text
├── src/                          # Frontend React Source Code
│   ├── components/
│   │   ├── customer/             # Customer Dashboard, Booking, Tracking, Invoices
│   │   ├── worker/               # Worker Dashboard, Schedule, Earnings, Skills
│   │   ├── farmer/               # CoWork Agri, Equipment, Labour, Crop Camera
│   │   ├── admin/                # Cooperative Admin & Audit Portal
│   │   ├── common/               # AI Assistant, Header, Footer, Modals
│   │   └── landing/              # Landing Page & Agricultural Showcase
│   ├── context/
│   │   └── CoopContext.jsx       # State management & real-time Socket.io sync
│   ├── data/
│   │   ├── translations.js       # 8-language localization dictionaries
│   │   ├── agriMockData.js       # Agricultural data & equipment catalog
│   │   └── mockData.js           # Trade definitions & initial workers
│   └── utils/                    # Voice Seva & audio helpers
├── server/                       # Backend Node.js + Express + TypeScript API
│   ├── src/
│   │   ├── controllers/          # Auth, Bookings, Workers, Farmers, Equipment, Admin
│   │   ├── routes/               # API Endpoints
│   │   ├── services/             # Socket.io real-time engine
│   │   ├── config/               # Dual-mode PostgreSQL + local JSON storage
│   │   └── types/                # TypeScript Interfaces
│   ├── data/                     # Persistent JSON Database
│   └── .env.example              # Environment variables template
├── public/                       # Static assets & icons
├── dist/                         # Optimized production build artifacts
├── package.json                  # Frontend dependencies & build scripts
├── vite.config.js                # Vite build and proxy configuration
└── tailwind.config.js            # Tailwind styling tokens
```

---

## 🚀 Getting Started

### 1. Clone or Download Repository
```bash
git clone <YOUR_GITHUB_REPO_URL>
cd RUTHIK
```

### 2. Install Dependencies
```bash
# Install frontend dependencies
npm install

# Install backend dependencies
cd server
npm install
cd ..
```

### 3. Configure Environment Variables (Optional)
```bash
cp server/.env.example server/.env
# Add your GEMINI_API_KEY in server/.env if using Voice Seva
```

### 4. Start the Application
```bash
# Terminal 1: Start Backend API (Port 5000)
cd server
npm run dev

# Terminal 2: Start Frontend Web App (Port 5173)
npm run dev
```

Open **`http://localhost:5173`** in your browser.
