import { Router } from 'express';
import {
  getBookings,
  getBookingById,
  createBooking,
  updateBookingStatus,
  processPayment,
  rateBooking
} from '../controllers/bookingController';

const router = Router();

router.get('/', getBookings);
router.get('/:id', getBookingById);
router.post('/', createBooking);
router.put('/:id/status', updateBookingStatus);
router.post('/:id/pay', processPayment);
router.post('/:id/rate', rateBooking);

export default router;
