import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  X,
  Printer,
  Download,
  ShieldCheck,
  CheckCircle2,
  Building2,
  FileText,
  QrCode,
  Award
} from 'lucide-react';

export const InvoiceModal = ({ booking, isOpen, onClose }) => {
  if (!isOpen || !booking) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200">
        
        {/* Modal Top Control Bar */}
        <div className="bg-slate-900 text-white p-4 flex justify-between items-center print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Official Cooperative Tax Invoice
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Printable Sheet */}
        <div className="p-6 sm:p-8 space-y-6 text-slate-800 text-xs bg-white">
          
          {/* Header of Society */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-black text-sm">
                  SS
                </div>
                <h2 className="text-lg font-black text-slate-900">
                  Tumakuru Community Services Cooperative Society Ltd.
                </h2>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Karnataka Souharda Sahakari Act Reg: <strong>2026-KA-TMK-019</strong> • GSTIN: <strong>29AABCT8892C1Z8</strong>
              </p>
              <p className="text-[10px] text-slate-400">
                Registered Office: 3rd Floor, Sahakara Soudha, BH Road, Tumakuru - 572102
              </p>
            </div>

            <div className="text-right shrink-0">
              <span className="bg-emerald-50 text-emerald-800 text-[10px] font-extrabold px-2.5 py-1 rounded-md border border-emerald-200 uppercase">
                Tax Invoice
              </span>
              <p className="text-[11px] font-mono font-bold text-slate-800 mt-1">INV-2026-0942</p>
              <p className="text-[10px] text-slate-400">{booking.date || 'Sep 12, 2026'}</p>
            </div>
          </div>

          {/* Customer & Worker Metadata Grid */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Billed To (Household):</span>
              <p className="font-bold text-slate-900 text-sm">{booking.customerName}</p>
              <p className="text-slate-600 text-[11px]">{booking.customerPhone}</p>
              <p className="text-slate-500 text-[10px] mt-0.5">{booking.customerAddress}</p>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Service Executed By:</span>
              <p className="font-bold text-slate-900 text-sm flex items-center gap-1">
                {booking.workerName}
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              </p>
              <p className="text-slate-600 text-[11px]">Co-owner ID: <strong>KA-TMK-0428</strong></p>
              <p className="text-slate-500 text-[10px] mt-0.5">Specialization: {booking.workerTrade || 'Plumbing'}</p>
            </div>
          </div>

          {/* Line Item Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">Service Description</th>
                  <th className="p-3">SAC Code</th>
                  <th className="p-3 text-right">Hours</th>
                  <th className="p-3 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="p-3">
                    <div className="font-bold text-slate-900">{booking.serviceTitle}</div>
                    <div className="text-[10px] text-slate-500">Scheduled Callout • Siddaganga Ext, Tumakuru</div>
                  </td>
                  <td className="p-3 font-mono text-slate-600">998719</td>
                  <td className="p-3 text-right">1.5 hrs</td>
                  <td className="p-3 text-right font-bold text-slate-900">₹{booking.grossTotal || 500}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Democratic Cooperative Split Ledger Breakdown */}
          <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 space-y-2">
            <div className="flex justify-between items-center pb-2 border-b border-emerald-200/80">
              <span className="font-bold text-emerald-950 uppercase tracking-wider text-[10px]">
                Cooperative Economic Distribution (No Corporate Commissions)
              </span>
              <span className="text-[10px] text-emerald-700 font-bold">100% Transparent</span>
            </div>

            <div className="space-y-1.5 text-slate-700 text-xs">
              <div className="flex justify-between">
                <span>1. Direct Worker Compensation (80%):</span>
                <span className="font-bold text-emerald-800">₹{booking.breakdown?.workerPayout || 400}.00</span>
              </div>
              <div className="flex justify-between">
                <span>2. Mutual Health & Welfare Reserve (15%):</span>
                <span className="font-bold text-teal-800">₹{booking.breakdown?.coopFee || 75}.00</span>
              </div>
              <div className="flex justify-between">
                <span>3. Open Platform Infrastructure & SMS (5%):</span>
                <span className="font-bold text-indigo-800">₹{booking.breakdown?.platformFee || 25}.00</span>
              </div>
            </div>

            <div className="pt-2 border-t border-emerald-200 flex justify-between items-center text-sm font-black text-slate-900">
              <span>Total Paid via Escrow:</span>
              <span className="text-emerald-900 text-base">₹{booking.grossTotal || 500}.00</span>
            </div>
          </div>

          {/* Footer & Authenticity Badge */}
          <div className="flex justify-between items-center pt-3 border-t border-slate-200 text-[10px] text-slate-400">
            <div>
              <p>Payment Ref: <strong className="text-slate-700 font-mono">UPI/26089/98451/OKHDFC</strong></p>
              <p>Generated automatically by SevaSetu Open Co-op Protocol (SIH26089).</p>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>Certified Co-op Receipt</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
