import React, { useState } from 'react';
import { X, User, Wrench, CheckCircle, AlertCircle, Eye, EyeOff, ShieldCheck, Sparkles, Sprout } from 'lucide-react';
import { TRADE_DEFINITIONS, getTradeIcon } from '../context/CoopContext';

export const RegistrationModal = ({ isOpen, onClose, onRegisterSuccess, initialRole = 'Customer' }) => {
  const [role, setRole] = useState(initialRole);
  const [formData, setFormData] = useState({
    // Common Personal Details
    fullName: '',
    mobileNumber: '',
    email: '',
    loginId: '',
    password: '',
    confirmPassword: '',
    preferredLanguage: 'en',
    avatar: '👨‍🌾',

    // Worker specific
    primaryTrade: 'Electrician',
    otherTradeName: '',
    additionalSkills: ['Wiring', 'Switchboard Repair'],
    experience: '5',
    serviceLocation: 'Tumakuru',
    serviceRadius: '10',

    // Farmer specific (Section 3: Farmer Registration)
    farmName: '',
    location: 'Tumakuru Rural',
    district: 'Tumakuru',
    state: 'Karnataka',
    farmSize: '5 Acres',
    landType: 'Red Sandy Loam',
    primaryCrop: 'Ragi',
    secondaryCrops: 'Groundnut, Tomato',
    farmingType: 'Mixed', // Conventional | Organic | Mixed
    irrigationType: 'Borewell & Drip', // Borewell | Drip | Sprinkler | Rain-fed | Other
    cooperativeName: 'Tumakuru Farmers Cooperative Society',
    cooperativeMembership: 'KA-TMK-AGRI-402'
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError('');
  };

  const handleToggleSkill = (skill) => {
    setFormData((prev) => {
      const exists = prev.additionalSkills.includes(skill);
      const updated = exists
        ? prev.additionalSkills.filter((s) => s !== skill)
        : [...prev.additionalSkills, skill];
      return { ...prev, additionalSkills: updated };
    });
  };

  const activeTradeDef = TRADE_DEFINITIONS.find((t) => t.id === formData.primaryTrade) || TRADE_DEFINITIONS[0];

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Common Form Validations
    if (!formData.fullName.trim()) {
      setError('Please enter your Full Name.');
      return;
    }
    if (!formData.mobileNumber.trim()) {
      setError('Please enter your Mobile Number.');
      return;
    }
    if (!formData.email.trim()) {
      setError('Please enter your Email Address.');
      return;
    }
    if (!formData.loginId.trim()) {
      setError('Please choose a Login ID.');
      return;
    }
    if (!formData.password) {
      setError('Please create a Password.');
      return;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    let finalTrade = formData.primaryTrade;
    if (role === 'Worker') {
      if (formData.primaryTrade === 'Other') {
        if (!formData.otherTradeName.trim()) {
          setError('Please enter your custom service/trade name.');
          return;
        }
        finalTrade = formData.otherTradeName.trim();
      }
      if (!formData.serviceLocation.trim()) {
        setError('Please enter your Service Location.');
        return;
      }
    }

    if (role === 'Farmer') {
      if (!formData.farmName.trim()) {
        setError('Please enter your Farm Name.');
        return;
      }
      if (!formData.location.trim()) {
        setError('Please enter your Village or Location.');
        return;
      }
      if (!formData.primaryCrop.trim()) {
        setError('Please enter your Primary Crop.');
        return;
      }
      if (!formData.farmSize.trim()) {
        setError('Please enter your Farm Size (e.g. 5 Acres).');
        return;
      }
    }

    try {
      const existingAccounts = JSON.parse(localStorage.getItem('cowork_registered_users') || '[]');
      const isDuplicate = existingAccounts.some(
        (u) => u.loginId.toLowerCase() === formData.loginId.trim().toLowerCase()
      );

      if (isDuplicate) {
        setError('This Login ID is already taken. Please choose another.');
        return;
      }

      let newAccount;

      if (role === 'Farmer') {
        const secCropsList = formData.secondaryCrops
          ? formData.secondaryCrops.split(',').map((s) => s.trim()).filter(Boolean)
          : [];
        const allCrops = Array.from(new Set([formData.primaryCrop.trim(), ...secCropsList]));

        newAccount = {
          role: 'Farmer',
          id: `farmer_${Date.now().toString().slice(-4)}`,
          loginId: formData.loginId.trim(),
          password: formData.password,
          fullName: formData.fullName.trim(),
          name: formData.fullName.trim(),
          mobileNumber: formData.mobileNumber.trim(),
          phone: formData.mobileNumber.trim(),
          email: formData.email.trim(),
          avatar: formData.avatar || '👨‍🌾',
          preferredLanguage: formData.preferredLanguage || 'en',

          // Farm Details
          farmName: formData.farmName.trim(),
          location: formData.location.trim(),
          village: formData.location.trim(),
          district: formData.district.trim() || 'Tumakuru',
          state: formData.state.trim() || 'Karnataka',
          farmSize: formData.farmSize.trim(),
          landSizeAcres: parseFloat(formData.farmSize) || 5,
          landType: formData.landType || 'Red Sandy Loam',

          // Farming Information
          primaryCrop: formData.primaryCrop.trim(),
          secondaryCrops: secCropsList,
          crops: allCrops,
          farmingType: formData.farmingType || 'Mixed',
          irrigationType: formData.irrigationType || 'Borewell & Drip',

          // Cooperative Information
          cooperativeName: formData.cooperativeName.trim() || 'Tumakuru Farmers Cooperative Society',
          cooperativeMembership: formData.cooperativeMembership.trim() || `KA-TMK-AGRI-${Math.floor(100 + Math.random() * 900)}`,
          coopMember: true,
          coopUnit: formData.cooperativeName.trim() || 'Tumakuru Farmers Cooperative Society',
          memberSince: 'Today',
          verificationStatus: 'Verified',
          verified: true,
          activeRequestsCount: 0,
          upcomingServicesCount: 0,
          equipmentBookingsCount: 0,
          skillsLearnedCount: 1
        };

        // Also append to cowork_farmers in localStorage
        try {
          const farmersList = JSON.parse(localStorage.getItem('cowork_farmers') || '[]');
          farmersList.unshift(newAccount);
          localStorage.setItem('cowork_farmers', JSON.stringify(farmersList));
        } catch {}
      } else if (role === 'Worker') {
        newAccount = {
          role: 'Worker',
          fullName: formData.fullName.trim(),
          name: formData.fullName.trim(),
          mobileNumber: formData.mobileNumber.trim(),
          phone: formData.mobileNumber.trim(),
          email: formData.email.trim(),
          loginId: formData.loginId.trim(),
          password: formData.password,
          primaryTrade: finalTrade,
          trade: finalTrade,
          additionalSkills: formData.additionalSkills,
          experience: parseInt(formData.experience) || 3,
          experienceText: `${formData.experience || 3} years experience`,
          serviceLocation: formData.serviceLocation.trim(),
          location: formData.serviceLocation.trim(),
          serviceRadius: parseInt(formData.serviceRadius) || 10,
          avatar: getTradeIcon(finalTrade),
          rating: 5.0,
          reviewCount: 1,
          completedJobs: 0,
          hourlyRate: 400,
          startingPrice: 350,
          available: true,
          verified: true
        };

        const workers = JSON.parse(localStorage.getItem('cowork_workers_directory') || '[]');
        workers.unshift(newAccount);
        localStorage.setItem('cowork_workers_directory', JSON.stringify(workers));
      } else {
        newAccount = {
          role: 'Customer',
          fullName: formData.fullName.trim(),
          name: formData.fullName.trim(),
          mobileNumber: formData.mobileNumber.trim(),
          phone: formData.mobileNumber.trim(),
          email: formData.email.trim(),
          loginId: formData.loginId.trim(),
          password: formData.password,
          location: 'Tumakuru'
        };
      }

      existingAccounts.push(newAccount);
      localStorage.setItem('cowork_registered_users', JSON.stringify(existingAccounts));

      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onRegisterSuccess(newAccount);
        onClose();
      }, 1400);
    } catch (err) {
      console.error(err);
      setError('Failed to complete registration. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-slate-900 to-emerald-950 text-white px-6 py-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🇮🇳</span>
              <h3 className="text-lg font-black tracking-tight">Create Account</h3>
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">
              Join CoWork Connect — Cooperative Gig Services Platform
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* User Type Selection: Customer | Worker | Farmer */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Registering As:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setRole('Customer')}
                className={`flex flex-col items-center justify-center gap-1 p-3 rounded-2xl border-2 text-xs font-extrabold transition-all cursor-pointer ${
                  role === 'Customer'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <User className={`w-4 h-4 ${role === 'Customer' ? 'text-emerald-700' : 'text-slate-400'}`} />
                <span>Customer</span>
                {role === 'Customer' && <span className="text-[10px] text-emerald-700 font-bold">✓ Selected</span>}
              </button>

              <button
                type="button"
                onClick={() => setRole('Worker')}
                className={`flex flex-col items-center justify-center gap-1 p-3 rounded-2xl border-2 text-xs font-extrabold transition-all cursor-pointer ${
                  role === 'Worker'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <Wrench className={`w-4 h-4 ${role === 'Worker' ? 'text-emerald-700' : 'text-slate-400'}`} />
                <span>Worker</span>
                {role === 'Worker' && <span className="text-[10px] text-emerald-700 font-bold">✓ Selected</span>}
              </button>

              <button
                type="button"
                onClick={() => setRole('Farmer')}
                className={`flex flex-col items-center justify-center gap-1 p-3 rounded-2xl border-2 text-xs font-extrabold transition-all cursor-pointer ${
                  role === 'Farmer'
                    ? 'border-lime-600 bg-lime-50 text-lime-950 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <span className="text-base">🌾</span>
                <span>Farmer</span>
                {role === 'Farmer' && <span className="text-[10px] text-lime-700 font-bold">✓ Selected</span>}
              </button>
            </div>
          </div>

          {/* Alert Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          {isSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>Account created successfully! Welcome to the cooperative.</span>
            </div>
          )}

          {/* Personal Details */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 border-b pb-1">
              1. Personal Details
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder={role === 'Farmer' ? 'e.g. Ravi Gowda' : 'e.g. Bhuvan Bhuvi'}
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mobile Number *
                </label>
                <input
                  type="tel"
                  name="mobileNumber"
                  value={formData.mobileNumber}
                  onChange={handleChange}
                  placeholder="+91 94480 12345"
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Language
                </label>
                <select
                  name="preferredLanguage"
                  value={formData.preferredLanguage}
                  onChange={handleChange}
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="en">English (English)</option>
                  <option value="kn">Kannada (ಕನ್ನಡ)</option>
                  <option value="hi">Hindi (हिन्दी)</option>
                  <option value="te">Telugu (తెలుగు)</option>
                  <option value="ta">Tamil (தமிழ்)</option>
                  <option value="mr">Marathi (मराठी)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Credentials Box */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Account Credentials
            </h4>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Create Login ID *
              </label>
              <input
                type="text"
                name="loginId"
                value={formData.loginId}
                onChange={handleChange}
                placeholder={role === 'Farmer' ? 'e.g. ravi01' : 'e.g. bhuvan01'}
                className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Create Password *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Min 6 characters"
                    className="w-full px-3.5 py-2.5 pr-9 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Confirm Password *
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    placeholder="Confirm password"
                    className="w-full px-3.5 py-2.5 pr-9 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* FARMER SPECIFIC DETAILS (SECTION 3 OF SPECIFICATION) */}
          {role === 'Farmer' && (
            <div className="bg-lime-50/70 p-4 rounded-2xl border border-lime-300 space-y-4 animate-in fade-in duration-150">
              <div className="flex items-center gap-2 text-xs font-black text-lime-900 border-b border-lime-200 pb-1">
                <span className="text-base">🌾</span>
                <span>2. Farm & Agriculture Details</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Farm Name *
                  </label>
                  <input
                    type="text"
                    name="farmName"
                    value={formData.farmName}
                    onChange={handleChange}
                    placeholder="e.g. Green Valley Farm"
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Farm Size *
                  </label>
                  <input
                    type="text"
                    name="farmSize"
                    value={formData.farmSize}
                    onChange={handleChange}
                    placeholder="e.g. 5 Acres"
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Village / Location *
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    placeholder="e.g. Tumakuru Rural"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    District
                  </label>
                  <input
                    type="text"
                    name="district"
                    value={formData.district}
                    onChange={handleChange}
                    placeholder="Tumakuru"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Land Type
                  </label>
                  <select
                    name="landType"
                    value={formData.landType}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  >
                    <option value="Red Sandy Loam">Red Sandy Loam</option>
                    <option value="Black Cotton Soil">Black Cotton Soil</option>
                    <option value="Clay Loam">Clay Loam</option>
                    <option value="Alluvial Soil">Alluvial Soil</option>
                    <option value="Laterite Soil">Laterite Soil</option>
                  </select>
                </div>
              </div>

              {/* Crops & Farming Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Primary Crop *
                  </label>
                  <input
                    type="text"
                    name="primaryCrop"
                    value={formData.primaryCrop}
                    onChange={handleChange}
                    placeholder="e.g. Ragi, Tomato, Groundnut"
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Secondary Crops
                  </label>
                  <input
                    type="text"
                    name="secondaryCrops"
                    value={formData.secondaryCrops}
                    onChange={handleChange}
                    placeholder="e.g. Groundnut, Tomato, Maize"
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Farming Type
                  </label>
                  <select
                    name="farmingType"
                    value={formData.farmingType}
                    onChange={handleChange}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  >
                    <option value="Mixed">Mixed</option>
                    <option value="Conventional">Conventional</option>
                    <option value="Organic">Organic</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Irrigation Type
                  </label>
                  <select
                    name="irrigationType"
                    value={formData.irrigationType}
                    onChange={handleChange}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  >
                    <option value="Borewell & Drip">Borewell & Drip</option>
                    <option value="Borewell">Borewell</option>
                    <option value="Drip">Drip</option>
                    <option value="Sprinkler">Sprinkler</option>
                    <option value="Rain-fed">Rain-fed</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Cooperative Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-lime-200">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Cooperative Society
                  </label>
                  <input
                    type="text"
                    name="cooperativeName"
                    value={formData.cooperativeName}
                    onChange={handleChange}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Cooperative Membership ID
                  </label>
                  <input
                    type="text"
                    name="cooperativeMembership"
                    value={formData.cooperativeMembership}
                    onChange={handleChange}
                    placeholder="e.g. KA-TMK-AGRI-402"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-lime-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* DYNAMIC WORKER PROFESSION / TRADE SELECTION SECTION */}
          {role === 'Worker' && (
            <div className="bg-emerald-50/70 p-4.5 rounded-2xl border border-emerald-300 space-y-4 animate-in fade-in duration-150">
              <div className="flex items-center gap-2 text-xs font-black text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Select Your Profession & Trade</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  Primary Trade / Service *
                </label>
                <select
                  name="primaryTrade"
                  value={formData.primaryTrade}
                  onChange={handleChange}
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
                >
                  {TRADE_DEFINITIONS.map((trade) => (
                    <option key={trade.id} value={trade.id}>
                      {trade.icon} {trade.name}
                    </option>
                  ))}
                </select>
              </div>

              {formData.primaryTrade === 'Other' && (
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Custom Trade Name *
                  </label>
                  <input
                    type="text"
                    name="otherTradeName"
                    value={formData.otherTradeName}
                    onChange={handleChange}
                    placeholder="e.g. Solar Technician, Welder, etc."
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              )}

              {/* Additional Trade Skills */}
              {activeTradeDef && activeTradeDef.skills && activeTradeDef.skills.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    Select Your Specialized Skills (Click to toggle)
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {activeTradeDef.skills.map((skill) => {
                      const isSelected = formData.additionalSkills.includes(skill);
                      return (
                        <button
                          key={skill}
                          type="button"
                          onClick={() => handleToggleSkill(skill)}
                          className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-700 text-white border-emerald-800'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '}
                          {skill}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Experience & Preferred Radius */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Experience (Years) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="40"
                    name="experience"
                    value={formData.experience}
                    onChange={handleChange}
                    placeholder="e.g. 5"
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Preferred Service Radius *
                  </label>
                  <select
                    name="serviceRadius"
                    value={formData.serviceRadius}
                    onChange={handleChange}
                    className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="5">5 km (Immediate Neighborhood)</option>
                    <option value="10">10 km (Ward & City Area)</option>
                    <option value="20">20 km (Town & Surrounds)</option>
                    <option value="30">30 km (District Level)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  Service Location / City Area *
                </label>
                <input
                  type="text"
                  name="serviceLocation"
                  value={formData.serviceLocation}
                  onChange={handleChange}
                  placeholder="e.g. Tumakuru Town & Surrounding Wards"
                  className="w-full px-3.5 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Submit Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSuccess}
              className="px-6 py-2.5 text-xs font-black text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-md transition disabled:opacity-50 cursor-pointer"
            >
              {isSuccess ? 'Account Created!' : 'Complete Registration'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
