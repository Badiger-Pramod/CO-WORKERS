import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import {
  User,
  WorkerProfile,
  FarmerProfile,
  Service,
  Cooperative,
  JobRequest,
  Equipment,
  EquipmentBooking,
  Notification,
  Complaint,
  Review
} from '../types';

dotenv.config();

// Configuration
const connectionString = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/cowork_connect';
let pgPool: Pool | null = null;
let isUsingPostgres = false;

// Local Embedded Fallback Store File
const dataDir = path.resolve(__dirname, '../../data');
const fallbackDbPath = path.join(dataDir, 'cowork_connect.json');

export interface LocalStore {
  users: User[];
  worker_profiles: WorkerProfile[];
  farmer_profiles: FarmerProfile[];
  services: Service[];
  cooperatives: Cooperative[];
  worker_cooperative: any[];
  job_requests: JobRequest[];
  equipment: Equipment[];
  equipment_bookings: EquipmentBooking[];
  notifications: Notification[];
  complaints: Complaint[];
  reviews: Review[];
}

export let localStore: LocalStore = {
  users: [],
  worker_profiles: [],
  farmer_profiles: [],
  services: [],
  cooperatives: [],
  worker_cooperative: [],
  job_requests: [],
  equipment: [],
  equipment_bookings: [],
  notifications: [],
  complaints: [],
  reviews: []
};

// Save local store to disk
export const persistLocalStore = () => {
  try {
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(fallbackDbPath, JSON.stringify(localStore, null, 2), 'utf8');
  } catch (err) {
    console.error('[DB] Error persisting local store:', err);
  }
};

// Load local store from disk
const loadLocalStore = () => {
  try {
    if (fs.existsSync(fallbackDbPath)) {
      const content = fs.readFileSync(fallbackDbPath, 'utf8');
      const parsed = JSON.parse(content);
      localStore = {
        users: parsed.users || [],
        worker_profiles: parsed.worker_profiles || [],
        farmer_profiles: parsed.farmer_profiles || [],
        services: parsed.services || [],
        cooperatives: parsed.cooperatives || [],
        worker_cooperative: parsed.worker_cooperative || [],
        job_requests: parsed.job_requests || [],
        equipment: parsed.equipment || [],
        equipment_bookings: parsed.equipment_bookings || [],
        notifications: parsed.notifications || [],
        complaints: parsed.complaints || [],
        reviews: parsed.reviews || []
      };
      return true;
    }
  } catch (err) {
    console.error('[DB] Error loading local store, initializing fresh:', err);
  }
  return false;
};

// Seed initial data
const seedInitialData = async () => {
  const salt = await bcrypt.genSalt(10);
  const customerPasswordHash = await bcrypt.hash('Customer@123', salt);
  const workerPasswordHash = await bcrypt.hash('Worker@123', salt);
  const adminPasswordHash = await bcrypt.hash('Admin@123', salt);
  const farmerPasswordHash = await bcrypt.hash('Farmer@123', salt);

  // 1. Services
  const defaultServices: Service[] = [
    {
      id: 1,
      name: 'Plumbing',
      category: 'Home Repair',
      description: 'Pipe leaks, tap fixtures, sanitary fittings, drain hydro-jetting and water tank inspection',
      base_price: 400.0,
      icon: 'Wrench',
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      name: 'Electrical',
      category: 'Home Repair',
      description: 'Wiring, MCB switches, appliance connections, EV charger installation & lighting setup',
      base_price: 450.0,
      icon: 'Zap',
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      name: 'Carpentry',
      category: 'Woodwork',
      description: 'Furniture assembly, modular cabinets, door lock repair and custom woodworking',
      base_price: 450.0,
      icon: 'Hammer',
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      name: 'Cleaning',
      category: 'Sanitization',
      description: 'Deep house cleaning, kitchen degreasing, bathroom descaling & floor polishing',
      base_price: 350.0,
      icon: 'Sparkles',
      created_at: new Date().toISOString()
    },
    {
      id: 5,
      name: 'Painting',
      category: 'Interior & Exterior',
      description: 'Wall painting, waterproof base primer, touch-ups and texture coating',
      base_price: 500.0,
      icon: 'Paintbrush',
      created_at: new Date().toISOString()
    },
    {
      id: 6,
      name: 'Appliance Repair',
      category: 'Electronics',
      description: 'AC gas refill, refrigerator cooling repair, washing machine & microwave servicing',
      base_price: 450.0,
      icon: 'Cpu',
      created_at: new Date().toISOString()
    },
    {
      id: 7,
      name: 'Agricultural Labor',
      category: 'Farming',
      description: 'Crop harvesting, weeding, transplanting, pruning, drip setup, organic spraying',
      base_price: 450.0,
      icon: 'Leaf',
      created_at: new Date().toISOString()
    },
    {
      id: 8,
      name: 'Vehicle Repair',
      category: 'Automotive',
      description: 'Two-wheeler puncture, mobile oil change, tractor mechanic & roadside assistance',
      base_price: 300.0,
      icon: 'Car',
      created_at: new Date().toISOString()
    },
    {
      id: 9,
      name: 'Home Maintenance',
      category: 'General',
      description: 'Roof waterproofing, tile grouting, ceiling seepage fix & general handywork',
      base_price: 500.0,
      icon: 'Home',
      created_at: new Date().toISOString()
    }
  ];

  // 2. Cooperatives
  const defaultCooperatives: Cooperative[] = [
    {
      id: 1,
      name: 'Tumakuru Community Services Cooperative',
      city: 'Tumakuru',
      description: 'Registered autonomous worker-owned cooperative society empowering local technicians in Tumakuru district.',
      registration_no: '2026-KA-TMK-019',
      member_count: 342,
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      name: 'Cauvery Farmers & Agro-Artisans Cooperative',
      city: 'Tumakuru Rural',
      description: 'Farmer Producer Cooperative providing collective farm machinery, seed bank, and fair labor exchange.',
      registration_no: '2026-KA-AGR-088',
      member_count: 512,
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      name: 'Bengaluru Urban Artisans Cooperative',
      city: 'Bengaluru',
      description: 'Metropolitan chapter providing fair wages, healthcare welfare, and equipment subsidies.',
      registration_no: '2026-KA-BLR-044',
      member_count: 4120,
      created_at: new Date().toISOString()
    }
  ];

  // 3. Initial Users
  const defaultUsers: User[] = [
    // Customer
    {
      id: 1,
      full_name: 'Ananya Sharma',
      email: 'customer@coworkconnect.demo',
      mobile: '+91 98860 11928',
      password_hash: customerPasswordHash,
      role: 'CUSTOMER',
      city: 'Tumakuru',
      address: 'Flat 402, Kaveri Nilaya, Siddaganga Extension, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Worker 1: Ravi Kumar (Plumber)
    {
      id: 2,
      full_name: 'Ravi Kumar',
      email: 'worker@coworkconnect.demo',
      mobile: '+91 98451 44820',
      password_hash: workerPasswordHash,
      role: 'WORKER',
      city: 'Tumakuru',
      address: 'Near Old Bus Stand, B.H. Road, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Worker 2: Suresh M (Electrician)
    {
      id: 3,
      full_name: 'Suresh M',
      email: 'suresh@coworkconnect.demo',
      mobile: '+91 94480 32189',
      password_hash: workerPasswordHash,
      role: 'WORKER',
      city: 'Tumakuru',
      address: 'Ashok Nagar 2nd Cross, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Worker 3: Manjunath R (Carpentry & Farm Machinery)
    {
      id: 4,
      full_name: 'Manjunath R',
      email: 'manjunath@coworkconnect.demo',
      mobile: '+91 97312 88401',
      password_hash: workerPasswordHash,
      role: 'WORKER',
      city: 'Tumakuru',
      address: 'Batawadi Industrial Area, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Worker 4: Priya K (Sanitization & Cleaning)
    {
      id: 5,
      full_name: 'Priya K',
      email: 'priya@coworkconnect.demo',
      mobile: '+91 98451 90812',
      password_hash: workerPasswordHash,
      role: 'WORKER',
      city: 'Tumakuru',
      address: 'Siddaganga College Road, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Admin
    {
      id: 6,
      full_name: 'S. R. Patil',
      email: 'admin@coworkconnect.demo',
      mobile: '+91 94481 00293',
      password_hash: adminPasswordHash,
      role: 'ADMIN',
      city: 'Tumakuru',
      address: 'Cooperative Society HQ, B.H. Road, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    // Farmer: Ravi Gowda
    {
      id: 7,
      full_name: 'Ravi Gowda',
      email: 'farmer@coworkconnect.demo',
      mobile: '+91 94482 11094',
      password_hash: farmerPasswordHash,
      role: 'FARMER',
      city: 'Tumakuru Rural',
      address: 'Green Valley Farm, Survey No 42, Hebbur Hobli, Tumakuru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  ];

  // 4. Worker Profiles
  const defaultWorkerProfiles: WorkerProfile[] = [
    {
      id: 1,
      user_id: 2, // Ravi Kumar
      primary_skill: 'Plumbing',
      skills: ['Pipe Leak Repair', 'Water Tank Cleaning', 'Bathroom Fitting', 'Drain Jetting'],
      experience_years: 6,
      availability: 'Available',
      service_radius_km: 15,
      verification_status: 'Verified',
      rating: 4.8,
      completed_jobs: 247,
      hourly_rate: 400.0,
      bio: 'Master Plumber with 6 years of expertise in pipe leaks, drainage hydro-jetting, and tank maintenance. Proud co-owner of Tumakuru Cooperative.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    {
      id: 2,
      user_id: 3, // Suresh M
      primary_skill: 'Electrical',
      skills: ['Circuit Wiring', 'Inverter Setup', 'Submersible Pump Wiring', 'Solar Panel Maintenance'],
      experience_years: 8,
      availability: 'Available',
      service_radius_km: 20,
      verification_status: 'Verified',
      rating: 4.7,
      completed_jobs: 310,
      hourly_rate: 450.0,
      bio: 'Licensed electrical contractor specializing in circuit breakers, domestic wiring, agricultural pump starters, and solar inverter installations.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    {
      id: 3,
      user_id: 4, // Manjunath R
      primary_skill: 'Carpentry',
      skills: ['Modular Furniture', 'Tractor Repair', 'Door Locking Systems', 'Farm Implements'],
      experience_years: 9,
      availability: 'Available',
      service_radius_km: 25,
      verification_status: 'Verified',
      rating: 4.9,
      completed_jobs: 185,
      hourly_rate: 450.0,
      bio: 'Skilled artisan with deep experience in custom teak wood, modular furniture assembly, and agricultural machinery repairs.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    },
    {
      id: 4,
      user_id: 5, // Priya K
      primary_skill: 'Cleaning',
      skills: ['Deep Sanitization', 'Floor Polishing', 'Kitchen Degreasing', 'Green Waste Composting'],
      experience_years: 5,
      availability: 'Available',
      service_radius_km: 12,
      verification_status: 'Verified',
      rating: 4.6,
      completed_jobs: 198,
      hourly_rate: 350.0,
      bio: 'Eco-friendly deep cleaning specialist using non-toxic sanitization agents for residential apartments and commercial premises.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  ];

  // 5. Farmer Profiles
  const defaultFarmerProfiles: FarmerProfile[] = [
    {
      id: 1,
      user_id: 7, // Ravi Gowda
      farm_name: 'Green Valley Organic Farm',
      farm_size_acres: 4.5,
      crops: ['Ragi (Finger Millet)', 'Tomato', 'Paddy', 'Groundnut'],
      soil_type: 'Red Sandy Loam',
      water_source: 'Borewell & Rainwater Pond',
      irrigation_type: 'Drip & Sprinkler',
      location: 'Hebbur Hobli, Tumakuru Rural',
      verification_status: 'Verified',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  ];

  // 6. Worker Cooperative Junction
  const defaultWorkerCoop = [
    { id: 1, worker_id: 1, cooperative_id: 1, joined_at: '2023-04-10', status: 'ACTIVE', share_class: 'Class A Voting Shareholder' },
    { id: 2, worker_id: 2, cooperative_id: 1, joined_at: '2023-06-15', status: 'ACTIVE', share_class: 'Class A Voting Shareholder' },
    { id: 3, worker_id: 3, cooperative_id: 1, joined_at: '2023-08-01', status: 'ACTIVE', share_class: 'Class A Voting Shareholder' },
    { id: 4, worker_id: 4, cooperative_id: 1, joined_at: '2024-01-20', status: 'ACTIVE', share_class: 'Class A Voting Shareholder' }
  ];

  // 7. Initial Job Requests
  const defaultJobRequests: JobRequest[] = [
    {
      id: 1,
      booking_code: 'BK-2026-001',
      customer_id: 1,
      worker_id: 2, // Ravi Kumar
      service_id: 1,
      service_title: 'Emergency Kitchen Pipe Leak Repair',
      customer_name: 'Ananya Sharma',
      customer_phone: '+91 98860 11928',
      customer_address: 'Flat 402, Kaveri Nilaya, Siddaganga Extension, Tumakuru',
      city: 'Tumakuru',
      requested_date: 'Today',
      requested_time: '2:30 PM - 3:30 PM',
      estimated_price: 500.0,
      worker_payout: 400.0,
      coop_fund: 75.0,
      platform_fee: 25.0,
      status: 'ACCEPTED',
      status_history: [
        { status: 'REQUESTED', changed_at: new Date(Date.now() - 3600000).toISOString(), note: 'Customer placed service request' },
        { status: 'ACCEPTED', changed_at: new Date(Date.now() - 1800000).toISOString(), note: 'Worker accepted the job' }
      ],
      payment_status: 'PENDING',
      notes: 'Water dripping continuously under the sink basin. Need washer replacement.',
      created_at: new Date(Date.now() - 3600000).toISOString(),
      updated_at: new Date(Date.now() - 1800000).toISOString()
    },
    {
      id: 2,
      booking_code: 'BK-2026-002',
      customer_id: 7, // Ravi Gowda (Farmer needing tractor wiring)
      worker_id: 3, // Suresh M (Electrician)
      service_id: 2,
      service_title: 'Borewell Starter Panel Wiring',
      customer_name: 'Ravi Gowda',
      customer_phone: '+91 94482 11094',
      customer_address: 'Green Valley Farm, Survey No 42, Hebbur Hobli, Tumakuru',
      city: 'Tumakuru Rural',
      requested_date: 'Tomorrow',
      requested_time: '10:00 AM - 12:00 PM',
      estimated_price: 650.0,
      worker_payout: 520.0,
      coop_fund: 97.5,
      platform_fee: 32.5,
      status: 'SCHEDULED',
      status_history: [
        { status: 'REQUESTED', changed_at: new Date(Date.now() - 7200000).toISOString(), note: 'Service request created' },
        { status: 'ACCEPTED', changed_at: new Date(Date.now() - 5400000).toISOString(), note: 'Worker confirmed' },
        { status: 'SCHEDULED', changed_at: new Date(Date.now() - 3600000).toISOString(), note: 'Visit confirmed for tomorrow 10 AM' }
      ],
      payment_status: 'PENDING',
      notes: 'Three-phase automatic starter tripping after 10 minutes run time.',
      created_at: new Date(Date.now() - 7200000).toISOString(),
      updated_at: new Date(Date.now() - 3600000).toISOString()
    }
  ];

  // 8. Farm Equipment
  const defaultEquipment: Equipment[] = [
    {
      id: 1,
      owner_id: 7, // Ravi Gowda
      owner_name: 'Ravi Gowda',
      name: 'Mahindra 575 DI Tractor (45 HP)',
      type: 'Tractor',
      daily_rate: 1800,
      location: 'Hebbur Hobli, Tumakuru',
      availability: 'Available',
      operator_provided: true,
      condition: 'Excellent - Serviced recently with hydraulic cultivator attachment',
      image_url: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=800&q=80',
      rating: 4.9,
      description: 'Heavy duty diesel tractor with optional 9-tyne cultivator or rotavator attachment. Fuel efficient and ready for deep ploughing.',
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      owner_id: 7,
      owner_name: 'Ravi Gowda',
      name: 'Shaktiman Regular Light Rotavator 6ft',
      type: 'Rotavator',
      daily_rate: 950,
      location: 'Hebbur Hobli, Tumakuru',
      availability: 'Available',
      operator_provided: false,
      condition: 'Good - Boron steel blades in prime condition',
      image_url: 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=800&q=80',
      rating: 4.8,
      description: 'Ideal for secondary tillage, soil pulverization, and mixing organic compost across vegetable and ragi beds.',
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      owner_id: 7,
      owner_name: 'Ravi Gowda',
      name: 'Kirloskar 5 HP Drip Irrigation Booster Pump',
      type: 'Water Pump',
      daily_rate: 450,
      location: 'Hebbur Hobli, Tumakuru',
      availability: 'Available',
      operator_provided: false,
      condition: 'Very Good - Portable on wheel trolley',
      image_url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=800&q=80',
      rating: 4.7,
      description: 'High-pressure monobloc water pump for drip lines, sprinklers, or transferring water between ponds.',
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      owner_id: 4, // Manjunath R
      owner_name: 'Manjunath R',
      name: 'Multi-Crop Harvester Combine',
      type: 'Harvester',
      daily_rate: 3200,
      location: 'Tumakuru Rural',
      availability: 'Available',
      operator_provided: true,
      condition: 'Excellent - High speed clean grain separation',
      image_url: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=800&q=80',
      rating: 4.9,
      description: 'Full-featured tracked harvester suitable for paddy and ragi harvest with minimal grain breakage.',
      created_at: new Date().toISOString()
    }
  ];

  // 9. Initial Notifications
  const defaultNotifications: Notification[] = [
    {
      id: 1,
      user_id: 2, // Ravi Kumar
      title: 'New Service Booking',
      message: 'Ananya Sharma has requested Kitchen Pipe Leak Repair in Siddaganga Ext.',
      type: 'booking',
      is_read: false,
      link: '/worker-dashboard',
      created_at: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: 2,
      user_id: 1, // Ananya Sharma
      title: 'Booking Accepted',
      message: 'Ravi Kumar (Master Plumber) accepted your booking #BK-2026-001.',
      type: 'booking',
      is_read: false,
      link: '/customer-dashboard',
      created_at: new Date(Date.now() - 1800000).toISOString()
    },
    {
      id: 3,
      user_id: 7, // Ravi Gowda (Farmer)
      title: 'Co-op Weather Advisory',
      message: 'Light pre-monsoon showers expected over Tumakuru Rural. Check drainage before spraying.',
      type: 'system',
      is_read: false,
      link: '/farmer-dashboard',
      created_at: new Date(Date.now() - 7200000).toISOString()
    }
  ];

  // 10. Initial Complaints
  const defaultComplaints: Complaint[] = [
    {
      id: 1,
      booking_id: 1,
      user_id: 1,
      user_name: 'Ananya Sharma',
      category: 'Other',
      description: 'Requesting confirmation on estimated arrival time.',
      status: 'RESOLVED',
      resolution_note: 'Worker confirmed arrival time directly via CoWork Connect messaging.',
      created_at: new Date(Date.now() - 86400000).toISOString(),
      updated_at: new Date(Date.now() - 43200000).toISOString()
    }
  ];

  // Apply to local store
  localStore.services = defaultServices;
  localStore.cooperatives = defaultCooperatives;
  localStore.users = defaultUsers;
  localStore.worker_profiles = defaultWorkerProfiles;
  localStore.farmer_profiles = defaultFarmerProfiles;
  localStore.worker_cooperative = defaultWorkerCoop;
  localStore.job_requests = defaultJobRequests;
  localStore.equipment = defaultEquipment;
  localStore.equipment_bookings = [];
  localStore.notifications = defaultNotifications;
  localStore.complaints = defaultComplaints;
  localStore.reviews = [];

  persistLocalStore();

  // If using postgres, also seed into PostgreSQL
  if (isUsingPostgres && pgPool) {
    try {
      const userCountRes = await pgPool.query('SELECT COUNT(*) FROM users');
      if (parseInt(userCountRes.rows[0].count, 10) === 0) {
        console.log('[DB] Seeding default records into PostgreSQL...');
        for (const s of defaultServices) {
          await pgPool.query(
            'INSERT INTO services (id, name, description, category, base_price, icon) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING',
            [s.id, s.name, s.description, s.category, s.base_price, s.icon]
          );
        }
        for (const c of defaultCooperatives) {
          await pgPool.query(
            'INSERT INTO cooperatives (id, name, city, description, registration_no, member_count) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING',
            [c.id, c.name, c.city, c.description, c.registration_no, c.member_count]
          );
        }
        for (const u of defaultUsers) {
          await pgPool.query(
            'INSERT INTO users (id, full_name, email, mobile, password_hash, role, city, address) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) ON CONFLICT DO NOTHING',
            [u.id, u.full_name, u.email, u.mobile, u.password_hash, u.role, u.city, u.address]
          );
        }
        console.log('[DB] PostgreSQL seed completed successfully.');
      }
    } catch (err) {
      console.error('[DB] Error during PostgreSQL seed:', err);
    }
  }
};

// Initialize Database
export const initDatabase = async (): Promise<void> => {
  console.log('[DB] Initializing database connection...');

  // Try PostgreSQL connection
  try {
    const testPool = new Pool({
      connectionString,
      connectionTimeoutMillis: 2000
    });

    const client = await testPool.connect();
    await client.query('SELECT 1');
    client.release();

    pgPool = testPool;
    isUsingPostgres = true;
    console.log('[DB] Connected successfully to PostgreSQL at:', connectionString.replace(/:[^:@]+@/, ':****@'));
  } catch (err) {
    console.warn('[DB] PostgreSQL unavailable, activating persistent local JSON storage at:', fallbackDbPath);
    isUsingPostgres = false;
    pgPool = null;
  }

  // Load from disk or seed fresh
  const loaded = loadLocalStore();
  if (!loaded || localStore.users.length === 0) {
    console.log('[DB] Initializing default seed data...');
    await seedInitialData();
  } else {
    console.log(`[DB] Loaded ${localStore.users.length} users, ${localStore.job_requests.length} bookings, ${localStore.equipment.length} equipment from persistent store.`);
  }
};

// Database Query Wrapper
export const dbQuery = async (queryText: string, params: any[] = []): Promise<{ rows: any[]; rowCount: number }> => {
  if (isUsingPostgres && pgPool) {
    try {
      const res = await pgPool.query(queryText, params);
      return { rows: res.rows, rowCount: res.rowCount ?? 0 };
    } catch (err) {
      console.error('[DB-PG] Query failed, falling back to local store:', err);
    }
  }

  // Local Store Query Handling
  const lowerQ = queryText.toLowerCase().trim();

  // 1. SELECT queries
  if (lowerQ.startsWith('select')) {
    // USERS by email
    if (lowerQ.includes('from users') && lowerQ.includes('where email =')) {
      const email = String(params[0]).toLowerCase().trim();
      const user = localStore.users.find(
        u => u.email.toLowerCase() === email ||
             (email === 'farmer01' && u.email === 'farmer@coworkconnect.demo') ||
             (email === 'worker01' && u.email === 'worker@coworkconnect.demo') ||
             (email === 'customer01' && u.email === 'customer@coworkconnect.demo') ||
             (email === 'admin01' && u.email === 'admin@coworkconnect.demo') ||
             u.mobile === email
      );
      const rows = user ? [user] : [];
      return { rows, rowCount: rows.length };
    }

    // USERS by id
    if (lowerQ.includes('from users') && lowerQ.includes('where id =')) {
      const id = Number(params[0]);
      const user = localStore.users.find(u => u.id === id);
      const rows = user ? [user] : [];
      return { rows, rowCount: rows.length };
    }

    // ALL USERS
    if (lowerQ.includes('from users') && !lowerQ.includes('where')) {
      return { rows: localStore.users, rowCount: localStore.users.length };
    }

    // WORKER_PROFILES
    if (lowerQ.includes('from worker_profiles') && lowerQ.includes('join users')) {
      const rows = localStore.worker_profiles.map(wp => {
        const u = localStore.users.find(user => user.id === wp.user_id);
        return {
          ...wp,
          full_name: u?.full_name || 'Worker',
          email: u?.email || '',
          mobile: u?.mobile || '',
          city: u?.city || 'Tumakuru',
          address: u?.address || ''
        };
      });
      return { rows, rowCount: rows.length };
    }

    // FARMER_PROFILES
    if (lowerQ.includes('from farmer_profiles')) {
      if (lowerQ.includes('where user_id =')) {
        const uid = Number(params[0]);
        const fp = localStore.farmer_profiles.find(f => f.user_id === uid);
        return { rows: fp ? [fp] : [], rowCount: fp ? 1 : 0 };
      }
      return { rows: localStore.farmer_profiles, rowCount: localStore.farmer_profiles.length };
    }

    // SERVICES
    if (lowerQ.includes('from services')) {
      return { rows: localStore.services, rowCount: localStore.services.length };
    }

    // COOPERATIVES
    if (lowerQ.includes('from cooperatives')) {
      return { rows: localStore.cooperatives, rowCount: localStore.cooperatives.length };
    }

    // JOB_REQUESTS for worker
    if (lowerQ.includes('from job_requests') && lowerQ.includes('where worker_id =')) {
      const workerId = Number(params[0]);
      const rows = localStore.job_requests.filter(jr => jr.worker_id === workerId);
      return { rows, rowCount: rows.length };
    }

    // JOB_REQUESTS for customer
    if (lowerQ.includes('from job_requests') && lowerQ.includes('where customer_id =')) {
      const customerId = Number(params[0]);
      const rows = localStore.job_requests.filter(jr => jr.customer_id === customerId);
      return { rows, rowCount: rows.length };
    }

    // ALL JOB_REQUESTS
    if (lowerQ.includes('from job_requests')) {
      return { rows: localStore.job_requests, rowCount: localStore.job_requests.length };
    }

    // EQUIPMENT
    if (lowerQ.includes('from equipment') || lowerQ.includes('from farm_equipment')) {
      return { rows: localStore.equipment, rowCount: localStore.equipment.length };
    }

    // NOTIFICATIONS
    if (lowerQ.includes('from notifications') && lowerQ.includes('where user_id =')) {
      const uid = Number(params[0]);
      const rows = localStore.notifications.filter(n => n.user_id === uid);
      return { rows, rowCount: rows.length };
    }

    // COMPLAINTS
    if (lowerQ.includes('from complaints')) {
      return { rows: localStore.complaints, rowCount: localStore.complaints.length };
    }
  }

  // 2. INSERT queries
  if (lowerQ.startsWith('insert into users')) {
    const nextId = localStore.users.length ? Math.max(...localStore.users.map(u => u.id)) + 1 : 1;
    const newUser: User = {
      id: nextId,
      full_name: params[0],
      email: params[1],
      mobile: params[2],
      password_hash: params[3],
      role: params[4],
      city: params[5] || 'Tumakuru',
      address: params[6] || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    localStore.users.push(newUser);
    persistLocalStore();
    return { rows: [newUser], rowCount: 1 };
  }

  if (lowerQ.startsWith('insert into worker_profiles')) {
    const nextId = localStore.worker_profiles.length ? Math.max(...localStore.worker_profiles.map(w => w.id)) + 1 : 1;
    const newWp: WorkerProfile = {
      id: nextId,
      user_id: Number(params[0]),
      primary_skill: params[1],
      skills: [params[1]],
      experience_years: Number(params[2]) || 1,
      availability: params[3] || 'Available',
      verification_status: params[4] || 'Pending',
      rating: 4.8,
      completed_jobs: 0,
      hourly_rate: 400.0,
      bio: params[5] || 'Cooperative member artisan.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    localStore.worker_profiles.push(newWp);
    persistLocalStore();
    return { rows: [newWp], rowCount: 1 };
  }

  if (lowerQ.startsWith('insert into farmer_profiles')) {
    const nextId = localStore.farmer_profiles.length ? Math.max(...localStore.farmer_profiles.map(f => f.id)) + 1 : 1;
    const newFp: FarmerProfile = {
      id: nextId,
      user_id: Number(params[0]),
      farm_name: params[1] || 'My Farm',
      farm_size_acres: Number(params[2]) || 2.0,
      crops: Array.isArray(params[3]) ? params[3] : ['Ragi'],
      soil_type: params[4] || 'Loam',
      water_source: params[5] || 'Borewell',
      irrigation_type: params[6] || 'Drip',
      location: params[7] || 'Tumakuru Rural',
      verification_status: 'Verified',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    localStore.farmer_profiles.push(newFp);
    persistLocalStore();
    return { rows: [newFp], rowCount: 1 };
  }

  if (lowerQ.startsWith('insert into job_requests')) {
    const nextId = localStore.job_requests.length ? Math.max(...localStore.job_requests.map(j => j.id)) + 1 : 1;
    const newJob: JobRequest = {
      id: nextId,
      booking_code: `BK-2026-${String(nextId).padStart(3, '0')}`,
      customer_id: Number(params[0]),
      worker_id: Number(params[1]) || undefined,
      service_id: Number(params[2]) || undefined,
      service_title: params[3] || 'Service Request',
      customer_name: params[4] || 'Customer',
      customer_phone: params[5] || '',
      customer_address: params[6] || '',
      city: params[7] || 'Tumakuru',
      requested_date: params[8] || 'Today',
      requested_time: params[9] || 'Immediate',
      estimated_price: Number(params[10]) || 400,
      worker_payout: Number(params[11]) || 320,
      coop_fund: Number(params[12]) || 60,
      platform_fee: Number(params[13]) || 20,
      status: (params[14] as any) || 'REQUESTED',
      status_history: [
        { status: 'REQUESTED', changed_at: new Date().toISOString(), note: 'Booking initiated' }
      ],
      payment_status: 'PENDING',
      notes: params[15] || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    localStore.job_requests.push(newJob);
    persistLocalStore();
    return { rows: [newJob], rowCount: 1 };
  }

  // 3. UPDATE queries
  if (lowerQ.startsWith('update worker_profiles set availability')) {
    const newAvail = params[0];
    const userId = Number(params[1]);
    const wp = localStore.worker_profiles.find(w => w.user_id === userId);
    if (wp) {
      wp.availability = newAvail;
      wp.updated_at = new Date().toISOString();
      persistLocalStore();
      return { rows: [wp], rowCount: 1 };
    }
  }

  if (lowerQ.startsWith('update job_requests set status')) {
    const newStatus = params[0];
    const jobId = Number(params[1]);
    const job = localStore.job_requests.find(j => j.id === jobId);
    if (job) {
      job.status = newStatus;
      if (!job.status_history) job.status_history = [];
      job.status_history.push({
        status: newStatus,
        changed_at: new Date().toISOString(),
        note: params[2] || `Status updated to ${newStatus}`
      });
      job.updated_at = new Date().toISOString();
      persistLocalStore();
      return { rows: [job], rowCount: 1 };
    }
  }

  if (lowerQ.startsWith('update users')) {
    const fullName = params[0];
    const mobile = params[1];
    const city = params[2];
    const address = params[3];
    const userId = Number(params[4]);
    const u = localStore.users.find(user => user.id === userId);
    if (u) {
      u.full_name = fullName;
      u.mobile = mobile;
      u.city = city;
      u.address = address;
      u.updated_at = new Date().toISOString();
      persistLocalStore();
      return { rows: [u], rowCount: 1 };
    }
  }

  return { rows: [], rowCount: 0 };
};

export const getDbPool = () => pgPool;
