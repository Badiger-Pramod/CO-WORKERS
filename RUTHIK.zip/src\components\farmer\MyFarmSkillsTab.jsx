import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  GraduationCap,
  CheckCircle2,
  Award,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  BookOpen,
  PlusCircle,
  FileBadge,
  Clock,
  ExternalLink
} from 'lucide-react';

export const MyFarmSkillsTab = ({ onNavigateToMentorDirectory }) => {
  const {
    currentFarmer,
    farmerSkills = [],
    completeSkillPractice,
    verifyFarmerSkill
  } = useCoop();

  const farmer = currentFarmer || {};

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ─── Header & Journey Roadmap ─────────────────────────────── */}
      <div className="border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🏅</span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            My Agricultural Skills & Cooperative Certifications
          </h2>
        </div>
        <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
          Level up your practical agronomy skills through field practice and receive verified certifications from the Tumakuru Farmers Cooperative Guild.
        </p>
      </div>

      {/* ─── Journey Stages Visual (Section 13) ────────────────────── */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-3">
        <p className="text-xs font-black uppercase tracking-wider text-emerald-400">
          Progression Pathway: Learn → Practice → Verify → Unlock Opportunities
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-3.5 flex items-center gap-3">
            <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 font-black text-sm flex items-center justify-center">1</span>
            <div>
              <p className="text-white font-bold text-xs">Learn Theory</p>
              <p className="text-slate-400 text-[10px]">Study guild modules</p>
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-3.5 flex items-center gap-3">
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black text-sm flex items-center justify-center">2</span>
            <div>
              <p className="text-white font-bold text-xs">Field Practice</p>
              <p className="text-slate-400 text-[10px]">On-farm practical hours</p>
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-3.5 flex items-center gap-3">
            <span className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 font-black text-sm flex items-center justify-center">3</span>
            <div>
              <p className="text-white font-bold text-xs">Co-op Verify</p>
              <p className="text-slate-400 text-[10px]">Guild field inspection</p>
            </div>
          </div>

          <div className="bg-emerald-950/60 border border-emerald-800/60 rounded-2xl p-3.5 flex items-center gap-3">
            <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-black text-sm flex items-center justify-center">4</span>
            <div>
              <p className="text-emerald-300 font-bold text-xs">Certified Pro</p>
              <p className="text-emerald-400/80 text-[10px]">Higher earnings & subsidies</p>
            </div>
          </div>
        </div>
      </div>

      {/* ─── My Skills List & Progression Cards ────────────────────── */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-base flex items-center gap-2">
            🌱 Active Farm Skills ({farmerSkills.length})
          </h3>
          <button
            onClick={onNavigateToMentorDirectory}
            className="text-xs text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
          >
            <span>+ Learn New Skill</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-4">
          {farmerSkills.map((skill) => {
            const isDripDemoSkill = skill.skillName.toLowerCase().includes('drip');

            return (
              <div
                key={skill.id}
                className={`bg-slate-900 border rounded-3xl p-5 sm:p-6 space-y-4 transition ${
                  skill.verified
                    ? 'border-emerald-600/60 bg-emerald-950/20'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-purple-950 border border-purple-800 flex items-center justify-center text-2xl flex-shrink-0">
                      {skill.skillName.includes('Drip') ? '💧' : skill.skillName.includes('Organic') ? '🌿' : skill.skillName.includes('Solar') ? '☀️' : '🌱'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-white font-black text-base">{skill.skillName}</h4>
                        {skill.verified ? (
                          <span className="bg-emerald-900/80 text-emerald-300 border border-emerald-700 text-xs font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                            Cooperative Certified ✓
                          </span>
                        ) : (
                          <span className="bg-amber-900/80 text-amber-300 border border-amber-700 text-xs font-bold px-2.5 py-0.5 rounded-full">
                            {skill.verificationStatus || 'In Progress'}
                          </span>
                        )}
                      </div>
                      <p className="text-slate-400 text-xs mt-0.5">
                        Category: {skill.category} · Mentored by {skill.mentorName || 'Cooperative Agromet Expert'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-300 bg-slate-800 px-3 py-1 rounded-xl">
                      Level: <strong className="text-emerald-400">{skill.skillLevel}</strong>
                    </span>
                    <span className="text-xs font-black text-white bg-slate-800 px-3 py-1 rounded-xl">
                      {skill.progress}% Complete
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Practical Field Modules: {skill.modulesCompleted || 8} of {skill.totalModules || 10}</span>
                    <span className="font-semibold text-emerald-400">{skill.progress}% Mastery</span>
                  </div>
                  <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        skill.verified
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                          : 'bg-gradient-to-r from-purple-500 to-emerald-500'
                      }`}
                      style={{ width: `${skill.progress}%` }}
                    />
                  </div>
                </div>

                {/* Certification stamp details if verified */}
                {skill.verified && (
                  <div className="bg-emerald-950/60 border border-emerald-800/60 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 text-emerald-300 font-semibold">
                      <FileBadge className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                      <span>Certified by: <strong>{skill.certifiedBy || 'Tumakuru Farmers Cooperative Guild'}</strong> on {skill.certificationDate || 'August 2025'}</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-black uppercase tracking-wider bg-emerald-900/80 px-2 py-0.5 rounded border border-emerald-700">
                      Guild ID #KA-AGSK-8042
                    </span>
                  </div>
                )}

                {/* Interactive Action Controls (Demo Scenario Ready!) */}
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => completeSkillPractice(skill.id)}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition active:scale-95"
                    >
                      <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Log Field Practice (+10%)</span>
                    </button>

                    {!skill.verified && (
                      <button
                        onClick={() => verifyFarmerSkill(farmer.id, skill.skillName)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 transition shadow-lg shadow-emerald-600/20 active:scale-95"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>Request Co-op Verification</span>
                      </button>
                    )}
                  </div>

                  <span className="text-[11px] text-slate-500 italic">
                    {skill.verified ? '✓ Official verification completed' : 'Eligible for verification at ≥ 80%'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
