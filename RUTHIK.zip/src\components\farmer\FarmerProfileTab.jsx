import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  User,
  MapPin,
  Trees,
  Droplets,
  ShieldCheck,
  CheckCircle2,
  Save,
  Phone,
  Mail,
  Building2,
  Calendar
} from 'lucide-react';

export const FarmerProfileTab = () => {
  const { currentFarmer, updateFarmerProfile } = useCoop();
  const farmer = currentFarmer || {};

  const [fullName, setFullName] = useState(farmer.fullName || farmer.name || 'Ravi Gowda');
  const [phone, setPhone] = useState(farmer.phone || '+91 94480 12345');
  const [email, setEmail] = useState(farmer.email || 'ravi.gowda@tumakuru.farm');
  const [farmName, setFarmName] = useState(farmer.farmName || 'Green Valley Farm');
  const [location, setLocation] = useState(farmer.location || 'Tumakuru Rural');
  const [district, setDistrict] = useState(farmer.district || 'Tumakuru');
  const [farmSize, setFarmSize] = useState(farmer.farmSize || '5 Acres');
  const [landType, setLandType] = useState(farmer.landType || 'Red Sandy Loam');
  const [primaryCrop, setPrimaryCrop] = useState(farmer.primaryCrop || 'Ragi');
  const [farmingType, setFarmingType] = useState(farmer.farmingType || 'Mixed');
  const [irrigationType, setIrrigationType] = useState(farmer.irrigationType || 'Borewell & Drip');
  const [isEditing, setIsEditing] = useState(false);

  const handleSaveProfile = (e) => {
    e.preventDefault();
    updateFarmerProfile({
      fullName,
      name: fullName.split(' ')[0],
      phone,
      email,
      farmName,
      location,
      district,
      farmSize,
      landType,
      primaryCrop,
      farmingType,
      irrigationType
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      {/* ─── Header ──────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">👨‍🌾</span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Farmer & Agricultural Land Profile
            </h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Manage your cooperative land holding credentials, irrigation infrastructure, and registered crops.
          </p>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className={`px-4 py-2 rounded-xl font-bold text-xs transition ${
            isEditing
              ? 'bg-slate-800 text-slate-300'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
        >
          {isEditing ? 'Cancel Edit' : 'Edit Farm Details'}
        </button>
      </div>

      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* ─── 1. Personal & Contact Details ───────────────────────── */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4">
          <h3 className="text-white font-bold text-sm uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <User className="w-4 h-4" /> Personal Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Full Legal Name</label>
              <input
                type="text"
                disabled={!isEditing}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Mobile Number</label>
              <input
                type="text"
                disabled={!isEditing}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Email Address</label>
              <input
                type="email"
                disabled={!isEditing}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>
          </div>
        </div>

        {/* ─── 2. Farm Land & Soil Details ─────────────────────────── */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4">
          <h3 className="text-white font-bold text-sm uppercase tracking-wider text-teal-400 flex items-center gap-2">
            <Trees className="w-4 h-4" /> Farm Land & Geographic Details
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Farm / Land Name</label>
              <input
                type="text"
                disabled={!isEditing}
                value={farmName}
                onChange={(e) => setFarmName(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Village / Location</label>
              <input
                type="text"
                disabled={!isEditing}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">District</label>
              <input
                type="text"
                disabled={!isEditing}
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Total Farm Size</label>
              <input
                type="text"
                disabled={!isEditing}
                value={farmSize}
                onChange={(e) => setFarmSize(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Soil / Land Type</label>
              <input
                type="text"
                disabled={!isEditing}
                value={landType}
                onChange={(e) => setLandType(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>
          </div>
        </div>

        {/* ─── 3. Agricultural Crops & Irrigation ──────────────────── */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4">
          <h3 className="text-white font-bold text-sm uppercase tracking-wider text-amber-400 flex items-center gap-2">
            <Droplets className="w-4 h-4" /> Farming Practices & Irrigation Source
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Primary Crop</label>
              <input
                type="text"
                disabled={!isEditing}
                value={primaryCrop}
                onChange={(e) => setPrimaryCrop(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Farming Type</label>
              <select
                disabled={!isEditing}
                value={farmingType}
                onChange={(e) => setFarmingType(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              >
                <option value="Conventional">Conventional</option>
                <option value="Organic">Organic</option>
                <option value="Mixed">Mixed Organic & Traditional</option>
                <option value="Natural Farming (ZBNF)">Natural Farming (ZBNF)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Irrigation Method</label>
              <select
                disabled={!isEditing}
                value={irrigationType}
                onChange={(e) => setIrrigationType(e.target.value)}
                className="w-full bg-slate-800 disabled:opacity-80 border border-slate-700 text-white rounded-xl px-3 py-2"
              >
                <option value="Borewell & Drip">Borewell & Drip</option>
                <option value="Sprinkler">Sprinkler</option>
                <option value="Canal / Flood">Canal / Surface Flow</option>
                <option value="Rain-fed">Rain-fed</option>
              </select>
            </div>
          </div>
        </div>

        {/* ─── 4. Cooperative Governance & Verification ────────────── */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4">
          <h3 className="text-white font-bold text-sm uppercase tracking-wider text-purple-400 flex items-center gap-2">
            <Building2 className="w-4 h-4" /> Cooperative Membership
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Society Name</span>
              <span className="text-white font-bold text-sm mt-0.5 block">
                {farmer.cooperativeName || 'Tumakuru Farmers Cooperative Society'}
              </span>
            </div>

            <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Member Identification</span>
              <span className="text-emerald-400 font-bold text-sm mt-0.5 block">
                {farmer.cooperativeMembership || '#KA-TMK-AGRI-402'}
              </span>
            </div>

            <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Verification Status</span>
              <span className="text-emerald-300 font-bold text-sm mt-0.5 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Verified Class-F Shareholder
              </span>
            </div>
          </div>
        </div>

        {isEditing && (
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Changes</span>
            </button>
          </div>
        )}
      </form>
    </div>
  );
};
