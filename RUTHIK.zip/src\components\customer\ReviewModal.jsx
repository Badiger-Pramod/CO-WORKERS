import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Star,
  ShieldCheck,
  CheckCircle2,
  X,
  Sparkles,
  Heart
} from 'lucide-react';

export const ReviewModal = () => {
  const {
    isReviewModalOpen,
    setIsReviewModalOpen,
    reviewBooking,
    submitReview
  } = useCoop();

  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('Excellent service and complete honesty. So glad to know the worker gets 85% instead of corporate commission!');
  const [selectedTags, setSelectedTags] = useState(['Punctual', 'Transparent Billing', 'Expert Work']);

  if (!isReviewModalOpen || !reviewBooking) return null;

  const availableTags = [
    'Punctual',
    'Transparent Billing',
    'Expert Work',
    'Polite & Respectful',
    'Safety Conscious',
    'Fair Co-op Pricing'
  ];

  const toggleTag = (tag) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(prev => prev.filter(t => t !== tag));
    } else {
      setSelectedTags(prev => [...prev, tag]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    submitReview({
      bookingId: reviewBooking.id,
      workerId: reviewBooking.workerId,
      rating,
      comment,
      tags: selectedTags
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-indigo-900 text-white p-6 flex justify-between items-start">
          <div className="flex items-center gap-3">
            <img
              src={reviewBooking.workerAvatar}
              alt={reviewBooking.workerName}
              className="w-12 h-12 rounded-full object-cover border-2 border-emerald-300"
            />
            <div>
              <h3 className="text-lg font-bold">Rate Co-owner Service</h3>
              <p className="text-xs text-emerald-200">{reviewBooking.workerName} • {reviewBooking.serviceTitle}</p>
            </div>
          </div>
          <button
            onClick={() => setIsReviewModalOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Star Rating */}
          <div className="text-center space-y-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Your Honest Quality Rating:
            </span>
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => {
                const filled = (hoverRating || rating) >= star;
                return (
                  <button
                    type="button"
                    key={star}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => setRating(star)}
                    className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none"
                  >
                    <Star
                      className={`w-7 h-7 ${
                        filled ? 'fill-amber-400 text-amber-500' : 'text-slate-300'
                      }`}
                    />
                  </button>
                );
              })}
            </div>
            <span className="text-xs font-bold text-slate-700">
              {rating === 5 ? '5.0 - Exceptional Co-owner Quality' : `${rating}.0 Stars`}
            </span>
          </div>

          {/* Feedback Tags */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Praise & Badges:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {availableTags.map((tag) => {
                const active = selectedTags.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-all ${
                      active
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {active ? `✓ ${tag}` : `+ ${tag}`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Written Feedback */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Customer Testimonial:
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows="3"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="Share your experience with the neighborhood..."
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1.5 transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            Publish Verified Review
          </button>

        </form>

      </div>
    </div>
  );
};
