import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  X,
  Star,
  ShieldCheck,
  CheckCircle2,
  Heart,
  Award,
  ArrowRight
} from 'lucide-react';

export const RatingModal = () => {
  const {
    isRatingModalOpen,
    setIsRatingModalOpen,
    activeBookingId,
    bookings,
    submitRatingReview
  } = useCoop();

  const [selectedRating, setSelectedRating] = useState(5);
  const [comment, setComment] = useState('Ravi was on time, diagnosed the pipe leak cleanly, and followed transparent co-op pricing. Excellent service!');
  const [selectedTags, setSelectedTags] = useState(['Punctual', 'Honest Pricing', 'Co-op Pride']);

  if (!isRatingModalOpen) return null;

  const booking = bookings.find(b => b.id === activeBookingId) || bookings[0];
  const workerName = booking ? booking.workerName : 'Ravi Kumar';
  const workerAvatar = booking ? booking.workerAvatar : 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=150&auto=format&fit=crop&q=80';
  const workerId = booking ? booking.workerId : 'w-ravi';

  const tagsList = [
    'Punctual',
    'Clean Work',
    'Polite & Respectful',
    'Honest Pricing',
    'Co-op Pride',
    'Skill Expert',
    'Safety First'
  ];

  const toggleTag = (tag) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(prev => prev.filter(t => t !== tag));
    } else {
      setSelectedTags(prev => [...prev, tag]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    submitRatingReview({
      workerId,
      rating: selectedRating,
      comment,
      tags: selectedTags
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 p-6 flex justify-between items-start">
          <div className="flex items-center gap-3">
            <img
              src={workerAvatar}
              alt={workerName}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-md"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-lg font-black text-slate-950">{workerName}</h3>
                <ShieldCheck className="w-4 h-4 text-slate-900" />
              </div>
              <p className="text-xs font-semibold text-amber-950">Plumbing Specialist • Co-owner</p>
              <p className="text-[11px] text-amber-900 mt-0.5">Booking #{booking?.id}</p>
            </div>
          </div>
          <button
            onClick={() => setIsRatingModalOpen(false)}
            className="text-slate-900/80 hover:text-slate-950 p-1 rounded-lg hover:bg-black/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Star Selector */}
          <div className="text-center space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
              Rate Service Quality & Professionalism
            </label>
            <div className="flex items-center justify-center gap-2 pt-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setSelectedRating(star)}
                  className="p-1 hover:scale-110 transition-transform focus:outline-none"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= selectedRating
                        ? 'fill-amber-400 text-amber-500'
                        : 'text-slate-200 fill-slate-100'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs font-bold text-slate-700">
              {selectedRating === 5 && '⭐⭐⭐⭐⭐ Exceptional Co-op Service!'}
              {selectedRating === 4 && '⭐⭐⭐⭐ Very Good Work'}
              {selectedRating === 3 && '⭐⭐⭐ Average Service'}
              {selectedRating <= 2 && 'Needs Improvement'}
            </p>
          </div>

          {/* Compliment Tags */}
          <div className="space-y-2">
            <span className="block text-xs font-bold text-slate-600">What went well?</span>
            <div className="flex flex-wrap gap-1.5">
              {tagsList.map((tag) => {
                const isSelected = selectedTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-amber-100 text-amber-900 border border-amber-300 font-bold'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-transparent'
                    }`}
                  >
                    {isSelected && '✓ '}
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Written Feedback Textarea */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-600">
              Share your experience with the cooperative community:
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows="3"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="Write genuine feedback..."
              required
            />
          </div>

          {/* Co-owner Reputation Notice */}
          <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs text-emerald-800 flex items-start gap-2">
            <Award className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              Your review boosts Ravi's democratic dividend eligibility score and guarantees quality across the Tumakuru cooperative network.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsRatingModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Skip
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-xs font-black shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all transform active:scale-95"
            >
              <span>Submit 5-Star Review</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
