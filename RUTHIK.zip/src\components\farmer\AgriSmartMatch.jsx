import React, { useState, useEffect } from 'react';
import { Sparkles, ChevronDown, CheckCircle2, Loader2 } from 'lucide-react';
import { AgriWorkerCard } from './AgriWorkerCard';
import { calculateAgriSmartMatch } from '../../utils/voiceSeva';
import { AGRI_WORKERS } from '../../data/agriMockData';

export const AgriSmartMatch = ({ serviceCategory, farmerLang = 'en', onWorkerSelected, onClose, isLowConnectivity = false }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [matchedWorkers, setMatchedWorkers] = useState([]);
  const [selectedWorker, setSelectedWorker] = useState(null);
  const [isConfirming, setIsConfirming] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    // Simulate SmartMatch processing time
    const timer = setTimeout(() => {
      const results = calculateAgriSmartMatch(AGRI_WORKERS, serviceCategory, farmerLang);
      setMatchedWorkers(results);
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, [serviceCategory, farmerLang]);

  const handleSelectWorker = (worker) => {
    if (!worker.available) return;
    setSelectedWorker(worker);
  };

  const handleConfirm = () => {
    if (!selectedWorker) return;
    setIsConfirming(true);
    setTimeout(() => {
      setIsConfirming(false);
      setIsConfirmed(true);
      setTimeout(() => {
        onWorkerSelected?.(selectedWorker, serviceCategory);
      }, 1000);
    }, 1500);
  };

  return (
    <div className="bg-slate-900 rounded-3xl border border-emerald-800/50 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 px-5 py-4 flex items-center justify-between border-b border-emerald-800/40">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-white font-black text-sm">SmartMatch AI</h3>
            <p className="text-emerald-400 text-xs">Finding best workers for: <strong>{serviceCategory}</strong></p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="text-slate-400 hover:text-white text-lg font-bold">✕</button>
        )}
      </div>

      <div className="p-4 space-y-4">
        {/* Scoring legend */}
        <div className="flex flex-wrap gap-2 text-[10px] text-slate-400">
          <span className="bg-slate-800 px-2 py-0.5 rounded">Skill match 35%</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded">Distance 25%</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded">Availability 20%</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded">Rating 10%</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded">Experience 10%</span>
        </div>

        {/* Loading state */}
        {isLoading && (
          <div className="flex flex-col items-center gap-3 py-8">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
            <p className="text-slate-300 text-sm font-medium">Analysing nearby service providers…</p>
            <p className="text-slate-500 text-xs">Checking skill match · distance · availability · rating</p>
          </div>
        )}

        {/* Results */}
        {!isLoading && (
          <div className="space-y-3">
            <p className="text-slate-400 text-xs font-semibold">
              Found {matchedWorkers.filter(w => w.available).length} available providers — ranked by match score
            </p>

            {matchedWorkers.map((worker, idx) => (
              <div key={worker.id} className="relative">
                {idx === 0 && (
                  <div className="absolute -top-2 left-4 z-10 bg-amber-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full">
                    🏆 Top Match
                  </div>
                )}
                <AgriWorkerCard
                  worker={worker}
                  onSelect={handleSelectWorker}
                  isSelected={selectedWorker?.id === worker.id}
                  showMatchScore
                  isLowConnectivity={isLowConnectivity}
                />
              </div>
            ))}
          </div>
        )}

        {/* Confirm CTA */}
        {selectedWorker && !isConfirmed && (
          <button
            onClick={handleConfirm}
            disabled={isConfirming}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white font-black rounded-2xl transition flex items-center justify-center gap-2 text-sm"
          >
            {isConfirming
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending Request…</>
              : <>✅ Confirm: {selectedWorker.name} for {serviceCategory}</>
            }
          </button>
        )}

        {/* Confirmed */}
        {isConfirmed && (
          <div className="flex items-center gap-3 bg-emerald-900 border border-emerald-700 rounded-2xl px-4 py-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="text-emerald-200 font-black text-sm">Request Sent!</p>
              <p className="text-emerald-400 text-xs">{selectedWorker.name} has been notified for {serviceCategory}.</p>
            </div>
          </div>
        )}

        <p className="text-center text-[10px] text-slate-500">
          📌 SmartMatch AI calculates real-time compatibility using verified skills, distance, and availability.
        </p>
      </div>
    </div>
  );
};
