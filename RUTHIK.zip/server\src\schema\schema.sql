-- =============================================================================
-- CoWork Connect & CoWork Agri (SIH26089) — PostgreSQL Database Schema DDL
-- Problem: Cooperative Gig Services Platform for Household, Community & Agriculture
-- =============================================================================

-- Drop existing tables if needed (in reverse dependency order)
DROP TABLE IF EXISTS farmer_skills CASCADE;
DROP TABLE IF EXISTS farm_service_requests CASCADE;
DROP TABLE IF EXISTS farm_equipment CASCADE;
DROP TABLE IF EXISTS farmers CASCADE;
DROP TABLE IF EXISTS worker_cooperative CASCADE;
DROP TABLE IF EXISTS job_requests CASCADE;
DROP TABLE IF EXISTS worker_profiles CASCADE;
DROP TABLE IF EXISTS services CASCADE;
DROP TABLE IF EXISTS cooperatives CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. Users Table (Customer | Worker | Admin | Farmer)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('CUSTOMER', 'WORKER', 'ADMIN', 'FARMER')),
    city VARCHAR(100) NOT NULL DEFAULT 'Tumakuru',
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Worker Profiles Table
CREATE TABLE worker_profiles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    primary_skill VARCHAR(100) NOT NULL,
    experience_years INTEGER NOT NULL DEFAULT 1,
    availability VARCHAR(20) NOT NULL DEFAULT 'Available' CHECK (availability IN ('Available', 'Not Available')),
    verification_status VARCHAR(30) NOT NULL DEFAULT 'Pending' CHECK (verification_status IN ('Pending', 'Verified', 'Rejected')),
    rating NUMERIC(3, 2) NOT NULL DEFAULT 4.50,
    completed_jobs INTEGER NOT NULL DEFAULT 0,
    hourly_rate NUMERIC(10, 2) NOT NULL DEFAULT 400.00,
    bio TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Services Table
CREATE TABLE services (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    icon VARCHAR(50) NOT NULL DEFAULT 'Wrench',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Cooperatives Table
CREATE TABLE cooperatives (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    city VARCHAR(100) NOT NULL,
    description TEXT,
    registration_no VARCHAR(100) DEFAULT '2026-KA-TMK-019',
    member_count INTEGER DEFAULT 342,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Worker Cooperative Junction Table
CREATE TABLE worker_cooperative (
    id SERIAL PRIMARY KEY,
    worker_id INTEGER NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
    cooperative_id INTEGER NOT NULL REFERENCES cooperatives(id) ON DELETE CASCADE,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'PENDING', 'SUSPENDED')),
    share_class VARCHAR(50) DEFAULT 'Class A Voting Shareholder'
);

-- 6. Job Requests / Bookings Table (Customer - Worker Household Services)
CREATE TABLE job_requests (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    worker_id INTEGER REFERENCES worker_profiles(id) ON DELETE SET NULL,
    service_id INTEGER REFERENCES services(id) ON DELETE SET NULL,
    service_title VARCHAR(150) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    customer_address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL DEFAULT 'Tumakuru',
    requested_date VARCHAR(50) NOT NULL DEFAULT 'Today',
    requested_time VARCHAR(50) NOT NULL DEFAULT '2:30 PM - 4:00 PM',
    estimated_price NUMERIC(10, 2) NOT NULL DEFAULT 500.00,
    worker_payout NUMERIC(10, 2) NOT NULL DEFAULT 400.00,
    coop_fund NUMERIC(10, 2) NOT NULL DEFAULT 75.00,
    platform_fee NUMERIC(10, 2) NOT NULL DEFAULT 25.00,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED', 'ON_THE_WAY', 'JOB_STARTED', 'COMPLETED')),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =============================================================================
-- CoWork Agri Module Tables (Section 25 DDL Specifications)
-- =============================================================================

-- 7. Farmers Profile Table
CREATE TABLE farmers (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    farm_name VARCHAR(150) NOT NULL,
    village VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL DEFAULT 'Tumakuru',
    state VARCHAR(100) NOT NULL DEFAULT 'Karnataka',
    farm_size_acres NUMERIC(6, 2) NOT NULL DEFAULT 5.0,
    land_type VARCHAR(100) NOT NULL DEFAULT 'Red Sandy Loam',
    primary_crop VARCHAR(100) NOT NULL DEFAULT 'Ragi',
    farming_type VARCHAR(50) NOT NULL DEFAULT 'Mixed' CHECK (farming_type IN ('Conventional', 'Organic', 'Mixed', 'Natural Farming (ZBNF)')),
    irrigation_type VARCHAR(100) NOT NULL DEFAULT 'Borewell & Drip',
    cooperative_id INTEGER REFERENCES cooperatives(id) ON DELETE SET NULL,
    cooperative_member_id VARCHAR(100) DEFAULT '#KA-TMK-AGRI-402',
    verification_status VARCHAR(30) NOT NULL DEFAULT 'Verified' CHECK (verification_status IN ('Pending', 'Verified', 'Rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Farm Equipment Table (For Equipment Sharing & Custom Hiring Centres)
CREATE TABLE farm_equipment (
    id SERIAL PRIMARY KEY,
    owner_farmer_id INTEGER REFERENCES farmers(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    equipment_type VARCHAR(100) NOT NULL, -- 'Tractor', 'Rotavator', 'Harvester', 'Water Pump', etc.
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    rental_price_per_day NUMERIC(10, 2) NOT NULL DEFAULT 1000.00,
    hourly_price NUMERIC(10, 2),
    operator_available BOOLEAN NOT NULL DEFAULT FALSE,
    operator_price_per_day NUMERIC(10, 2) DEFAULT 400.00,
    location VARCHAR(150) NOT NULL,
    availability_status VARCHAR(30) NOT NULL DEFAULT 'Available' CHECK (availability_status IN ('Available', 'In Use', 'Maintenance')),
    verification_status VARCHAR(30) NOT NULL DEFAULT 'Verified' CHECK (verification_status IN ('Pending', 'Verified', 'Rejected')),
    description TEXT,
    suitable_for TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Farm Service Requests & Equipment Bookings Table
CREATE TABLE farm_service_requests (
    id SERIAL PRIMARY KEY,
    farmer_id INTEGER NOT NULL REFERENCES farmers(id) ON DELETE CASCADE,
    booking_type VARCHAR(30) NOT NULL CHECK (booking_type IN ('Worker', 'Equipment', 'Combined', 'Service')),
    title VARCHAR(150) NOT NULL,
    equipment_id INTEGER REFERENCES farm_equipment(id) ON DELETE SET NULL,
    worker_id INTEGER REFERENCES worker_profiles(id) ON DELETE SET NULL,
    operator_included BOOLEAN NOT NULL DEFAULT FALSE,
    work_type VARCHAR(100) NOT NULL,
    crop VARCHAR(100) NOT NULL DEFAULT 'Ragi',
    requested_date VARCHAR(50) NOT NULL,
    duration VARCHAR(50) NOT NULL DEFAULT '1 Day',
    location VARCHAR(150) NOT NULL,
    estimated_cost NUMERIC(10, 2) NOT NULL,
    final_cost NUMERIC(10, 2) NOT NULL,
    payment_status VARCHAR(30) NOT NULL DEFAULT 'Pending' CHECK (payment_status IN ('Pending', 'Escrow', 'Paid')),
    payment_method VARCHAR(100) DEFAULT 'UPI (Co-op Escrow)',
    status VARCHAR(30) NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Requested', 'Accepted', 'Scheduled', 'In Use', 'Completed', 'Cancelled')),
    review_rating NUMERIC(2, 1),
    review_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Farmer Skills & Guild Certifications Table (Peer Barter & Progression)
CREATE TABLE farmer_skills (
    id SERIAL PRIMARY KEY,
    farmer_id INTEGER NOT NULL REFERENCES farmers(id) ON DELETE CASCADE,
    skill_name VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    skill_level VARCHAR(30) NOT NULL DEFAULT 'Beginner' CHECK (skill_level IN ('Beginner', 'Intermediate', 'Advanced', 'Expert')),
    progress_percent INTEGER NOT NULL DEFAULT 40 CHECK (progress_percent BETWEEN 0 AND 100),
    modules_completed INTEGER NOT NULL DEFAULT 4,
    total_modules INTEGER NOT NULL DEFAULT 10,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    verification_status VARCHAR(30) NOT NULL DEFAULT 'In Training' CHECK (verification_status IN ('In Training', 'Ready for Verification', 'Verified')),
    certified_by VARCHAR(150),
    certified_at TIMESTAMP WITH TIME ZONE,
    mentor_name VARCHAR(150),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 11. Crop Posts Table (Show My Crop & Crop Community Feed)
CREATE TABLE crop_posts (
    id SERIAL PRIMARY KEY,
    farmer_id VARCHAR(50) NOT NULL,
    farmer_name VARCHAR(150) NOT NULL,
    crop_name VARCHAR(100) NOT NULL,
    farm_id VARCHAR(50),
    farm_name VARCHAR(150),
    image_url TEXT NOT NULL,
    description TEXT,
    location VARCHAR(150),
    date VARCHAR(50),
    visibility VARCHAR(50) NOT NULL DEFAULT 'My Cooperative' CHECK (visibility IN ('Only Me', 'My Cooperative', 'Other Farmers', 'People I Share With')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 12. Crop Comments Table (Farmer-to-Farmer Help & Experience Sharing)
CREATE TABLE crop_comments (
    id SERIAL PRIMARY KEY,
    crop_post_id INTEGER NOT NULL REFERENCES crop_posts(id) ON DELETE CASCADE,
    user_id VARCHAR(50) NOT NULL,
    user_name VARCHAR(150) NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 13. Crop Media Table (High Resolution Photos & Video Recordings)
CREATE TABLE crop_media (
    id SERIAL PRIMARY KEY,
    crop_post_id INTEGER NOT NULL REFERENCES crop_posts(id) ON DELETE CASCADE,
    media_type VARCHAR(50) NOT NULL DEFAULT 'image' CHECK (media_type IN ('image', 'video')),
    media_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create Indexes for Performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_worker_profiles_skill ON worker_profiles(primary_skill);
CREATE INDEX idx_worker_profiles_avail ON worker_profiles(availability);
CREATE INDEX idx_job_requests_worker ON job_requests(worker_id);
CREATE INDEX idx_job_requests_customer ON job_requests(customer_id);

-- Indexes for CoWork Agri
CREATE INDEX idx_farmers_user ON farmers(user_id);
CREATE INDEX idx_farmers_crop ON farmers(primary_crop);
CREATE INDEX idx_farm_equipment_type ON farm_equipment(equipment_type);
CREATE INDEX idx_farm_equipment_avail ON farm_equipment(availability_status);
CREATE INDEX idx_farm_service_requests_farmer ON farm_service_requests(farmer_id);
CREATE INDEX idx_farm_service_requests_status ON farm_service_requests(status);
CREATE INDEX idx_farmer_skills_farmer ON farmer_skills(farmer_id);
CREATE INDEX idx_crop_posts_farmer ON crop_posts(farmer_id);
CREATE INDEX idx_crop_posts_crop ON crop_posts(crop_name);
CREATE INDEX idx_crop_comments_post ON crop_comments(crop_post_id);
CREATE INDEX idx_crop_media_post ON crop_media(crop_post_id);
