import React from 'react';
import { Mic, Sparkles, Users, ArrowRight } from 'lucide-react';

const FEATURES = [
  {
    icon: '🎙️',
    title: 'Speak → Get Help',
    desc: 'Speak in Kannada, Hindi, Telugu, Tamil or any supported language. Voice Seva understands you.',
    color: 'emerald',
  },
  {
    icon: '🌾',
    title: 'Agriculture Experts',
    desc: 'Verified crop inspectors, pest control specialists, soil testers and farm workers — all cooperative members.',
    color: 'lime',
  },
  {
    icon: '🤝',
    title: 'Cooperative Network',
    desc: 'Workers are owners. 8-10% cooperative fee. 100% transparent earnings. Fair pay guaranteed.',
    color: 'teal',
  },
];

export const AgriLandingSection = ({ onOpenFarmerDashboard }) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 border-y border-emerald-900/40 py-16 sm:py-20 px-4">

      {/* Subtle grid background */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:28px_28px]" />

      <div className="relative max-w-5xl mx-auto">

        {/* Tag */}
        <div className="flex justify-center mb-6">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black tracking-wide">
            🌾 Agriculture Voice Seva · New Feature
          </span>
        </div>

        {/* Heading */}
        <h2 className="text-3xl sm:text-5xl font-black text-white text-center leading-tight max-w-3xl mx-auto">
          Technology that{' '}
          <span className="text-emerald-400">speaks your language.</span>
        </h2>

        {/* Subtitle */}
        <p className="mt-5 text-slate-300 text-center text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
          Helping farmers and rural communities access trusted local services through{' '}
          <strong className="text-emerald-400">voice</strong>,{' '}
          <strong className="text-emerald-400">AI</strong> and{' '}
          <strong className="text-emerald-400">cooperative networks</strong>.
        </p>

        {/* CTAs */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
          <button
            onClick={onOpenFarmerDashboard}
            className="flex items-center gap-2 px-7 py-4 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/20 transition-all"
          >
            <Mic className="w-4 h-4" />
            Try Voice Seva
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenFarmerDashboard}
            className="flex items-center gap-2 px-7 py-4 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-sm rounded-2xl backdrop-blur-md transition-all"
          >
            👨‍🌾 Farmer Dashboard
          </button>
        </div>

        {/* Voice language chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
          <span className="text-slate-400 text-xs font-semibold">Speaks:</span>
          {['ಕನ್ನಡ', 'हिन्दी', 'తెలుగు', 'தமிழ்', 'मराठी', 'বাংলা', 'English'].map(lang => (
            <span key={lang} className="bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs font-bold px-2.5 py-1 rounded-full">
              {lang}
            </span>
          ))}
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mt-12">
          {FEATURES.map(feat => (
            <div
              key={feat.title}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:border-emerald-500/40 transition"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-900/60 flex items-center justify-center text-2xl mb-4">
                {feat.icon}
              </div>
              <h3 className="text-white font-black text-base">{feat.title}</h3>
              <p className="text-slate-400 text-sm mt-2 leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </div>

        {/* Demo flow illustration */}
        <div className="mt-12 bg-white/5 border border-white/10 rounded-2xl px-6 py-5">
          <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">How Voice Seva works</p>
          <div className="flex flex-wrap items-center gap-2 justify-center text-sm">
            {[
              { icon: '🌾', text: 'Farmer speaks' },
              '→',
              { icon: '🎙️', text: 'Voice Seva listens' },
              '→',
              { icon: '🤖', text: 'Intent detected' },
              '→',
              { icon: '✅', text: 'Response in your language' },
              '→',
              { icon: '👨‍🌾', text: 'Worker matched' },
            ].map((step, i) =>
              step === '→'
                ? <span key={i} className="text-emerald-600 font-black text-base">→</span>
                : (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <span className="text-2xl">{step.icon}</span>
                    <span className="text-slate-300 text-xs font-semibold text-center">{step.text}</span>
                  </div>
                )
            )}
          </div>
        </div>

        <p className="text-center text-slate-500 text-xs mt-8">
          🎤 Voice Seva enables multilingual voice commands in Kannada, Hindi, and English with audio feedback.
        </p>
      </div>
    </section>
  );
};
