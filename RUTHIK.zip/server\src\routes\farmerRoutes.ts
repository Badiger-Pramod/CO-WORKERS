import { Router } from 'express';
import {
  getFarmerProfile,
  updateFarmerProfile,
  addCrop
} from '../controllers/farmerController';

const router = Router();

router.get('/:id', getFarmerProfile);
router.put('/:id', updateFarmerProfile);
router.post('/:id/crops', addCrop);

export default router;
