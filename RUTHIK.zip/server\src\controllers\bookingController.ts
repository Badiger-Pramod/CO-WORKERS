import { Request, Response } from 'express';
import { localStore, persistLocalStore, dbQuery } from '../config/db';
import { JobRequest, BookingStatus, Notification } from '../types';
import { broadcastEvent } from '../services/socketService';

// Status transition validator
const VALID_TRANSITIONS: Record<BookingStatus, BookingStatus[]> = {
  REQUESTED: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['SCHEDULED', 'ON_THE_WAY', 'CANCELLED'],
  SCHEDULED: ['ON_THE_WAY', 'CANCELLED'],
  ON_THE_WAY: ['WORK_STARTED', 'CANCELLED'],
  WORK_STARTED: ['COMPLETED'],
  COMPLETED: ['PAID'],
  PAID: ['RATED'],
  RATED: [],
  CANCELLED: []
};

// GET /api/bookings
export const getBookings = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, role, status } = req.query;

    let bookings = [...localStore.job_requests];

    if (userId) {
      const uid = Number(userId);
      if (role === 'WORKER') {
        bookings = bookings.filter(b => b.worker_id === uid);
      } else if (role === 'CUSTOMER' || role === 'FARMER') {
        bookings = bookings.filter(b => b.customer_id === uid);
      } else {
        bookings = bookings.filter(b => b.customer_id === uid || b.worker_id === uid);
      }
    }

    if (status) {
      bookings = bookings.filter(b => b.status === status);
    }

    // Sort descending by created_at
    bookings.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

    res.json({ success: true, count: bookings.length, bookings });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch bookings.' });
  }
};

// GET /api/bookings/:id
export const getBookingById = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const booking = localStore.job_requests.find(b => b.id === id);
    if (!booking) {
      res.status(404).json({ success: false, message: 'Booking not found.' });
      return;
    }
    res.json({ success: true, booking });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Error retrieving booking.' });
  }
};

// POST /api/bookings
export const createBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      customer_id,
      worker_id,
      service_id,
      service_title,
      customer_name,
      customer_phone,
      customer_address,
      city = 'Tumakuru',
      requested_date = 'Today',
      requested_time = 'Immediate',
      estimated_price = 500,
      notes = ''
    } = req.body;

    if (!customer_id || !service_title) {
      res.status(400).json({ success: false, message: 'Customer ID and service title are required.' });
      return;
    }

    const price = Number(estimated_price) || 500;
    // 80% to Worker, 15% to Cooperative Fund, 5% Platform Maintenance
    const worker_payout = Math.round(price * 0.8);
    const coop_fund = Math.round(price * 0.15);
    const platform_fee = price - worker_payout - coop_fund;

    const nextId = localStore.job_requests.length
      ? Math.max(...localStore.job_requests.map(j => j.id)) + 1
      : 1;

    const newBooking: JobRequest = {
      id: nextId,
      booking_code: `BK-2026-${String(nextId).padStart(3, '0')}`,
      customer_id: Number(customer_id),
      worker_id: worker_id ? Number(worker_id) : undefined,
      service_id: service_id ? Number(service_id) : undefined,
      service_title,
      customer_name: customer_name || 'Customer',
      customer_phone: customer_phone || '',
      customer_address: customer_address || '',
      city,
      requested_date,
      requested_time,
      estimated_price: price,
      worker_payout,
      coop_fund,
      platform_fee,
      status: 'REQUESTED',
      status_history: [
        {
          status: 'REQUESTED',
          changed_at: new Date().toISOString(),
          note: `Booking created by ${customer_name || 'Customer'}`
        }
      ],
      payment_status: 'PENDING',
      notes,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    localStore.job_requests.unshift(newBooking);

    // Notify assigned worker or pool
    if (newBooking.worker_id) {
      const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
      const workerNotif: Notification = {
        id: notifId,
        user_id: newBooking.worker_id,
        title: 'New Service Booking Request',
        message: `${newBooking.customer_name} requested ${newBooking.service_title} (₹${newBooking.worker_payout} earnings).`,
        type: 'booking',
        is_read: false,
        link: '/worker-dashboard',
        created_at: new Date().toISOString()
      };
      localStore.notifications.unshift(workerNotif);

      // Realtime emit to worker room
      broadcastEvent(`user_${newBooking.worker_id}`, 'new_booking', newBooking);
      broadcastEvent(`user_${newBooking.worker_id}`, 'new_notification', workerNotif);
    } else {
      // Broadcast to workers role
      broadcastEvent('role_WORKER', 'new_pool_booking', newBooking);
    }

    persistLocalStore();

    res.status(201).json({
      success: true,
      message: 'Booking requested successfully!',
      booking: newBooking
    });
  } catch (err: any) {
    console.error('[Bookings] Create error:', err);
    res.status(500).json({ success: false, message: 'Booking creation failed.' });
  }
};

// PUT /api/bookings/:id/status
export const updateBookingStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const { status, note, worker_id } = req.body;

    const booking = localStore.job_requests.find(b => b.id === id);
    if (!booking) {
      res.status(404).json({ success: false, message: 'Booking not found.' });
      return;
    }

    const currentStatus = booking.status;
    const targetStatus = status as BookingStatus;

    // Validate state transition
    const allowed = VALID_TRANSITIONS[currentStatus] || [];
    if (!allowed.includes(targetStatus) && currentStatus !== targetStatus) {
      res.status(400).json({
        success: false,
        message: `Invalid status transition from '${currentStatus}' to '${targetStatus}'. Allowed: ${allowed.join(', ')}`
      });
      return;
    }

    booking.status = targetStatus;
    if (worker_id && !booking.worker_id) {
      booking.worker_id = Number(worker_id);
    }

    if (!booking.status_history) {
      booking.status_history = [];
    }

    const timestamp = new Date().toISOString();
    booking.status_history.push({
      status: targetStatus,
      changed_at: timestamp,
      note: note || `Status updated to ${targetStatus}`
    });
    booking.updated_at = timestamp;

    // If completed, update worker statistics
    if (targetStatus === 'COMPLETED' && booking.worker_id) {
      const wp = localStore.worker_profiles.find(w => w.user_id === booking.worker_id);
      if (wp) {
        wp.completed_jobs = (wp.completed_jobs || 0) + 1;
        wp.updated_at = timestamp;
      }
    }

    // Create notification for customer
    const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
    const statusTitles: Record<string, string> = {
      ACCEPTED: 'Booking Accepted! 🛠️',
      SCHEDULED: 'Booking Scheduled 📅',
      ON_THE_WAY: 'Worker is On The Way! 🛵',
      WORK_STARTED: 'Work Started ⚡',
      COMPLETED: 'Job Completed! Please review & pay ✅',
      PAID: 'Payment Received! 💳',
      RATED: 'Rating Submitted ⭐'
    };

    const notif: Notification = {
      id: notifId,
      user_id: booking.customer_id,
      title: statusTitles[targetStatus] || `Booking Update: ${targetStatus}`,
      message: `${booking.service_title} is now: ${targetStatus}.`,
      type: 'booking',
      is_read: false,
      link: '/customer-dashboard',
      created_at: timestamp
    };
    localStore.notifications.unshift(notif);

    persistLocalStore();

    // Broadcast real-time updates to customer and worker
    broadcastEvent(`user_${booking.customer_id}`, 'booking_status_updated', {
      bookingId: booking.id,
      status: targetStatus,
      booking
    });
    broadcastEvent(`user_${booking.customer_id}`, 'new_notification', notif);

    if (booking.worker_id) {
      broadcastEvent(`user_${booking.worker_id}`, 'booking_status_updated', {
        bookingId: booking.id,
        status: targetStatus,
        booking
      });
    }

    res.json({
      success: true,
      message: `Booking status updated to ${targetStatus}`,
      booking
    });
  } catch (err: any) {
    console.error('[Bookings] Update status error:', err);
    res.status(500).json({ success: false, message: 'Status update failed.' });
  }
};

// POST /api/bookings/:id/pay
export const processPayment = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const { payment_method = 'UPI (Razorpay/GPay)', amount } = req.body;

    const booking = localStore.job_requests.find(b => b.id === id);
    if (!booking) {
      res.status(404).json({ success: false, message: 'Booking not found.' });
      return;
    }

    // Verify payment amount matches
    const paymentAmount = Number(amount) || booking.estimated_price;
    const txId = `TXN_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;

    booking.payment_status = 'SUCCESS';
    booking.payment_id = txId;
    booking.payment_method = payment_method;
    booking.payment_amount = paymentAmount;
    booking.status = 'PAID';
    booking.updated_at = new Date().toISOString();

    if (!booking.status_history) booking.status_history = [];
    booking.status_history.push({
      status: 'PAID',
      changed_at: new Date().toISOString(),
      note: `Payment of ₹${paymentAmount} verified via ${payment_method}. Tx: ${txId}`
    });

    // Notify worker of payment
    if (booking.worker_id) {
      const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
      const workerNotif: Notification = {
        id: notifId,
        user_id: booking.worker_id,
        title: 'Payment Credited to Wallet',
        message: `₹${booking.worker_payout} credited for ${booking.service_title}. (Txn: ${txId})`,
        type: 'payment',
        is_read: false,
        link: '/worker-dashboard',
        created_at: new Date().toISOString()
      };
      localStore.notifications.unshift(workerNotif);
      broadcastEvent(`user_${booking.worker_id}`, 'new_notification', workerNotif);
      broadcastEvent(`user_${booking.worker_id}`, 'payment_received', { bookingId: booking.id, amount: booking.worker_payout });
    }

    persistLocalStore();

    broadcastEvent(`user_${booking.customer_id}`, 'booking_status_updated', {
      bookingId: booking.id,
      status: 'PAID',
      booking
    });

    res.json({
      success: true,
      message: 'Payment verified and processed successfully!',
      transactionId: txId,
      booking
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Payment verification failed.' });
  }
};

// POST /api/bookings/:id/rate
export const rateBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const { rating, review = '', reviewer_id, reviewer_name } = req.body;

    const booking = localStore.job_requests.find(b => b.id === id);
    if (!booking) {
      res.status(404).json({ success: false, message: 'Booking not found.' });
      return;
    }

    if (booking.rating) {
      res.status(400).json({ success: false, message: 'This booking has already been rated.' });
      return;
    }

    const numRating = Math.min(5, Math.max(1, Number(rating) || 5));
    booking.rating = numRating;
    booking.review = review;
    booking.status = 'RATED';
    booking.updated_at = new Date().toISOString();

    // Recalculate Worker Rating
    if (booking.worker_id) {
      const wp = localStore.worker_profiles.find(w => w.user_id === booking.worker_id);
      if (wp) {
        // Find all rated bookings for this worker
        const ratedJobs = localStore.job_requests.filter(j => j.worker_id === booking.worker_id && j.rating);
        const totalScore = ratedJobs.reduce((sum, j) => sum + (j.rating || 5), 0);
        wp.rating = Number((totalScore / ratedJobs.length).toFixed(1));
      }
    }

    // Add to reviews table
    const revId = localStore.reviews.length ? Math.max(...localStore.reviews.map(r => r.id)) + 1 : 1;
    localStore.reviews.push({
      id: revId,
      booking_id: booking.id,
      reviewer_id: Number(reviewer_id) || booking.customer_id,
      reviewer_name: reviewer_name || booking.customer_name,
      reviewee_id: booking.worker_id || 0,
      reviewee_name: booking.service_title,
      rating: numRating,
      review_text: review,
      created_at: new Date().toISOString()
    });

    persistLocalStore();

    res.json({
      success: true,
      message: 'Thank you for your rating!',
      booking
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Rating submission failed.' });
  }
};
