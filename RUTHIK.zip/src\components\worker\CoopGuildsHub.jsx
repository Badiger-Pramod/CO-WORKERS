import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Users,
  Zap,
  Sparkles,
  HeartHandshake,
  Wrench,
  Calendar,
  Layers,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Award
} from 'lucide-react';

export const CoopGuildsHub = () => {
  const { guilds, toolBank, reserveTool, showToast } = useCoop();

  const guildIcons = {
    electrical: Zap,
    cleaning: Sparkles,
    caregiving: HeartHandshake,
    plumbing: Wrench
  };

  const handleClaimWelfare = () => {
    showToast(`Mutual aid healthcare reimbursement claim submitted for Guild review!`, 'success');
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Guilds Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              ICA Principle 6: Cooperation Among Co-operatives
            </span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-1">
            Democratic Trade Guilds & Group Management
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Self-governing professional working circles that organize bulk tool procurement, safety training, and peer assistance.
          </p>
        </div>

        <button
          onClick={handleClaimWelfare}
          className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-md shadow-teal-600/20 flex items-center gap-1.5"
        >
          <HeartHandshake className="w-4 h-4" />
          File Welfare Claim
        </button>
      </div>

      {/* Trade Guilds Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {guilds.map((guild) => {
          const Icon = guildIcons[guild.trade] || Users;
          return (
            <div
              key={guild.id}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{guild.name}</h4>
                    <p className="text-xs text-slate-500">Lead: {guild.lead}</p>
                  </div>
                </div>
                <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full">
                  {guild.membersCount} Members
                </span>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Assembly: <strong>{guild.meetingSchedule}</strong></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Guild Mutual Aid Fund: <strong>₹{guild.mutualAidBalance.toLocaleString()}</strong></span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Active Member Initiatives:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {guild.activeProjects.map((proj, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md font-medium"
                    >
                      • {proj}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Shared Tool Bank Section */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                Cooperative Tool Bank
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-1">Shared Heavy Equipment & Rig Rentals</h3>
            <p className="text-xs text-slate-500">
              Expensive diagnostic & industrial tools purchased with co-op surplus and rented to members at 70% discount.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {toolBank.map((tool) => (
            <div
              key={tool.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between space-y-3"
            >
              <div>
                <div className="flex justify-between items-start gap-2">
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">{tool.name}</h4>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      tool.status === 'AVAILABLE'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {tool.status === 'AVAILABLE' ? 'Available' : `In Use (${tool.reservedBy})`}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">{tool.category} • Location: {tool.currentLocation}</p>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-200 text-xs">
                <div>
                  <span className="line-through text-slate-400 text-[11px]">Commercial: ₹{tool.marketRentalDay}/day</span>
                  <p className="font-bold text-emerald-700">Co-op Member: ₹{tool.coopMemberPriceDay}/day</p>
                </div>

                <button
                  disabled={tool.status !== 'AVAILABLE'}
                  onClick={() => reserveTool(tool.id, 'Rajesh Kumar')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    tool.status === 'AVAILABLE'
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {tool.status === 'AVAILABLE' ? 'Reserve Equipment' : 'Occupied'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
