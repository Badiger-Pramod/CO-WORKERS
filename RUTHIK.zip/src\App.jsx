import React, { useState, useEffect } from 'react';
import { CoopProvider, useCoop, INITIAL_DEMO_WORKERS, DEMO_CUSTOMERS } from './context/CoopContext';
import { DEMO_FARMER } from './data/agriMockData';
import { HomePage } from './components/HomePage';
import { CustomerDashboard } from './components/customer/CustomerDashboard';
import { WorkerDashboard } from './components/worker/WorkerDashboard';
import { AdminPortal } from './components/admin/AdminPortal';
import { FarmerDashboard } from './components/farmer/FarmerDashboard';
import { CoWorkAIAssistant } from './components/common/CoWorkAIAssistant';
import { Toast } from './components/common/Toast';
import { InnovationModal } from './components/common/InnovationModal';
import { SocialImpactModal } from './components/common/SocialImpactModal';
import { LanguageSelector } from './components/common/LanguageSelector';
import {
  User,
  Wrench,
  Globe,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Bell,
  LogOut,
  Calendar,
  Layers
} from 'lucide-react';

const MainRouter = () => {
  const {
    currentView,
    setCurrentView,
    currentUser,
    setCurrentUser,
    isInnovationModalOpen,
    setIsInnovationModalOpen,
    isImpactModalOpen,
    setIsImpactModalOpen,
    notifications,
    showToast,
    t
  } = useCoop();

  const [isNotifOpen, setIsNotifOpen] = useState(false);

  // URL route sync
  const [currentPath, setCurrentPath] = useState(() => {
    const path = window.location.pathname;
    if (path.includes('customer-dashboard')) return 'customer-dashboard';
    if (path.includes('worker-dashboard')) return 'worker-dashboard';
    if (path.includes('admin-portal')) return 'admin-portal';
    if (path.includes('farmer-dashboard')) return 'farmer-dashboard';
    return 'home';
  });

  // Handle browser back / forward
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path.includes('customer-dashboard')) {
        setCurrentPath('customer-dashboard');
        setCurrentView('customer');
      } else if (path.includes('worker-dashboard')) {
        setCurrentPath('worker-dashboard');
        setCurrentView('worker');
      } else if (path.includes('admin-portal')) {
        setCurrentPath('admin-portal');
        setCurrentView('admin');
      } else if (path.includes('farmer-dashboard')) {
        setCurrentPath('farmer-dashboard');
        setCurrentView('farmer');
      } else {
        setCurrentPath('home');
        setCurrentView('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [setCurrentView]);

  // Navigate helper
  const navigateTo = (path, targetUser = null) => {
    if (path === 'customer-dashboard') {
      window.history.pushState({}, '', '/customer-dashboard');
      setCurrentPath('customer-dashboard');
      setCurrentView('customer');
      if (targetUser || !currentUser || currentUser.role !== 'Customer') {
        const user = targetUser && targetUser.role === 'Customer'
          ? targetUser
          : DEMO_CUSTOMERS[0];
        setCurrentUser(user);
        localStorage.setItem('cowork_active_session', JSON.stringify(user));
      }
    } else if (path === 'worker-dashboard') {
      window.history.pushState({}, '', '/worker-dashboard');
      setCurrentPath('worker-dashboard');
      setCurrentView('worker');
      const defaultWorker = INITIAL_DEMO_WORKERS.find(w => w.loginId === 'worker01') || INITIAL_DEMO_WORKERS[0];
      const user = targetUser && targetUser.role === 'Worker'
        ? targetUser
        : (currentUser && currentUser.role === 'Worker' ? currentUser : defaultWorker);
      setCurrentUser(user);
      localStorage.setItem('cowork_active_session', JSON.stringify(user));
    } else if (path === 'admin-portal') {
      window.history.pushState({}, '', '/admin-portal');
      setCurrentPath('admin-portal');
      setCurrentView('admin');
      const adminUser = {
        role: 'Admin',
        loginId: 'admin01',
        fullName: 'S. R. Patil',
        title: 'Registrar & Board Trustee'
      };
      setCurrentUser(adminUser);
      localStorage.setItem('cowork_active_session', JSON.stringify(adminUser));
    } else if (path === 'farmer-dashboard') {
      window.history.pushState({}, '', '/farmer-dashboard');
      setCurrentPath('farmer-dashboard');
      setCurrentView('farmer');
      const user = targetUser && targetUser.role === 'Farmer'
        ? targetUser
        : (currentUser && currentUser.role === 'Farmer' ? currentUser : DEMO_FARMER);
      setCurrentUser(user);
      localStorage.setItem('cowork_active_session', JSON.stringify(user));
    } else {
      window.history.pushState({}, '', '/');
      setCurrentPath('home');
      setCurrentView('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Login handler
  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    localStorage.setItem('cowork_active_session', JSON.stringify(user));
    if (user.role === 'Customer') {
      navigateTo('customer-dashboard', user);
    } else if (user.role === 'Admin') {
      navigateTo('admin-portal');
    } else if (user.role === 'Farmer') {
      navigateTo('farmer-dashboard', user);
    } else {
      navigateTo('worker-dashboard', user);
    }
  };

  // Logout handler
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('cowork_active_session');
    localStorage.removeItem('cowork_auth_token');
    showToast('Signed out successfully.', 'info');
    navigateTo('home');
  };

  const unreadNotifs = notifications?.filter(n => !n.read) || [];

  return (
    <div className="min-h-screen flex flex-col antialiased bg-slate-50">
      {/* Production Product Navigation Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-slate-200 text-xs py-2.5 px-4 sticky top-0 z-50 shadow-2xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          
          {/* Logo & Platform Tag */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => navigateTo('home')}
              className="font-black text-slate-900 text-sm tracking-tight flex items-center gap-1.5 cursor-pointer bg-transparent border-none p-0 select-none group"
            >
              <span className="text-base group-hover:scale-110 transition-transform">🇮🇳</span>
              <span className="text-base font-extrabold text-slate-900 tracking-tight">CoWork Connect</span>
            </button>
            <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full hidden sm:inline-flex">
              District Cooperative Platform
            </span>
          </div>

          {/* Primary Navigation Tabs */}
          <nav className="flex items-center gap-1 text-xs font-semibold text-slate-600">
            <button
              onClick={() => navigateTo('home')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                currentPath === 'home'
                  ? 'bg-emerald-800 text-white'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {t('home')}
            </button>

            <button
              onClick={() => navigateTo('customer-dashboard')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                currentPath === 'customer-dashboard'
                  ? 'bg-emerald-800 text-white'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{t('customer', 'Services')}</span>
            </button>

            <button
              onClick={() => navigateTo('worker-dashboard')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                currentPath === 'worker-dashboard'
                  ? 'bg-emerald-800 text-white'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>{t('worker', 'Workers')}</span>
            </button>

            <button
              onClick={() => navigateTo('farmer-dashboard')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                currentPath === 'farmer-dashboard'
                  ? 'bg-emerald-800 text-white'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="text-sm">🌾</span>
              <span>{t('farmer', 'CoWork Agri')}</span>
            </button>

            <button
              onClick={() => navigateTo('admin-portal')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                currentPath === 'admin-portal'
                  ? 'bg-emerald-800 text-white'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t('admin', 'Admin')}</span>
            </button>
          </nav>

          {/* Right Action Controls: Info, Realtime Notifications, Language, Profile */}
          <div className="flex items-center gap-2">
            {/* About Co-op Innovation Modal Trigger */}
            <button
              onClick={() => setIsInnovationModalOpen(true)}
              className="px-2 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md text-xs font-medium transition hidden md:flex items-center gap-1 cursor-pointer"
              title="Platform Innovation"
            >
              <Sparkles className="w-3 h-3 text-emerald-600" />
              <span>{t('whyDifferent', 'Why CoWork')}</span>
            </button>

            {/* Social Impact Modal Trigger */}
            <button
              onClick={() => setIsImpactModalOpen(true)}
              className="px-2 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md text-xs font-medium transition hidden lg:flex items-center gap-1 cursor-pointer"
              title="Social Impact"
            >
              <TrendingUp className="w-3 h-3 text-emerald-600" />
              <span>{t('socialImpact', 'Impact')}</span>
            </button>

            {/* Real-time Notifications Bell Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="relative p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer"
                title="Notifications"
                aria-label="Toggle notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifs.length > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-emerald-600 text-white font-extrabold text-[9px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                    {unreadNotifs.length}
                  </span>
                )}
              </button>

              {/* Notifications Popup */}
              {isNotifOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 p-3 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                    <span className="font-extrabold text-xs text-slate-900">
                      Notifications ({notifications?.length || 0})
                    </span>
                    <button
                      onClick={() => {
                        setIsNotifOpen(false);
                        showToast('Notifications reviewed.', 'info');
                      }}
                      className="text-[10px] text-emerald-700 font-semibold hover:underline cursor-pointer bg-transparent border-none p-0"
                    >
                      Close ✕
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-1.5">
                    {!notifications || notifications.length === 0 ? (
                      <p className="text-center py-5 text-xs text-slate-400">No new notifications</p>
                    ) : (
                      notifications.slice(0, 8).map((n) => (
                        <div
                          key={n.id}
                          className={`p-2.5 rounded-xl border text-left transition ${
                            n.read ? 'bg-slate-50/70 border-slate-100 text-slate-500' : 'bg-emerald-50/60 border-emerald-200 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <p className="font-bold text-xs">{n.title}</p>
                            <span className="text-[9px] text-slate-400">{n.time || 'Recent'}</span>
                          </div>
                          <p className="text-[11px] mt-0.5 leading-snug">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Language Selector (8 Indian Languages) */}
            <div className="border-l border-slate-200 pl-1.5">
              <LanguageSelector />
            </div>

            {/* Dynamic Authenticated User Badge / Sign In */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 ml-1 pl-2 border-l border-slate-200">
                <div className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  <span className="max-w-[120px] truncate">
                    {currentUser.fullName || currentUser.name || 'User'}
                  </span>
                  <span className="text-[10px] text-slate-500 font-normal">
                    ({currentUser.role})
                  </span>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition cursor-pointer text-xs flex items-center"
                  title="Sign Out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigateTo('home')}
                className="ml-1 px-3 py-1 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
              >
                {t('login', 'Sign In')}
              </button>
            )}
          </div>

        </div>
      </header>

      {/* Main View Render */}
      <main className="flex-1 flex flex-col">
        {currentPath === 'customer-dashboard' && (
          <CustomerDashboard onLogout={handleLogout} />
        )}

        {currentPath === 'worker-dashboard' && (
          <WorkerDashboard onLogout={handleLogout} />
        )}

        {currentPath === 'admin-portal' && (
          <div className="bg-slate-50 min-h-screen">
            <AdminPortal />
          </div>
        )}

        {currentPath === 'farmer-dashboard' && (
          <FarmerDashboard onLogout={handleLogout} />
        )}

        {currentPath === 'home' && (
          <HomePage
            onLoginSuccess={handleLoginSuccess}
            onNavigateToFarmer={() => navigateTo('farmer-dashboard')}
          />
        )}
      </main>

      {/* Innovation Statement Modal */}
      <InnovationModal
        isOpen={isInnovationModalOpen}
        onClose={() => setIsInnovationModalOpen(false)}
      />

      {/* Social Impact Modal */}
      <SocialImpactModal
        isOpen={isImpactModalOpen}
        onClose={() => setIsImpactModalOpen(false)}
      />

      {/* Platform-Wide Floating AI Assistant */}
      <CoWorkAIAssistant onNavigate={(route) => navigateTo(route)} />

      {/* Global Notifications Toast */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <CoopProvider>
      <MainRouter />
    </CoopProvider>
  );
}
