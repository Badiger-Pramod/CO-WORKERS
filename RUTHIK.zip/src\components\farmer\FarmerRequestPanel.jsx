import React from 'react';
import { CheckCircle2, Clock, Calendar, MapPin, Star, PhoneCall, AlertCircle } from 'lucide-react';

const STATUS_CONFIG = {
  Pending:   { color: 'amber',  icon: Clock,         label: 'Pending' },
  Scheduled: { color: 'blue',   icon: Calendar,      label: 'Scheduled' },
  Accepted:  { color: 'emerald',icon: CheckCircle2,  label: 'Accepted' },
  Completed: { color: 'green',  icon: CheckCircle2,  label: 'Completed' },
  Cancelled: { color: 'red',    icon: AlertCircle,   label: 'Cancelled' },
};

export const FarmerRequestPanel = ({ requests = [], isLowConnectivity = false }) => {
  if (requests.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 py-12 text-center">
        <span className="text-5xl">📋</span>
        <p className="text-slate-300 font-semibold">No requests yet</p>
        <p className="text-slate-500 text-sm">Use Voice Seva to create your first service request.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-white font-black text-base flex items-center gap-2">
        📋 My Requests
        <span className="bg-emerald-700 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">{requests.length}</span>
      </h3>

      {requests.map((req) => {
        const cfg = STATUS_CONFIG[req.status] || STATUS_CONFIG['Pending'];
        const Icon = cfg.icon;

        return (
          <div
            key={req.id}
            className={`rounded-2xl border bg-slate-800/70 border-slate-700 overflow-hidden ${isLowConnectivity ? 'p-5' : 'p-4'}`}
          >
            {/* Status bar */}
            <div className={`flex items-center justify-between mb-3`}>
              <span className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full
                bg-${cfg.color}-900 text-${cfg.color}-300 border border-${cfg.color}-700`}>
                <Icon className="w-3 h-3" />
                {cfg.label}
              </span>
              <span className="text-slate-500 text-xs">#{req.id}</span>
            </div>

            {/* Service type */}
            <p className={`text-white font-black ${isLowConnectivity ? 'text-lg' : 'text-sm'}`}>
              {req.serviceCategory}
            </p>

            {/* Worker */}
            <p className="text-emerald-400 text-xs font-semibold mt-0.5">
              Worker: {req.workerName}
            </p>

            {/* Notes */}
            {req.notes && (
              <p className="text-slate-400 text-xs mt-1 italic">"{req.notes}"</p>
            )}

            {/* Meta */}
            <div className="flex flex-wrap gap-3 mt-3 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {req.scheduledDate} · {req.scheduledTime}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3" /> {req.location}
              </span>
              <span className="text-white font-bold">₹{req.amount}</span>
            </div>

            {/* Rating (if completed) */}
            {req.status === 'Completed' && req.rating && (
              <div className="flex items-center gap-1 mt-2">
                {Array.from({ length: 5 }, (_, i) => (
                  <Star key={i} className={`w-3.5 h-3.5 ${i < req.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`} />
                ))}
                <span className="text-slate-400 text-xs ml-1">Your rating</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
