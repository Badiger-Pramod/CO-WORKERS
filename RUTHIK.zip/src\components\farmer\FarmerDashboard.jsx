import React, { useState, useEffect } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Globe,
  Wifi,
  WifiOff,
  LogOut,
  Bell,
  Sparkles,
  ShieldCheck,
  Mic,
  LayoutDashboard,
  Users,
  Tractor,
  Wrench,
  GraduationCap,
  Calendar,
  Building2,
  User,
  X,
  CheckCircle2,
  ChevronRight,
  ChevronDown,
  MessageSquare,
  Camera
} from 'lucide-react';
import { LANGUAGES } from '../../data/translations';
import { VoiceSeva } from './VoiceSeva';
import { LowConnectivityMode } from './LowConnectivityMode';
import { FarmerOverviewTab } from './FarmerOverviewTab';
import { FindWorkersTab } from './FindWorkersTab';
import { EquipmentSharingTab } from './EquipmentSharingTab';
import { MyEquipmentTab } from './MyEquipmentTab';
import { FarmServicesTab } from './FarmServicesTab';
import { SkillExchangeTab } from './SkillExchangeTab';
import { MyFarmSkillsTab } from './MyFarmSkillsTab';
import { FarmerBookingsTab } from './FarmerBookingsTab';
import { FarmerCooperativeTab } from './FarmerCooperativeTab';
import { FarmerProfileTab } from './FarmerProfileTab';
import { FarmerDemoWalkthrough } from './FarmerDemoWalkthrough';
import { CropCommunityTab } from './CropCommunityTab';
import { CropCameraModal } from './CropCameraModal';

const supportedLangs = LANGUAGES.filter((l) =>
  ['en', 'kn', 'hi', 'te', 'ta', 'mr', 'bn'].includes(l.code)
);

export const FarmerDashboard = ({ onLogout }) => {
  const {
    currentFarmer,
    farmerActiveTab = 'overview',
    setFarmerActiveTab,
    farmerBookings = [],
    notifications = [],
    selectedLanguage = 'en',
    setSelectedLanguage,
    currentLanguage = 'en',
    setLanguage,
    t
  } = useCoop();

  const farmer = currentFarmer || {};
  const activeLang = currentLanguage || selectedLanguage || 'en';

  const [activeTab, setActiveTab] = useState(farmerActiveTab || 'overview');
  const [equipmentSubTab, setEquipmentSubTab] = useState('find');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isLowConnectivity, setIsLowConnectivity] = useState(false);
  const [showVoiceSevaModal, setShowVoiceSevaModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showDemoWalkthrough, setShowDemoWalkthrough] = useState(false);
  const [showCropCameraModal, setShowCropCameraModal] = useState(false);

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    if (setFarmerActiveTab) {
      setFarmerActiveTab(tabId);
    }
  };

  const handleNavigateToListEquipment = () => {
    setEquipmentSubTab('list');
    handleTabChange('equipment');
  };

  // Farmer-specific notifications
  const farmerNotifications = notifications.filter(
    (n) => n.forRole === 'Farmer' || n.forUserId === farmer.id || !n.forRole
  );

  // Low Connectivity Mode View
  if (isLowConnectivity) {
    return (
      <div className="relative min-h-screen bg-slate-950">
        <button
          onClick={() => setIsLowConnectivity(false)}
          className="absolute top-4 right-4 z-50 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-full font-bold border border-slate-700 shadow"
        >
          Normal Mode ✕
        </button>
        <LowConnectivityMode
          isOnline={isOnline}
          farmerName={farmer.fullName || farmer.name || farmer.loginId || t('farmer')}
          onSpeakTap={() => {
            setIsLowConnectivity(false);
            setShowVoiceSevaModal(true);
          }}
          onCallHelp={() => alert('📞 Cooperative Kisan Helpline: 1800-425-1555 (Tumakuru Support)')}
        />
      </div>
    );
  }

  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  // Minimal Primary Navigation (Section 9)
  const PRIMARY_NAV = [
    { id: 'overview', label: 'Home', icon: LayoutDashboard },
    { id: 'workers', label: 'Find Workers', icon: Users },
    { id: 'crops', label: 'Show Crop', icon: Camera },
    { id: 'community', label: 'Community', icon: MessageSquare },
    { id: 'bookings', label: 'Bookings', icon: Calendar, badge: farmerBookings.length },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  // Secondary items placed under "More"
  const MORE_NAV = [
    { id: 'equipment', label: t('farmer.equipment', 'Equipment Sharing'), icon: Tractor },
    { id: 'my-equipment', label: t('farmer.myEquipment', 'My Equipment'), icon: Wrench },
    { id: 'services', label: t('farmer.farmServices', 'Farm Services'), icon: Sparkles },
    { id: 'skills', label: t('farmer.skillExchange', 'Skill Exchange'), icon: GraduationCap },
    { id: 'my-skills', label: t('farmer.myFarmSkills', 'My Farm Skills'), icon: ShieldCheck },
    { id: 'cooperative', label: t('farmer.cooperative', 'Cooperative'), icon: Building2 }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {/* ─── Top Header (Minimalist Banner) ────────────────── */}
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3.5 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 flex-wrap">
          {/* Left: CoWork Agri & Farmer Snapshot */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800 text-white flex items-center justify-center text-xl shadow-xs flex-shrink-0">
              🌾
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-slate-900 font-bold text-sm sm:text-base">CoWork Agri</span>
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-700" />
                  {t('farmer.verifiedMember', 'Verified Member')}
                </span>
              </div>
              <p className="text-slate-500 text-xs mt-0.5">
                <strong className="text-slate-700 font-semibold">{farmer.fullName || farmer.name || farmer.loginId || t('farmer')}</strong> · {farmer.farmName || 'Green Valley Farm'} ({farmer.location || 'Tumakuru'}, {farmer.primaryCrop || 'Ragi'}, {farmer.farmSize || '5 Acres'})
              </p>
            </div>
          </div>

          {/* Right: Controls & Shortcuts */}
          <div className="flex items-center gap-2 ml-auto flex-wrap">
            {/* Show My Crop (Major Action) */}
            <button
              onClick={() => setShowCropCameraModal(true)}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              title={t('showMyCrop', 'Show My Crop')}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{t('showMyCrop', '📷 Show My Crop')}</span>
            </button>

            {/* Voice Seva Trigger */}
            <button
              onClick={() => setShowVoiceSevaModal(true)}
              className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              title="Open Voice Seva rural assistant"
            >
              <Mic className="w-3.5 h-3.5 text-emerald-700" />
              <span className="hidden md:inline">Voice Seva</span>
            </button>

            {/* Demo Walkthrough Shortcut */}
            <button
              onClick={() => setShowDemoWalkthrough(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
              title="Launch Demo Walkthrough"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Demo</span>
            </button>

            {/* Low Connectivity Toggle */}
            <button
              onClick={() => setIsLowConnectivity(!isLowConnectivity)}
              title="Toggle Low Connectivity / 2G Mode"
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                isOnline
                  ? 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
                  : 'bg-red-50 text-red-700 border-red-200'
              }`}
            >
              {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-600" /> : <WifiOff className="w-3.5 h-3.5 text-red-500" />}
              <span className="hidden lg:inline">{isOnline ? 'Online' : 'Offline'}</span>
            </button>

            {/* Notifications Bell */}
            <button
              onClick={() => setShowNotificationsModal(true)}
              className="relative p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 transition cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {farmerNotifications.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                  {farmerNotifications.length}
                </span>
              )}
            </button>

            {/* Logout */}
            <button
              onClick={onLogout}
              className="p-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-500 hover:text-red-600 transition cursor-pointer"
              title="Logout from CoWork Agri"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* ─── Minimalist Sub-Navigation Tabs Bar (Section 9) ───────── */}
      <nav className="bg-white border-b border-slate-200 px-4 sm:px-6 sticky top-[61px] z-30">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 py-2">
          {/* Primary Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
            {PRIMARY_NAV.map((tab) => {
              const Icon = tab.icon;
              const isActive = (activeTab === tab.id) || (tab.id === 'community' && activeTab === 'crops');

              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (tab.id === 'community') handleTabChange('crops');
                    else handleTabChange(tab.id);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        isActive ? 'bg-white text-emerald-800' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* More Options Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMoreMenuOpen(!moreMenuOpen)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                MORE_NAV.some(item => item.id === activeTab)
                  ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                  : 'border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span>More</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {moreMenuOpen && (
              <div className="absolute right-0 mt-1 w-52 bg-white border border-slate-200 rounded-xl shadow-lg p-1.5 z-50 space-y-1">
                {MORE_NAV.map((item) => {
                  const Icon = item.icon;
                  const isItemActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        handleTabChange(item.id);
                        setMoreMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition text-left cursor-pointer ${
                        isItemActive
                          ? 'bg-emerald-50 text-emerald-800 font-semibold'
                          : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-slate-500" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* ─── Main Content Container ───────────────────────────────── */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 overflow-y-auto">
        {activeTab === 'overview' && (
          <FarmerOverviewTab
            onNavigateTab={handleTabChange}
            onOpenShowCrop={() => setShowCropCameraModal(true)}
            onRunDemo={() => setShowDemoWalkthrough(true)}
          />
        )}

        {activeTab === 'crops' && (
          <CropCommunityTab
            onOpenShowCrop={() => setShowCropCameraModal(true)}
            onNavigateToSkills={() => handleTabChange('skills')}
          />
        )}

        {activeTab === 'workers' && (
          <FindWorkersTab
            onBookingCreated={() => handleTabChange('bookings')}
          />
        )}

        {activeTab === 'equipment' && (
          <EquipmentSharingTab
            initialSubTab={equipmentSubTab}
            onBookingCreated={() => handleTabChange('bookings')}
          />
        )}

        {activeTab === 'my-equipment' && (
          <MyEquipmentTab
            onNavigateToListEquipment={handleNavigateToListEquipment}
          />
        )}

        {activeTab === 'services' && (
          <FarmServicesTab
            onBookingCreated={() => handleTabChange('bookings')}
          />
        )}

        {activeTab === 'skills' && (
          <SkillExchangeTab
            onNavigateToMySkills={() => handleTabChange('my-skills')}
          />
        )}

        {activeTab === 'my-skills' && (
          <MyFarmSkillsTab
            onNavigateToMentorDirectory={() => handleTabChange('skills')}
          />
        )}

        {activeTab === 'bookings' && (
          <FarmerBookingsTab />
        )}

        {activeTab === 'cooperative' && (
          <FarmerCooperativeTab />
        )}

        {activeTab === 'profile' && (
          <FarmerProfileTab />
        )}
      </main>

      {/* ─── Voice Seva Modal / Sheet ─────────────────────────────── */}
      {showVoiceSevaModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl animate-scale-up">
            <div className="bg-gradient-to-r from-emerald-900 to-slate-900 px-5 py-4 border-b border-emerald-800/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎙️</span>
                <div>
                  <h3 className="text-white font-black text-sm">Voice Seva Assistant</h3>
                  <p className="text-emerald-400 text-xs">Speak in Kannada, Hindi, or English</p>
                </div>
              </div>
              <button
                onClick={() => setShowVoiceSevaModal(false)}
                className="text-slate-400 hover:text-white font-bold p-1"
              >
                ✕
              </button>
            </div>
            <div className="p-4">
              <VoiceSeva
                lang={selectedLanguage}
                isLowConnectivity={isLowConnectivity}
                isOnline={isOnline}
                onRequestWorker={(cat) => {
                  setShowVoiceSevaModal(false);
                  handleTabChange('workers');
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* ─── Notifications Modal ──────────────────────────────────── */}
      {showNotificationsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-white font-black text-base flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-400" />
                Farmer Notifications
              </h3>
              <button
                onClick={() => setShowNotificationsModal(false)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {farmerNotifications.length === 0 ? (
                <p className="text-center py-6 text-slate-500 text-xs">No new notifications</p>
              ) : (
                farmerNotifications.map((notif, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-800/80 border border-slate-700/80 rounded-2xl text-xs space-y-1"
                  >
                    <p className="font-bold text-white">{notif.title}</p>
                    <p className="text-slate-300 leading-relaxed">{notif.message}</p>
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowNotificationsModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Section 26 Demo Walkthrough Modal ────────────────────── */}
      <FarmerDemoWalkthrough
        isOpen={showDemoWalkthrough}
        onClose={() => setShowDemoWalkthrough(false)}
        onNavigateTab={handleTabChange}
      />

      {/* ─── Show My Crop Camera Modal ────────────────────────────── */}
      <CropCameraModal
        isOpen={showCropCameraModal}
        onClose={() => setShowCropCameraModal(false)}
        onCropShared={() => handleTabChange('crops')}
      />
    </div>
  );
};

