import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Smartphone,
  CreditCard,
  Banknote,
  QrCode,
  ArrowRight,
  Info,
  Lock,
  Award
} from 'lucide-react';

export const PaymentModal = () => {
  const {
    isPaymentModalOpen,
    setIsPaymentModalOpen,
    activeBookingId,
    bookings,
    processSimulatedPayment
  } = useCoop();

  const [paymentMethod, setPaymentMethod] = useState('upi'); // 'upi' | 'card' | 'cash'
  const [upiApp, setUpiApp] = useState('gpay'); // 'gpay' | 'phonepe' | 'paytm' | 'bhim'
  const [upiId, setUpiId] = useState('ananya.sharma@okhdfcbank');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isPaymentModalOpen) return null;

  const booking = bookings.find(b => b.id === activeBookingId) || bookings[0];
  const grossTotal = booking ? booking.grossTotal : 500;
  const workerPayout = booking ? booking.breakdown.workerPayout : 400;
  const coopFee = booking ? booking.breakdown.coopFee : 75;
  const platformFee = booking ? booking.breakdown.platformFee : 25;

  const handlePay = (e) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const methodName =
        paymentMethod === 'upi'
          ? `UPI (${upiApp.toUpperCase()} - ${upiId})`
          : paymentMethod === 'card'
          ? 'Debit Card (Ending 4082)'
          : 'Cash on Completion (Digital Receipt Generated)';
      processSimulatedPayment(booking.id, methodName);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-indigo-950 text-white p-5 sm:p-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Lock className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold">SevaSetu Digital Escrow</h3>
                <span className="bg-emerald-400/20 text-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300/40">
                  100% Transparent
                </span>
              </div>
              <p className="text-xs text-emerald-100/80 mt-0.5">
                Booking #{booking?.id} • {booking?.workerName}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsPaymentModalOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handlePay} className="p-6 space-y-6">
          
          {/* Payment Method Selector Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Select Payment Mode
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'upi', label: 'UPI / QR', icon: Smartphone, desc: 'Instant 0% fee' },
                { id: 'card', label: 'Card / NetBanking', icon: CreditCard, desc: 'Debit / Credit' },
                { id: 'cash', label: 'Cash on Service', icon: Banknote, desc: 'Digital verification' }
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = paymentMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id)}
                    className={`p-3 rounded-2xl border text-left transition-all flex flex-col items-center sm:items-start ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-1.5 ${isSelected ? 'text-emerald-700' : 'text-slate-400'}`} />
                    <span className="text-xs font-bold">{m.label}</span>
                    <span className="text-[10px] text-slate-500 hidden sm:inline">{m.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* UPI Options */}
          {paymentMethod === 'upi' && (
            <div className="space-y-4 bg-slate-50 p-4 rounded-2xl border border-slate-200 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">Choose UPI App:</span>
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
                  NPCI Escrow Certified
                </span>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'gpay', label: 'Google Pay', badge: 'GPay' },
                  { id: 'phonepe', label: 'PhonePe', badge: 'PhonePe' },
                  { id: 'paytm', label: 'Paytm', badge: 'Paytm' },
                  { id: 'bhim', label: 'BHIM UPI', badge: 'BHIM' }
                ].map((app) => (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => setUpiApp(app.id)}
                    className={`p-2 rounded-xl text-xs font-bold border transition-all text-center ${
                      upiApp === app.id
                        ? 'bg-white border-emerald-600 text-emerald-800 shadow-sm'
                        : 'bg-white/60 border-slate-200 text-slate-600 hover:bg-white'
                    }`}
                  >
                    {app.badge}
                  </button>
                ))}
              </div>

              {/* UPI ID Input */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Enter VPA / UPI ID or Scan QR:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="e.g. yourname@okaxis"
                    required
                  />
                  <div className="w-9 h-9 rounded-xl bg-white border border-slate-300 flex items-center justify-center text-slate-700 shrink-0 shadow-2xs" title="Scan QR">
                    <QrCode className="w-5 h-5 text-emerald-700" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Card Form */}
          {paymentMethod === 'card' && (
            <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 animate-fade-in text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Card Number</label>
                <input
                  type="text"
                  defaultValue="4532 •••• •••• 4082"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Expiry</label>
                  <input
                    type="text"
                    defaultValue="08/29"
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">CVV</label>
                  <input
                    type="password"
                    defaultValue="•••"
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Cash Confirmation */}
          {paymentMethod === 'cash' && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1 animate-fade-in">
              <span className="font-bold flex items-center gap-1">
                <Info className="w-4 h-4 text-amber-700" />
                Cash Payment with Digital Verification
              </span>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Pay exact amount (₹500) to Ravi Kumar upon service inspection. Ravi will confirm receipt in his co-owner portal to update the cooperative ledger.
              </p>
            </div>
          )}

          {/* Transparent Cooperative Fee Split (Crucial for SIH26089) */}
          <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-xs uppercase tracking-wider text-amber-300">
                  Cooperative Escrow Distribution
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400">Total: ₹{grossTotal}</span>
            </div>

            <div className="space-y-1.5 text-xs text-slate-300">
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Direct Worker Payout (80%):</span>
                </span>
                <span className="font-bold text-emerald-400">₹{workerPayout}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                  <span>Co-op Welfare & Healthcare Fund (15%):</span>
                </span>
                <span className="font-bold text-teal-300">₹{coopFee}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                  <span>Platform Operations & Cloud (5%):</span>
                </span>
                <span className="font-bold text-indigo-300">₹{platformFee}</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsPaymentModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Processing NPCI Escrow...</span>
                </>
              ) : (
                <>
                  <span>Pay ₹{grossTotal} via {paymentMethod.toUpperCase()}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
