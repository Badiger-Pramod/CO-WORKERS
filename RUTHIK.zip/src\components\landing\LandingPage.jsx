import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Wrench,
  Zap,
  Hammer,
  Paintbrush,
  Sparkles,
  Cpu,
  Leaf,
  Home,
  HeartHandshake,
  ShieldCheck,
  CheckCircle2,
  Users,
  Award,
  ArrowRight,
  PlayCircle,
  TrendingUp,
  MapPin,
  Percent,
  Bot,
  Star,
  Layers,
  Clock,
  ChevronRight,
  HelpCircle,
  Info
} from 'lucide-react';

export const LandingPage = () => {
  const {
    services,
    setRole,
    setSelectedService,
    setIsBookingModalOpen,
    setBookingWorker,
    workers,
    setIsDemoModeActive,
    setDemoStep
  } = useCoop();

  const serviceIcons = {
    plumbing: Wrench,
    electrical: Zap,
    carpentry: Hammer,
    painting: Paintbrush,
    cleaning: Sparkles,
    appliance: Cpu,
    vehicle: Wrench,
    gardening: Leaf,
    maintenance: Home,
    community: HeartHandshake
  };

  const handleSelectServiceCategory = (serviceId) => {
    setSelectedService(serviceId);
    setRole('customer');
  };

  const startDemo = () => {
    setIsDemoModeActive(true);
    setDemoStep(1);
    setRole('customer');
  };

  return (
    <div className="space-y-16 pb-20">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950 via-slate-900 to-indigo-950 text-white p-8 sm:p-14 shadow-2xl border border-emerald-800/40">
        
        {/* Subtle Map Matrix Background Graphic */}
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]"></div>
        
        <div className="relative z-10 max-w-4xl space-y-6">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Digital Worker & Farmer Cooperative Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            Empowering Local Workers. <br />
            <span className="text-emerald-400">Connecting Every Community.</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-lg leading-relaxed max-w-2xl font-medium">
            A cooperative-powered platform connecting households and communities with trusted local service professionals. Built on fair pay, worker co-ownership, and transparent pricing.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setRole('customer')}
              className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 flex items-center gap-2 transition-all transform active:scale-95"
            >
              <span>Find a Service</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setRole('worker')}
              className="px-6 py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-sm backdrop-blur-md flex items-center gap-2 transition-all"
            >
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Join as a Worker</span>
            </button>

            <button
              onClick={() => setRole('farmer')}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-black text-sm shadow-lg shadow-emerald-500/30 flex items-center gap-2 transition-all transform active:scale-95"
            >
              <span>🌾 CoWork Agri Portal</span>
            </button>
          </div>

          {/* Live Quick Counter Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6">
            <div className="bg-slate-800/80 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700">
              <span className="text-[11px] text-slate-400 uppercase font-bold">Worker Payout</span>
              <p className="text-2xl font-black text-emerald-400 mt-0.5">80% – 85%</p>
              <span className="text-[10px] text-emerald-300/80">Direct to worker</span>
            </div>

            <div className="bg-slate-800/80 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700">
              <span className="text-[11px] text-slate-400 uppercase font-bold">Welfare & Health</span>
              <p className="text-2xl font-black text-teal-300 mt-0.5">15%</p>
              <span className="text-[10px] text-teal-200/80">Mutual safety net</span>
            </div>

            <div className="bg-slate-800/80 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700">
              <span className="text-[11px] text-slate-400 uppercase font-bold">Platform Ops</span>
              <p className="text-2xl font-black text-indigo-300 mt-0.5">5%</p>
              <span className="text-[10px] text-indigo-200/80">Lowest in India</span>
            </div>

            <div className="bg-slate-800/80 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700">
              <span className="text-[11px] text-slate-400 uppercase font-bold">Democracy</span>
              <p className="text-2xl font-black text-amber-300 mt-0.5">1 Vote</p>
              <span className="text-[10px] text-amber-200/80">Per member worker</span>
            </div>
          </div>

        </div>
      </section>

      {/* 2. 10 SERVICE CATEGORIES SECTION */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-2">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
              <Award className="w-4 h-4" />
              Verified Cooperative Trades
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
              Essential Household & Community Services
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md">
            All tradespeople are verified cooperative co-owners backed by police verification, trade certifications, and transparent tariffs.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {services.map((srv) => {
            const Icon = serviceIcons[srv.id] || Wrench;
            return (
              <div
                key={srv.id}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group hover:border-emerald-400"
              >
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 group-hover:bg-emerald-600 text-emerald-700 group-hover:text-white flex items-center justify-center transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">{srv.name}</h3>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {srv.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 mt-4 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-medium">Available:</span>
                    <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      {srv.availableWorkers} Workers
                    </span>
                  </div>

                  <button
                    onClick={() => handleSelectServiceCategory(srv.id)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-100 group-hover:bg-emerald-600 group-hover:text-white text-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>Find Workers</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. HOW IT WORKS & TRANSPARENT COOPERATIVE EARNINGS */}
      <section className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 shadow-xl border border-slate-800 space-y-8">
        
        <div className="max-w-3xl space-y-2">
          <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
            A Better Model for India
          </span>
          <h2 className="text-2xl sm:text-4xl font-black text-white">
            Transparent Cooperative Earnings Breakdown
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Corporate gig apps deduct 25% to 30% in hidden platform commissions. SevaSetu is owned democratically by the workers themselves.
          </p>
        </div>

        {/* Real Example Visual Breakdown Card (₹500 payment) */}
        <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 max-w-3xl space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-700">
            <div>
              <span className="text-xs text-slate-400">Example Service Fee:</span>
              <p className="text-xl font-black text-white">Customer Payment: ₹500</p>
            </div>
            <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-600/40 px-3 py-1 rounded-full font-bold">
              100% Accountable
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3.5 bg-emerald-950/60 rounded-xl border border-emerald-600/30">
              <span className="text-xs text-emerald-300 font-bold block">Worker Payout (80%)</span>
              <p className="text-2xl font-black text-emerald-400 mt-1">₹400</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Credited directly to Ravi Kumar</p>
            </div>

            <div className="p-3.5 bg-teal-950/60 rounded-xl border border-teal-600/30">
              <span className="text-xs text-teal-300 font-bold block">Cooperative Fund (15%)</span>
              <p className="text-2xl font-black text-teal-300 mt-1">₹75</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Healthcare, sick leave & shared tools</p>
            </div>

            <div className="p-3.5 bg-indigo-950/60 rounded-xl border border-indigo-600/30">
              <span className="text-xs text-indigo-300 font-bold block">Platform Maintenance (5%)</span>
              <p className="text-2xl font-black text-indigo-300 mt-1">₹25</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Digital servers, maps & audit hosting</p>
            </div>
          </div>
        </div>

        {/* 4-Step Process Timeline */}
        <div className="pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
            How The Ecosystem Operates:
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { step: '01', title: 'Request Service', desc: 'Customer selects service or uses SmartMatch AI to pinpoint the exact problem.' },
              { step: '02', title: 'SmartMatch Dispatch', desc: 'Algorithm matches nearest verified co-op member using 6 weighted criteria.' },
              { step: '03', title: 'Transparent Execution', desc: 'Worker arrives with standard toolkit; live status updates on GPS map.' },
              { step: '04', title: 'Escrow Settlement', desc: 'Secure UPI payment released directly to worker escrow with 5-star review.' }
            ].map((st, i) => (
              <div key={i} className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                <span className="text-xs font-black text-emerald-400">{st.step}</span>
                <h4 className="font-bold text-white text-sm">{st.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{st.desc}</p>
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* 4. AI SMARTMATCH HIGHLIGHT SECTION */}
      <section className="bg-gradient-to-br from-indigo-950 via-slate-900 to-emerald-950 text-white rounded-3xl p-8 sm:p-12 shadow-xl border border-indigo-800/40">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>Cooperative Algorithmic Transparency</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white">
              ⚡ SmartMatch AI Recommendation Engine
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Unlike black-box corporate rating algorithms that punish workers with arbitrary suspensions, SmartMatch uses transparent, weighted criteria to guarantee fair dispatch for every cooperative member.
            </p>

            {/* 6 Weighted Factors */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                Algorithmic Weight Distribution:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Skill Match</span>
                  <span className="font-black text-emerald-400 text-base">30%</span>
                </div>
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Distance</span>
                  <span className="font-black text-indigo-400 text-base">20%</span>
                </div>
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Availability</span>
                  <span className="font-black text-teal-400 text-base">20%</span>
                </div>
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Rating</span>
                  <span className="font-black text-amber-400 text-base">15%</span>
                </div>
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Experience</span>
                  <span className="font-black text-blue-400 text-base">10%</span>
                </div>
                <div className="p-2.5 bg-slate-800/70 rounded-lg border border-slate-700">
                  <span className="text-slate-400 block">Performance</span>
                  <span className="font-black text-rose-400 text-base">5%</span>
                </div>
              </div>
            </div>
          </div>

          {/* AI Recommendation Sample Output Card */}
          <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-2xl border-2 border-emerald-400 space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=150&auto=format&fit=crop&q=80"
                  alt="Ravi Kumar"
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-sm"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-900 text-base">Ravi Kumar</h3>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                      ✓ Verified Co-owner
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Master Plumber • 6 Years Exp</p>
                  <p className="text-xs text-emerald-700 font-semibold">Tumakuru Community Services Cooperative</p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400 block">AI Match Score</span>
                <span className="text-2xl font-black text-emerald-600">94%</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed italic">
              "Recommended because Ravi is nearby (1.2 km away), available at your requested time, highly rated (4.8 ⭐), and verified with 247 completed plumbing jobs."
            </div>

            <button
              onClick={() => {
                setRole('customer');
              }}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2"
            >
              <span>Test SmartMatch AI on Live Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* 5. SOCIAL IMPACT DASHBOARD */}
      <section className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-sm space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-2">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
              <TrendingUp className="w-4 h-4" />
              Empowerment Metrics (Demo Statistics)
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
              Our Community Impact
            </h2>
          </div>
          <span className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-bold">
            Simulated Prototype Impact Ledger
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
            <p className="text-3xl font-black text-emerald-800">1,250+</p>
            <span className="text-xs font-bold text-slate-700 block mt-1">Workers Empowered</span>
            <span className="text-[10px] text-slate-500">Co-owners registered</span>
          </div>

          <div className="p-5 rounded-2xl bg-teal-50 border border-teal-200 text-center">
            <p className="text-3xl font-black text-teal-800">8,430+</p>
            <span className="text-xs font-bold text-slate-700 block mt-1">Jobs Completed</span>
            <span className="text-[10px] text-slate-500">Across 4 districts</span>
          </div>

          <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 text-center">
            <p className="text-3xl font-black text-indigo-800">24</p>
            <span className="text-xs font-bold text-slate-700 block mt-1">Cooperatives</span>
            <span className="text-[10px] text-slate-500">Registered societies</span>
          </div>

          <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-center">
            <p className="text-3xl font-black text-amber-800">₹32.5L</p>
            <span className="text-xs font-bold text-slate-700 block mt-1">Worker Earnings</span>
            <span className="text-[10px] text-slate-500">Generated directly</span>
          </div>

          <div className="p-5 rounded-2xl bg-rose-50 border border-rose-200 text-center col-span-2 md:col-span-1">
            <p className="text-3xl font-black text-rose-800">4.7 / 5</p>
            <span className="text-xs font-bold text-slate-700 block mt-1">Average Rating</span>
            <span className="text-[10px] text-slate-500">96.4% satisfaction</span>
          </div>
        </div>

        {/* Impact Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
          {[
            { title: 'Local Employment', desc: 'Connecting neighborhood households with tradespeople living within 3 km.' },
            { title: 'Worker Empowerment', desc: 'Every worker owns a Class A share and votes on minimum wages and policies.' },
            { title: 'Transparent Income', desc: '100% itemized receipts showing direct worker fee, welfare pool, and platform cost.' },
            { title: 'Community Services', desc: 'Mutual assistance for elder mobility care, school repairs, and clean energy.' },
            { title: 'Zero Middleman Commission', desc: 'Replacing 30% private app commissions with an ultra-low 5% sustainable fee.' },
            { title: 'Digital Financial Inclusion', desc: 'UPI escrow payments deposited directly into verified worker bank accounts.' }
          ].map((pil, idx) => (
            <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
              <span className="font-bold text-slate-900 text-sm">✓ {pil.title}</span>
              <p className="text-slate-600 leading-relaxed">{pil.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 6. BUILDING A COOPERATIVE GIG NETWORK ACROSS INDIA */}
      <section className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            Scale & Federal Expansion
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
            Building a Cooperative Gig Network Across India
          </h2>
          <p className="text-xs sm:text-slate-300 mt-1 max-w-2xl">
            Simulated blueprint of state federations adopting the SevaSetu model (Prototype / Demo locations).
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { state: 'Karnataka', city: 'Tumakuru & Bengaluru', coops: 8, workers: 948, tag: 'Active Operating Hub' },
            { state: 'Maharashtra', city: 'Pune & Nashik', coops: 4, workers: 420, tag: 'Pilot Launch' },
            { state: 'Tamil Nadu', city: 'Coimbatore & Madurai', coops: 3, workers: 310, tag: 'Registered' },
            { state: 'Telangana', city: 'Hyderabad & Warangal', coops: 3, workers: 280, tag: 'Pilot Launch' },
            { state: 'Kerala', city: 'Kochi & Kozhikode', coops: 2, workers: 240, tag: 'Registered' },
            { state: 'Andhra Pradesh', city: 'Visakhapatnam', coops: 2, workers: 190, tag: 'In Formation' },
            { state: 'Delhi NCR', city: 'New Delhi & Noida', coops: 1, workers: 150, tag: 'Incubating' },
            { state: 'Rajasthan', city: 'Jaipur & Jodhpur', coops: 1, workers: 120, tag: 'Incubating' }
          ].map((node, i) => (
            <div key={i} className="bg-slate-800/70 p-4 rounded-xl border border-slate-700 space-y-2">
              <div className="flex justify-between items-start">
                <h4 className="font-bold text-white text-sm">{node.state}</h4>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-700">
                  {node.tag}
                </span>
              </div>
              <p className="text-xs text-slate-400">Hub: {node.city}</p>
              <div className="flex justify-between text-xs pt-1 border-t border-slate-700 text-slate-300">
                <span>{node.coops} Co-ops</span>
                <span className="text-emerald-400 font-bold">{node.workers} Workers</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. FREQUENTLY ASKED QUESTIONS */}
      <section className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-sm space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">Clear Answers</span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">Frequently Asked Questions</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900 text-sm">How does SevaSetu differ from commercial apps?</h4>
            <p className="text-slate-600 leading-relaxed">
              Commercial apps take 25%–30% commissions and treat workers as expendable contractors. SevaSetu is a worker-owned cooperative where 80%–85% goes directly to the worker, 15% to a mutual healthcare welfare pool, and workers hold equal voting rights.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900 text-sm">Are workers verified?</h4>
            <p className="text-slate-600 leading-relaxed">
              Yes. Every service provider must pass Aadhaar identity verification, police background clearance, and trade qualification checks by their local Cooperative Guild.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900 text-sm">How does the 15% Cooperative Fund help?</h4>
            <p className="text-slate-600 leading-relaxed">
              The cooperative fund pays for mutual health insurance, emergency sick pay, and shared high-grade industrial equipment (hydro-jetting rigs, leak detectors) rented to members at 70% below commercial market rates.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <h4 className="font-bold text-slate-900 text-sm">How do customers pay?</h4>
            <p className="text-slate-600 leading-relaxed">
              Customers can pay via Indian UPI (GPay, PhonePe, Paytm), Co-op Member Wallet, Card, or Cash. Funds are held in escrow until the customer confirms satisfactory completion of work.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
