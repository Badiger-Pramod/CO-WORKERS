import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Building2,
  Users,
  ShieldCheck,
  Tractor,
  Tag,
  CloudSun,
  AlertTriangle,
  Phone,
  FileText,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { COOPERATIVE_AGRI_DATA } from '../../data/agriMockData';

export const FarmerCooperativeTab = () => {
  const { currentFarmer } = useCoop();
  const farmer = currentFarmer || {};

  const coopData = COOPERATIVE_AGRI_DATA;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ─── Header ──────────────────────────────────────────────── */}
      <div className="border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🏛️</span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Farmer Cooperative Hub & Community Resources
          </h2>
        </div>
        <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
          Access collective purchasing benefits, subsidized machinery pools, agricultural credit, and official cooperative governance.
        </p>
      </div>

      {/* ─── Cooperative Profile Card ─────────────────────────────── */}
      <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-800/60 rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-900/60 border border-emerald-700 flex items-center justify-center text-3xl flex-shrink-0">
              🏛️
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg sm:text-xl font-black text-white">{coopData.name}</h3>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Registered Society
                </span>
              </div>
              <p className="text-slate-300 text-xs mt-0.5">
                Reg: {coopData.registrationNo} · {coopData.district}, Karnataka · Established 1978
              </p>
            </div>
          </div>

          <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 text-xs space-y-1">
            <span className="text-slate-400 uppercase text-[10px] font-bold block">My Membership</span>
            <p className="text-emerald-400 font-black text-sm">
              {farmer.cooperativeMembership || '#KA-TMK-AGRI-402'}
            </p>
            <p className="text-slate-300">Class-F Voting Farm Shareholder</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-xs">
          <div>
            <span className="text-slate-400 block text-[10px]">Society Members</span>
            <span className="text-white font-bold text-sm">{coopData.totalMembers} Farmers</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Total Farm Land</span>
            <span className="text-white font-bold text-sm">3,850 Acres</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Board President</span>
            <span className="text-emerald-300 font-bold">{coopData.president}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Secretary / Manager</span>
            <span className="text-white font-bold">{coopData.secretary}</span>
          </div>
        </div>
      </div>

      {/* ─── Shared Machinery Pool (Custom Hiring Centre - CHC) ────── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-white font-black text-base flex items-center gap-2">
            🚜 Cooperative Shared Fleet (Custom Hiring Centre)
          </h3>
          <p className="text-slate-400 text-xs">
            Subsidized community machinery accessible to all small and marginal cooperative member farmers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {coopData.sharedEquipmentFleet?.map((eq) => (
            <div
              key={eq.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{eq.icon}</span>
                <div>
                  <h4 className="text-white font-bold text-sm">{eq.name}</h4>
                  <p className="text-emerald-400 text-xs font-semibold">{eq.rate}</p>
                  <p className="text-slate-500 text-[10px]">Total units: {eq.units}</p>
                </div>
              </div>

              <span className="bg-emerald-950 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-800">
                {eq.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Collective Purchasing & Subsidized Inputs ─────────────── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-white font-black text-base flex items-center gap-2">
            🏷️ Collective Seed & Fertilizer Purchasing Schemes
          </h3>
          <p className="text-slate-400 text-xs">
            Bulk procurement discounts negotiated directly with Karnataka State Seeds Corporation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {coopData.bulkPurchaseSchemes?.map((scheme) => (
            <div
              key={scheme.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2"
            >
              <div className="flex items-start justify-between">
                <span className="text-2xl">{scheme.icon}</span>
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                  {scheme.discount}
                </span>
              </div>

              <h4 className="text-white font-bold text-sm">{scheme.title}</h4>
              <p className="text-slate-400 text-xs">{scheme.description}</p>
              <p className="text-emerald-400 text-xs font-bold pt-1">{scheme.price}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Agromet Weather Bulletin ──────────────────────────────── */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-3">
        <h3 className="text-white font-black text-sm flex items-center gap-2">
          <CloudSun className="w-4 h-4 text-amber-400" />
          Cooperative Agromet Field Advisories
        </h3>
        <div className="space-y-2 text-xs">
          {coopData.announcements?.map((ann, idx) => (
            <div
              key={idx}
              className="bg-slate-800/70 border border-slate-700/70 rounded-xl p-3 flex items-start gap-3"
            >
              <span className="text-lg">{ann.icon}</span>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-white font-bold">{ann.title}</p>
                  <span className="text-[10px] text-slate-400">{ann.date}</span>
                </div>
                <p className="text-slate-300 mt-0.5 leading-relaxed">{ann.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
