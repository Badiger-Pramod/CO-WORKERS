import { Request, Response } from 'express';
import { dbQuery } from '../config/db';

// GET /api/services
export const getServices = async (req: Request, res: Response): Promise<void> => {
  try {
    const servicesRes = await dbQuery('SELECT * FROM services ORDER BY id ASC');
    res.status(200).json({
      success: true,
      services: servicesRes.rows
    });
  } catch (err) {
    console.error('[Services] Get error:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve services.' });
  }
};
