/**
 * Voice Seva — Platform Tool Handlers
 * These run SERVER-SIDE when Gemini calls one of the declared tools.
 * They interact with the platform's own mock data (and later, the real DB).
 * The API key never touches the browser.
 */

import { AGRI_WORKERS, AGRI_SERVICE_CATEGORIES } from './agriData.js';

// ─── Tool: Search General Workers ──────────────────────────────────────────
export function searchWorkers(params: {
  trade?: string;
  location?: string;
  available?: boolean;
}) {
  let workers = AGRI_WORKERS;
  if (params.trade) {
    workers = workers.filter(w =>
      w.primarySkill.toLowerCase().includes(params.trade!.toLowerCase()) ||
      w.skills.some(s => s.toLowerCase().includes(params.trade!.toLowerCase()))
    );
  }
  if (params.available !== undefined) {
    workers = workers.filter(w => w.available === params.available);
  }
  return {
    count: workers.length,
    workers: workers.slice(0, 5).map(w => ({
      id: w.id,
      name: w.name,
      primarySkill: w.primarySkill,
      rating: w.rating,
      distanceKm: w.distanceKm,
      available: w.available,
      hourlyRate: w.hourlyRate,
      verified: w.verified,
      coopMember: w.coopMember,
      languages: w.languages,
    })),
  };
}

// ─── Tool: Find Nearby Services ─────────────────────────────────────────────
export function findNearbyServices(params: { location?: string; category?: string }) {
  const categories = AGRI_SERVICE_CATEGORIES;
  const availableWorkers = AGRI_WORKERS.filter(w => w.available)
    .sort((a, b) => a.distanceKm - b.distanceKm);
  return {
    location: params.location || 'Pavagada, Tumakuru',
    categories: categories.map(c => c.label),
    nearestProvider: availableWorkers[0]
      ? {
          name: availableWorkers[0].name,
          skill: availableWorkers[0].primarySkill,
          distanceKm: availableWorkers[0].distanceKm,
          hourlyRate: availableWorkers[0].hourlyRate,
        }
      : null,
    totalAvailable: availableWorkers.length,
  };
}

// ─── Tool: Create Service Request ────────────────────────────────────────────
export function createServiceRequest(params: {
  serviceType: string;
  location?: string;
  preferredDate?: string;
  preferredTime?: string;
  notes?: string;
  urgency?: 'normal' | 'urgent';
}) {
  // SmartMatch: pick best available worker for the service type
  const matching = AGRI_WORKERS
    .filter(w => w.available && (
      w.serviceCategories.some(c => c.toLowerCase().includes(params.serviceType.toLowerCase())) ||
      w.skills.some(s => s.toLowerCase().includes(params.serviceType.toLowerCase()))
    ))
    .sort((a, b) => a.distanceKm - b.distanceKm);

  const matched = matching[0] || AGRI_WORKERS.find(w => w.available) || AGRI_WORKERS[0];
  const requestId = `VSR-${Date.now()}`;

  return {
    requestId,
    status: 'Created',
    serviceType: params.serviceType,
    assignedWorker: {
      id: matched.id,
      name: matched.name,
      primarySkill: matched.primarySkill,
      phone: matched.phone,
      distanceKm: matched.distanceKm,
      rating: matched.rating,
      verified: matched.verified,
      coopMember: matched.coopMember,
    },
    location: params.location || 'Farmer\'s registered location',
    scheduledDate: params.preferredDate || 'To be confirmed',
    scheduledTime: params.preferredTime || 'Morning (9AM–12PM)',
    estimatedCost: `₹${matched.hourlyRate} per hour`,
    notes: params.notes || '',
    urgency: params.urgency || 'normal',
    message: `Your request for ${params.serviceType} has been created. ${matched.name} (${matched.distanceKm}km away, rated ${matched.rating}★) will be notified.`,
  };
}

// ─── Tool: Find Agricultural Services ───────────────────────────────────────
export function findAgriculturalServices(params: {
  serviceType?: string;
  maxDistanceKm?: number;
}) {
  let workers = AGRI_WORKERS.filter(w => w.available);
  if (params.serviceType) {
    workers = workers.filter(w =>
      w.serviceCategories.some(c =>
        c.toLowerCase().includes(params.serviceType!.toLowerCase())
      ) ||
      w.skills.some(s => s.toLowerCase().includes(params.serviceType!.toLowerCase()))
    );
  }
  if (params.maxDistanceKm) {
    workers = workers.filter(w => w.distanceKm <= params.maxDistanceKm!);
  }
  return {
    serviceType: params.serviceType || 'All agricultural services',
    found: workers.length,
    providers: workers.slice(0, 4).map(w => ({
      name: w.name,
      primarySkill: w.primarySkill,
      distanceKm: w.distanceKm,
      rating: w.rating,
      hourlyRate: w.hourlyRate,
      coopMember: w.coopMember,
      verified: w.verified,
    })),
  };
}

// ─── Tool: Create Crop Inspection Request ────────────────────────────────────
export function createCropInspectionRequest(params: {
  cropType: string;
  problem?: string;
  location?: string;
  urgency?: 'normal' | 'urgent';
}) {
  const inspectors = AGRI_WORKERS.filter(w =>
    w.available &&
    (w.serviceCategories.includes('Crop Inspection') ||
      w.skills.some(s => s.toLowerCase().includes('crop')))
  ).sort((a, b) => a.distanceKm - b.distanceKm);

  const inspector = inspectors[0] || AGRI_WORKERS[0];
  const requestId = `CIR-${Date.now()}`;

  return {
    requestId,
    status: 'Pending Confirmation',
    cropType: params.cropType,
    problem: params.problem || 'General inspection',
    assignedInspector: {
      id: inspector.id,
      name: inspector.name,
      skills: inspector.skills.slice(0, 3),
      distanceKm: inspector.distanceKm,
      rating: inspector.rating,
      phone: inspector.phone,
      verified: inspector.verified,
    },
    location: params.location || 'Farmer\'s registered location',
    urgency: params.urgency || 'normal',
    estimatedArrival: inspector.distanceKm < 5 ? 'Within 2 hours' : 'Within 4 hours',
    estimatedCost: `₹${inspector.hourlyRate} per hour`,
    disclaimer:
      'Note: The inspector will provide an on-site assessment. For disease diagnosis, please also consult your local Krishi Vigyan Kendra (KVK).',
    message: `Crop inspection request for your ${params.cropType} created. ${inspector.name} (${inspector.distanceKm}km away) will inspect and provide a detailed report.`,
  };
}

// ─── Tool: Get Booking Status ────────────────────────────────────────────────
export function getBookingStatus(params: { bookingId?: string; farmerId?: string }) {
  // Demo: return mock booking data
  return {
    bookings: [
      {
        id: 'freq01',
        serviceCategory: 'Crop Inspection',
        workerName: 'Venkatesh Reddy',
        status: 'Completed',
        scheduledDate: '2026-09-20',
        amount: 350,
        rating: 5,
      },
      {
        id: 'freq02',
        serviceCategory: 'Soil Testing',
        workerName: 'Rajesh Patil',
        status: 'Scheduled',
        scheduledDate: '2026-09-27',
        amount: 300,
        rating: null,
      },
    ],
    totalBookings: 2,
    pendingBookings: 1,
    note: 'Demo data — real booking history would come from the database.',
  };
}

// ─── Tool: Get Booking History ────────────────────────────────────────────────
export function getBookingHistory(params: { farmerId?: string; limit?: number }) {
  return getBookingStatus(params);
}

// ─── Tool Dispatcher ─────────────────────────────────────────────────────────
export function dispatchTool(name: string, args: Record<string, unknown>) {
  switch (name) {
    case 'searchWorkers':           return searchWorkers(args as Parameters<typeof searchWorkers>[0]);
    case 'findNearbyServices':      return findNearbyServices(args as Parameters<typeof findNearbyServices>[0]);
    case 'createServiceRequest':    return createServiceRequest(args as Parameters<typeof createServiceRequest>[0]);
    case 'findAgriculturalServices':return findAgriculturalServices(args as Parameters<typeof findAgriculturalServices>[0]);
    case 'createCropInspectionRequest': return createCropInspectionRequest(args as Parameters<typeof createCropInspectionRequest>[0]);
    case 'getBookingStatus':        return getBookingStatus(args as Parameters<typeof getBookingStatus>[0]);
    case 'getBookingHistory':       return getBookingHistory(args as Parameters<typeof getBookingHistory>[0]);
    default:
      return { error: `Unknown tool: ${name}` };
  }
}
