import React, { createContext, useContext, useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { LANGUAGES, TRANSLATIONS } from '../data/translations';
import {
  INITIAL_TEACHING_WORKSHOPS,
  INITIAL_WORKER_LEARNING_PROGRESS,
  INITIAL_SKILL_EXCHANGE_REQUESTS
} from '../data/skillExchangeData';
import {
  DEMO_FARMER,
  DEMO_FARMERS,
  FARM_WORK_TYPES,
  FARM_EQUIPMENT_TYPES,
  AGRI_WORKERS,
  INITIAL_FARM_EQUIPMENT,
  INITIAL_FARMER_SKILLS,
  FARMER_SKILL_MENTORS,
  FARM_SERVICES_MARKETPLACE,
  INITIAL_FARM_BOOKINGS,
  COOPERATIVE_AGRI_DATA,
  AGRICULTURAL_SKILLS_CATALOG
} from '../data/agriMockData';

const CoopContext = createContext();

export const useCoop = () => {
  const context = useContext(CoopContext);
  if (!context) {
    throw new Error('useCoop must be used within a CoopProvider');
  }
  return context;
};

// Master Trade Definitions & Skills
export const TRADE_DEFINITIONS = [
  {
    id: 'Plumber',
    name: 'Plumber',
    icon: '🔧',
    serviceCategory: 'Plumbing',
    skills: ['Pipe Repair', 'Tap Installation', 'Bathroom Plumbing', 'Water Tank Repair', 'Drain Cleaning', 'Geyser Connection']
  },
  {
    id: 'Electrician',
    name: 'Electrician',
    icon: '⚡',
    serviceCategory: 'Electrical',
    skills: ['Wiring', 'Fan Repair', 'Switchboard Repair', 'Inverter Installation', 'MCB Tripping', 'Lighting Setup']
  },
  {
    id: 'Carpenter',
    name: 'Carpenter',
    icon: '🪚',
    serviceCategory: 'Carpentry',
    skills: ['Furniture Assembly', 'Door Lock Repair', 'Cupboard Hinges', 'Modular Kitchen Repair', 'Wooden Partition', 'Window Latches']
  },
  {
    id: 'Painter',
    name: 'Painter',
    icon: '🎨',
    serviceCategory: 'Painting',
    skills: ['Interior Wall Painting', 'Waterproof Coating', 'Exterior Painting', 'Texture Finish', 'Wood Polishing', 'Putty Finishing']
  },
  {
    id: 'Cleaning Professional',
    name: 'Cleaning Professional',
    icon: '🧹',
    serviceCategory: 'Cleaning',
    skills: ['Deep Home Cleaning', 'Kitchen Degreasing', 'Sofa & Carpet Cleaning', 'Water Tank Sanitization', 'Bathroom Deep Wash', 'Floor Polishing']
  },
  {
    id: 'Appliance / AC Technician',
    name: 'Appliance / AC Technician',
    icon: '❄️',
    serviceCategory: 'Appliance Repair',
    skills: ['AC Gas Refill', 'AC Servicing', 'Refrigerator Cooling Repair', 'Washing Machine Repair', 'Microwave Servicing', 'RO Purifier Service']
  },
  {
    id: 'Vehicle Mechanic',
    name: 'Vehicle Mechanic',
    icon: '🚗',
    serviceCategory: 'Vehicle Repair',
    skills: ['Two-Wheeler Servicing', 'Mobile Oil Change', 'Puncture Repair', 'Brake Adjustment', 'Car Jumpstart', 'Battery Replacement']
  },
  {
    id: 'Gardener',
    name: 'Gardener',
    icon: '🌱',
    serviceCategory: 'Gardening',
    skills: ['Lawn Mowing', 'Plant Pruning', 'Organic Soil Prep', 'Terrace Garden Care', 'Pest Control Spray', 'Drip Irrigation Setup']
  },
  {
    id: 'Home Maintenance',
    name: 'Home Maintenance',
    icon: '🏠',
    serviceCategory: 'Home Maintenance',
    skills: ['Roof Leakage Repair', 'Tile Grouting', 'Glass Replacement', 'Curtain Rod Setup', 'Door Seal Replacement', 'Civil Patchwork']
  },
  {
    id: 'Community Service',
    name: 'Community Service',
    icon: '🤝',
    serviceCategory: 'Community Services',
    skills: ['Elderly Care Assistance', 'Neighborhood Sanitation', 'Public Park Maintenance', 'Community Water Testing', 'Disaster Relief Support']
  },
  {
    id: 'Agricultural Worker',
    name: 'Agricultural Worker',
    icon: '🌾',
    serviceCategory: 'Farm Labour',
    skills: ['Harvesting', 'Sowing', 'Weeding', 'Planting', 'Irrigation Setup', 'Spraying', 'Field Preparation', 'Crop Maintenance']
  },
  {
    id: 'Farm Equipment Operator',
    name: 'Farm Equipment Operator',
    icon: '🚜',
    serviceCategory: 'Tractor Service',
    skills: ['Tractor Operation', 'Rotavator Operation', 'Harvester Operation', 'Equipment Repair', 'Water Pump Operation']
  },
  {
    id: 'Other',
    name: 'Other',
    icon: '🛠️',
    serviceCategory: 'Other',
    skills: ['General Repair', 'Custom Maintenance']
  }
];

export const getTradeIcon = (tradeName = '') => {
  const found = TRADE_DEFINITIONS.find(
    (t) => t.id.toLowerCase() === tradeName.toLowerCase() || t.name.toLowerCase() === tradeName.toLowerCase() || t.serviceCategory.toLowerCase() === tradeName.toLowerCase()
  );
  return found ? found.icon : '🛠️';
};

// Official Demo Customer Accounts
export const DEMO_CUSTOMERS = [
  {
    id: 'customer01',
    loginId: 'customer01',
    password: 'customer123',
    role: 'Customer',
    name: 'Ananya Sharma',
    fullName: 'Ananya Sharma',
    email: 'ananya.sharma@example.com',
    phone: '+91 98860 44210',
    location: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    city: 'Tumakuru',
    memberSince: 'January 2026',
    coopUnit: 'Tumakuru Community Services Cooperative',
    status: 'Active Class-A Resident Member'
  },
  {
    id: 'bhuvan01',
    loginId: 'bhuvan01',
    password: 'customer123',
    role: 'Customer',
    name: 'Bhuvan Bhuvi',
    fullName: 'Bhuvan Bhuvi',
    email: 'bhuvan.bhuvi@example.com',
    phone: '+91 98860 44210',
    location: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    city: 'Tumakuru',
    memberSince: 'January 2026',
    coopUnit: 'Tumakuru Community Services Cooperative',
    status: 'Active Class-A Resident Member'
  },
  {
    id: 'customer02',
    loginId: 'customer02',
    password: 'customer123',
    role: 'Customer',
    name: 'Priya Sharma',
    fullName: 'Priya Sharma',
    email: 'priya.sharma@example.com',
    phone: '+91 98450 67890',
    location: 'No. 88, 2nd Main, Ashok Nagar, Tumakuru',
    city: 'Tumakuru',
    memberSince: 'March 2026',
    coopUnit: 'Tumakuru Community Services Cooperative',
    status: 'Active Class-A Resident Member'
  },
  {
    id: 'customer03',
    loginId: 'customer03',
    password: 'customer123',
    role: 'Customer',
    name: 'Rahul Kumar',
    fullName: 'Rahul Kumar',
    email: 'rahul.kumar@example.com',
    phone: '+91 97410 11223',
    location: 'No. 14, 5th Cross, Batawadi, Tumakuru',
    city: 'Tumakuru',
    memberSince: 'February 2026',
    coopUnit: 'Tumakuru Community Services Cooperative',
    status: 'Active Class-A Resident Member'
  }
];

// Initial Realistic Demo Workers (Multiple workers per trade)
export const INITIAL_DEMO_WORKERS = [
  // Plumbers
  {
    id: 'ruthik01',
    loginId: 'ruthik01',
    password: 'worker123',
    name: 'Ruthik',
    fullName: 'Ruthik',
    role: 'Worker',
    primaryTrade: 'Plumber',
    trade: 'Plumber',
    additionalSkills: ['Pipe Repair', 'Tap Installation', 'Bathroom Plumbing', 'Water Tank Repair'],
    experience: 5,
    experienceText: '5 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 450,
    startingPrice: 400,
    rating: 4.8,
    reviewCount: 42,
    completedJobs: 168,
    distanceKm: 2.0,
    available: true,
    verified: true,
    avatar: '🔧',
    phone: '+91 98860 11928'
  },
  {
    id: 'suresh01',
    loginId: 'suresh01',
    password: 'worker123',
    name: 'Suresh',
    fullName: 'Suresh Gowda',
    role: 'Worker',
    primaryTrade: 'Plumber',
    trade: 'Plumber',
    additionalSkills: ['Underground Pipeline', 'Grouting & Leak Fixes', 'Overhead Tank Cleaning', 'Water Motor Repair'],
    experience: 7,
    experienceText: '7 years experience',
    location: 'Tumakuru',
    serviceRadius: 20,
    hourlyRate: 480,
    startingPrice: 450,
    rating: 4.6,
    reviewCount: 36,
    completedJobs: 195,
    distanceKm: 3.5,
    available: true,
    verified: true,
    avatar: '🔧',
    phone: '+91 98455 33211'
  },
  {
    id: 'manoj01',
    loginId: 'manoj01',
    password: 'worker123',
    name: 'Manoj',
    fullName: 'Manoj Kumar',
    role: 'Worker',
    primaryTrade: 'Plumber',
    trade: 'Plumber',
    additionalSkills: ['Modern Bathroom Fittings', 'Jet Spray Repair', 'Kitchen Sink Unclogging', 'Drainage Traps'],
    experience: 4,
    experienceText: '4 years experience',
    location: 'Tumakuru',
    serviceRadius: 10,
    hourlyRate: 400,
    startingPrice: 350,
    rating: 4.9,
    reviewCount: 48,
    completedJobs: 130,
    distanceKm: 1.8,
    available: true,
    verified: true,
    avatar: '🔧',
    phone: '+91 99012 44332'
  },
  {
    id: 'worker01',
    loginId: 'worker01',
    password: 'worker123',
    name: 'Ravi Kumar',
    fullName: 'Ravi Kumar',
    role: 'Worker',
    primaryTrade: 'Plumber',
    trade: 'Plumber',
    additionalSkills: ['Pipe Repair', 'Tap Installation', 'Bathroom Plumbing', 'Drain Cleaning'],
    experience: 6,
    experienceText: '6 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 450,
    startingPrice: 400,
    rating: 4.8,
    reviewCount: 32,
    completedJobs: 125,
    distanceKm: 2.4,
    available: true,
    verified: true,
    avatar: '🔧',
    phone: '+91 98860 11928'
  },
  // Electricians
  {
    id: 'kiran01',
    loginId: 'kiran01',
    password: 'worker123',
    name: 'Kiran Gowda',
    fullName: 'Kiran Gowda',
    role: 'Worker',
    primaryTrade: 'Electrician',
    trade: 'Electrician',
    additionalSkills: ['Fan Repair', 'Wiring', 'Switchboard Repair', 'Inverter Installation', 'MCB Tripping Check'],
    experience: 6,
    experienceText: '6 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 420,
    startingPrice: 380,
    rating: 4.9,
    reviewCount: 44,
    completedJobs: 172,
    distanceKm: 1.5,
    available: true,
    verified: true,
    avatar: '⚡',
    phone: '+91 98450 12345'
  },
  {
    id: 'bhuvan_w01',
    loginId: 'bhuvan01',
    password: 'worker123',
    name: 'Bhuvan S',
    fullName: 'Bhuvan S (Electrician)',
    role: 'Worker',
    primaryTrade: 'Electrician',
    trade: 'Electrician',
    additionalSkills: ['Fan Repair', 'Wiring', 'Switchboard Repair', 'Inverter Installation'],
    experience: 5,
    experienceText: '5 years experience',
    location: 'Tumakuru',
    serviceRadius: 10,
    hourlyRate: 400,
    startingPrice: 350,
    rating: 4.8,
    reviewCount: 38,
    completedJobs: 142,
    distanceKm: 2.2,
    available: true,
    verified: true,
    avatar: '⚡',
    phone: '+91 98450 99881'
  },
  {
    id: 'deepak01',
    loginId: 'deepak01',
    password: 'worker123',
    name: 'Deepak Rao',
    fullName: 'Deepak Rao',
    role: 'Worker',
    primaryTrade: 'Electrician',
    trade: 'Electrician',
    additionalSkills: ['Geyser Installation', 'Chandelier Wiring', 'Earthing & Phase Testing'],
    experience: 4,
    experienceText: '4 years experience',
    location: 'Tumakuru',
    serviceRadius: 12,
    hourlyRate: 380,
    startingPrice: 350,
    rating: 4.7,
    reviewCount: 28,
    completedJobs: 98,
    distanceKm: 2.8,
    available: true,
    verified: true,
    avatar: '⚡',
    phone: '+91 97412 88776'
  },
  // Carpenters
  {
    id: 'chandan01',
    loginId: 'chandan01',
    password: 'worker123',
    name: 'Chandan',
    fullName: 'Chandan',
    role: 'Worker',
    primaryTrade: 'Carpenter',
    trade: 'Carpenter',
    additionalSkills: ['Furniture Assembly', 'Door Lock Repair', 'Modular Kitchen Repair', 'Cupboard Hinges'],
    experience: 5,
    experienceText: '5 years experience',
    location: 'Tumakuru',
    serviceRadius: 12,
    hourlyRate: 450,
    startingPrice: 400,
    rating: 4.8,
    reviewCount: 29,
    completedJobs: 115,
    distanceKm: 2.1,
    available: true,
    verified: true,
    avatar: '🪚',
    phone: '+91 99001 23456'
  },
  {
    id: 'venkatesh01',
    loginId: 'venkatesh01',
    password: 'worker123',
    name: 'Venkatesh',
    fullName: 'Venkatesh Acharya',
    role: 'Worker',
    primaryTrade: 'Carpenter',
    trade: 'Carpenter',
    additionalSkills: ['Custom Teak Woodwork', 'Sliding Wardrobes', 'Antique Restoration', 'Door Fitting'],
    experience: 8,
    experienceText: '8 years experience',
    location: 'Tumakuru',
    serviceRadius: 18,
    hourlyRate: 500,
    startingPrice: 450,
    rating: 4.9,
    reviewCount: 52,
    completedJobs: 230,
    distanceKm: 3.2,
    available: true,
    verified: true,
    avatar: '🪚',
    phone: '+91 98801 66554'
  },
  // Painters
  {
    id: 'pramod01',
    loginId: 'pramod01',
    password: 'worker123',
    name: 'Pramod',
    fullName: 'Pramod',
    role: 'Worker',
    primaryTrade: 'Painter',
    trade: 'Painter',
    additionalSkills: ['Interior Wall Painting', 'Waterproof Coating', 'Texture Finish', 'Wood Polishing'],
    experience: 4,
    experienceText: '4 years experience',
    location: 'Tumakuru',
    serviceRadius: 20,
    hourlyRate: 500,
    startingPrice: 450,
    rating: 4.8,
    reviewCount: 25,
    completedJobs: 89,
    distanceKm: 2.8,
    available: true,
    verified: true,
    avatar: '🎨',
    phone: '+91 98452 77889'
  },
  // Cleaning Professionals
  {
    id: 'tushar01',
    loginId: 'tushar01',
    password: 'worker123',
    name: 'Tushar',
    fullName: 'Tushar',
    role: 'Worker',
    primaryTrade: 'Cleaning Professional',
    trade: 'Cleaning Professional',
    additionalSkills: ['Deep Home Cleaning', 'Kitchen Degreasing', 'Sofa & Carpet Cleaning', 'Water Tank Sanitization'],
    experience: 3,
    experienceText: '3 years experience',
    location: 'Tumakuru',
    serviceRadius: 10,
    hourlyRate: 350,
    startingPrice: 300,
    rating: 4.9,
    reviewCount: 51,
    completedJobs: 210,
    distanceKm: 1.9,
    available: true,
    verified: true,
    avatar: '🧹',
    phone: '+91 98800 55432'
  },
  {
    id: 'lakshmi01',
    loginId: 'lakshmi01',
    password: 'worker123',
    name: 'Lakshmi Devi',
    fullName: 'Lakshmi Devi',
    role: 'Worker',
    primaryTrade: 'Cleaning Professional',
    trade: 'Cleaning Professional',
    additionalSkills: ['Move-in Deep Sanitation', 'Bathroom Acid Wash', 'Balcony & Tile Scrubbing'],
    experience: 6,
    experienceText: '6 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 380,
    startingPrice: 320,
    rating: 4.8,
    reviewCount: 39,
    completedJobs: 175,
    distanceKm: 2.5,
    available: true,
    verified: true,
    avatar: '🧹',
    phone: '+91 97410 33445'
  },
  {
    id: 'suresh_e01',
    loginId: 'suresh_e01',
    password: 'worker123',
    name: 'Suresh M',
    fullName: 'Suresh M',
    role: 'Worker',
    primaryTrade: 'Electrician',
    trade: 'Electrician',
    additionalSkills: ['Wiring', 'Switchboard Repair', 'Fan Repair', 'Solar Inverter Setup', 'Fuse & MCB Fixes'],
    experience: 7,
    experienceText: '7 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 420,
    startingPrice: 380,
    rating: 4.7,
    reviewCount: 88,
    completedJobs: 215,
    distanceKm: 1.6,
    available: true,
    verified: true,
    avatar: '⚡',
    phone: '+91 94480 32189'
  },
  {
    id: 'manjunath01',
    loginId: 'manjunath01',
    password: 'worker123',
    name: 'Manjunath R',
    fullName: 'Manjunath R',
    role: 'Worker',
    primaryTrade: 'Carpenter',
    trade: 'Carpenter',
    additionalSkills: ['Furniture Assembly', 'Door Lock Fitting', 'Modular Kitchen Repair', 'Antique Wood Restoration'],
    experience: 8,
    experienceText: '8 years experience',
    location: 'Tumakuru',
    serviceRadius: 16,
    hourlyRate: 480,
    startingPrice: 420,
    rating: 4.9,
    reviewCount: 94,
    completedJobs: 260,
    distanceKm: 2.0,
    available: true,
    verified: true,
    avatar: '🪚',
    phone: '+91 98450 77123'
  },
  {
    id: 'priya01',
    loginId: 'priya01',
    password: 'worker123',
    name: 'Priya K',
    fullName: 'Priya K',
    role: 'Worker',
    primaryTrade: 'Cleaning Professional',
    trade: 'Cleaning Professional',
    additionalSkills: ['Deep Home Cleaning', 'Kitchen Sanitation', 'Water Purifier & Tank Cleaning', 'Balcony Wash'],
    experience: 5,
    experienceText: '5 years experience',
    location: 'Tumakuru',
    serviceRadius: 12,
    hourlyRate: 360,
    startingPrice: 300,
    rating: 4.6,
    reviewCount: 62,
    completedJobs: 185,
    distanceKm: 1.7,
    available: true,
    verified: true,
    avatar: '🧹',
    phone: '+91 98860 88231'
  },
  // Agricultural Workers (CoWork Agri 🌾)
  {
    id: 'manjunath01',
    loginId: 'manjunath01',
    password: 'worker123',
    name: 'Manjunath',
    fullName: 'Manjunath Gowda',
    role: 'Worker',
    primaryTrade: 'Agricultural Worker',
    trade: 'Agricultural Worker',
    additionalSkills: ['Harvesting', 'Sowing', 'Irrigation', 'Field Preparation', 'Weeding'],
    agriculturalSkills: ['Harvesting', 'Sowing', 'Irrigation', 'Field Preparation'],
    experience: 5,
    experienceText: '5 years experience',
    location: 'Tumakuru',
    serviceRadius: 15,
    hourlyRate: 50,
    startingPrice: 350,
    dailyRate: 350,
    rating: 4.8,
    reviewCount: 46,
    completedFarmJobs: 126,
    completedJobs: 126,
    distanceKm: 2.5,
    available: true,
    verified: true,
    avatar: '🌾',
    phone: '+91 94482 77123',
    operatorAvailable: true
  },
  {
    id: 'basavanna01',
    loginId: 'basavanna01',
    password: 'worker123',
    name: 'Basavanna Gowda',
    fullName: 'Basavanna Gowda',
    role: 'Worker',
    primaryTrade: 'Farm Equipment Operator',
    trade: 'Farm Equipment Operator',
    additionalSkills: ['Tractor Operation', 'Rotavator Operation', 'Harvester Driving', 'Pump Set Repair', 'Drip Setup'],
    agriculturalSkills: ['Tractor Operation', 'Equipment Repair', 'Drip Setup'],
    experience: 12,
    experienceText: '12 years experience',
    location: 'Tumakuru',
    serviceRadius: 20,
    hourlyRate: 70,
    startingPrice: 450,
    dailyRate: 450,
    rating: 4.9,
    reviewCount: 62,
    completedFarmJobs: 230,
    completedJobs: 230,
    distanceKm: 2.1,
    available: true,
    verified: true,
    avatar: '🚜',
    phone: '+91 98440 91234',
    operatorAvailable: true
  }
];

// Initial Bookings per Customer Account
export const INITIAL_DEMO_BOOKINGS = [
  // Customer 1: Bhuvan Bhuvi (customer01)
  {
    id: 'BK-2026-001',
    customerId: 'customer01',
    customerName: 'Bhuvan Bhuvi',
    customer: 'Bhuvan Bhuvi',
    customerPhone: '+91 98860 44210',
    service: 'Plumbing',
    serviceIcon: 'Wrench',
    worker: 'Ruthik',
    workerId: 'ruthik01',
    workerPhone: '+91 98860 11928',
    workerRating: 4.8,
    workerAvatar: '🔧',
    location: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    date: 'Today',
    time: '11:00 AM',
    price: 450,
    coopFee: 36,
    totalPrice: 486,
    status: 'On the Way',
    etaMinutes: 8,
    distanceKm: 2.0,
    paymentStatus: 'Pending',
    paymentMethod: 'UPI (GPay)',
    issueDescription: 'Bathroom shower mixer leak and pipeline inspection.',
    reviewed: false
  },
  {
    id: 'BK-2026-002',
    customerId: 'customer01',
    customerName: 'Bhuvan Bhuvi',
    customer: 'Bhuvan Bhuvi',
    customerPhone: '+91 98860 44210',
    service: 'Electrical',
    serviceIcon: 'Zap',
    worker: 'Kiran Gowda',
    workerId: 'kiran01',
    workerPhone: '+91 98450 12345',
    workerRating: 4.9,
    workerAvatar: '⚡',
    location: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    date: 'Tomorrow',
    time: '3:30 PM',
    price: 450,
    coopFee: 36,
    totalPrice: 486,
    status: 'Worker Assigned',
    etaMinutes: 45,
    distanceKm: 1.5,
    paymentStatus: 'Pending',
    paymentMethod: 'UPI',
    issueDescription: 'Main circuit breaker trip check and switchboard spark inspection.',
    reviewed: false
  },
  // Customer 2: Priya Sharma (customer02)
  {
    id: 'BK-2026-101',
    customerId: 'customer02',
    customerName: 'Priya Sharma',
    customer: 'Priya Sharma',
    customerPhone: '+91 98450 99881',
    service: 'Plumbing',
    serviceIcon: 'Wrench',
    worker: 'Manoj',
    workerId: 'manoj01',
    workerPhone: '+91 99012 44332',
    workerRating: 4.9,
    workerAvatar: '🔧',
    location: 'House No 45, 2nd Main, SS Puram, Tumakuru',
    date: 'Today',
    time: '2:00 PM',
    price: 400,
    coopFee: 32,
    totalPrice: 432,
    status: 'On the Way',
    etaMinutes: 12,
    distanceKm: 1.8,
    paymentStatus: 'Pending',
    paymentMethod: 'UPI',
    issueDescription: 'Kitchen sink clog and drainage pipe seal replacement.',
    reviewed: false
  },
  {
    id: 'BK-2026-102',
    customerId: 'customer02',
    customerName: 'Priya Sharma',
    customer: 'Priya Sharma',
    customerPhone: '+91 98450 99881',
    service: 'Cleaning Professional',
    serviceIcon: 'Sparkles',
    worker: 'Tushar',
    workerId: 'tushar01',
    workerPhone: '+91 98800 55432',
    workerRating: 4.9,
    workerAvatar: '🧹',
    location: 'House No 45, 2nd Main, SS Puram, Tumakuru',
    date: 'Sep 09, 2026',
    time: '10:00 AM',
    price: 350,
    coopFee: 28,
    totalPrice: 378,
    status: 'Completed',
    etaMinutes: 0,
    distanceKm: 1.9,
    paymentStatus: 'Paid',
    paymentMethod: 'Cash',
    issueDescription: 'Full kitchen deep degreasing and balcony scrub.',
    reviewed: true
  },
  // Customer 3: Rahul Kumar (customer03)
  {
    id: 'BK-2026-201',
    customerId: 'customer03',
    customerName: 'Rahul Kumar',
    customer: 'Rahul Kumar',
    customerPhone: '+91 97410 11223',
    service: 'Carpentry',
    serviceIcon: 'Hammer',
    worker: 'Chandan',
    workerId: 'chandan01',
    workerPhone: '+91 99001 23456',
    workerRating: 4.8,
    workerAvatar: '🪚',
    location: 'No. 14, 5th Cross, Batawadi, Tumakuru',
    date: 'Today',
    time: '4:30 PM',
    price: 450,
    coopFee: 36,
    totalPrice: 486,
    status: 'Worker Assigned',
    etaMinutes: 30,
    distanceKm: 2.1,
    paymentStatus: 'Pending',
    paymentMethod: 'UPI',
    issueDescription: 'Wardrobe drawer alignment and sliding track repair.',
    reviewed: false
  }
];

export const CoopProvider = ({ children }) => {
  // Current active view: 'home' | 'customer' | 'worker' | 'admin' | 'farmer'
  const [currentView, setCurrentView] = useState(() => {
    const path = typeof window !== 'undefined' ? window.location.pathname : '';
    if (path.includes('customer-dashboard')) return 'customer';
    if (path.includes('worker-dashboard')) return 'worker';
    if (path.includes('admin-portal')) return 'admin';
    if (path.includes('farmer-dashboard')) return 'farmer';
    return 'home';
  });

  // Current logged in user (Dynamic: restored from localStorage, defaults to DEMO_CUSTOMERS[0] or DEMO_FARMERS[0] if on farmer route)
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const stored = localStorage.getItem('cowork_active_session');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && (parsed.loginId || parsed.name || parsed.fullName)) {
          return parsed;
        }
      }
    } catch {}
    const path = typeof window !== 'undefined' ? window.location.pathname : '';
    if (path.includes('farmer-dashboard')) {
      return DEMO_FARMERS[0];
    }
    return DEMO_CUSTOMERS[0];
  });

  // Keep session synced
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('cowork_active_session', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  // Master Workers Directory
  const [workersDirectory, setWorkersDirectory] = useState(() => {
    const saved = localStorage.getItem('cowork_workers_directory');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return INITIAL_DEMO_WORKERS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_workers_directory', JSON.stringify(workersDirectory));
  }, [workersDirectory]);

  // Worker Skill Exchange State
  const [teachingWorkshops, setTeachingWorkshops] = useState(() => {
    const saved = localStorage.getItem('cowork_teaching_workshops');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_TEACHING_WORKSHOPS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_teaching_workshops', JSON.stringify(teachingWorkshops));
  }, [teachingWorkshops]);

  const [learningProgress, setLearningProgress] = useState(() => {
    const saved = localStorage.getItem('cowork_learning_progress');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_WORKER_LEARNING_PROGRESS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_learning_progress', JSON.stringify(learningProgress));
  }, [learningProgress]);

  const [skillExchangeRequests, setSkillExchangeRequests] = useState(() => {
    const saved = localStorage.getItem('cowork_skill_exchange_requests');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_SKILL_EXCHANGE_REQUESTS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_skill_exchange_requests', JSON.stringify(skillExchangeRequests));
  }, [skillExchangeRequests]);

  // Customer & Worker active tabs
  const [customerActiveTab, setCustomerActiveTab] = useState('dashboard');
  const [workerActiveTab, setWorkerActiveTab] = useState('dashboard');

  // Customer selected location
  const [selectedLocation, setSelectedLocation] = useState('Tumakuru');

  // Worker availability
  const [isWorkerAvailable, setIsWorkerAvailable] = useState(() => {
    const saved = localStorage.getItem('cowork_worker_availability');
    return saved !== null ? JSON.parse(saved) : true;
  });

  useEffect(() => {
    localStorage.setItem('cowork_worker_availability', JSON.stringify(isWorkerAvailable));
  }, [isWorkerAvailable]);

  // Toast notification
  const [toast, setToast] = useState(null);
  const showToast = (message, type = 'success') => {
    setToast({ id: Date.now(), message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Notifications
  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem('cowork_notifications');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'notif-1',
        forRole: 'Customer',
        title: 'Booking Confirmed',
        message: 'Your service booking is confirmed with Tumakuru Cooperative.',
        time: '15 mins ago',
        read: false
      },
      {
        id: 'notif-2',
        forRole: 'Worker',
        title: 'Welcome to Cooperative Hub',
        message: 'Your democratic cooperative profile is active with voting rights.',
        time: '1 hour ago',
        read: false
      }
    ];
  });

  const addNotification = (notif) => {
    const item = {
      id: `notif-${Date.now()}`,
      time: 'Just now',
      read: false,
      ...notif
    };
    setNotifications((prev) => [item, ...prev]);
  };

  // Shared Bookings List (per-customer segmented)
  const [bookings, setBookings] = useState(() => {
    const saved = localStorage.getItem('cowork_bookings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].customerId) {
          return parsed;
        }
      } catch {}
    }
    return INITIAL_DEMO_BOOKINGS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_bookings', JSON.stringify(bookings));
  }, [bookings]);

  // Dynamic Job Requests matching Worker's Trade
  const [jobRequests, setJobRequests] = useState(() => {
    const saved = localStorage.getItem('cowork_job_requests');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'REQ-801',
        targetTrade: 'Electrician',
        customer: 'Ananya Sharma',
        customerPhone: '+91 98860 44210',
        service: 'Electrical Repair',
        issue: 'Switchboard sparking & ceiling fan regulator replacement',
        location: 'Siddaganga Ext, Tumakuru',
        distance: '1.5 km',
        time: 'Today, 11:00 AM',
        estimatedPayment: 400,
        customerRating: 4.9,
        status: 'Pending'
      },
      {
        id: 'REQ-802',
        targetTrade: 'Plumber',
        customer: 'Kishore Hegde',
        customerPhone: '+91 98450 11223',
        service: 'Plumbing Service',
        issue: 'Bathroom mixer leak & main tank float valve check',
        location: 'Batawadi Ward, Tumakuru',
        distance: '2.4 km',
        time: 'Today, 4:00 PM',
        estimatedPayment: 450,
        customerRating: 4.8,
        status: 'Pending'
      },
      {
        id: 'REQ-803',
        targetTrade: 'Carpenter',
        customer: 'Sunita Rao',
        customerPhone: '+91 99881 22334',
        service: 'Carpentry Repair',
        issue: 'Modular kitchen cabinet hydraulic hinges replacement',
        location: 'SS Puram, Tumakuru',
        distance: '1.9 km',
        time: 'Tomorrow, 10:30 AM',
        estimatedPayment: 450,
        customerRating: 4.7,
        status: 'Pending'
      },
      {
        id: 'REQ-804',
        targetTrade: 'Painter',
        customer: 'Girish Kumar',
        customerPhone: '+91 98450 99881',
        service: 'Painting Service',
        issue: 'Living room accent wall painting & primer touch-up',
        location: 'Gandhinagar, Tumakuru',
        distance: '3.0 km',
        time: 'Tomorrow, 2:00 PM',
        estimatedPayment: 500,
        customerRating: 4.8,
        status: 'Pending'
      },
      {
        id: 'REQ-805',
        targetTrade: 'Cleaning Professional',
        customer: 'Meenakshi Sundaram',
        customerPhone: '+91 98860 33445',
        service: 'Deep Cleaning',
        issue: 'Kitchen deep degreasing & water purifier filter wash',
        location: 'Kyatsandra, Tumakuru',
        distance: '2.8 km',
        time: 'Today, 3:00 PM',
        estimatedPayment: 350,
        customerRating: 4.9,
        status: 'Pending'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('cowork_job_requests', JSON.stringify(jobRequests));
  }, [jobRequests]);

  // Worker Financial Stats
  const [workerStats, setWorkerStats] = useState(() => {
    const saved = localStorage.getItem('cowork_worker_stats');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return {
      todayEarnings: 1250,
      thisMonth: 28450,
      grossEarnings: 30000,
      coopFee: 2400, // 8%
      netEarnings: 27600,
      jobsCompleted: 15,
      averageRating: 4.8,
      coopDividend: 2350,
      totalReviews: 32,
      onTimeRate: 96,
      customerSatisfaction: 94
    };
  });

  useEffect(() => {
    localStorage.setItem('cowork_worker_stats', JSON.stringify(workerStats));
  }, [workerStats]);

  // Customer Stats
  const [customerStats, setCustomerStats] = useState(() => {
    const saved = localStorage.getItem('cowork_customer_stats');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return {
      activeBookings: 2,
      completedServices: 12,
      averageRating: 4.8,
      totalSpent: 4850
    };
  });

  useEffect(() => {
    localStorage.setItem('cowork_customer_stats', JSON.stringify(customerStats));
  }, [customerStats]);

  // Democratic Proposals
  const [proposals, setProposals] = useState(() => {
    const saved = localStorage.getItem('cowork_proposals');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'prop-1',
        title: 'Approve new cooperative base tariff',
        description: 'Adjust the standard callout base tariff from ₹400 to ₹450 to reflect tool costs and fuel inflation across Tumakuru.',
        deadline: 'October 15, 2026',
        totalYes: 142,
        totalNo: 18,
        userVote: null
      },
      {
        id: 'prop-2',
        title: 'Tool subsidy program',
        description: 'Allocate 15% of annual cooperative welfare reserve to provide 50% subsidized power toolkits to active co-owners.',
        deadline: 'October 20, 2026',
        totalYes: 189,
        totalNo: 8,
        userVote: 'YES'
      },
      {
        id: 'prop-3',
        title: 'Cooperative safety fund',
        description: 'Establish a ₹5,00,000 emergency medical and hospitalization micro-cover for all field gig workers.',
        deadline: 'October 25, 2026',
        totalYes: 210,
        totalNo: 4,
        userVote: null
      },
      {
        id: 'prop-4',
        title: 'New service area expansion',
        description: 'Authorize cooperative dispatch expansion into Kunigal, Sira, and Gubbi taluks under Tumakuru District Union.',
        deadline: 'November 01, 2026',
        totalYes: 165,
        totalNo: 29,
        userVote: null
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('cowork_proposals', JSON.stringify(proposals));
  }, [proposals]);

  // Service Areas
  const [selectedAreas, setSelectedAreas] = useState(['Tumakuru', 'Gubbi', 'Kunigal']);
  const [workingRadiusKm, setWorkingRadiusKm] = useState(12);

  // Reviews List
  const [reviews, setReviews] = useState(() => {
    const saved = localStorage.getItem('cowork_reviews');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'rev-1',
        customer: 'Ananya Sharma',
        worker: 'Bhuvan Bhuvi',
        workerTrade: 'Electrician',
        rating: 5,
        date: 'Sep 02, 2026',
        comment: 'Bhuvan arrived promptly with complete safety gear. Fixed our MCB tripping and replaced the switchboard neatly at standard cooperative rates.',
        tags: ['Punctual', 'Honest Pricing', 'Co-op Pride']
      },
      {
        id: 'rev-2',
        customer: 'Dr. Srinivas Murthy',
        worker: 'Ruthik',
        workerTrade: 'Plumber',
        rating: 5,
        date: 'Aug 24, 2026',
        comment: 'Ruthik is a very skilled plumber. Cleaned up everything after fixing the shower valve.',
        tags: ['Clean Work', 'Polite', 'Expert Skills']
      },
      {
        id: 'rev-3',
        customer: 'Meenakshi Sundaram',
        worker: 'Chandan',
        workerTrade: 'Carpenter',
        rating: 4.8,
        date: 'Aug 12, 2026',
        comment: 'Chandan repaired our dining table and door hinges smoothly. Highly recommend CoWork Connect.',
        tags: ['Punctual', 'Clean Work']
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('cowork_reviews', JSON.stringify(reviews));
  }, [reviews]);

  // Complaints List
  const [complaints, setComplaints] = useState(() => [
    {
      id: 'CMP-101',
      ticketNo: 'TKT-TMK-802',
      category: 'Poor Service',
      description: 'Minor fitting vibration observed after initial service.',
      worker: 'Bhuvan Bhuvi',
      status: 'Resolved',
      date: 'Aug 15, 2026',
      resolutionNote: 'Worker revisited free of cost and re-tightened mounting brackets.'
    }
  ]);

  // Emergency SOS State
  const [emergencyAlert, setEmergencyAlert] = useState(null);

  // ==========================================
  // CORE MATCHING ENGINE (Trade #1 Factor)
  // ==========================================
  const calculateSmartMatch = (requestedService, userCity = 'Tumakuru') => {
    const normalizedService = requestedService.toLowerCase();

    return workersDirectory
      .map((w) => {
        const workerTrade = (w.primaryTrade || w.trade || '').toLowerCase();

        // Check if trade matches
        let isTradeMatch = false;
        if (
          (normalizedService.includes('electric') && workerTrade.includes('electric')) ||
          (normalizedService.includes('plumb') && workerTrade.includes('plumb')) ||
          (normalizedService.includes('carpent') && workerTrade.includes('carpent')) ||
          (normalizedService.includes('paint') && workerTrade.includes('paint')) ||
          (normalizedService.includes('clean') && workerTrade.includes('clean')) ||
          (normalizedService.includes('appliance') && (workerTrade.includes('appliance') || workerTrade.includes('ac'))) ||
          (normalizedService.includes('vehicle') && (workerTrade.includes('vehicle') || workerTrade.includes('mechanic'))) ||
          (normalizedService.includes('garden') && workerTrade.includes('garden')) ||
          (normalizedService.includes('maintenance') && workerTrade.includes('maintenance')) ||
          (normalizedService.includes('community') && workerTrade.includes('community')) ||
          workerTrade.includes(normalizedService) ||
          normalizedService.includes(workerTrade)
        ) {
          isTradeMatch = true;
        }

        // Trade is worth 50 points out of 100!
        const tradeScore = isTradeMatch ? 50 : 5;

        // Rating (max 20)
        const ratingScore = Math.min(20, Math.round((w.rating / 5) * 20));

        // Experience (max 15)
        const expScore = Math.min(15, Math.round((w.experience / 10) * 15));

        // Distance & Availability (max 15)
        const availScore = w.available ? 10 : 2;
        const distScore = 5;

        const matchScore = tradeScore + ratingScore + expScore + availScore + distScore;

        const reason = isTradeMatch
          ? `Certified ${w.primaryTrade} specialist • Top rated (${w.rating} ⭐) • ${w.experience}y experience in ${w.location} • Available now.`
          : `Secondary cooperative service provider (${w.primaryTrade}).`;

        return {
          ...w,
          matchScore,
          isTradeMatch,
          reason
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore);
  };

  // ==========================================
  // ACTIONS / METHODS
  // ==========================================

  // Update Worker Profile (DYNAMIC PROFESSION UPDATE)
  const updateWorkerProfile = (updatedProfile) => {
    const updated = {
      ...currentUser,
      ...updatedProfile,
      primaryTrade: updatedProfile.primaryTrade || updatedProfile.trade || currentUser.primaryTrade,
      trade: updatedProfile.primaryTrade || updatedProfile.trade || currentUser.trade
    };

    setCurrentUser(updated);

    // Update in workersDirectory too
    setWorkersDirectory((prev) =>
      prev.map((w) => (w.id === updated.id || w.loginId === updated.loginId ? { ...w, ...updated } : w))
    );

    showToast(`Profile updated! Your trade is now "${updated.primaryTrade}".`, 'success');
  };

  // Customer Creates Booking
  const createCustomerBooking = async ({ service, workerId, date = 'Today', time = '11:00 AM', location, issueDescription }) => {
    const worker = workersDirectory.find((w) => w.id === workerId) || workersDirectory[0];
    const price = worker.hourlyRate || worker.startingPrice || 400;
    const coopFee = Math.round(price * 0.08); // 8% Co-op fee
    const totalPrice = price + coopFee;

    const custName = currentUser?.name || currentUser?.fullName || 'Customer';
    const custId = currentUser?.loginId || 'customer01';
    const custPhone = currentUser?.phone || '+91 98860 44210';
    const custLocation = location || currentUser?.location || 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru';

    const newBookingId = `BK-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newBooking = {
      id: newBookingId,
      customerId: custId,
      customerName: custName,
      customer: custName,
      customerPhone: custPhone,
      service: worker.primaryTrade || service,
      serviceIcon: getTradeIcon(worker.primaryTrade || service),
      worker: worker.name,
      workerId: worker.id,
      workerPhone: worker.phone || '+91 98450 12345',
      workerRating: worker.rating,
      workerAvatar: worker.avatar || getTradeIcon(worker.primaryTrade),
      location: custLocation,
      date,
      time,
      price,
      coopFee,
      totalPrice,
      status: 'Confirmed',
      etaMinutes: 15,
      distanceKm: 1.5,
      paymentStatus: 'Pending',
      paymentMethod: 'UPI',
      issueDescription: issueDescription || `${worker.primaryTrade} service requested via CoWork Connect.`,
      reviewed: false
    };

    setBookings((prev) => [newBooking, ...prev]);

    // Send to worker's job requests
    const newReq = {
      id: `REQ-${Math.floor(700 + Math.random() * 300)}`,
      bookingId: newBookingId,
      targetTrade: worker.primaryTrade,
      customer: custName,
      customerPhone: custPhone,
      service: worker.primaryTrade,
      issue: newBooking.issueDescription,
      location: newBooking.location,
      distance: '1.5 km',
      time: `${date}, ${time}`,
      estimatedPayment: price,
      customerRating: 4.9,
      status: 'Pending'
    };
    setJobRequests((prev) => [newReq, ...prev]);

    addNotification({
      forRole: 'Worker',
      title: `New ${worker.primaryTrade} Request`,
      message: `${custName} booked ${worker.primaryTrade} (₹${price}) in ${newBooking.location.split(',')[0]}.`
    });

    addNotification({
      forRole: 'Customer',
      forUserId: custId,
      title: 'Booking Confirmed',
      message: `Booking #${newBookingId} for ${worker.primaryTrade} confirmed with ${worker.name}.`
    });

    setCustomerStats((prev) => ({
      ...prev,
      activeBookings: prev.activeBookings + 1
    }));

    // Async backend persistence & socket broadcast
    try {
      const numericWorkerId = typeof worker.id === 'number' ? worker.id : parseInt(String(worker.id).replace(/\D/g, '') || '2', 10);
      const numericCustId = typeof currentUser?.id === 'number' ? currentUser.id : parseInt(String(custId).replace(/\D/g, '') || '1', 10);

      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: numericCustId,
          worker_id: numericWorkerId,
          service_title: worker.primaryTrade || service,
          customer_name: custName,
          customer_phone: custPhone,
          customer_address: custLocation,
          requested_date: date,
          requested_time: time,
          estimated_price: totalPrice,
          notes: issueDescription
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.booking?.id) {
          newBooking.dbId = data.booking.id;
          newBooking.id = data.booking.booking_code || newBooking.id;
        }
      }
    } catch (e) {
      console.warn('Backend API booking sync fallback to local store:', e);
    }

    showToast(`Booking #${newBookingId} created successfully! Dispatched to ${worker.name} (${worker.primaryTrade}).`, 'success');
    return newBooking;
  };

  // Worker Accepts Job Request
  const workerAcceptJob = (reqId) => {
    const req = jobRequests.find((r) => r.id === reqId);
    if (!req) return;

    setJobRequests((prev) => prev.filter((r) => r.id !== reqId));

    if (req.bookingId) {
      setBookings((prev) =>
        prev.map((b) =>
          b.id === req.bookingId ? { ...b, status: 'Worker Assigned', etaMinutes: 12 } : b
        )
      );

      // Async backend status transition to ACCEPTED
      try {
        const targetBooking = bookings.find((b) => b.id === req.bookingId);
        const bId = targetBooking?.dbId || parseInt(String(req.bookingId).replace(/\D/g, '') || '1', 10);
        const wId = typeof currentUser?.id === 'number' ? currentUser.id : 2;
        fetch(`/api/bookings/${bId}/status`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'ACCEPTED', worker_id: wId })
        }).catch(() => {});
      } catch {}
    }

    addNotification({
      forRole: 'Customer',
      title: 'Worker Assigned',
      message: `${currentUser?.fullName || currentUser?.name || 'Your worker'} accepted your ${req.service} request.`
    });

    showToast(`Job accepted! Added to your active schedule.`, 'success');
  };

  // Worker Declines Job Request
  const workerDeclineJob = (reqId) => {
    setJobRequests((prev) => prev.filter((r) => r.id !== reqId));
    showToast(`Job declined and rerouted to another cooperative member.`, 'info');
  };

  // Worker Updates Status
  const workerUpdateJobStatus = (bookingId, nextStatus) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id === bookingId) {
          let eta = b.etaMinutes;
          if (nextStatus === 'On the Way') eta = 8;
          if (nextStatus === 'Arrived' || nextStatus === 'Work Started') eta = 0;
          return {
            ...b,
            status: nextStatus,
            etaMinutes: eta
          };
        }
        return b;
      })
    );

    // Sync status transition with backend
    try {
      const bObj = bookings.find((b) => b.id === bookingId);
      const bId = bObj?.dbId || parseInt(String(bookingId).replace(/\D/g, '') || '1', 10);
      const backendStatusMap = {
        'On the Way': 'ON_THE_WAY',
        'Arrived': 'WORK_STARTED',
        'Work Started': 'WORK_STARTED',
        'Completed': 'COMPLETED'
      };
      const apiStatus = backendStatusMap[nextStatus];
      if (apiStatus) {
        fetch(`/api/bookings/${bId}/status`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: apiStatus })
        }).catch(() => {});
      }
    } catch {}

    const messages = {
      'On the Way': `${currentUser?.fullName || currentUser?.name || 'Worker'} is on the way (ETA 8 mins).`,
      'Arrived': `${currentUser?.fullName || currentUser?.name || 'Worker'} has arrived at your location.`,
      'Work Started': `Work is in progress.`,
      'Completed': `Service completed! Please proceed to payment and rating.`
    };

    if (messages[nextStatus]) {
      addNotification({
        forRole: 'Customer',
        title: nextStatus,
        message: messages[nextStatus]
      });
      showToast(`Status updated to "${nextStatus}"`, 'success');
    }
  };

  // Customer Pays Booking
  const customerPayBooking = (bookingId, method = 'UPI (GPay)') => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, paymentStatus: 'Paid', paymentMethod: method } : b))
    );

    const workerEarn = booking.price;
    const fee = booking.coopFee;
    setWorkerStats((prev) => ({
      ...prev,
      todayEarnings: prev.todayEarnings + workerEarn,
      thisMonth: prev.thisMonth + workerEarn,
      grossEarnings: prev.grossEarnings + workerEarn,
      coopFee: prev.coopFee + fee,
      netEarnings: prev.netEarnings + (workerEarn - fee),
      jobsCompleted: prev.jobsCompleted + 1
    }));

    setCustomerStats((prev) => ({
      ...prev,
      activeBookings: Math.max(0, prev.activeBookings - 1),
      completedServices: prev.completedServices + 1,
      totalSpent: prev.totalSpent + booking.totalPrice
    }));

    // Sync payment with backend API
    try {
      const bId = booking.dbId || parseInt(String(bookingId).replace(/\D/g, '') || '1', 10);
      fetch(`/api/bookings/${bId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: booking.totalPrice || booking.price,
          payment_method: method
        })
      }).catch(() => {});
    } catch {}

    addNotification({
      forRole: 'Worker',
      title: 'Payment Received',
      message: `₹${workerEarn} credited directly via CoWork Connect Escrow (${method}).`
    });

    showToast(`Payment of ₹${booking.totalPrice} successful! Cooperative receipt generated.`, 'success');
  };

  // Customer Submits Review
  const customerSubmitReview = ({ bookingId, workerName = 'Ruthik', rating, comment, tags = [] }) => {
    const custName = currentUser?.name || currentUser?.fullName || 'Customer';
    const custId = currentUser?.loginId || 'customer01';

    const newRev = {
      id: `rev-${Date.now()}`,
      customerId: custId,
      customer: custName,
      worker: workerName,
      workerTrade: 'Specialist',
      rating,
      date: 'Today',
      comment,
      tags: tags.length ? tags : ['Punctual', 'Honest Pricing']
    };

    setReviews((prev) => [newRev, ...prev]);

    if (bookingId) {
      setBookings((prev) => prev.map((b) => (b.id === bookingId ? { ...b, reviewed: true } : b)));
      try {
        const bObj = bookings.find((b) => b.id === bookingId);
        const bId = bObj?.dbId || parseInt(String(bookingId).replace(/\D/g, '') || '1', 10);
        fetch(`/api/bookings/${bId}/rate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ rating, review: comment })
        }).catch(() => {});
      } catch {}
    }

    setWorkerStats((prev) => {
      const newTotal = prev.totalReviews + 1;
      const newAvg = Number(((prev.averageRating * prev.totalReviews + rating) / newTotal).toFixed(1));
      return {
        ...prev,
        totalReviews: newTotal,
        averageRating: newAvg
      };
    });

    addNotification({
      forRole: 'Worker',
      title: 'New Customer Review',
      message: `${rating} ⭐ review received from ${custName}.`
    });

    showToast(`Review submitted! Thank you for supporting our cooperative workers.`, 'success');
  };

  // Customer Submits Complaint
  const customerSubmitComplaint = ({ category, description, worker = 'Ruthik' }) => {
    const custName = currentUser?.name || currentUser?.fullName || 'Customer';
    const custId = currentUser?.loginId || 'customer01';
    const ticketNo = `TKT-TMK-${Math.floor(100 + Math.random() * 900)}`;

    const newCmp = {
      id: `CMP-${Date.now()}`,
      ticketNo,
      customerId: custId,
      customer: custName,
      category,
      description,
      worker,
      status: 'Pending',
      date: 'Today',
      resolutionNote: 'Assigned to Tumakuru Cooperative Peer Review Committee.'
    };

    setComplaints((prev) => [newCmp, ...prev]);

    // Async backend complaint persistence
    try {
      fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: typeof currentUser?.id === 'number' ? currentUser.id : 1,
          category,
          description
        })
      }).catch(() => {});
    } catch {}

    showToast(`Ticket #${ticketNo} submitted. Peer committee arbitrates within 2 hours.`, 'info');
  };

  // Customer Triggers SOS Emergency
  const customerTriggerEmergency = (type = 'Electrical Hazard') => {
    const alertData = {
      id: `SOS-${Date.now()}`,
      type,
      location: 'Siddaganga Ext, Tumakuru',
      nearestWorker: 'Bhuvan Bhuvi',
      workerPhone: '+91 98450 12345',
      etaMinutes: 6,
      status: 'Priority Dispatched',
      time: 'Just now'
    };

    setEmergencyAlert(alertData);

    addNotification({
      forRole: 'Worker',
      title: '🚨 PRIORITY EMERGENCY SOS',
      message: `Urgent ${type} reported in Siddaganga Ext. Priority dispatch assigned.`
    });

    showToast(`🚨 Emergency request sent! Nearest verified worker dispatched (ETA 6 mins).`, 'error');
  };

  // Worker Casts Vote on Proposal
  const workerVoteProposal = (proposalId, voteType) => {
    setProposals((prev) =>
      prev.map((p) => {
        if (p.id === proposalId) {
          const wasYes = p.userVote === 'YES';
          const wasNo = p.userVote === 'NO';
          return {
            ...p,
            userVote: voteType,
            totalYes: voteType === 'YES' ? (wasYes ? p.totalYes : p.totalYes + 1) : (wasYes ? p.totalYes - 1 : p.totalYes),
            totalNo: voteType === 'NO' ? (wasNo ? p.totalNo : p.totalNo + 1) : (wasNo ? p.totalNo - 1 : p.totalNo)
          };
        }
        return p;
      })
    );
    showToast(`Your vote has been recorded under "One Worker = One Vote".`, 'success');
  };

  // Worker Toggles Availability
  const workerToggleAvailability = () => {
    setIsWorkerAvailable((prev) => {
      const next = !prev;
      showToast(next ? 'Status: AVAILABLE — Accepting Jobs' : 'Status: OFFLINE', next ? 'success' : 'info');
      try {
        const wId = typeof currentUser?.id === 'number' ? currentUser.id : 2;
        fetch(`/api/workers/${wId}/availability`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ is_available: next })
        }).catch(() => {});
      } catch {}
      return next;
    });
  };

  // Worker Toggles Service Area
  const workerToggleArea = (areaName) => {
    setSelectedAreas((prev) => {
      if (prev.includes(areaName)) {
        if (prev.length <= 1) {
          showToast('You must select at least one active service area.', 'error');
          return prev;
        }
        return prev.filter((a) => a !== areaName);
      } else {
        return [...prev, areaName];
      }
    });
  };

  // Admin Portal State & Actions
  const [activeAdminTab, setActiveAdminTab] = useState('dashboard');
  const [analytics, setAnalytics] = useState(() => ({
    totalMembers: 342,
    activeWorkers: 128,
    jobsCompleted: 1420,
    grossRevenue: 3250000,
    coopWelfareFund: 487500,
    workerEarnings: 2600000,
    platformOps: 162500,
    customerSatisfaction: 98.4
  }));

  const resolveComplaint = (complaintId, resolutionNote = 'Resolved by District Cooperative Mediation Panel') => {
    setComplaints((prev) =>
      prev.map((c) =>
        c.id === complaintId
          ? { ...c, status: 'Resolved', resolutionNote }
          : c
      )
    );
    try {
      const numId = parseInt(String(complaintId).replace(/\D/g, '') || '1', 10);
      fetch(`/api/admin/complaints/${numId}/resolve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resolution: resolutionNote })
      }).catch(() => {});
    } catch {}
    showToast(`Complaint ${complaintId} resolved by mediation tribunal.`, 'success');
  };

  const approveWorkerVerification = (workerId) => {
    setWorkersDirectory((prev) =>
      prev.map((w) =>
        w.id === workerId ? { ...w, verified: true } : w
      )
    );
    try {
      const numId = typeof workerId === 'number' ? workerId : parseInt(String(workerId).replace(/\D/g, '') || '2', 10);
      fetch(`/api/admin/verify-worker/${numId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'Verified' })
      }).catch(() => {});
    } catch {}
    showToast(`Worker credentials verified and Class A Equity issued!`, 'success');
  };

  // Multilingual State (8 Indian Languages)
  const [currentLanguage, setCurrentLanguage] = useState(() => {
    return localStorage.getItem('cowork_language') || 'en';
  });

  const setLanguage = (langCode) => {
    setCurrentLanguage(langCode);
    localStorage.setItem('cowork_language', langCode);
    const langObj = LANGUAGES.find((l) => l.code === langCode);
    showToast(`Language switched to ${langObj ? langObj.nativeName : langCode}`, 'info');
  };

  const t = (key, fallback = '') => {
    if (!key) return fallback || '';
    const langDict = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en || {};
    if (langDict[key]) return langDict[key];
    const cleanKey = key.startsWith('farmer.') ? key.replace('farmer.', '') : key;
    if (langDict[cleanKey]) return langDict[cleanKey];
    if (TRANSLATIONS.en?.[key]) return TRANSLATIONS.en[key];
    if (TRANSLATIONS.en?.[cleanKey]) return TRANSLATIONS.en[cleanKey];
    return fallback || key;
  };

  // Innovation & Impact Modals
  const [isInnovationModalOpen, setIsInnovationModalOpen] = useState(false);
  const [isImpactModalOpen, setIsImpactModalOpen] = useState(false);

  // Hackathon Interactive Demo Mode State (16 steps)
  const [isDemoModeActive, setIsDemoModeActive] = useState(false);
  const [demoStep, setDemoStep] = useState(1);

  const startDemoMode = (navigateFn = null) => {
    setIsDemoModeActive(true);
    setDemoStep(1);
    const cust = DEMO_CUSTOMERS[0];
    setCurrentUser(cust);
    setCurrentView('customer');
    setCustomerActiveTab('dashboard');
    if (navigateFn) navigateFn('customer-dashboard', cust);
    showToast('⚡ SIH26089 Interactive Demo Flow Activated! Step 1/16: Customer Login', 'info');
  };

  const exitDemoMode = () => {
    setIsDemoModeActive(false);
    setDemoStep(1);
    showToast('Exited Demo Mode.', 'info');
  };

  const handleNextDemoStep = (navigateFn = null) => {
    setDemoStep((prev) => {
      const next = prev >= 16 ? 1 : prev + 1;

      if (next === 1) {
        const cust = DEMO_CUSTOMERS[0];
        setCurrentUser(cust);
        setCurrentView('customer');
        setCustomerActiveTab('dashboard');
        if (navigateFn) navigateFn('customer-dashboard', cust);
        showToast('Step 1/16: Logged in as Ananya Sharma (Customer in Tumakuru).', 'info');
      } else if (next === 2) {
        setCurrentView('customer');
        setCustomerActiveTab('find-services');
        if (navigateFn) navigateFn('customer-dashboard');
        showToast('Step 2/16: Customer selects Plumbing category.', 'info');
      } else if (next === 3) {
        setSelectedLocation('Tumakuru');
        showToast('Step 3/16: Service location set: Siddaganga Ext, Tumakuru.', 'info');
      } else if (next === 4) {
        showToast('Step 4/16: Time slot selected: Today, 11:00 AM.', 'info');
      } else if (next === 5) {
        setCurrentView('customer');
        setCustomerActiveTab('smartmatch');
        if (navigateFn) navigateFn('customer-dashboard');
        showToast('Step 5/16: SmartMatch AI evaluating proximity, availability & rating...', 'info');
      } else if (next === 6) {
        showToast('Step 6/16: AI recommends Ravi Kumar (Plumber, 4.8⭐, 1.4 km, 96% Match).', 'success');
      } else if (next === 7) {
        const newBooking = {
          id: 'BK-2026-SIH',
          customerId: 'customer01',
          customerName: 'Ananya Sharma',
          customer: 'Ananya Sharma',
          customerPhone: '+91 98860 44210',
          service: 'Plumbing',
          serviceIcon: '🔧',
          worker: 'Ravi Kumar',
          workerId: 'worker01',
          workerPhone: '+91 98451 44820',
          workerRating: 4.8,
          workerAvatar: '🔧',
          location: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
          date: 'Today',
          time: '11:00 AM',
          price: 400,
          coopFee: 75,
          platformFee: 25,
          totalPrice: 500,
          status: 'Confirmed',
          etaMinutes: 12,
          distanceKm: 1.4,
          paymentStatus: 'Pending',
          paymentMethod: 'UPI (GPay)',
          issueDescription: 'Bathroom pipe leak and drainage mixer inspection.',
          reviewed: false
        };
        setBookings((prev) => [newBooking, ...prev.filter((b) => b.id !== 'BK-2026-SIH')]);
        setJobRequests((prev) => [
          {
            id: 'REQ-SIH-99',
            bookingId: 'BK-2026-SIH',
            targetTrade: 'Plumber',
            customer: 'Ananya Sharma',
            customerPhone: '+91 98860 44210',
            service: 'Plumbing',
            issue: 'Bathroom pipe leak and drainage mixer inspection.',
            location: 'Siddaganga Ext, Tumakuru',
            distance: '1.4 km',
            time: 'Today, 11:00 AM',
            estimatedPayment: 400,
            customerRating: 4.9,
            status: 'Pending'
          },
          ...prev.filter((r) => r.id !== 'REQ-SIH-99')
        ]);
        showToast('Step 7/16: Booking #BK-2026-SIH confirmed (₹500: ₹400 Worker, ₹75 Co-op, ₹25 Platform).', 'success');
      } else if (next === 8) {
        const raviWorker = workersDirectory.find((w) => w.loginId === 'worker01') || {
          role: 'Worker',
          loginId: 'worker01',
          name: 'Ravi Kumar',
          fullName: 'Ravi Kumar',
          primaryTrade: 'Plumber',
          trade: 'Plumber',
          rating: 4.8
        };
        setCurrentUser(raviWorker);
        setCurrentView('worker');
        setWorkerActiveTab('inbox');
        if (navigateFn) navigateFn('worker-dashboard', raviWorker);
        showToast('Step 8/16: Switched to Worker Dashboard (Ravi Kumar, Master Plumber).', 'info');
      } else if (next === 9) {
        workerAcceptJob('REQ-SIH-99');
        setWorkerActiveTab('active-jobs');
        showToast('Step 9/16: Ravi Kumar ACCEPTED the job request! Added to schedule.', 'success');
      } else if (next === 10) {
        workerUpdateJobStatus('BK-2026-SIH', 'On the Way');
        showToast('Step 10/16: Worker is "On the Way" (Simulated GPS ETA: 8 mins).', 'info');
      } else if (next === 11) {
        workerUpdateJobStatus('BK-2026-SIH', 'Completed');
        showToast('Step 11/16: Service completed! Awaiting payment & customer rating.', 'success');
      } else if (next === 12) {
        const cust = DEMO_CUSTOMERS[0];
        setCurrentUser(cust);
        setCurrentView('customer');
        setCustomerActiveTab('bookings');
        if (navigateFn) navigateFn('customer-dashboard', cust);
        showToast('Step 12/16: Switched back to Customer Dashboard (Ananya Sharma).', 'info');
      } else if (next === 13) {
        customerPayBooking('BK-2026-SIH', 'UPI (GPay)');
        setAnalytics((prev) => ({
          ...prev,
          grossRevenue: prev.grossRevenue + 500,
          workerEarnings: prev.workerEarnings + 400,
          coopWelfareFund: prev.coopWelfareFund + 75,
          platformOps: prev.platformOps + 25,
          jobsCompleted: prev.jobsCompleted + 1
        }));
        showToast('Step 13/16: ₹500 Paid via UPI Escrow! Worker: ₹400, Co-op: ₹75, Ops: ₹25.', 'success');
      } else if (next === 14) {
        customerSubmitReview({
          bookingId: 'BK-2026-SIH',
          workerName: 'Ravi Kumar',
          rating: 5,
          comment: 'Ravi Kumar arrived on time with verified co-op gear. Perfect plumbing fix at standardized rates!',
          tags: ['Punctual', 'Honest Pricing', 'Co-op Pride']
        });
        showToast('Step 14/16: 5-Star Rating & Review submitted for Ravi Kumar!', 'success');
      } else if (next === 15) {
        setCurrentView('admin');
        setActiveAdminTab('dashboard');
        if (navigateFn) navigateFn('admin-portal');
        showToast('Step 15/16: Opened Cooperative Admin Portal (Tumakuru Co-op Society).', 'info');
      } else if (next === 16) {
        setActiveAdminTab('analytics');
        showToast('🎉 Step 16/16: Hackathon Demo Completed! All live metrics updated.', 'success');
      }
      return next;
    });
  };

  // -------------------------------------------------------------
  // WORKER SKILL EXCHANGE HELPER METHODS
  // -------------------------------------------------------------
  const enrollInWorkshop = (workshopId) => {
    const ws = teachingWorkshops.find((w) => w.id === workshopId);
    if (!ws) return;

    if (ws.enrolledLearners >= ws.maxLearners) {
      showToast('This workshop batch is currently full.', 'error');
      return;
    }

    setTeachingWorkshops((prev) =>
      prev.map((w) => (w.id === workshopId ? { ...w, enrolledLearners: w.enrolledLearners + 1 } : w))
    );

    setLearningProgress((prev) => {
      const exists = prev.some((p) => p.skillName.toLowerCase() === ws.skillName.toLowerCase());
      if (exists) return prev;
      return [
        {
          id: `prog-${Date.now()}`,
          workerId: currentUser?.id || 'bhuvan01',
          skillName: ws.skillName,
          category: ws.skillCategory,
          level: ws.skillLevel,
          progressPercent: 0,
          status: 'In Progress (0%)',
          mentorName: ws.teacherName,
          completedModules: 0,
          totalModules: ws.modules?.length || 4,
          nextMilestone: ws.modules?.[0] ? `Module 1: ${ws.modules[0]}` : 'Module 1: Foundations & Safety',
          nextSession: `${ws.availableDays}, ${ws.availableTime}`,
          higherPayingUnlocked: false,
          unlockedJobTitle: `${ws.skillName} Specialist (${ws.higherPayingRate || '₹750/hr'})`
        },
        ...prev
      ];
    });

    showToast(`Enrolled in "${ws.skillName}"! Track progress in "My Learning".`, 'success');
  };

  const publishTeachingWorkshop = (workshopData) => {
    const newWs = {
      id: `ws-${Date.now()}`,
      teacherId: currentUser?.id || 'bhuvan01',
      teacherName: currentUser?.name || currentUser?.fullName || 'Bhuvan S',
      teacherTrade: currentUser?.trade || 'Electrician',
      teacherRating: currentUser?.rating || 4.9,
      teacherAvatar: '⚡',
      verifiedMentor: true,
      enrolledLearners: 0,
      ...workshopData
    };

    setTeachingWorkshops((prev) => [newWs, ...prev]);
    showToast(`Workshop "${workshopData.skillName}" published to the Cooperative Guild!`, 'success');
  };

  const advanceLearningModule = (progId) => {
    setLearningProgress((prev) =>
      prev.map((p) => {
        if (p.id === progId) {
          const nextCompleted = Math.min(p.totalModules, p.completedModules + 1);
          const nextPct = Math.min(100, Math.round((nextCompleted / p.totalModules) * 100));
          const isDone = nextPct === 100;

          if (isDone) {
            showToast(`🎉 Congratulations! You verified "${p.skillName}". Co-op Certificate issued!`, 'success');
          } else {
            showToast(`Practice milestone completed! "${p.skillName}" is now at ${nextPct}%.`, 'info');
          }

          return {
            ...p,
            completedModules: nextCompleted,
            progressPercent: nextPct,
            status: isDone ? 'Verified ✓' : `In Progress (${nextPct}%)`,
            higherPayingUnlocked: isDone,
            certificateId: isDone ? (p.certificateId || `COOP-CERT-${Date.now().toString(36).toUpperCase()}`) : p.certificateId,
            certifiedOn: isDone ? (p.certifiedOn || 'Today') : p.certifiedOn
          };
        }
        return p;
      })
    );
  };

  const respondToSkillExchangeRequest = (reqId, newStatus) => {
    setSkillExchangeRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: newStatus } : r))
    );
    showToast(`Skill barter request ${newStatus.toLowerCase()}!`, newStatus === 'Accepted' ? 'success' : 'info');
  };

  const proposeSkillExchange = (reqData) => {
    const newReq = {
      id: `req-se-${Date.now()}`,
      fromWorkerId: currentUser?.id || 'bhuvan01',
      fromWorkerName: currentUser?.name || currentUser?.fullName || 'Bhuvan S',
      fromWorkerTrade: currentUser?.trade || 'Electrician',
      toWorkerId: reqData.toWorkerId,
      type: 'MUTUAL_BARTER',
      offerSkill: reqData.offerSkill,
      wantSkill: reqData.wantSkill,
      message: reqData.message,
      status: 'Pending',
      date: 'Just now'
    };

    setSkillExchangeRequests((prev) => [newReq, ...prev]);
    showToast(`Skill barter proposal sent to ${reqData.toWorkerName}!`, 'success');
  };

  // ─── CoWork Agri 🌾 State & Handlers ─────────────────────────────────────────
  const [farmers, setFarmers] = useState(() => {
    let base = DEMO_FARMERS;
    const saved = localStorage.getItem('cowork_farmers');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const merged = [...parsed];
          DEMO_FARMERS.forEach((df) => {
            if (!merged.some((m) => m.loginId?.toLowerCase() === df.loginId?.toLowerCase())) {
              merged.push(df);
            }
          });
          return merged;
        }
      } catch {}
    }
    return base;
  });

  useEffect(() => {
    localStorage.setItem('cowork_farmers', JSON.stringify(farmers));
  }, [farmers]);

  const [farmEquipment, setFarmEquipment] = useState(() => {
    const saved = localStorage.getItem('cowork_farm_equipment');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_FARM_EQUIPMENT;
  });

  useEffect(() => {
    localStorage.setItem('cowork_farm_equipment', JSON.stringify(farmEquipment));
  }, [farmEquipment]);

  const [farmerSkills, setFarmerSkills] = useState(() => {
    const saved = localStorage.getItem('cowork_farmer_skills');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_FARMER_SKILLS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_farmer_skills', JSON.stringify(farmerSkills));
  }, [farmerSkills]);

  const [farmerBookings, setFarmerBookings] = useState(() => {
    const saved = localStorage.getItem('cowork_farmer_bookings');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_FARM_BOOKINGS;
  });

  useEffect(() => {
    localStorage.setItem('cowork_farmer_bookings', JSON.stringify(farmerBookings));
  }, [farmerBookings]);

  const [farmerActiveTab, setFarmerActiveTab] = useState('overview');

  // Dynamically resolve current farmer based on logged in account
  const currentFarmer = React.useMemo(() => {
    if (currentUser && (currentUser.role === 'Farmer' || currentUser.loginId?.toLowerCase().startsWith('farmer'))) {
      const match = farmers.find(
        (f) =>
          f.loginId?.toLowerCase() === currentUser.loginId?.toLowerCase() ||
          f.id === currentUser.id ||
          (currentUser.fullName && f.fullName?.toLowerCase() === currentUser.fullName?.toLowerCase())
      );
      if (match) return { ...match, ...currentUser };
      return currentUser;
    }
    return farmers[0] || DEMO_FARMERS[0];
  }, [currentUser, farmers]);

  // ─── Crop Sharing State & API Sync (SIH26089) ─────────────────────────────────
  const [cropPosts, setCropPosts] = useState(() => {
    const saved = localStorage.getItem('cowork_crop_posts');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return [
      {
        id: 'crop_post_001',
        farmer_id: 'farmer01',
        farmer_name: 'Ravi Gowda',
        crop_name: 'Ragi',
        farm_name: 'Green Valley Farm',
        image_url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=900&q=80',
        description: 'Leaves are showing slight yellowing along the margins after two days of pre-monsoon showers. Wondering if this is nitrogen deficiency or waterlogging in red sandy loam.',
        location: 'Tumakuru Rural',
        date: '26 Sep 2026',
        visibility: 'My Cooperative',
        created_at: new Date(Date.now() - 86400000).toISOString(),
        media: [
          {
            id: 'media_001',
            crop_post_id: 'crop_post_001',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=900&q=80',
            created_at: new Date(Date.now() - 86400000).toISOString()
          }
        ],
        comments: [
          {
            id: 'comment_001',
            crop_post_id: 'crop_post_001',
            user_id: 'farmer02',
            user_name: 'Suresh Nayak',
            user_role: 'Farmer',
            comment: 'I had the same issue last season. My field used a different irrigation schedule. Ensure drainage ditches are cleared before adding bio-fertilizer.',
            created_at: new Date(Date.now() - 50000000).toISOString()
          },
          {
            id: 'comment_002',
            crop_post_id: 'crop_post_001',
            user_id: 'mentor_01',
            user_name: 'Prof. Basavaraj (Co-op Agri Mentor)',
            user_role: 'Agronomist',
            comment: 'Red loam drains quickly, so this is likely temporary nitrogen leaching from rain. Spray 1% 19:19:19 or jeevamrutha in the evening.',
            created_at: new Date(Date.now() - 20000000).toISOString()
          }
        ]
      },
      {
        id: 'crop_post_002',
        farmer_id: 'farmer02',
        farmer_name: 'Suresh Nayak',
        crop_name: 'Tomato',
        farm_name: 'Cauvery Organic Orchards',
        image_url: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?auto=format&fit=crop&w=900&q=80',
        description: 'Flower drop noticed in row 3 after the recent humidity spike. Using drip irrigation for 25 minutes twice daily. Looking for organic preventive measures.',
        location: 'Sira, Tumakuru',
        date: '25 Sep 2026',
        visibility: 'My Cooperative',
        created_at: new Date(Date.now() - 172800000).toISOString(),
        media: [
          {
            id: 'media_002',
            crop_post_id: 'crop_post_002',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?auto=format&fit=crop&w=900&q=80',
            created_at: new Date(Date.now() - 172800000).toISOString()
          }
        ],
        comments: [
          {
            id: 'comment_003',
            crop_post_id: 'crop_post_002',
            user_id: 'farmer01',
            user_name: 'Ravi Gowda',
            user_role: 'Farmer',
            comment: 'Try spraying diluted buttermilk + hing solution early morning. It prevented flower drop for my neighbor in Gubbi last month.',
            created_at: new Date(Date.now() - 100000000).toISOString()
          }
        ]
      },
      {
        id: 'crop_post_003',
        farmer_id: 'farmer03',
        farmer_name: 'Chennappa M',
        crop_name: 'Groundnut',
        farm_name: 'Shree Siddaganga Agro Farm',
        image_url: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=900&q=80',
        description: 'Groundnut pegging stage progressing well with sprinkler irrigation. Applied gypsum 10 days ago. Soil moisture is uniform.',
        location: 'Madhugiri, Tumakuru',
        date: '24 Sep 2026',
        visibility: 'Other Farmers',
        created_at: new Date(Date.now() - 259200000).toISOString(),
        media: [
          {
            id: 'media_003',
            crop_post_id: 'crop_post_003',
            media_type: 'image',
            media_url: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=900&q=80',
            created_at: new Date(Date.now() - 259200000).toISOString()
          }
        ],
        comments: []
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('cowork_crop_posts', JSON.stringify(cropPosts));
  }, [cropPosts]);

  // Sync with backend API on mount
  useEffect(() => {
    fetch('/api/crop-sharing/posts')
      .then((res) => (res.ok ? res.json() : null))
      .then((json) => {
        if (json?.success && Array.isArray(json.data) && json.data.length > 0) {
          setCropPosts((prev) => {
            const serverPosts = json.data;
            const customLocalPosts = prev.filter((p) => !serverPosts.some((sp) => sp.id === p.id));
            return [...customLocalPosts, ...serverPosts];
          });
        }
      })
      .catch(() => {});
  }, []);

  // ─── Real-Time WebSocket & Backend API Data Sync ───────────────────────────
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    let socketInstance;
    try {
      socketInstance = io(window.location.origin, {
        transports: ['websocket', 'polling'],
        reconnectionAttempts: 10,
        reconnectionDelay: 1000
      });
      setSocket(socketInstance);
    } catch (e) {
      console.warn('Socket connection fallback:', e);
    }

    return () => {
      if (socketInstance) socketInstance.disconnect();
    };
  }, []);

  // Room Subscription on User / Role changes
  useEffect(() => {
    if (!socket || !currentUser) return;

    const uid = currentUser.id || currentUser.loginId;
    if (uid) {
      socket.emit('join_user', uid);
    }

    const role = (currentUser.role || 'CUSTOMER').toUpperCase();
    socket.emit('join_role', role);
    socket.emit('join_community');
  }, [socket, currentUser]);

  // Real-time Event Listeners
  useEffect(() => {
    if (!socket) return;

    // 1. New Booking received (for Workers & Admins)
    const handleNewBooking = (bookingData) => {
      const uiBooking = {
        id: bookingData.booking_code || `BK-${bookingData.id}`,
        dbId: bookingData.id,
        customerId: `cust-${bookingData.customer_id}`,
        customerName: bookingData.customer_name,
        customer: bookingData.customer_name,
        customerPhone: bookingData.customer_phone,
        service: bookingData.service_title,
        worker: bookingData.worker_id ? 'Assigned' : 'Unassigned',
        workerId: bookingData.worker_id,
        location: bookingData.customer_address || bookingData.city || 'Tumakuru',
        date: bookingData.requested_date || 'Today',
        time: bookingData.requested_time || 'Immediate',
        price: bookingData.estimated_price,
        totalPrice: bookingData.estimated_price,
        status: bookingData.status === 'REQUESTED' ? 'Confirmed' : bookingData.status,
        paymentStatus: bookingData.payment_status || 'Pending',
        issueDescription: bookingData.notes || 'Service requested via CoWork Connect.'
      };

      setBookings((prev) => [uiBooking, ...prev.filter((b) => b.id !== uiBooking.id && b.dbId !== uiBooking.dbId)]);

      if (currentUser?.role === 'Worker') {
        const newReq = {
          id: `REQ-${bookingData.id}`,
          bookingId: uiBooking.id,
          targetTrade: bookingData.service_title,
          customer: bookingData.customer_name,
          customerPhone: bookingData.customer_phone,
          service: bookingData.service_title,
          issue: bookingData.notes || 'Service requested',
          location: uiBooking.location,
          distance: '1.5 km',
          time: `${uiBooking.date}, ${uiBooking.time}`,
          estimatedPayment: bookingData.worker_payout || bookingData.estimated_price,
          status: 'Pending'
        };
        setJobRequests((prev) => [newReq, ...prev.filter((r) => r.id !== newReq.id)]);
        showToast(`🔔 New booking request: ${bookingData.service_title}!`, 'info');
      }
    };

    // 2. Booking Status Updated
    const handleBookingStatusUpdated = ({ bookingId, status, booking }) => {
      const statusMap = {
        REQUESTED: 'Confirmed',
        ACCEPTED: 'Worker Assigned',
        SCHEDULED: 'Scheduled',
        ON_THE_WAY: 'On the Way',
        WORK_STARTED: 'Work Started',
        COMPLETED: 'Completed',
        PAID: 'Completed',
        RATED: 'Completed',
        CANCELLED: 'Cancelled'
      };

      const friendlyStatus = statusMap[status] || status;

      setBookings((prev) =>
        prev.map((b) => {
          if (b.dbId === bookingId || b.id === bookingId || b.id === booking?.booking_code) {
            return {
              ...b,
              status: friendlyStatus,
              paymentStatus: status === 'PAID' ? 'Paid' : b.paymentStatus
            };
          }
          return b;
        })
      );

      setFarmerBookings((prev) =>
        prev.map((b) => {
          if (b.id === bookingId || b.dbId === bookingId) {
            return {
              ...b,
              status: friendlyStatus,
              paymentStatus: status === 'PAID' ? 'Paid' : b.paymentStatus
            };
          }
          return b;
        })
      );
    };

    // 3. Payment Received
    const handlePaymentReceived = ({ bookingId, amount }) => {
      setWorkerStats((prev) => ({
        ...prev,
        todayEarnings: prev.todayEarnings + amount,
        thisMonth: prev.thisMonth + amount,
        grossEarnings: prev.grossEarnings + amount,
        jobsCompleted: prev.jobsCompleted + 1
      }));
      showToast(`💰 Payment received: ₹${amount} credited directly to your account!`, 'success');
    };

    // 4. New Notification
    const handleNewNotification = (notif) => {
      const item = {
        id: notif.id ? `notif-${notif.id}` : `notif-${Date.now()}`,
        title: notif.title,
        message: notif.message,
        time: 'Just now',
        read: false,
        forRole: notif.type || 'All'
      };
      setNotifications((prev) => [item, ...prev]);
    };

    // 5. New Crop Post
    const handleNewCropPost = (post) => {
      setCropPosts((prev) => {
        if (prev.some((p) => p.id === post.id)) return prev;
        return [post, ...prev];
      });
      showToast(`🌾 Community update: ${post.farmer_name} posted on ${post.crop_name}`, 'info');
    };

    // 6. New Crop Comment
    const handleNewCropComment = ({ postId, comment }) => {
      setCropPosts((prev) =>
        prev.map((post) => {
          if (post.id === postId) {
            const comments = post.comments || [];
            if (comments.some((c) => c.id === comment.id)) return post;
            return {
              ...post,
              comments: [...comments, comment]
            };
          }
          return post;
        })
      );
    };

    // 7. Equipment Booked / Listed
    const handleEquipmentBooked = (eqBooking) => {
      setFarmEquipment((prev) =>
        prev.map((e) => (e.id === eqBooking.equipment_id ? { ...e, availability: 'Rented', status: 'Rented' } : e))
      );
      showToast(`🚜 Equipment booked: ${eqBooking.equipment_name} by ${eqBooking.farmer_name}`, 'info');
    };

    const handleNewEquipmentListed = (newEquip) => {
      setFarmEquipment((prev) => {
        if (prev.some((e) => e.id === newEquip.id)) return prev;
        return [{
          id: `eq_${newEquip.id}`,
          name: newEquip.name,
          equipmentName: newEquip.name,
          equipmentType: newEquip.type,
          rentalPrice: newEquip.daily_rate,
          daily_rate: newEquip.daily_rate,
          location: newEquip.location,
          availability: newEquip.availability,
          ownerName: newEquip.owner_name,
          ownerId: newEquip.owner_id,
          condition: newEquip.condition,
          operatorAvailable: newEquip.operator_provided,
          description: newEquip.description
        }, ...prev];
      });
    };

    socket.on('new_booking', handleNewBooking);
    socket.on('new_pool_booking', handleNewBooking);
    socket.on('booking_status_updated', handleBookingStatusUpdated);
    socket.on('payment_received', handlePaymentReceived);
    socket.on('new_notification', handleNewNotification);
    socket.on('new_crop_post', handleNewCropPost);
    socket.on('new_crop_comment', handleNewCropComment);
    socket.on('equipment_booked', handleEquipmentBooked);
    socket.on('new_equipment_listed', handleNewEquipmentListed);

    return () => {
      socket.off('new_booking', handleNewBooking);
      socket.off('new_pool_booking', handleNewBooking);
      socket.off('booking_status_updated', handleBookingStatusUpdated);
      socket.off('payment_received', handlePaymentReceived);
      socket.off('new_notification', handleNewNotification);
      socket.off('new_crop_post', handleNewCropPost);
      socket.off('new_crop_comment', handleNewCropComment);
      socket.off('equipment_booked', handleEquipmentBooked);
      socket.off('new_equipment_listed', handleNewEquipmentListed);
    };
  }, [socket, currentUser]);

  // Initial backend sync for real persistent data
  useEffect(() => {
    // 1. Fetch bookings from backend
    fetch('/api/bookings')
      .then((res) => (res.ok ? res.json() : null))
      .then((json) => {
        if (json?.success && Array.isArray(json.bookings) && json.bookings.length > 0) {
          const mapped = json.bookings.map((b) => ({
            id: b.booking_code || `BK-${b.id}`,
            dbId: b.id,
            customerId: `cust-${b.customer_id}`,
            customerName: b.customer_name,
            customer: b.customer_name,
            customerPhone: b.customer_phone,
            service: b.service_title,
            worker: b.worker_id ? 'Assigned' : 'Unassigned',
            workerId: b.worker_id,
            location: b.customer_address || b.city || 'Tumakuru',
            date: b.requested_date || 'Today',
            time: b.requested_time || 'Immediate',
            price: b.estimated_price,
            totalPrice: b.estimated_price,
            status: b.status === 'REQUESTED' ? 'Confirmed' : b.status === 'ACCEPTED' ? 'Worker Assigned' : b.status === 'ON_THE_WAY' ? 'On the Way' : b.status === 'WORK_STARTED' ? 'Work Started' : b.status === 'COMPLETED' ? 'Completed' : b.status === 'PAID' ? 'Completed' : b.status,
            paymentStatus: b.payment_status === 'SUCCESS' ? 'Paid' : 'Pending',
            issueDescription: b.notes || 'Service requested via CoWork Connect.'
          }));
          setBookings((prev) => {
            const serverIds = new Set(mapped.map((m) => m.id));
            const uniquePrev = prev.filter((p) => !serverIds.has(p.id));
            return [...mapped, ...uniquePrev];
          });
        }
      })
      .catch(() => {});

    // 2. Fetch notifications from backend
    fetch('/api/notifications')
      .then((res) => (res.ok ? res.json() : null))
      .then((json) => {
        if (json?.success && Array.isArray(json.notifications) && json.notifications.length > 0) {
          const mappedNotifs = json.notifications.map((n) => ({
            id: `notif-${n.id}`,
            title: n.title,
            message: n.message,
            time: new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            read: n.is_read,
            forRole: n.type || 'All'
          }));
          setNotifications((prev) => {
            const serverIds = new Set(mappedNotifs.map((m) => m.id));
            const uniquePrev = prev.filter((p) => !serverIds.has(p.id));
            return [...mappedNotifs, ...uniquePrev];
          });
        }
      })
      .catch(() => {});

    // 3. Fetch equipment from backend
    fetch('/api/equipment')
      .then((res) => (res.ok ? res.json() : null))
      .then((json) => {
        if (json?.success && Array.isArray(json.equipment) && json.equipment.length > 0) {
          const mappedEq = json.equipment.map((e) => ({
            id: `eq_${e.id}`,
            dbId: e.id,
            name: e.name,
            equipmentName: e.name,
            equipmentType: e.type,
            rentalPrice: e.daily_rate,
            daily_rate: e.daily_rate,
            location: e.location,
            availability: e.availability,
            ownerName: e.owner_name,
            ownerId: e.owner_id,
            condition: e.condition,
            operatorAvailable: e.operator_provided,
            description: e.description,
            icon: '🚜'
          }));
          setFarmEquipment((prev) => {
            const serverIds = new Set(mappedEq.map((m) => m.id));
            const uniquePrev = prev.filter((p) => !serverIds.has(p.id));
            return [...mappedEq, ...uniquePrev];
          });
        }
      })
      .catch(() => {});
  }, []);

  const addCropPost = async (postData) => {
    const postId = `crop_post_${Date.now()}`;
    const newPost = {
      id: postId,
      farmer_id: currentFarmer.id || currentFarmer.loginId || 'farmer01',
      farmer_name: currentFarmer.fullName || currentFarmer.name || 'Farmer',
      crop_name: postData.crop_name || 'Crop',
      farm_name: currentFarmer.farmName || 'Farm',
      image_url: postData.image_url,
      description: postData.description || '',
      location: postData.location || currentFarmer.location || 'Tumakuru',
      date: postData.date || new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      visibility: postData.visibility || 'My Cooperative',
      created_at: new Date().toISOString(),
      media: [
        {
          id: `media_${Date.now()}`,
          crop_post_id: postId,
          media_type: 'image',
          media_url: postData.image_url,
          created_at: new Date().toISOString()
        }
      ],
      comments: []
    };

    setCropPosts((prev) => [newPost, ...prev]);

    try {
      await fetch('/api/crop-sharing/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPost)
      });
    } catch {}

    showToast(`✓ Crop shared with ${newPost.visibility}!`, 'success');
    return newPost;
  };

  const addCropComment = async (postId, commentText, userRole = 'Farmer') => {
    const newComment = {
      id: `comment_${Date.now()}`,
      crop_post_id: postId,
      user_id: currentUser?.id || currentFarmer.id || 'farmer01',
      user_name: currentUser?.fullName || currentUser?.name || currentFarmer.fullName || 'Fellow Farmer',
      user_role: userRole,
      comment: commentText,
      created_at: new Date().toISOString()
    };

    setCropPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            comments: [...(post.comments || []), newComment]
          };
        }
        return post;
      })
    );

    try {
      await fetch(`/api/crop-sharing/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newComment)
      });
    } catch {}

    showToast('✓ Experience shared with fellow farmer!', 'success');
    return newComment;
  };

  const resetUserPassword = (loginIdOrPhone, newPassword) => {
    let updated = false;
    
    // 1. Check Farmers
    setFarmers((prev) =>
      prev.map((f) => {
        const matchId = f.loginId?.toLowerCase() === loginIdOrPhone?.trim()?.toLowerCase();
        const matchPhone = f.phone?.replace(/\D/g, '') === loginIdOrPhone?.trim()?.replace(/\D/g, '');
        if (matchId || matchPhone) {
          updated = true;
          return { ...f, password: newPassword };
        }
        return f;
      })
    );

    // 2. Check Workers
    setWorkersDirectory((prev) =>
      prev.map((w) => {
        const matchId = w.id?.toLowerCase() === loginIdOrPhone?.trim()?.toLowerCase();
        const matchPhone = w.phone?.replace(/\D/g, '') === loginIdOrPhone?.trim()?.replace(/\D/g, '');
        const matchUsername = w.username?.toLowerCase() === loginIdOrPhone?.trim()?.toLowerCase();
        if (matchId || matchPhone || matchUsername) {
          updated = true;
          return { ...w, password: newPassword };
        }
        return w;
      })
    );

    // 3. Check Registered Users (Customers) in localStorage
    try {
      const storedUsersStr = localStorage.getItem('cowork_registered_users');
      if (storedUsersStr) {
        let storedUsers = JSON.parse(storedUsersStr);
        let userUpdated = false;
        storedUsers = storedUsers.map(u => {
           const matchId = u.loginId?.toLowerCase() === loginIdOrPhone?.trim()?.toLowerCase();
           const matchPhone = u.phone?.replace(/\D/g, '') === loginIdOrPhone?.trim()?.replace(/\D/g, '');
           if (matchId || matchPhone) {
             userUpdated = true;
             updated = true;
             return { ...u, password: newPassword };
           }
           return u;
        });
        if (userUpdated) {
          localStorage.setItem('cowork_registered_users', JSON.stringify(storedUsers));
        }
      }
    } catch (e) {
      console.warn('Failed to parse cowork_registered_users', e);
    }

    if (updated) {
      showToast('Password updated successfully! Please login with your new credentials.', 'success');
    } else {
      showToast('Account not found with this ID/Phone number.', 'error');
    }
    return updated;
  };

  // Farmer Actions
  const createFarmerLabourRequest = (reqData) => {
    const bookingId = `AGBK-${Date.now().toString().slice(-6)}`;
    const cost = reqData.budget ? Number(reqData.budget) : (Number(reqData.workersCount || 1) * 350 * Number(reqData.durationDays || 1));
    
    const newBooking = {
      id: bookingId,
      farmerId: currentFarmer.id || 'farmer01',
      farmerName: currentFarmer.fullName || currentFarmer.name || 'Ravi Gowda',
      farmName: currentFarmer.farmName || 'Green Valley Farm',
      bookingType: 'Worker',
      title: `${reqData.crop || 'Crop'} ${reqData.workType || 'Field Work'} (${reqData.workersCount || 1} Workers)`,
      workerId: reqData.workerId || 'manjunath01',
      workerName: reqData.workerName || 'Manjunath Gowda (Crew Lead)',
      workersCount: Number(reqData.workersCount) || 1,
      workerAvatar: '🌾',
      date: reqData.date || 'Today',
      duration: reqData.duration || '1 Day',
      location: reqData.location || currentFarmer.location || 'Tumakuru',
      estimatedCost: cost,
      finalCost: cost,
      budget: Number(reqData.budget) || cost,
      workType: reqData.workType || 'Harvesting',
      crop: reqData.crop || currentFarmer.primaryCrop || 'Ragi',
      specialRequirements: reqData.specialRequirements || '',
      status: 'Accepted',
      paymentStatus: 'Pending',
      paymentMethod: 'UPI',
      reviewed: false,
      rating: null,
      reviewNotes: null,
      createdAt: new Date().toISOString()
    };

    setFarmerBookings((prev) => [newBooking, ...prev]);

    addNotification({
      forRole: 'Worker',
      title: `🌾 Farm Labour Request: ${newBooking.crop} ${newBooking.workType}`,
      message: `${newBooking.farmerName} requested ${newBooking.workersCount} workers in ${newBooking.location}. Budget: ₹${newBooking.budget}.`
    });

    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '✓ Labour Request Confirmed',
      message: `Request #${bookingId} confirmed with ${newBooking.workerName}.`
    });

    showToast(`Farm labour request #${bookingId} created! Matched with verified agricultural crew.`, 'success');
    return newBooking;
  };

  const bookFarmEquipment = (equipmentId, bookingDetails = {}) => {
    const eq = farmEquipment.find((e) => e.id === equipmentId) || farmEquipment[0];
    const bookingId = `AGBK-${Date.now().toString().slice(-6)}`;
    const cost = bookingDetails.finalCost || eq.rentalPrice;

    const newBooking = {
      id: bookingId,
      farmerId: currentFarmer.id || 'farmer01',
      farmerName: currentFarmer.fullName || currentFarmer.name || 'Ravi Gowda',
      farmName: currentFarmer.farmName || 'Green Valley Farm',
      bookingType: bookingDetails.operatorIncluded ? 'Combined' : 'Equipment',
      title: `${eq.equipmentName || eq.name} Rental`,
      equipmentId: eq.id,
      equipmentName: eq.name || eq.equipmentName,
      equipmentPhoto: eq.icon || '🚜',
      ownerId: eq.ownerId || 'farmer03',
      ownerName: eq.ownerName || 'Anand Gowda',
      ownerPhone: eq.ownerPhone || '+91 94481 22334',
      operatorIncluded: Boolean(bookingDetails.operatorIncluded),
      operatorName: bookingDetails.operatorName || (bookingDetails.operatorIncluded ? 'Basavanna Gowda' : null),
      operatorPhone: bookingDetails.operatorPhone || '+91 98440 91234',
      date: bookingDetails.date || '05 October 2026',
      duration: bookingDetails.duration || '1 Day',
      location: bookingDetails.location || currentFarmer.location || 'Tumakuru',
      estimatedCost: cost,
      finalCost: cost,
      budget: bookingDetails.budget || 1500,
      workType: bookingDetails.workType || 'Field Preparation',
      crop: bookingDetails.crop || currentFarmer.primaryCrop || 'Ragi',
      status: 'Scheduled',
      paymentStatus: 'Pending',
      paymentMethod: 'UPI (Co-op Escrow)',
      reviewed: false,
      rating: null,
      reviewNotes: null,
      createdAt: new Date().toISOString()
    };

    setFarmerBookings((prev) => [newBooking, ...prev]);

    // Async backend booking persistence
    try {
      const numEqId = typeof eq.id === 'number' ? eq.id : parseInt(String(eq.id).replace(/\D/g, '') || '1', 10);
      fetch(`/api/equipment/${numEqId}/book`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmer_id: typeof currentFarmer.id === 'number' ? currentFarmer.id : 7,
          farmer_name: newBooking.farmerName,
          start_date: newBooking.date,
          days: 1
        })
      }).catch(() => {});
    } catch {}

    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '🚜 Equipment Booking Confirmed',
      message: `${eq.equipmentName} booked for ${newBooking.date} (${newBooking.duration}). Total: ₹${cost}.`
    });

    showToast(`Booking #${bookingId} confirmed: ${eq.equipmentName} reserved!`, 'success');
    return newBooking;
  };

  const bookCombinedTractorOperator = (tractorId, operatorId, bookingDetails = {}) => {
    const tractor = farmEquipment.find((e) => e.id === tractorId) || farmEquipment[0];
    const operator = AGRI_WORKERS.find((w) => w.id === operatorId) || AGRI_WORKERS.find(w => w.primaryTrade === 'Farm Equipment Operator') || AGRI_WORKERS[2];
    const bookingId = `AGBK-${Date.now().toString().slice(-6)}`;
    const cost = (tractor.rentalPrice || 1200) + (operator.dailyRate || 400);

    const newBooking = {
      id: bookingId,
      farmerId: currentFarmer.id || 'farmer01',
      farmerName: currentFarmer.fullName || currentFarmer.name || 'Ravi Gowda',
      farmName: currentFarmer.farmName || 'Green Valley Farm',
      bookingType: 'Combined',
      title: `${tractor.equipmentName} + Verified Operator (${operator.name})`,
      equipmentId: tractor.id,
      equipmentName: tractor.name || tractor.equipmentName,
      equipmentPhoto: '🚜',
      ownerId: tractor.ownerId,
      ownerName: tractor.ownerName,
      ownerPhone: tractor.ownerPhone,
      operatorIncluded: true,
      operatorId: operator.id,
      operatorName: operator.name,
      operatorPhone: operator.phone,
      date: bookingDetails.date || '05 October 2026',
      duration: bookingDetails.duration || '1 Day',
      location: bookingDetails.location || currentFarmer.location || 'Tumakuru',
      estimatedCost: cost,
      finalCost: cost,
      budget: bookingDetails.budget || 1600,
      workType: bookingDetails.workType || 'Field Preparation',
      crop: bookingDetails.crop || currentFarmer.primaryCrop || 'Ragi',
      status: 'Scheduled',
      paymentStatus: 'Pending',
      paymentMethod: 'UPI (Co-op Escrow)',
      reviewed: false,
      rating: null,
      reviewNotes: null,
      createdAt: new Date().toISOString()
    };

    setFarmerBookings((prev) => [newBooking, ...prev]);

    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '🚜 Combined SmartMatch Booking Confirmed',
      message: `${tractor.equipmentName} + Driver ${operator.name} booked together for ${newBooking.date} (₹${cost}).`
    });

    showToast(`SmartMatch Combined Booking Confirmed! Tractor + Operator matched.`, 'success');
    return newBooking;
  };

  const listFarmEquipment = (newEqData) => {
    const newId = `eq_${Date.now().toString().slice(-4)}`;
    const newEntry = {
      id: newId,
      name: newEqData.name || newEqData.equipmentName,
      equipmentName: newEqData.name || newEqData.equipmentName,
      equipmentType: newEqData.equipmentType || 'Tractor',
      brand: newEqData.brand || 'Local Cooperative',
      model: newEqData.model || 'Standard',
      condition: newEqData.condition || 'Good',
      location: newEqData.location || currentFarmer.location || 'Tumakuru Rural',
      district: 'Tumakuru',
      distanceKm: 1.5,
      distanceText: '1.5 km away',
      rentalPrice: Number(newEqData.rentalPrice) || 800,
      hourlyPrice: Math.round((Number(newEqData.rentalPrice) || 800) / 7),
      priceUnit: 'day',
      priceDisplay: `₹${Number(newEqData.rentalPrice) || 800}/day`,
      operatorAvailable: Boolean(newEqData.operatorAvailable),
      operatorPricePerDay: newEqData.operatorAvailable ? 400 : 0,
      verified: true,
      verificationStatus: 'Verified',
      availability: 'Available',
      status: 'Available',
      ownerId: currentFarmer.id || 'farmer01',
      ownerName: currentFarmer.fullName || currentFarmer.name || 'Ravi Gowda',
      ownerPhone: currentFarmer.phone || '+91 94480 12345',
      rating: 5.0,
      reviewCount: 0,
      completedRentals: 0,
      photos: [newEqData.icon || '🚜'],
      icon: newEqData.icon || '🚜',
      description: newEqData.description || 'Agricultural equipment available for cooperative farm sharing.',
      suitableFor: [newEqData.equipmentType || 'Farming']
    };

    setFarmEquipment((prev) => [newEntry, ...prev]);

    // Async backend equipment persistence
    try {
      fetch('/api/equipment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          owner_id: typeof currentFarmer.id === 'number' ? currentFarmer.id : 7,
          owner_name: newEntry.ownerName,
          name: newEntry.equipmentName,
          type: newEntry.equipmentType,
          daily_rate: newEntry.rentalPrice,
          location: newEntry.location,
          operator_provided: newEntry.operatorAvailable,
          condition: newEntry.condition,
          description: newEntry.description
        })
      }).catch(() => {});
    } catch {}

    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '✓ Equipment Listed Successfully',
      message: `${newEntry.equipmentName} is now live on CoWork Agri Equipment Sharing.`
    });

    showToast(`"${newEntry.equipmentName}" listed successfully on CoWork Agri!`, 'success');
    return newEntry;
  };

  const requestSkillExchange = (mentorId, skillName) => {
    const mentor = FARMER_SKILL_MENTORS.find((m) => m.id === mentorId) || FARMER_SKILL_MENTORS[0];
    const skillCatalogItem = AGRICULTURAL_SKILLS_CATALOG.find((s) => s.name === skillName || s.id === skillName) || {
      name: skillName,
      category: 'Agronomy'
    };

    const newSkill = {
      id: `fskill_${Date.now().toString().slice(-4)}`,
      farmerId: currentFarmer.id || 'farmer01',
      skillName: skillCatalogItem.name,
      category: skillCatalogItem.category,
      skillLevel: 'Beginner',
      progress: 40,
      verified: false,
      verificationStatus: 'In Training',
      certifiedBy: null,
      certificationDate: null,
      canTeach: false,
      wantingToLearn: false,
      modulesCompleted: 4,
      totalModules: 10,
      mentorName: mentor.name
    };

    setFarmerSkills((prev) => {
      const existsIndex = prev.findIndex((s) => s.skillName.toLowerCase() === skillCatalogItem.name.toLowerCase());
      if (existsIndex >= 0) {
        const copy = [...prev];
        copy[existsIndex] = { ...copy[existsIndex], mentorName: mentor.name, verificationStatus: 'In Training', progress: Math.max(copy[existsIndex].progress, 40) };
        return copy;
      }
      return [...prev, newSkill];
    });

    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '🌱 Skill Learning Request Sent',
      message: `Mentorship request for "${skillCatalogItem.name}" accepted by ${mentor.name}.`
    });

    showToast(`Learning request sent to mentor ${mentor.name}! Training module opened.`, 'success');
  };

  const completeSkillPractice = (skillId) => {
    setFarmerSkills((prev) =>
      prev.map((s) => {
        if (s.id === skillId || s.skillName.toLowerCase() === skillId.toLowerCase()) {
          return {
            ...s,
            progress: 80,
            modulesCompleted: 8,
            skillLevel: 'Advanced',
            verificationStatus: 'Ready for Verification'
          };
        }
        return s;
      })
    );
    showToast(`Practical training completed! Skill submitted for Cooperative verification.`, 'info');
  };

  const verifyFarmerSkill = (farmerId, skillIdOrName) => {
    setFarmerSkills((prev) =>
      prev.map((s) => {
        if (
          s.id === skillIdOrName ||
          s.skillName.toLowerCase() === skillIdOrName.toLowerCase()
        ) {
          return {
            ...s,
            progress: 80,
            modulesCompleted: 8,
            skillLevel: 'Advanced',
            verified: true,
            verificationStatus: 'Verified',
            certifiedBy: 'Tumakuru Farmers Cooperative Guild',
            certificationDate: 'Today'
          };
        }
        return s;
      })
    );

    addNotification({
      forRole: 'Farmer',
      forUserId: farmerId || currentFarmer.id,
      title: '🏅 Skill Certified by Cooperative',
      message: `Your skill "${skillIdOrName}" is verified at Advanced level ✓.`
    });

    showToast(`Skill Verified by Cooperative! Profile updated with Advanced ✓ badge.`, 'success');
  };

  const updateFarmerProfile = (updatedFields) => {
    const updated = { ...currentFarmer, ...updatedFields };
    setFarmers((prev) =>
      prev.map((f) => (f.id === updated.id || f.loginId === updated.loginId ? updated : f))
    );
    if (currentUser?.role === 'Farmer') {
      setCurrentUser(updated);
      localStorage.setItem('cowork_active_session', JSON.stringify(updated));
    }
    showToast('Farmer profile updated successfully!', 'success');
  };

  const payFarmerBooking = (bookingId, method = 'UPI (Co-op Escrow)') => {
    setFarmerBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, paymentStatus: 'Paid', status: 'Completed', paymentMethod: method } : b))
    );
    addNotification({
      forRole: 'Farmer',
      forUserId: currentFarmer.id,
      title: '₹ Payment Successful',
      message: `Booking #${bookingId} payment settled securely via ${method}.`
    });
    showToast(`Payment of booking #${bookingId} completed successfully!`, 'success');
  };

  const rateFarmerBooking = (bookingId, { rating, notes }) => {
    setFarmerBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, reviewed: true, rating, reviewNotes: notes } : b))
    );
    showToast('Rating and feedback recorded. Thank you for supporting the cooperative!', 'success');
  };

  const verifyFarmer = (farmerId) => {
    setFarmers((prev) =>
      prev.map((f) => (f.id === farmerId ? { ...f, verified: true, verificationStatus: 'Verified' } : f))
    );
    showToast(`Farmer verified! Class-F Cooperative Member ID activated.`, 'success');
  };

  const approveEquipment = (eqId) => {
    setFarmEquipment((prev) =>
      prev.map((e) => (e.id === eqId ? { ...e, verified: true, verificationStatus: 'Verified', status: 'Available' } : e))
    );
    showToast(`Equipment listing approved for cooperative booking.`, 'success');
  };

  return (
    <CoopContext.Provider
      value={{
        DEMO_CUSTOMERS,
        INITIAL_DEMO_BOOKINGS,
        currentView,
        setCurrentView,
        currentUser,
        setCurrentUser,
        customerActiveTab,
        setCustomerActiveTab,
        workerActiveTab,
        setWorkerActiveTab,
        activeAdminTab,
        setActiveAdminTab,
        selectedLocation,
        setSelectedLocation,
        isWorkerAvailable,
        setIsWorkerAvailable,
        workerToggleAvailability,
        notifications,
        addNotification,
        toast,
        showToast,
        socket,
        bookings,
        setBookings,
        jobRequests,
        setJobRequests,
        workerStats,
        customerStats,
        analytics,
        setAnalytics,
        proposals,
        selectedAreas,
        workerToggleArea,
        workingRadiusKm,
        setWorkingRadiusKm,
        reviews,
        complaints,
        resolveComplaint,
        approveWorkerVerification,
        emergencyAlert,
        setEmergencyAlert,
        workersDirectory,
        setWorkersDirectory,
        workers: workersDirectory,
        TRADE_DEFINITIONS,
        getTradeIcon,
        calculateSmartMatch,
        updateWorkerProfile,
        createCustomerBooking,
        workerAcceptJob,
        workerDeclineJob,
        workerUpdateJobStatus,
        customerPayBooking,
        customerSubmitReview,
        customerSubmitComplaint,
        customerTriggerEmergency,
        workerVoteProposal,
        // New Additions:
        currentLanguage,
        setLanguage,
        selectedLanguage: currentLanguage,
        setSelectedLanguage: setLanguage,
        t,
        LANGUAGES,
        isDemoModeActive,
        setIsDemoModeActive,
        demoStep,
        setDemoStep,
        startDemoMode,
        exitDemoMode,
        handleNextDemoStep,
        isInnovationModalOpen,
        setIsInnovationModalOpen,
        isImpactModalOpen,
        setIsImpactModalOpen,
        // Worker Skill Exchange:
        teachingWorkshops,
        setTeachingWorkshops,
        learningProgress,
        setLearningProgress,
        skillExchangeRequests,
        setSkillExchangeRequests,
        enrollInWorkshop,
        publishTeachingWorkshop,
        advanceLearningModule,
        respondToSkillExchangeRequest,
        proposeSkillExchange,
        // CoWork Agri 🌾:
        DEMO_FARMER,
        DEMO_FARMERS,
        FARM_WORK_TYPES,
        FARM_EQUIPMENT_TYPES,
        AGRI_WORKERS,
        INITIAL_FARM_EQUIPMENT,
        INITIAL_FARMER_SKILLS,
        FARMER_SKILL_MENTORS,
        FARM_SERVICES_MARKETPLACE,
        INITIAL_FARM_BOOKINGS,
        COOPERATIVE_AGRI_DATA,
        AGRICULTURAL_SKILLS_CATALOG,
        farmers,
        setFarmers,
        currentFarmer,
        farmEquipment,
        setFarmEquipment,
        farmerSkills,
        setFarmerSkills,
        farmerBookings,
        setFarmerBookings,
        farmerActiveTab,
        setFarmerActiveTab,
        cropPosts,
        setCropPosts,
        addCropPost,
        addCropComment,
        resetUserPassword,
        createFarmerLabourRequest,
        bookFarmEquipment,
        bookCombinedTractorOperator,
        listFarmEquipment,
        requestSkillExchange,
        completeSkillPractice,
        verifyFarmerSkill,
        updateFarmerProfile,
        payFarmerBooking,
        rateFarmerBooking,
        verifyFarmer,
        approveEquipment
      }}
    >
      {children}
    </CoopContext.Provider>
  );
};
