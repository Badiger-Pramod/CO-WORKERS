import React, { useState, useRef, useEffect } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Camera,
  X,
  RotateCcw,
  Check,
  Upload,
  RefreshCw,
  Mic,
  MicOff,
  Video,
  Shield,
  Users,
  Lock,
  Building2,
  Sparkles,
  AlertCircle,
  HelpCircle,
  CheckCircle2
} from 'lucide-react';

const COMMON_CROPS = [
  { id: 'Ragi', label: '🌾 Ragi', name: 'Ragi' },
  { id: 'Tomato', label: '🍅 Tomato', name: 'Tomato' },
  { id: 'Groundnut', label: '🥜 Groundnut', name: 'Groundnut' },
  { id: 'Paddy', label: '🌾 Paddy', name: 'Paddy' },
  { id: 'Maize', label: '🌽 Maize', name: 'Maize' },
  { id: 'Vegetables', label: '🌱 Vegetables', name: 'Vegetables' },
  { id: 'Banana', label: '🍌 Banana', name: 'Banana' },
  { id: 'Mango', label: '🥭 Mango', name: 'Mango' },
  { id: 'Other', label: '➕ Other', name: 'Other' },
];

export const CropCameraModal = ({ isOpen, onClose, onCropShared }) => {
  const { currentFarmer, addCropPost, t } = useCoop();
  const farmer = currentFarmer || {};

  // Step state: 'camera' | 'preview' | 'details' | 'success'
  const [step, setStep] = useState('camera');
  const [facingMode, setFacingMode] = useState('environment'); // 'environment' | 'user'
  const [capturedImage, setCapturedImage] = useState(null);
  const [permissionError, setPermissionError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isCameraStarting, setIsCameraStarting] = useState(false);
  const [isRecording, setIsRecording] = useState(false);

  // Form details
  const [selectedCrop, setSelectedCrop] = useState(farmer.primaryCrop || 'Ragi');
  const [customCropName, setCustomCropName] = useState('');
  const [farmName, setFarmName] = useState(farmer.farmName || 'Green Valley Farm');
  const [location, setLocation] = useState(farmer.location || 'Tumakuru');
  const [date, setDate] = useState(() =>
    new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  );
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState('My Cooperative'); // 'Only Me' | 'My Cooperative' | 'Other Farmers' | 'People I Share With'
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Speech Recognition state
  const [isListening, setIsListening] = useState(false);

  // DOM Refs
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const fileInputRef = useRef(null);

  // Stop camera helper
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  // Start camera helper
  const startCamera = async (mode = facingMode) => {
    stopCameraStream();
    setPermissionError(false);
    setErrorMessage('');
    setIsCameraStarting(true);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported on this device/browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setIsCameraStarting(false);
    } catch (err) {
      console.warn('Camera access issue:', err);
      setIsCameraStarting(false);
      setPermissionError(true);
      setErrorMessage(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? t('cameraPermissionRequired', 'Camera permission is required.')
          : 'Unable to start camera stream on this device. You can upload a photo from your gallery.'
      );
    }
  };

  // Trigger camera on open
  useEffect(() => {
    if (isOpen) {
      setStep('camera');
      setCapturedImage(null);
      setPermissionError(false);
      setSelectedCrop(farmer.primaryCrop || 'Ragi');
      setFarmName(farmer.farmName || 'Green Valley Farm');
      setLocation(farmer.location || 'Tumakuru');
      setDescription('');
      setVisibility('My Cooperative');
      startCamera(facingMode);
    } else {
      stopCameraStream();
    }

    return () => {
      stopCameraStream();
    };
  }, [isOpen]);

  // Handle Switch Camera (Front <-> Back)
  const handleToggleFacingMode = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    startCamera(nextMode);
  };

  // Capture Photo from Video Stream
  const handleCapturePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvasRef.current = canvas;

    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Draw current video frame to canvas
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setCapturedImage(dataUrl);
      stopCameraStream();
      setStep('preview');
    }
  };

  // Handle Gallery Upload Fallback
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result;
      if (result) {
        setCapturedImage(result);
        stopCameraStream();
        setStep('preview');
      }
    };
    reader.readAsDataURL(file);
  };

  // Retake Photo
  const handleRetake = () => {
    setCapturedImage(null);
    setStep('camera');
    startCamera(facingMode);
  };

  // Proceed to details
  const handleUsePhoto = () => {
    setStep('details');
  };

  // Voice Crop Input (Web Speech Recognition)
  const handleVoiceInput = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Voice recognition is not supported in this browser. Please select or type the crop name.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'kn-IN'; // Default to Kannada or regional
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      setIsListening(true);
      recognition.start();

      recognition.onresult = (event) => {
        const spokenText = event.results[0][0].transcript.trim();
        setIsListening(false);

        // Match spoken text with known crops
        const match = COMMON_CROPS.find(
          (c) =>
            spokenText.toLowerCase().includes(c.name.toLowerCase()) ||
            c.name.toLowerCase().includes(spokenText.toLowerCase())
        );

        if (match) {
          setSelectedCrop(match.name);
        } else {
          setSelectedCrop('Other');
          setCustomCropName(spokenText);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    } catch {
      setIsListening(false);
    }
  };

  // Share Crop Post
  const handleShareCrop = async () => {
    if (!capturedImage) return;

    setIsSubmitting(true);
    const cropFinal = selectedCrop === 'Other' ? (customCropName || 'Other Crop') : selectedCrop;

    try {
      await addCropPost({
        crop_name: cropFinal,
        image_url: capturedImage,
        description: description.trim(),
        farm_name: farmName,
        location,
        date,
        visibility,
      });

      setStep('success');
      setTimeout(() => {
        setIsSubmitting(false);
        onClose();
        if (onCropShared) onCropShared();
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden text-slate-800 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center text-base">
              📷
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {t('showMyCrop', 'Show My Crop')}
              </h2>
              <p className="text-[11px] text-slate-500">
                {step === 'camera' && 'Point camera at your field or crop'}
                {step === 'preview' && 'Review your photo'}
                {step === 'details' && 'Add crop details & an idea'}
                {step === 'success' && 'Crop shared with community'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCameraStream();
              onClose();
            }}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* ──────────────── STEP 1: CAMERA STREAM VIEW ──────────────── */}
          {step === 'camera' && (
            <div className="space-y-4">
              {permissionError ? (
                /* Permission Error State */
                <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-4">
                  <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                    <Camera className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-800">
                      Camera access needed
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Please allow camera access in your browser or select an existing photo from your device.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => startCamera(facingMode)}
                      className="w-full sm:w-auto px-4 py-2 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Try Again</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full sm:w-auto px-4 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition shadow-xs cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload from Gallery</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Live Viewfinder */
                <div className="relative rounded-xl overflow-hidden bg-black aspect-4/3 flex items-center justify-center border border-slate-200 shadow-xs">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />

                  {isCameraStarting && (
                    <div className="absolute inset-0 bg-slate-900/60 flex flex-col items-center justify-center text-xs text-white gap-2 font-medium">
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>Starting camera...</span>
                    </div>
                  )}

                  {/* Flip Camera Button */}
                  <button
                    type="button"
                    onClick={handleToggleFacingMode}
                    className="absolute top-3 right-3 p-2 rounded-full bg-white/80 hover:bg-white text-slate-700 shadow-xs transition"
                    title="Flip camera"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Hidden file input for gallery upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />

              {/* Minimalist Bottom Controls (Section 11) */}
              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Gallery</span>
                </button>

                {/* Main Capture Button */}
                <button
                  type="button"
                  onClick={handleCapturePhoto}
                  disabled={isCameraStarting}
                  className="flex-1 py-3 px-6 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span className="text-base">●</span>
                  <span>Capture</span>
                </button>
              </div>
            </div>
          )}

          {/* ──────────────── STEP 2: PHOTO PREVIEW ──────────────── */}
          {step === 'preview' && capturedImage && (
            <div className="space-y-4">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-4/3 flex items-center justify-center border border-slate-200">
                <img
                  src={capturedImage}
                  alt="Captured Crop"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Action Buttons: Retake | Use Photo (Section 11) */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleRetake}
                  className="flex-1 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake</span>
                </button>

                <button
                  type="button"
                  onClick={handleUsePhoto}
                  className="flex-1 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Use Photo</span>
                </button>
              </div>
            </div>
          )}

          {/* ──────────────── STEP 3: CROP DETAILS & SHARING ──────────────── */}
          {step === 'details' && (
            <div className="space-y-4">
              {/* Photo Thumbnail + Crop Selector */}
              <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                {capturedImage && (
                  <img
                    src={capturedImage}
                    alt="Crop Thumbnail"
                    className="w-14 h-14 rounded-lg object-cover border border-slate-200 flex-shrink-0"
                  />
                )}
                <div className="flex-1">
                  <div className="text-xs font-medium text-slate-500">Selected Crop</div>
                  <div className="text-base font-bold text-slate-900">
                    {selectedCrop === 'Other' ? (customCropName || 'Other Crop') : selectedCrop}
                  </div>
                </div>
              </div>

              {/* Crop Selector Chips */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Crop:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {COMMON_CROPS.map((c) => {
                    const isSelected = selectedCrop === c.name;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setSelectedCrop(c.name)}
                        className={`py-2 px-2.5 rounded-lg text-xs font-medium text-center border transition cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 text-emerald-900 border-emerald-700 font-semibold'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {c.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Add an idea (Section 11 Requirement) */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Add an idea:
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="I noticed good growth after changing irrigation timing."
                  className="w-full bg-white border border-slate-300 text-slate-900 text-xs rounded-lg p-3 focus:outline-hidden focus:ring-1 focus:ring-emerald-700 focus:border-emerald-700 placeholder-slate-400"
                />
              </div>

              {/* Privacy / Audience Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Who can see this?
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {['My Cooperative', 'Other Farmers', 'Only Me', 'People I Share With'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setVisibility(opt)}
                      className={`p-2.5 rounded-lg border text-left text-xs transition cursor-pointer ${
                        visibility === opt
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit Share Button (Section 11) */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleRetake}
                  className="px-4 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition cursor-pointer"
                >
                  Back
                </button>

                <button
                  type="button"
                  onClick={handleShareCrop}
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 px-4 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition cursor-pointer disabled:opacity-60"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isSubmitting ? 'Sharing...' : 'Share'}</span>
                </button>
              </div>
            </div>
          )}

          {/* ──────────────── STEP 4: SUCCESS CONFIRMATION ──────────────── */}
          {step === 'success' && (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-2xl text-emerald-700">
                ✓
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                Crop Shared!
              </h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Your crop update is now visible in the community feed.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
