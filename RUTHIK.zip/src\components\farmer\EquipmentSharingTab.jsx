import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Tractor,
  Filter,
  Search,
  CheckCircle2,
  ShieldCheck,
  Star,
  MapPin,
  Calendar,
  Clock,
  PlusCircle,
  Sparkles,
  ArrowRight,
  Info,
  DollarSign,
  UserCheck
} from 'lucide-react';
import { FARM_EQUIPMENT_TYPES } from '../../data/agriMockData';

export const EquipmentSharingTab = ({ initialSubTab = 'find', onBookingCreated }) => {
  const {
    farmEquipment = [],
    bookFarmEquipment,
    bookCombinedTractorOperator,
    listFarmEquipment,
    currentFarmer
  } = useCoop();

  const farmer = currentFarmer || {};

  const [subTab, setSubTab] = useState(initialSubTab); // 'find' | 'combined' | 'list'
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [maxPrice, setMaxPrice] = useState(3000);
  const [onlyOperatorAvailable, setOnlyOperatorAvailable] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Booking Modal State
  const [bookingModalEq, setBookingModalEq] = useState(null);
  const [bookingDate, setBookingDate] = useState('06 October 2026');
  const [bookingDuration, setBookingDuration] = useState('1 Day');
  const [includeOperator, setIncludeOperator] = useState(false);

  // List Equipment Form State
  const [newEqName, setNewEqName] = useState('');
  const [newEqType, setNewEqType] = useState('Tractor');
  const [newEqBrand, setNewEqBrand] = useState('Mahindra');
  const [newEqModel, setNewEqModel] = useState('');
  const [newEqRate, setNewEqRate] = useState(1000);
  const [newEqHasOperator, setNewEqHasOperator] = useState(false);
  const [newEqDesc, setNewEqDesc] = useState('');

  // Filter equipment
  const filteredEquipment = farmEquipment.filter((eq) => {
    if (selectedCategory !== 'All' && eq.equipmentType !== selectedCategory) return false;
    if (eq.rentalPrice > maxPrice) return false;
    if (onlyOperatorAvailable && !eq.operatorAvailable) return false;
    if (searchQuery && !eq.name.toLowerCase().includes(searchQuery.toLowerCase()) && !eq.brand?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const handleOpenBookingModal = (eq, forceOperator = false) => {
    setBookingModalEq(eq);
    setIncludeOperator(forceOperator || eq.operatorAvailable);
    setBookingDuration('1 Day');
  };

  const handleConfirmBooking = () => {
    if (!bookingModalEq) return;

    const days = bookingDuration.includes('2') ? 2 : bookingDuration.includes('3') ? 3 : bookingDuration.includes('Week') ? 7 : 1;
    const baseCost = (bookingModalEq.rentalPrice || 1200) * days;
    const operatorCost = includeOperator ? (bookingModalEq.operatorPricePerDay || 400) * days : 0;
    const totalCost = baseCost + operatorCost;

    const booking = bookFarmEquipment(bookingModalEq.id, {
      date: bookingDate,
      duration: bookingDuration,
      operatorIncluded: includeOperator,
      finalCost: totalCost,
      estimatedCost: totalCost,
      budget: totalCost,
      location: farmer.location || 'Tumakuru Rural',
      crop: farmer.primaryCrop || 'Ragi',
      workType: 'Field Preparation & Ploughing'
    });

    setBookingModalEq(null);
    if (onBookingCreated) {
      onBookingCreated(booking);
    }
  };

  const handleCombinedBooking = (tractorId) => {
    const booking = bookCombinedTractorOperator(tractorId, 'agri03', {
      date: '06 October 2026',
      duration: '1 Day',
      budget: 1600,
      workType: 'Field Ploughing & Harrowing',
      crop: farmer.primaryCrop || 'Ragi',
      location: farmer.location || 'Tumakuru Rural'
    });

    if (onBookingCreated) {
      onBookingCreated(booking);
    }
  };

  const handleListEquipmentSubmit = (e) => {
    e.preventDefault();
    if (!newEqName) return;

    listFarmEquipment({
      name: newEqName,
      equipmentName: newEqName,
      equipmentType: newEqType,
      brand: newEqBrand,
      model: newEqModel || 'Standard',
      rentalPrice: Number(newEqRate),
      operatorAvailable: newEqHasOperator,
      description: newEqDesc || 'Agricultural equipment available for cooperative farm sharing.',
      icon: newEqType === 'Tractor' ? '🚜' : newEqType === 'Harvester' ? '🌾' : '⚙️'
    });

    setNewEqName('');
    setNewEqModel('');
    setNewEqDesc('');
    setSubTab('find');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Header & Navigation Sub-Tabs ─────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🚜</span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              Agricultural Equipment Sharing & Rental
            </h2>
          </div>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            Rent tractors, tillers, harvesters, and implements from nearby verified cooperative farmers at transparent community rates.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 border border-slate-200 p-1 rounded-xl flex-shrink-0">
          <button
            onClick={() => setSubTab('find')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
              subTab === 'find'
                ? 'bg-emerald-800 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Find Equipment
          </button>

          <button
            onClick={() => setSubTab('combined')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition ${
              subTab === 'combined'
                ? 'bg-amber-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Tractor + Operator
          </button>

          <button
            onClick={() => setSubTab('list')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition ${
              subTab === 'list'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            List My Equipment
          </button>
        </div>
      </div>

      {/* =========================================================================
          SUB-TAB 1: Find Equipment (Sections 7, 8)
      ========================================================================= */}
      {subTab === 'find' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-4">
            <div className="flex flex-col md:flex-row gap-3">
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search Mahindra, John Deere, Rotavator, Harvester..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Operator available filter */}
              <label className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-4 py-2 rounded-xl text-xs text-slate-300 font-semibold cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={onlyOperatorAvailable}
                  onChange={(e) => setOnlyOperatorAvailable(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-0 bg-slate-50 border-slate-700"
                />
                <span>Operator Available Only</span>
              </label>

              {/* Max budget filter */}
              <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-4 py-2 rounded-xl text-xs text-slate-300">
                <span className="text-slate-400 font-bold whitespace-nowrap">Max Price:</span>
                <span className="text-emerald-800 font-black whitespace-nowrap">₹{maxPrice}/day</span>
                <input
                  type="range"
                  min="400"
                  max="3500"
                  step="100"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-24 accent-emerald-500"
                />
              </div>
            </div>

            {/* Category Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setSelectedCategory('All')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  selectedCategory === 'All'
                    ? 'bg-emerald-800 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                All Equipment ({farmEquipment.length})
              </button>
              {FARM_EQUIPMENT_TYPES.map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedCategory(type)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                    selectedCategory === type
                      ? 'bg-emerald-800 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Equipment Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredEquipment.map((eq) => {
              const isMahindraDemoTractor = eq.id === 'eq01';

              return (
                <div
                  key={eq.id}
                  className={`bg-white border rounded-2xl shadow-2xs p-5 flex flex-col justify-between transition-all group ${
                    isMahindraDemoTractor
                      ? 'border-emerald-500 shadow-lg shadow-emerald-500/10'
                      : 'border-slate-200 hover:border-emerald-600'
                  }`}
                >
                  <div>
                    {/* Top Row: Icon + Name + Verification */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-800 flex items-center justify-center text-3xl flex-shrink-0">
                          {eq.icon || '🚜'}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h3 className="text-slate-900 font-black text-sm">{eq.name}</h3>
                            {eq.verified && (
                              <ShieldCheck className="w-4 h-4 text-emerald-800" title="Cooperative Inspected" />
                            )}
                          </div>
                          <p className="text-slate-400 text-xs mt-0.5">
                            {eq.brand} · {eq.model}
                          </p>
                        </div>
                      </div>

                      <span className="bg-emerald-900/60 text-emerald-800 border border-emerald-800 text-[11px] font-black px-2.5 py-1 rounded-full whitespace-nowrap">
                        {eq.priceDisplay || `₹${eq.rentalPrice}/day`}
                      </span>
                    </div>

                    {/* Owner & Proximity */}
                    <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-400 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-800" /> {eq.location}
                        </span>
                        <span className="font-bold text-slate-300">{eq.distanceText || `${eq.distanceKm} km away`}</span>
                      </div>

                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-400">Owner:</span>
                        <span className="text-white font-semibold">{eq.ownerName}</span>
                      </div>

                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-400">Operator Option:</span>
                        <span className={`font-bold ${eq.operatorAvailable ? 'text-amber-400' : 'text-slate-500'}`}>
                          {eq.operatorAvailable ? `Yes (+₹${eq.operatorPricePerDay}/day)` : 'No (Bring own driver)'}
                        </span>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-slate-400 text-xs mt-3 line-clamp-2 leading-relaxed">
                      {eq.description}
                    </p>

                    {/* Suitability Pills */}
                    <div className="flex flex-wrap gap-1 mt-3">
                      {eq.suitableFor?.slice(0, 3).map((item) => (
                        <span key={item} className="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded-md">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Booking CTA */}
                  <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
                    <button
                      onClick={() => handleOpenBookingModal(eq, false)}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md shadow-emerald-600/20"
                    >
                      <Tractor className="w-3.5 h-3.5" />
                      <span>Book Equipment</span>
                    </button>

                    {eq.operatorAvailable && (
                      <button
                        onClick={() => handleOpenBookingModal(eq, true)}
                        className="py-2.5 px-3 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-600/50 font-bold text-xs flex items-center justify-center transition active:scale-95"
                        title="Book with Verified Operator"
                      >
                        <UserCheck className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 2: Section 10 Combined Tractor + Operator Matching
      ========================================================================= */}
      {subTab === 'combined' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-emerald-950/80 border border-amber-800/60 rounded-3xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-3xl">
                🚜
              </div>
              <div>
                <span className="text-[10px] font-black tracking-wider uppercase text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                  Section 10 Feature
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Need Tractor + Verified Operator?
                </h3>
                <p className="text-slate-300 text-xs sm:text-sm">
                  Never worry about driving heavy farm machinery yourself. Book a high-torque tractor bundled with an experienced, cooperative-verified driver in a single hassle-free transaction.
                </p>
              </div>
            </div>

            {/* Combined Match Spotlight Card */}
            <div className="bg-white border border-slate-200 shadow-2xs rounded-2xl p-5 mt-4 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              {/* Tractor details */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase">1. Selected Equipment</span>
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🚜</span>
                  <div>
                    <h4 className="text-slate-900 font-bold text-sm">Mahindra 575 DI Tractor</h4>
                    <p className="text-xs text-slate-400">45 HP · Owner: Anand Gowda</p>
                    <p className="text-xs text-emerald-800 font-bold">₹1,200 / day</p>
                  </div>
                </div>
              </div>

              {/* Operator details */}
              <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-800 md:pl-6">
                <span className="text-[10px] font-bold text-slate-400 uppercase">2. Matched Operator</span>
                <div className="flex items-center gap-3">
                  <span className="text-3xl">👨‍🌾</span>
                  <div>
                    <h4 className="text-slate-900 font-bold text-sm">Basavanna Gowda</h4>
                    <p className="text-xs text-slate-400">12 yrs exp · 230 completed jobs</p>
                    <p className="text-xs text-amber-400 font-bold">₹400 / day operator fee</p>
                  </div>
                </div>
              </div>

              {/* Total & Action */}
              <div className="space-y-3 border-t md:border-t-0 md:border-l border-slate-800 md:pl-6 text-center md:text-left">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Combined Daily Cost</span>
                  <p className="text-2xl font-black text-emerald-800">₹1,600 <span className="text-xs font-normal text-slate-400">/ day</span></p>
                  <p className="text-[11px] text-slate-400">Zero coordination hassle · Escrow protected</p>
                </div>

                <button
                  onClick={() => handleCombinedBooking('eq01')}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-amber-500/20 active:scale-95"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Book Tractor + Driver (1-Click)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 3: Section 9 List My Equipment
      ========================================================================= */}
      {subTab === 'list' && (
        <div className="bg-slate-50 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h3 className="text-slate-900 font-bold text-lg flex items-center gap-2">
              ➕ List Agricultural Equipment for Cooperative Rental
            </h3>
            <p className="text-slate-400 text-xs mt-1">
              Monetize your idle farm machinery. Cooperative equipment listings are inspected, insured, and protected by escrow deposits.
            </p>
          </div>

          <form onSubmit={handleListEquipmentSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Equipment Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Swaraj 744 FE Tractor, Honda Water Pump"
                  value={newEqName}
                  onChange={(e) => setNewEqName(e.target.value)}
                  className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Equipment Category
                </label>
                <select
                  value={newEqType}
                  onChange={(e) => setNewEqType(e.target.value)}
                  className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                >
                  {FARM_EQUIPMENT_TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Manufacturer / Brand
                </label>
                <input
                  type="text"
                  placeholder="e.g. Mahindra, John Deere, Shaktiman"
                  value={newEqBrand}
                  onChange={(e) => setNewEqBrand(e.target.value)}
                  className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Model / Horsepower
                </label>
                <input
                  type="text"
                  placeholder="e.g. 45 HP, 7 Tynes, 3-inch discharge"
                  value={newEqModel}
                  onChange={(e) => setNewEqModel(e.target.value)}
                  className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Daily Rental Rate (₹ / Day) <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 text-xs">₹</span>
                  <input
                    type="number"
                    min="100"
                    step="50"
                    required
                    value={newEqRate}
                    onChange={(e) => setNewEqRate(Math.max(100, parseInt(e.target.value) || 500))}
                    className="w-full pl-7 pr-3 bg-white border border-slate-300 text-slate-800 rounded-xl py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Operator Availability
                </label>
                <div className="flex items-center gap-3 pt-2">
                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      name="operatorOpt"
                      checked={newEqHasOperator}
                      onChange={() => setNewEqHasOperator(true)}
                      className="text-emerald-500"
                    />
                    <span>Yes, I can operate or provide driver</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      name="operatorOpt"
                      checked={!newEqHasOperator}
                      onChange={() => setNewEqHasOperator(false)}
                      className="text-emerald-500"
                    />
                    <span>Equipment only</span>
                  </label>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Description & Special Operating Guidelines
              </label>
              <textarea
                rows="3"
                value={newEqDesc}
                onChange={(e) => setNewEqDesc(e.target.value)}
                placeholder="Describe equipment condition, attachments included (plough, trolley, rotavator), fuel policy, etc."
                className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSubTab('find')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 active:scale-95"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Publish Equipment Listing</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ─── Equipment Booking Modal ──────────────────────────────── */}
      {bookingModalEq && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-50 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-5 animate-scale-up">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-slate-900 font-black text-base">
                  Confirm Equipment Booking
                </h3>
                <p className="text-emerald-800 text-xs font-semibold mt-0.5">
                  {bookingModalEq.name} · ₹{bookingModalEq.rentalPrice}/day
                </p>
              </div>
              <button
                onClick={() => setBookingModalEq(null)}
                className="text-slate-400 hover:text-slate-900 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Rental Start Date</label>
                <input
                  type="text"
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Duration</label>
                <select
                  value={bookingDuration}
                  onChange={(e) => setBookingDuration(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="1 Day">1 Day</option>
                  <option value="2 Days">2 Days</option>
                  <option value="3 Days">3 Days</option>
                  <option value="1 Week">1 Week</option>
                </select>
              </div>

              {bookingModalEq.operatorAvailable && (
                <div className="bg-amber-950/40 border border-amber-800/60 rounded-xl p-3">
                  <label className="flex items-center gap-2 text-amber-200 font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeOperator}
                      onChange={(e) => setIncludeOperator(e.target.checked)}
                      className="rounded text-amber-500 focus:ring-0"
                    />
                    <span>Include Verified Operator (+₹{bookingModalEq.operatorPricePerDay}/day)</span>
                  </label>
                  <p className="text-[11px] text-amber-300/80 mt-1 pl-6">
                    A certified driver will arrive with the machine to handle the operation safely.
                  </p>
                </div>
              )}

              {/* Total Calculation */}
              <div className="bg-slate-800 rounded-xl p-3 space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>Base Machine Rental:</span>
                  <span>₹{bookingModalEq.rentalPrice} × {bookingDuration}</span>
                </div>
                {includeOperator && (
                  <div className="flex justify-between text-slate-400">
                    <span>Operator Fee:</span>
                    <span>₹{bookingModalEq.operatorPricePerDay} × {bookingDuration}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-900 font-bold pt-1 border-t border-slate-700">
                  <span>Estimated Total:</span>
                  <span className="text-emerald-800 text-sm">
                    ₹{(bookingModalEq.rentalPrice + (includeOperator ? bookingModalEq.operatorPricePerDay : 0)) * (bookingDuration.includes('2') ? 2 : bookingDuration.includes('3') ? 3 : bookingDuration.includes('Week') ? 7 : 1)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setBookingModalEq(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmBooking}
                className="px-5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95"
              >
                Confirm Booking
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
