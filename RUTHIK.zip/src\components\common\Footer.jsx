import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Users,
  ShieldCheck,
  HeartHandshake,
  Percent,
  CheckCircle2,
  HelpCircle,
  Phone,
  Scale
} from 'lucide-react';

export const Footer = () => {
  const { role, setRole } = useCoop();

  return (
    <footer className="bg-slate-900 text-white mt-auto border-t border-slate-800">
      {/* 7 ICA Cooperative Principles Strip */}
      <div className="bg-emerald-950/80 border-b border-emerald-800/40 py-4 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 font-bold text-emerald-300">
            <Scale className="w-4 h-4 text-emerald-400" />
            <span>ICA Co-operative Principles:</span>
          </div>
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-emerald-100/80 text-[11px]">
            <span>1. Open & Voluntary Membership</span>
            <span>2. Democratic Member Control (1 Member, 1 Vote)</span>
            <span>3. Member Economic Participation</span>
            <span>4. Autonomy & Independence</span>
            <span>5. Education, Training & Information</span>
            <span>6. Cooperation Among Co-operatives</span>
            <span>7. Concern for Community</span>
          </div>
        </div>
      </div>

      {/* Main Footer Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: About */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-md">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="font-extrabold text-xl text-white">
                  Seva<span className="text-emerald-400">Setu</span>
                </span>
                <span className="block text-[10px] text-emerald-300 font-semibold tracking-wider uppercase">
                  Cooperative Gig Platform
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              CoWork Connect — A democratic, worker-owned digital platform cooperative connecting Indian households with verified local service workers through AI SmartMatch and transparent fair earnings.
            </p>
            <div className="text-[11px] text-slate-500 font-mono">
              Tumakuru Co-op Society Reg #2026-KA-TMK-019
            </div>
          </div>

          {/* Col 2: Transparent Economics */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">Transparent Economics</h4>
            <ul className="text-xs space-y-1.5 text-slate-400">
              <li className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span><strong>80% (₹400)</strong> Direct Worker Compensation</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                <span><strong>15% (₹75)</strong> Co-op Welfare & Healthcare Pool</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                <span><strong>5% (₹25)</strong> Platform Infrastructure & Hosting</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span><strong>100%</strong> Net Annual Profits Paid as Dividends</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Portal Switching Shortcuts */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">Demo Role Portals</h4>
            <div className="flex flex-col space-y-1.5 text-xs">
              <button
                onClick={() => setRole('landing')}
                className={`text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                  role === 'landing' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🌐 Public Overview</span>
                <span className="text-[10px] text-slate-500">Landing</span>
              </button>
              <button
                onClick={() => setRole('customer')}
                className={`text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                  role === 'customer' ? 'bg-emerald-800/70 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🏠 Customer Portal</span>
                <span className="text-[10px] text-emerald-400">Ananya Sharma</span>
              </button>
              <button
                onClick={() => setRole('worker')}
                className={`text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                  role === 'worker' ? 'bg-emerald-800/70 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🛠️ Worker Co-owner Hub</span>
                <span className="text-[10px] text-emerald-400">Ravi Kumar</span>
              </button>
              <button
                onClick={() => setRole('admin')}
                className={`text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                  role === 'admin' ? 'bg-emerald-800/70 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🛡️ Cooperative Admin</span>
                <span className="text-[10px] text-indigo-400">S. R. Patil</span>
              </button>
            </div>
          </div>

          {/* Col 4: Safety & Support */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">Karnataka Co-op Network</h4>
            <p className="text-xs text-slate-400">
              Federated network across Tumakuru, Bengaluru, Mysuru, Mangaluru, and Hubballi.
            </p>
            <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-xs text-slate-300 space-y-1">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Toll-Free Helpline: <strong>1800-SEVA-SETU</strong></span>
              </div>
              <p className="text-[11px] text-slate-400 pl-6">Available in Kannada, English & Hindi</p>
            </div>
          </div>

        </div>

        {/* Copyright */}
        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-500">
          <div>
            © 2026 CoWork Connect Cooperative Gig Services Platform. Registered under Karnataka Cooperative Societies Act.
          </div>
          <div className="flex gap-4">
            <span className="hover:text-slate-400 cursor-pointer">Co-op By-laws</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Audited Ledger</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Worker Safety Charter</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
