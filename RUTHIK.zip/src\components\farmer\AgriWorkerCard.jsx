import React from 'react';
import { ShieldCheck, Star, MapPin, Clock, Users, Award, Mic } from 'lucide-react';

export const AgriWorkerCard = ({ worker, onSelect, isSelected = false, showMatchScore = false, isLowConnectivity = false }) => {
  if (!worker) return null;

  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(worker.rating));

  return (
    <div
      onClick={() => onSelect?.(worker)}
      className={`relative rounded-2xl border-2 transition-all cursor-pointer
        ${isSelected
          ? 'border-emerald-500 bg-emerald-950/60 shadow-lg shadow-emerald-500/20'
          : 'border-slate-700 bg-slate-800/60 hover:border-emerald-700 hover:bg-slate-800'
        }
        ${isLowConnectivity ? 'p-5' : 'p-4'}
      `}
    >
      {/* Match Score Badge */}
      {showMatchScore && worker.matchScore !== undefined && (
        <div className="absolute top-3 right-3 bg-emerald-600 text-white text-xs font-black px-2 py-0.5 rounded-full">
          {worker.matchScore}% match
        </div>
      )}

      {/* Selected badge */}
      {isSelected && (
        <div className="absolute top-3 left-3 bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
          <ShieldCheck className="w-3 h-3" /> Selected
        </div>
      )}

      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div className={`flex-shrink-0 rounded-2xl bg-emerald-900 flex items-center justify-center ${isLowConnectivity ? 'w-16 h-16 text-4xl' : 'w-12 h-12 text-2xl'}`}>
          {worker.avatar}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className={`font-black text-white ${isLowConnectivity ? 'text-lg' : 'text-sm'}`}>
              {worker.name}
            </h3>
            {worker.verified && (
              <span className="flex items-center gap-1 text-[10px] bg-blue-900 text-blue-300 border border-blue-700 px-1.5 py-0.5 rounded-full font-bold">
                <ShieldCheck className="w-2.5 h-2.5" /> Verified
              </span>
            )}
            {worker.coopMember && (
              <span className="text-[10px] bg-emerald-900 text-emerald-300 border border-emerald-700 px-1.5 py-0.5 rounded-full font-bold">
                🤝 Co-op
              </span>
            )}
            {!worker.available && (
              <span className="text-[10px] bg-red-900 text-red-300 border border-red-700 px-1.5 py-0.5 rounded-full font-bold">
                Unavailable
              </span>
            )}
          </div>

          <p className={`text-emerald-400 font-semibold mt-0.5 ${isLowConnectivity ? 'text-base' : 'text-xs'}`}>
            {worker.primarySkill}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1">
            <div className="flex">
              {stars.map((filled, i) => (
                <Star key={i} className={`w-3 h-3 ${filled ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`} />
              ))}
            </div>
            <span className="text-slate-300 text-xs font-semibold">{worker.rating}</span>
            <span className="text-slate-500 text-xs">({worker.reviewCount} reviews)</span>
          </div>

          {/* Meta row */}
          <div className="flex items-center gap-3 mt-1.5 flex-wrap">
            <span className="flex items-center gap-1 text-slate-400 text-xs">
              <MapPin className="w-3 h-3 text-emerald-500" />
              {worker.distanceKm} km
            </span>
            <span className="flex items-center gap-1 text-slate-400 text-xs">
              <Clock className="w-3 h-3 text-blue-400" />
              {worker.experience} yrs exp
            </span>
            <span className="flex items-center gap-1 text-slate-400 text-xs">
              <Award className="w-3 h-3 text-amber-400" />
              {worker.completedJobs} jobs
            </span>
          </div>

          {/* Skills */}
          <div className="flex flex-wrap gap-1 mt-2">
            {worker.skills?.slice(0, 3).map((skill) => (
              <span key={skill} className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                {skill}
              </span>
            ))}
          </div>

          {/* Languages */}
          {worker.languages?.length > 0 && (
            <div className="flex items-center gap-1 mt-2">
              <Mic className="w-3 h-3 text-slate-500" />
              <span className="text-xs text-slate-400">
                {worker.languages.map(l => l.toUpperCase()).join(' · ')}
              </span>
            </div>
          )}

          {/* Match reasons */}
          {showMatchScore && worker.matchReasons?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {worker.matchReasons.map((r) => (
                <span key={r} className="text-[10px] bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded-full">
                  ✓ {r}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Rate & Select CTA */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-700">
        <span className="text-white font-black text-sm">₹{worker.hourlyRate}<span className="text-slate-400 font-normal text-xs">/hr</span></span>
        <button
          onClick={(e) => { e.stopPropagation(); onSelect?.(worker); }}
          disabled={!worker.available}
          className={`px-4 py-1.5 rounded-xl font-bold text-xs transition-all
            ${worker.available
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
              : 'bg-slate-700 text-slate-500 cursor-not-allowed'
            }
            ${isLowConnectivity ? 'text-base px-5 py-2' : ''}
          `}
        >
          {worker.available ? 'Request' : 'Unavailable'}
        </button>
      </div>
    </div>
  );
};
