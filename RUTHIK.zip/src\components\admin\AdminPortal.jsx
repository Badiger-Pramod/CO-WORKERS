import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  ShieldCheck,
  Users,
  TrendingUp,
  HeartHandshake,
  Percent,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileCheck,
  MapPin,
  Flame,
  ArrowUpRight,
  Filter,
  DollarSign,
  Activity,
  Layers,
  Sparkles,
  HelpCircle,
  Check,
  Scale,
  Award,
  Phone,
  Clock,
  Briefcase,
  Tractor,
  Wheat,
  Sprout
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';

export const AdminPortal = () => {
  const coopContext = useCoop();
  const [localAdminTab, setLocalAdminTab] = useState('dashboard');
  
  const activeAdminTab = coopContext?.activeAdminTab || localAdminTab;
  const setActiveAdminTab = coopContext?.setActiveAdminTab || setLocalAdminTab;
  const complaints = coopContext?.complaints || [];
  const showToast = coopContext?.showToast || console.log;
  const rawAnalytics = coopContext?.analytics;
  const t = coopContext?.t || ((k, d) => d || k);

  const farmers = coopContext?.farmers || [];
  const farmEquipment = coopContext?.farmEquipment || [];
  const farmerBookings = coopContext?.farmerBookings || [];
  const farmerSkills = coopContext?.farmerSkills || [];
  const verifyFarmer = coopContext?.verifyFarmer || (() => {});
  const approveEquipment = coopContext?.approveEquipment || (() => {});
  const verifyFarmerSkill = coopContext?.verifyFarmerSkill || (() => {});

  const defaultAnalytics = {
    totalMembers: 342,
    activeWorkers: 128,
    jobsCompleted: 1420,
    grossRevenue: 3250000,
    coopWelfareFund: 487500,
    workerEarnings: 2600000,
    platformOps: 162500,
    customerSatisfaction: 98.4
  };
  const analytics = { ...defaultAnalytics, ...(rawAnalytics || {}) };

  const [disputeFilter, setDisputeFilter] = useState('ALL');

  // Pending worker verification applicants
  const [pendingApplicants, setPendingApplicants] = useState([
    {
      id: 'app-001',
      name: 'Suresh Gowda',
      trade: 'Electrical Specialist',
      experienceYears: 7,
      phone: '+91 94480 32189',
      location: 'Siddaganga Ext, Tumakuru',
      appliedDate: 'Yesterday',
      credentials: [
        { name: 'Aadhaar Card', status: 'VERIFIED' },
        { name: 'Govt ITI Level 5 Electrician License', status: 'VERIFIED' },
        { name: 'Police Verification Record', status: 'VERIFIED' }
      ],
      notes: 'Passed trade skill practical exam administered by Tumakuru Guild Committee.'
    },
    {
      id: 'app-002',
      name: 'Lakshmi Devi',
      trade: 'Deep Cleaning & Sanitization',
      experienceYears: 5,
      phone: '+91 98451 90812',
      location: 'Ashok Nagar, Tumakuru',
      appliedDate: '2 days ago',
      credentials: [
        { name: 'Aadhaar Card', status: 'VERIFIED' },
        { name: 'National Skill Development (NSDC) Certificate', status: 'VERIFIED' },
        { name: 'Police Verification Record', status: 'PENDING_AUDIT' }
      ],
      notes: 'Police check in final verification stage with Tumakuru SP office.'
    },
    {
      id: 'app-003',
      name: 'Ramesh Naik',
      trade: 'Carpentry & Furniture Repair',
      experienceYears: 9,
      phone: '+91 97312 88401',
      location: 'Batawadi, Tumakuru',
      appliedDate: '3 days ago',
      credentials: [
        { name: 'Aadhaar Card', status: 'VERIFIED' },
        { name: 'Master Carpenter Guild Endorsement', status: 'VERIFIED' },
        { name: 'Police Verification Record', status: 'VERIFIED' }
      ],
      notes: 'Recommended by 3 active Tumakuru Class A Co-owners.'
    }
  ]);

  const handleApproveApplicant = (appId) => {
    const app = pendingApplicants.find(a => a.id === appId);
    setPendingApplicants(prev => prev.filter(a => a.id !== appId));
    showToast(`Approved ${app?.name}! Issued Class A Shareholder Equity & Co-owner ID.`, 'success');
  };

  const handleRejectApplicant = (appId) => {
    setPendingApplicants(prev => prev.filter(a => a.id !== appId));
    showToast(`Applicant requested to resubmit missing verification documents.`, 'info');
  };

  // Recharts Monthly Revenue & Transparent 80/15/5 Distribution
  const monthlyAdminChartData = [
    { month: 'Apr', workerShare: 420000, welfarePool: 78750, opsFee: 26250 },
    { month: 'May', workerShare: 480000, welfarePool: 90000, opsFee: 30000 },
    { month: 'Jun', workerShare: 520000, welfarePool: 97500, opsFee: 32500 },
    { month: 'Jul', workerShare: 560000, welfarePool: 105000, opsFee: 35000 },
    { month: 'Aug', workerShare: 610000, welfarePool: 114375, opsFee: 38125 },
    { month: 'Sep', workerShare: 660000, welfarePool: 123750, opsFee: 41250 }
  ];

  const filteredComplaints = complaints.filter(c => {
    if (disputeFilter === 'ALL') return true;
    if (disputeFilter === 'PENDING') return c.status !== 'Resolved';
    if (disputeFilter === 'RESOLVED') return c.status === 'Resolved';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-16">
      
      {/* 1. Admin Board Executive Header (Minimalist Design) */}
      <section className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span className="text-[11px] uppercase tracking-wider text-emerald-800 font-bold bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                {t('adminPortalTitle', 'Tumakuru District Cooperative Admin Portal')}
              </span>
              <span className="bg-slate-100 text-slate-600 text-[10px] font-mono px-2 py-0.5 rounded border border-slate-200">
                REG-KA-TMK-2026
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              S. R. Patil, <span className="font-semibold text-slate-600 text-xl sm:text-2xl">{t('adminRole', 'Registrar & Board Trustee')}</span>
            </h1>
            <p className="text-slate-500 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {t('adminSubtitle', 'Overseeing democratic audit logs, transparent 80/15/5 fee collections, worker credential verification, and customer issue mediation.')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-50 px-4 py-2 rounded-xl border border-slate-200 text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">{t('platformState', 'Platform State')}</span>
              <p className="text-xs font-bold text-emerald-800 flex items-center justify-end gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                {t('platformState', '100% Democratic • Verified')}
              </p>
            </div>
            <button
              onClick={() => showToast('Disbursed ₹35,000 Emergency Healthcare Grant from Welfare Reserve!', 'info')}
              className="px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>{t('disburseWelfareGrant', 'Disburse Welfare Grant')}</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. 6 KPI Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* KPI 1: Total Members */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('coopMembers', 'Co-op Members')}</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{analytics.totalMembers.toLocaleString()}</p>
          <span className="text-[10px] text-emerald-800 font-bold mt-1 block">342 in Tumakuru</span>
        </div>

        {/* KPI 2: Active Verified Workers */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('activeWorkers', 'Active Workers')}</span>
          <p className="text-2xl font-black text-emerald-800 mt-1">{analytics.activeWorkers.toLocaleString()}</p>
          <span className="text-[10px] text-slate-500 font-semibold mt-1 block">128 in Tumakuru</span>
        </div>

        {/* KPI 3: Completed Jobs */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('completedJobs', 'Completed Jobs')}</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{analytics.jobsCompleted.toLocaleString()}</p>
          <span className="text-[10px] text-slate-500 font-semibold mt-1 block">99.1% Successful</span>
        </div>

        {/* KPI 4: Total Volume */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('totalVolume', 'Total Volume (GMV)')}</span>
          <p className="text-2xl font-black text-slate-900 mt-1">₹32.5L</p>
          <span className="text-[10px] text-emerald-800 font-semibold mt-1 block">80% to Workers</span>
        </div>

        {/* KPI 5: Pending Verifications */}
        <div
          onClick={() => setActiveAdminTab('workers')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs hover:border-emerald-600 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('verificationsQueue', 'Verifications Queue')}</span>
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
          </div>
          <p className="text-2xl font-black text-amber-600 mt-1">{pendingApplicants.length}</p>
          <span className="text-[10px] text-slate-500 group-hover:text-emerald-800 font-semibold mt-1 block">
            Audit Queue ➔
          </span>
        </div>

        {/* KPI 6: Customer Satisfaction */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{t('satisfaction', 'Satisfaction')}</span>
          <p className="text-2xl font-black text-emerald-800 mt-1">{analytics.customerSatisfaction}%</p>
          <span className="text-[10px] text-emerald-700 font-semibold mt-1 block">Verified Feedback</span>
        </div>

      </div>

      {/* 3. Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'dashboard', label: t('financialAnalytics', 'Financial Analytics & GMV'), icon: Activity },
          { id: 'workers', label: t('workerVerificationQueue', 'Worker Verification Queue'), icon: FileCheck, count: pendingApplicants.length },
          { id: 'complaints', label: t('disputeMediation', 'Complaint & Dispute Mediation'), icon: Scale, count: complaints.filter(c => c.status !== 'Resolved').length },
          { id: 'regional', label: t('regionalNodes', 'Karnataka Regional Nodes'), icon: MapPin },
          { id: 'farmers', label: t('farmerManagement', 'Farmer Management'), icon: Wheat, count: farmers.filter(f => !f.verified).length },
          { id: 'equipment-management', label: t('equipmentManagement', 'Equipment Pool'), icon: Tractor },
          { id: 'agri-services', label: t('agriculturalServices', 'Agri Bookings & Escrow'), icon: Sprout, count: farmerBookings.length },
          { id: 'farmer-skills', label: t('farmerSkillExchange', 'Agri Skill Certifications'), icon: Award }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'border-emerald-800 text-emerald-800 bg-emerald-50/60 rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-800' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className={`px-2 py-0.5 text-[10px] rounded-full font-extrabold ${
                  isActive ? 'bg-emerald-800 text-white' : 'bg-rose-500 text-white'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* =========================================================================
          TAB 1: Financial & GMV Analytics (Recharts)
      ========================================================================= */}
      {activeAdminTab === 'dashboard' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  Platform GMV & Transparent 80/15/5 Distribution Flow
                </h3>
                <p className="text-xs text-slate-500">
                  Visual audit of funds flow: 80% direct to Workers, 15% to Welfare & Healthcare Pool, 5% to Platform Hosting
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs font-bold">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-emerald-600"></span>
                  <span>{t('workerPayShare', 'Worker Pay (80%)')}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-teal-500"></span>
                  <span>{t('welfarePoolShare', 'Welfare Pool (15%)')}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-indigo-600"></span>
                  <span>{t('hostingShare', 'Hosting (5%)')}</span>
                </div>
              </div>
            </div>

            <div className="h-80 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyAdminChartData} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} tickFormatter={(val) => `₹${val/100000}L`} />
                  <Tooltip
                    formatter={(val, name) => [`₹${Number(val).toLocaleString()}`, name]}
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff' }}
                  />
                  <Legend />
                  <Bar dataKey="workerShare" name="Workers (80%)" fill="#059669" stackId="a" />
                  <Bar dataKey="welfarePool" name="Welfare Fund (15%)" fill="#0d9488" stackId="a" />
                  <Bar dataKey="opsFee" name="Platform (5%)" fill="#4f46e5" stackId="a" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Transparent Economic Audit Card */}
          <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-400">
              Cooperative Model vs Monopolistic Corporate Gig Apps
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-3">
                <div className="flex justify-between items-center text-xs text-rose-400 font-bold">
                  <span>Corporate Monopolies (Urban Company, TaskRabbit)</span>
                  <span>25% – 30% Deducted</span>
                </div>
                <div className="w-full bg-slate-700 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-rose-500 h-full w-[28%]"></div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Worker pays heavy commission with no health insurance, no job security, and zero ownership in the platform.
                </p>
              </div>

              <div className="bg-emerald-950/60 p-5 rounded-2xl border border-emerald-700/60 space-y-3">
                <div className="flex justify-between items-center text-xs text-emerald-300 font-bold">
                  <span>CoWork Connect Cooperative Model</span>
                  <span>5% Operating Cost Only</span>
                </div>
                <div className="w-full bg-slate-700 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-400 h-full w-[5%]"></div>
                </div>
                <p className="text-xs text-emerald-200/80 leading-relaxed">
                  Workers receive 80% upfront, 15% into their mutual health pool, and 100% of quarterly profits as patronage dividends.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 2: Worker Verification Queue
      ========================================================================= */}
      {activeAdminTab === 'workers' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Pending Worker Co-owner Verifications</h3>
              <p className="text-xs text-slate-500">
                Audit government IDs, trade skill certifications, and police background clearance.
              </p>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-800 font-bold px-3 py-1 rounded-lg border border-indigo-200">
              {pendingApplicants.length} Applicants Waiting
            </span>
          </div>

          {pendingApplicants.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h4 className="font-bold text-slate-800">Verification Queue is Fully Cleared!</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                All submitted worker applications have been audited and granted Class A Shareholder status.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingApplicants.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6"
                >
                  <div className="space-y-3 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                        {app.id}
                      </span>
                      <h4 className="text-base font-bold text-slate-900">{app.name}</h4>
                      <span className="text-xs bg-indigo-50 text-indigo-800 px-2.5 py-0.5 rounded-full font-bold uppercase border border-indigo-200">
                        {app.trade}
                      </span>
                      <span className="text-xs text-slate-500">
                        • {app.experienceYears} Years Exp • Applied {app.appliedDate}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 flex flex-wrap items-center gap-4">
                      <span>📍 {app.location}</span>
                      <span>📞 {app.phone}</span>
                    </div>

                    {/* Uploaded Documents List */}
                    <div className="pt-1">
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                        Document Verifications:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {app.credentials.map((c, idx) => (
                          <span
                            key={idx}
                            className={`text-xs font-semibold px-2.5 py-1 rounded-lg border flex items-center gap-1.5 ${
                              c.status === 'VERIFIED'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>{c.name}: <strong>{c.status}</strong></span>
                          </span>
                        ))}
                      </div>
                    </div>

                    {app.notes && (
                      <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <strong>Board Audit Note:</strong> {app.notes}
                      </p>
                    )}
                  </div>

                  {/* Approve / Reject Actions */}
                  <div className="flex sm:flex-col gap-2 w-full sm:w-auto shrink-0">
                    <button
                      onClick={() => handleApproveApplicant(app.id)}
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center justify-center gap-1.5 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Approve Co-owner</span>
                    </button>
                    <button
                      onClick={() => handleRejectApplicant(app.id)}
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Decline / Request Doc</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* =========================================================================
          TAB 3: Complaint & Dispute Mediation
      ========================================================================= */}
      {activeAdminTab === 'complaints' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Cooperative Dispute Mediation Board</h3>
              <p className="text-xs text-slate-500">
                Customer and worker flags handled via democratic mediation under Tumakuru Cooperative By-laws.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500">Filter:</span>
              <select
                value={disputeFilter}
                onChange={(e) => setDisputeFilter(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Tickets</option>
                <option value="PENDING">Pending Review</option>
                <option value="RESOLVED">Resolved</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredComplaints.map((c) => (
              <div
                key={c.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded">
                      {c.ticketNo}
                    </span>
                    <h4 className="font-bold text-slate-900 text-base">{c.category}</h4>
                    <span className="text-[10px] font-extrabold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                      {c.severity} Priority
                    </span>
                  </div>

                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                    c.status === 'Resolved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {c.status}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1">
                    <span className="font-bold text-slate-800">Customer Statement ({c.customerName}):</span>
                    <p className="text-slate-600 leading-relaxed italic">"{c.description}"</p>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1">
                    <span className="font-bold text-slate-800">Worker Associated ({c.workerName} - {c.trade}):</span>
                    <p className="text-slate-600 leading-relaxed">
                      Confirmed appointment. Ready for joint inspection or cooperative resolution.
                    </p>
                  </div>
                </div>

                {c.status !== 'Resolved' ? (
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
                    <span className="text-xs font-bold text-slate-500 mr-2">Admin Mediation Action:</span>
                    <button
                      onClick={() => resolveComplaint(c.id, 'Worker compensated; customer issued complimentary co-op service voucher.')}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-all"
                    >
                      Compensate & Issue Voucher
                    </button>
                    <button
                      onClick={() => resolveComplaint(c.id, 'Joint warranty re-visit scheduled with senior plumbing inspector.')}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all"
                    >
                      Schedule Free Re-visit
                    </button>
                  </div>
                ) : (
                  <div className="text-xs text-emerald-700 font-semibold bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                    Resolution: {c.resolutionNote || 'Closed following cooperative mediation consensus.'}
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 4: Karnataka Regional Nodes
      ========================================================================= */}
      {activeAdminTab === 'regional' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-2">
            <h3 className="text-lg font-bold text-slate-900">Federated Cooperative Expansion Nodes</h3>
            <p className="text-xs text-slate-500">
              Each district operates as an autonomous member-owned cooperative under the Karnataka State Federation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                city: 'Tumakuru Hub (Primary)',
                reg: 'Reg #2026-KA-TMK-019',
                members: 342,
                volume: '₹14.2 Lakhs',
                satisfaction: '98.2%',
                status: 'ACTIVE HUB',
                workers: 128
              },
              {
                city: 'Bengaluru District Hub',
                reg: 'Reg #2026-KA-BLR-044',
                members: 4120,
                volume: '₹12.5 Lakhs',
                satisfaction: '96.1%',
                status: 'EXPANDING',
                workers: 410
              },
              {
                city: 'Mysuru Cultural Hub',
                reg: 'Reg #2026-KA-MYS-012',
                members: 2840,
                volume: '₹3.8 Lakhs',
                satisfaction: '97.4%',
                status: 'ACTIVE',
                workers: 230
              },
              {
                city: 'Mangaluru Coastal Hub',
                reg: 'Reg #2026-KA-MNG-008',
                members: 2238,
                volume: '₹2.0 Lakhs',
                satisfaction: '96.8%',
                status: 'ACTIVE',
                workers: 180
              }
            ].map((node) => (
              <div
                key={node.city}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 hover:border-indigo-300 transition-all"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{node.reg}</span>
                    <h4 className="text-base font-bold text-slate-900 mt-0.5">{node.city}</h4>
                  </div>
                  <span className="bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
                    {node.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Co-owners</span>
                    <span className="font-bold text-slate-900">{node.workers}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total GMV</span>
                    <span className="font-bold text-emerald-700">{node.volume}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Rating</span>
                    <span className="font-bold text-slate-900">{node.satisfaction}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 5: Farmer Management & Verification (CoWork Agri)
      ========================================================================= */}
      {activeAdminTab === 'farmers' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                🌾 Registered Farmers & Land Holdings Registry
              </h3>
              <p className="text-xs text-slate-500">
                Class-F cooperative member verification, land record checks, and irrigation audits.
              </p>
            </div>
            <span className="bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200 self-start sm:self-auto">
              Total Farmers: {farmers.length}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {farmers.map((farmer) => (
              <div
                key={farmer.id}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 hover:border-emerald-300 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-2xl flex-shrink-0">
                      👨‍🌾
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">{farmer.fullName || farmer.name}</h4>
                      <p className="text-xs text-slate-500">{farmer.location} · {farmer.district}</p>
                    </div>
                  </div>
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      farmer.verified
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {farmer.verified ? '✓ Verified' : 'Pending Verification'}
                  </span>
                </div>

                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Farm Name:</span>
                    <span className="font-bold text-slate-900">{farmer.farmName || 'Family Farm'}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Land Size:</span>
                    <span className="font-bold text-slate-900">{farmer.farmSize || '5 Acres'}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Primary Crop:</span>
                    <span className="font-bold text-emerald-700">{farmer.primaryCrop || 'Ragi'}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Irrigation:</span>
                    <span className="font-bold text-slate-900">{farmer.irrigationType || 'Borewell'}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200">
                    <span className="font-medium">Member ID:</span>
                    <span className="font-mono text-slate-700 font-bold">{farmer.cooperativeMembership || '#KA-TMK-AGRI-402'}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Class-F Voting Member</span>
                  {!farmer.verified ? (
                    <button
                      onClick={() => verifyFarmer(farmer.id)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-sm"
                    >
                      Verify Farmer ✓
                    </button>
                  ) : (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Approved
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 6: Equipment Management (CoWork Agri)
      ========================================================================= */}
      {activeAdminTab === 'equipment-management' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                🚜 Shared Agricultural Equipment Fleet
              </h3>
              <p className="text-xs text-slate-500">
                Inspect tractors, tillers, and implements listed by member farmers and cooperative hiring centres.
              </p>
            </div>
            <span className="bg-amber-50 text-amber-800 text-xs font-bold px-3 py-1 rounded-full border border-amber-200 self-start sm:self-auto">
              Total Equipment: {farmEquipment.length}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {farmEquipment.map((eq) => (
              <div
                key={eq.id}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 hover:border-amber-300 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-2xl flex-shrink-0">
                      {eq.icon || '🚜'}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">{eq.name}</h4>
                      <p className="text-xs text-slate-500">{eq.brand} · {eq.model}</p>
                    </div>
                  </div>
                  <span className="bg-emerald-50 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-200">
                    ₹{eq.rentalPrice}/day
                  </span>
                </div>

                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Owner:</span>
                    <span className="font-bold text-slate-900">{eq.ownerName}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Location:</span>
                    <span className="font-bold text-slate-900">{eq.location}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Operator Available:</span>
                    <span className={`font-bold ${eq.operatorAvailable ? 'text-amber-700' : 'text-slate-500'}`}>
                      {eq.operatorAvailable ? 'Yes (+₹400/day)' : 'No'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Status:</span>
                    <span className="font-bold text-emerald-700">{eq.status || 'Available'}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Co-op Inspected ✓</span>
                  {!eq.verified ? (
                    <button
                      onClick={() => approveEquipment(eq.id)}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition shadow-sm"
                    >
                      Approve Listing
                    </button>
                  ) : (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Certified
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 7: Agricultural Services & Escrow (CoWork Agri)
      ========================================================================= */}
      {activeAdminTab === 'agri-services' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                🌾 Farm Labour & Equipment Bookings Audit
              </h3>
              <p className="text-xs text-slate-500">
                Real-time escrow transactions, machine rentals, and seasonal farm labour settlements.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-indigo-50 text-indigo-800 text-xs font-bold px-3 py-1 rounded-full border border-indigo-200">
                Bookings: {farmerBookings.length}
              </span>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-[10px] font-bold">
                  <tr>
                    <th className="py-3 px-4">Booking ID</th>
                    <th className="py-3 px-4">Title / Equipment</th>
                    <th className="py-3 px-4">Farmer</th>
                    <th className="py-3 px-4">Date & Duration</th>
                    <th className="py-3 px-4">Cost</th>
                    <th className="py-3 px-4">Escrow Status</th>
                    <th className="py-3 px-4">Review</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {farmerBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/80 transition-all">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-700">#{b.id}</td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span>{b.equipmentPhoto || '🚜'}</span>
                          <span className="font-bold text-slate-900">{b.title}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700">{b.farmerName}</td>
                      <td className="py-3.5 px-4 text-slate-500">{b.date} ({b.duration})</td>
                      <td className="py-3.5 px-4 font-bold text-emerald-700">₹{b.finalCost || b.estimatedCost}</td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            b.paymentStatus === 'Paid'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {b.paymentStatus || 'Pending'} ({b.status})
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        {b.reviewed ? (
                          <span className="text-amber-500 font-bold flex items-center gap-0.5">
                            ★ {b.rating || 5}.0
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[10px]">Awaiting feedback</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 8: Farmer Skill Exchange & Guild Certifications (CoWork Agri)
      ========================================================================= */}
      {activeAdminTab === 'farmer-skills' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                🌱 Agricultural Skill Barter & Cooperative Certifications
              </h3>
              <p className="text-xs text-slate-500">
                Validate practical agronomic skills, issue official guild certificates, and inspect mentorship logs.
              </p>
            </div>
            <span className="bg-purple-50 text-purple-800 text-xs font-bold px-3 py-1 rounded-full border border-purple-200 self-start sm:self-auto">
              Certified Skills: {farmerSkills.filter(s => s.verified).length}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {farmerSkills.map((skill) => (
              <div
                key={skill.id}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 hover:border-purple-300 transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-purple-50 border border-purple-200 flex items-center justify-center text-2xl flex-shrink-0">
                      🌱
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">{skill.skillName}</h4>
                      <p className="text-xs text-slate-500">Category: {skill.category}</p>
                    </div>
                  </div>
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      skill.verified
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-purple-50 text-purple-800 border border-purple-200'
                    }`}
                  >
                    {skill.verified ? '✓ Guild Certified' : 'In Training'}
                  </span>
                </div>

                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Mastery Level:</span>
                    <span className="font-bold text-purple-800">{skill.skillLevel} ({skill.progress}%)</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Modules Completed:</span>
                    <span className="font-bold text-slate-900">{skill.modulesCompleted || 8} of {skill.totalModules || 10}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="font-medium">Mentor:</span>
                    <span className="font-bold text-slate-900">{skill.mentorName || 'Tumakuru Agri Guild'}</span>
                  </div>
                  {skill.certifiedBy && (
                    <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200">
                      <span className="font-medium">Certified By:</span>
                      <span className="font-bold text-emerald-700">{skill.certifiedBy}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Class-F Skill Credential</span>
                  {!skill.verified ? (
                    <button
                      onClick={() => verifyFarmerSkill(skill.farmerId || 'farmer01', skill.skillName)}
                      className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition shadow-sm"
                    >
                      Certify Skill ✓
                    </button>
                  ) : (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Approved Badge
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

