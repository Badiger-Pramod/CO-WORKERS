import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Users,
  ShieldCheck,
  Briefcase,
  Home,
  Bell,
  Globe,
  Sparkles,
  Zap,
  PlayCircle,
  HelpCircle,
  CheckCircle2,
  X,
  Flame,
  Award
} from 'lucide-react';

export const Header = () => {
  const {
    role,
    setRole,
    lang,
    setLang,
    customerLocation,
    setCustomerLocation,
    notifications,
    isDemoModeActive,
    setIsDemoModeActive,
    demoStep,
    setDemoStep,
    handleNextDemoStep
  } = useCoop();

  const [notifDropdown, setNotifDropdown] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'kn', label: 'ಕನ್ನಡ' },
    { code: 'hi', label: 'हिन्दी' },
    { code: 'ta', label: 'தமிழ்' },
    { code: 'te', label: 'తెలుగు' },
    { code: 'ml', label: 'മലയാളം' },
    { code: 'mr', label: 'मराठी' },
    { code: 'bn', label: 'বাংলা' }
  ];

  const locations = [
    'Tumakuru, Karnataka',
    'Bengaluru, Karnataka',
    'Mysuru, Karnataka',
    'Mangaluru, Karnataka'
  ];

  const startDemo = () => {
    setIsDemoModeActive(true);
    setDemoStep(1);
    setRole('customer');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm transition-all">
      {/* Top Value / SIH Ribbon */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          
          <div className="flex items-center gap-2 font-medium">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-black bg-emerald-700 text-white border border-emerald-500">
              Cooperative Platform
            </span>
            <span className="hidden sm:inline font-bold">CoWork Connect Ecosystem</span>
            <span className="text-emerald-300 font-semibold">• Digital Worker & Farmer Cooperative</span>
          </div>

          <div className="flex items-center gap-4 text-emerald-100 text-[11px]">
            <span className="hidden md:inline">📍 Primary Demo Hub: <strong className="text-white">Tumakuru Cooperative</strong></span>
            
            {/* Language Switcher */}
            <div className="flex items-center gap-1.5 bg-white/10 px-2 py-0.5 rounded-md">
              <Globe className="w-3.5 h-3.5 text-emerald-300" />
              <select
                value={lang}
                onChange={(e) => setLang(e.target.value)}
                className="bg-transparent text-white text-xs font-semibold focus:outline-none cursor-pointer"
              >
                {languages.map((l) => (
                  <option key={l.code} value={l.code} className="text-slate-900">
                    {l.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          
          {/* Logo & Tagline */}
          <div className="flex items-center justify-between gap-4">
            <button
              onClick={() => setRole('landing')}
              className="flex items-center gap-3 text-left group focus:outline-none"
            >
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-emerald-600/30 group-hover:scale-105 transition-transform">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-2xl tracking-tight text-slate-900">
                    Seva<span className="text-emerald-600">Setu</span>
                  </span>
                  <span className="bg-emerald-50 text-emerald-800 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-emerald-300">
                    Co-op Network
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Empowering Local Workers. Connecting Every Community.
                </p>
              </div>
            </button>

            {/* Quick Demo Mode Trigger Button */}
            <button
              onClick={startDemo}
              className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all shadow-md ${
                isDemoModeActive
                  ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400 animate-pulse'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950'
              }`}
            >
              <PlayCircle className="w-4 h-4" />
              <span>Interactive Workflow Tour</span>
            </button>
          </div>

          {/* Persona Switchers & Utility Controls */}
          <div className="flex flex-wrap items-center justify-between xl:justify-end gap-3">
            
            {/* 3 Live Demo Accounts / Persona Switcher */}
            <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 shadow-inner">
              {[
                { id: 'landing', label: 'Overview', icon: Home },
                { id: 'customer', label: 'Ananya (Customer)', icon: Users, badge: 'Tumakuru' },
                { id: 'worker', label: 'Ravi (Worker)', icon: Briefcase, badge: 'Plumber' },
                { id: 'admin', label: 'Co-op Admin', icon: ShieldCheck, badge: 'Registrar' }
              ].map((p) => {
                const Icon = p.icon;
                const isActive = role === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => setRole(p.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      isActive
                        ? 'bg-white text-emerald-900 shadow-sm border border-slate-200'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span className="whitespace-nowrap">{p.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Notifications Dropdown Toggle */}
            <div className="relative">
              <button
                onClick={() => setNotifDropdown(!notifDropdown)}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 relative transition-colors"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Dropdown Card */}
              {notifDropdown && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 z-50 animate-fade-in space-y-3">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                    <span className="font-bold text-xs uppercase tracking-wider text-slate-800">
                      Live Co-op Notifications
                    </span>
                    <button
                      onClick={() => setNotifDropdown(false)}
                      className="text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="max-h-72 overflow-y-auto space-y-2 text-xs">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        className="p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/50 border border-slate-100 space-y-0.5"
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-800 text-[11px]">{n.title}</span>
                          <span className="text-[9px] text-slate-400">{n.time}</span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-relaxed">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};
