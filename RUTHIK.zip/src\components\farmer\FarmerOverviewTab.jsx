import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Users,
  Tractor,
  Wrench,
  GraduationCap,
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  TrendingUp,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  CloudSun,
  Droplets,
  DollarSign,
  Camera,
  Layers,
  Sprout
} from 'lucide-react';

export const FarmerOverviewTab = ({ onNavigateTab, onOpenShowCrop, onRunDemo }) => {
  const {
    currentFarmer,
    farmerBookings = [],
    farmerSkills = [],
    farmEquipment = [],
    cropPosts = [],
    t
  } = useCoop();

  const farmer = currentFarmer || {};

  // Compute metrics
  const activeBookings = farmerBookings.filter(
    (b) => b.status === 'Requested' || b.status === 'Accepted' || b.status === 'Scheduled' || b.status === 'In Use'
  );
  const completedBookings = farmerBookings.filter((b) => b.status === 'Completed');
  const equipmentBookings = farmerBookings.filter(
    (b) => b.bookingType === 'Equipment' || b.bookingType === 'Combined'
  );
  const labourRequests = farmerBookings.filter((b) => b.bookingType === 'Worker');
  const verifiedSkills = farmerSkills.filter((s) => s.verified);

  const ownedEquipment = farmEquipment.filter(
    (e) => e.ownerId === farmer.id || e.ownerName === (farmer.fullName || farmer.name)
  );

  // Filter crop posts belonging to or relevant for this farmer
  const recentCropPhotos = cropPosts.slice(0, 4);

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* ─── 1. Top Farmer Welcome Header (Minimalist & Clean) ──── */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                {farmer.cooperativeMembership || 'Co-op Class-F Member'}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Verified Farmer
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Welcome, {farmer.fullName || farmer.name || 'Ravi Gowda'} 👋
            </h1>

            <p className="text-sm text-slate-600 font-normal">
              {farmer.farmName || 'Green Valley Farm'} · {farmer.location || 'Tumakuru'} · {farmer.farmSize || '5 Acres'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenShowCrop}
              className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white text-sm font-semibold rounded-lg shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Show My Crop</span>
            </button>
            <button
              onClick={() => onNavigateTab?.('workers')}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-lg border border-slate-200 transition flex items-center gap-2 cursor-pointer"
            >
              <Users className="w-4 h-4 text-slate-600" />
              <span>Find Workers</span>
            </button>
          </div>
        </div>
      </div>

      {/* ─── 2. What do you need today? (Section 10 Requirement) ─ */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            What do you need today?
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Select an action to find verified support, machinery or share farm progress.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {/* Action 1: 🌾 Farm Workers */}
          <button
            onClick={() => onNavigateTab?.('workers')}
            className="p-5 bg-white hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-700/60 rounded-xl text-center flex flex-col items-center justify-center transition cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100 flex items-center justify-center text-2xl mb-3 group-hover:scale-105 transition-transform">
              🌾
            </div>
            <p className="text-slate-900 font-semibold text-sm">
              Farm Workers
            </p>
            <span className="text-[11px] text-slate-500 mt-0.5">Harvest, weeding, crew</span>
          </button>

          {/* Action 2: 🚜 Equipment */}
          <button
            onClick={() => onNavigateTab?.('equipment')}
            className="p-5 bg-white hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-700/60 rounded-xl text-center flex flex-col items-center justify-center transition cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100 flex items-center justify-center text-2xl mb-3 group-hover:scale-105 transition-transform">
              🚜
            </div>
            <p className="text-slate-900 font-semibold text-sm">
              Equipment
            </p>
            <span className="text-[11px] text-slate-500 mt-0.5">Tractor, rotavator, drone</span>
          </button>

          {/* Action 3: 🔧 Farm Service */}
          <button
            onClick={() => onNavigateTab?.('services')}
            className="p-5 bg-white hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-700/60 rounded-xl text-center flex flex-col items-center justify-center transition cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100 flex items-center justify-center text-2xl mb-3 group-hover:scale-105 transition-transform">
              🔧
            </div>
            <p className="text-slate-900 font-semibold text-sm">
              Farm Service
            </p>
            <span className="text-[11px] text-slate-500 mt-0.5">Pump, motor, drip fix</span>
          </button>

          {/* Action 4: 📷 Show My Crop */}
          <button
            onClick={onOpenShowCrop}
            className="p-5 bg-white hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-700/60 rounded-xl text-center flex flex-col items-center justify-center transition cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100 flex items-center justify-center text-2xl mb-3 group-hover:scale-105 transition-transform">
              📷
            </div>
            <p className="text-slate-900 font-semibold text-sm">
              Show My Crop
            </p>
            <span className="text-[11px] text-slate-500 mt-0.5">Take photo & check health</span>
          </button>

          {/* Action 5: 💡 Share Idea */}
          <button
            onClick={onOpenShowCrop}
            className="p-5 bg-white hover:bg-emerald-50/50 border border-slate-200 hover:border-emerald-700/60 rounded-xl text-center flex flex-col items-center justify-center transition cursor-pointer group col-span-2 sm:col-span-1"
          >
            <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-100 flex items-center justify-center text-2xl mb-3 group-hover:scale-105 transition-transform">
              💡
            </div>
            <p className="text-slate-900 font-semibold text-sm">
              Share Idea
            </p>
            <span className="text-[11px] text-slate-500 mt-0.5">Post tip to community</span>
          </button>
        </div>
      </div>

      {/* ─── 3. Upcoming Booking (Section 10 Requirement) ─────────── */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">
            Upcoming Booking
          </h2>
          <button
            onClick={() => onNavigateTab?.('bookings')}
            className="text-xs text-emerald-800 hover:text-emerald-950 font-semibold flex items-center gap-1"
          >
            <span>View All Bookings</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {farmerBookings.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm border border-dashed border-slate-200 rounded-lg p-6">
            <p className="font-medium text-slate-700">No active bookings yet</p>
            <p className="text-xs text-slate-500 mt-1">Hire agricultural workers or reserve equipment above to get started.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {farmerBookings.slice(0, 2).map((booking) => (
              <div
                key={booking.id}
                onClick={() => onNavigateTab?.('bookings')}
                className="bg-white border border-slate-200 hover:border-slate-300 rounded-lg p-4 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center text-xl flex-shrink-0">
                    {booking.bookingType === 'Worker' ? '🌾' : '🚜'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-slate-900 font-bold text-sm">{booking.title}</p>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {booking.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {booking.date} · {booking.duration || 'Full Day'} · {booking.location || 'Tumakuru'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 text-right">
                  <div>
                    <p className="text-sm font-bold text-slate-900">₹{booking.finalCost || booking.estimatedCost}</p>
                    <p className="text-[10px] text-slate-500 font-medium">{booking.paymentStatus || 'Verified Co-op Rate'}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ─── 4. Recent Activity (Section 10 & 12 Clean Social Feed) ─ */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Recent Activity
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Crop updates and ideas shared by fellow farmers in Tumakuru.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab?.('crops')}
            className="text-xs text-emerald-800 hover:text-emerald-950 font-semibold flex items-center gap-1"
          >
            <span>Community Feed</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {recentCropPhotos.slice(0, 3).map((post) => (
            <div
              key={post.id}
              onClick={() => onNavigateTab?.('crops')}
              className="bg-white border border-slate-200 hover:border-slate-300 rounded-lg overflow-hidden transition cursor-pointer flex flex-col justify-between"
            >
              <div className="aspect-video relative overflow-hidden bg-slate-100">
                <img
                  src={post.image_url}
                  alt={post.crop_name}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 bg-white/90 text-slate-800 px-2 py-0.5 rounded text-[10px] font-semibold border border-slate-200 shadow-xs">
                  {post.crop_name}
                </span>
              </div>

              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900 truncate">
                    {post.farmer_name}
                  </span>
                  <span className="text-[10px] text-slate-500">📍 {post.location}</span>
                </div>
                <p className="text-slate-600 text-xs line-clamp-2">
                  “{post.description || 'Noticed good crop health after scheduled weeding.'}”
                </p>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span>💬 {post.comments ? post.comments.length : 0} replies</span>
                  <span className="text-emerald-800 font-semibold">View Post →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── 5. My Farm Skills (Section 10 & 17 Progression Display) ── */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              My Farm Skills
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified agricultural skills and peer mentoring exchange.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab?.('my-skills')}
            className="text-xs text-emerald-800 hover:text-emerald-950 font-semibold flex items-center gap-1"
          >
            <span>All Skills</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {farmerSkills.slice(0, 2).map((skill) => (
            <div key={skill.id} className="border border-slate-200 rounded-lg p-4 space-y-2 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">{skill.skillName}</h3>
                  <span className="text-xs text-slate-500 font-medium">{skill.skillLevel || 'Advanced'}</span>
                </div>
                <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                  ✓ Verified
                </span>
              </div>

              {/* Minimalist Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Progress</span>
                  <span className="font-semibold text-slate-700">{skill.progress || 80}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-800 h-full rounded-full transition-all duration-300"
                    style={{ width: `${skill.progress || 80}%` }}
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => onNavigateTab?.('skills')}
                  className="text-xs text-emerald-800 hover:text-emerald-950 font-semibold cursor-pointer"
                >
                  Continue Learning →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
