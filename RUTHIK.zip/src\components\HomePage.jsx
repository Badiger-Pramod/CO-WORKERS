import React, { useState } from 'react';
import {
  Wrench,
  Zap,
  Hammer,
  Paintbrush,
  Sparkles,
  Cpu,
  Car,
  Leaf,
  Home,
  HeartHandshake,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Coins,
  Bot,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Menu,
  X
} from 'lucide-react';
import { RegistrationModal } from './RegistrationModal';
import { AgriLandingSection } from './landing/AgriLandingSection';
import { INITIAL_DEMO_WORKERS, DEMO_CUSTOMERS, useCoop } from '../context/CoopContext';
import { DEMO_FARMERS, DEMO_FARMER } from '../data/agriMockData';

export const HomePage = ({ onLoginSuccess, onNavigateToFarmer }) => {
  const { t, currentLanguage, resetUserPassword } = useCoop();
  // Login State
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState(null); // 'Customer' | 'Worker' | 'Farmer' | 'Admin' | null
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Forgot Password Modal State
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotRole, setForgotRole] = useState('Farmer');
  const [forgotIdOrPhone, setForgotIdOrPhone] = useState('');
  const [forgotOtp, setForgotOtp] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');

  // Registration Modal State
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [registerInitialRole, setRegisterInitialRole] = useState('Customer');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Smooth scroll helper
  const scrollToSection = (sectionId, roleToSelect = null) => {
    if (roleToSelect) {
      setSelectedRole(roleToSelect);
    }
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  // Login handler with exact specified validation
  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    // Rule 1: Validate Role
    const trimmedCheck = loginId.trim().toLowerCase();
    if (!selectedRole && trimmedCheck !== 'admin01') {
      setErrorMessage('Please select Customer, Worker, Farmer, or Cooperative/Admin.');
      return;
    }

    // Rule 2: Validate Login ID
    if (!loginId.trim()) {
      setErrorMessage('Please enter your Login ID.');
      return;
    }

    // Rule 3: Validate Password
    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);

    try {
      const trimmedId = loginId.trim().toLowerCase();

      // First attempt authenticating against the real backend API
      try {
        const apiRes = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: trimmedId,
            password: password,
            expectedRole: selectedRole ? selectedRole.toUpperCase() : undefined
          })
        });
        const apiData = await apiRes.json();
        if (apiData.success && apiData.user) {
          setIsLoading(false);
          if (apiData.token) {
            localStorage.setItem('cowork_auth_token', apiData.token);
          }
          const realUser = {
            ...apiData.user,
            loginId: trimmedId,
            fullName: apiData.user.name || apiData.user.fullName,
            role: apiData.user.role
          };
          localStorage.setItem('cowork_active_session', JSON.stringify(realUser));
          setSuccessMessage(`Login successful! Welcome, ${realUser.fullName || realUser.name}!`);
          setTimeout(() => {
            onLoginSuccess(realUser);
          }, 500);
          return;
        }
      } catch (backendErr) {
        console.warn('Real backend authentication attempt failed or offline, checking local records:', backendErr);
      }

      // Check Fallback / Offline Credentials
      let authenticatedUser = null;

      if (selectedRole === 'Customer') {
        const demoCust = DEMO_CUSTOMERS.find(
          (c) => c.loginId.toLowerCase() === trimmedId && (c.password === password || password === 'Customer@123' || password === 'customer123')
        );
        if (demoCust) {
          authenticatedUser = { ...demoCust, role: 'Customer' };
        }
      }
      
      if (!authenticatedUser && selectedRole === 'Farmer') {
        const localFarmers = JSON.parse(localStorage.getItem('cowork_farmers') || '[]');
        const allFarmers = [...localFarmers, ...DEMO_FARMERS];
        const farmerMatch = allFarmers.find(
          (f) =>
            (f.loginId?.toLowerCase() === trimmedId || f.id?.toLowerCase() === trimmedId) &&
            (f.password === password || password === 'Farmer@123' || password === 'farmer123')
        );
        if (farmerMatch) {
          authenticatedUser = { ...farmerMatch, role: 'Farmer' };
        }
      }

      if (!authenticatedUser && (selectedRole === 'Admin' || trimmedId === 'admin01')) {
        if (trimmedId === 'admin01' && (password === 'admin123' || password === 'Admin@123')) {
          authenticatedUser = {
            role: 'Admin',
            loginId: 'admin01',
            fullName: 'S. R. Patil',
            title: 'Registrar & Board Trustee'
          };
        }
      }
      
      if (!authenticatedUser && selectedRole === 'Worker') {
        const demoWorkerMatch = INITIAL_DEMO_WORKERS.find(
          (w) => w.loginId.toLowerCase() === trimmedId && (w.password === password || password === 'Worker@123' || password === 'worker123')
        );
        if (demoWorkerMatch) {
          authenticatedUser = {
            ...demoWorkerMatch,
            role: 'Worker'
          };
        }
      }

      if (!authenticatedUser) {
        // Also check newly registered users in localStorage
        try {
          const registeredUsers = JSON.parse(localStorage.getItem('cowork_registered_users') || '[]');
          const matched = registeredUsers.find(
            (u) =>
              (u.role === selectedRole || !selectedRole) &&
              u.loginId.toLowerCase() === trimmedId &&
              u.password === password
          );
          if (matched) {
            authenticatedUser = matched;
          }
        } catch (err) {
          console.error(err);
        }
      }

      setIsLoading(false);

      if (!authenticatedUser) {
        setErrorMessage('Invalid Login ID or Password for the selected role.');
        return;
      }

      // Success
      if (authenticatedUser.role === 'Customer') {
        setSuccessMessage('Customer login successful!');
      } else if (authenticatedUser.role === 'Admin') {
        setSuccessMessage('Cooperative Board Admin login successful!');
      } else if (authenticatedUser.role === 'Farmer') {
        setSuccessMessage(`Farmer login successful (Welcome ${authenticatedUser.fullName || authenticatedUser.name})! Redirecting to Farmer Dashboard...`);
      } else {
        setSuccessMessage(`Worker login successful (${authenticatedUser.primaryTrade || authenticatedUser.trade || 'Co-op Worker'})!`);
      }

      // Transition to Dashboard after short delay
      setTimeout(() => {
        onLoginSuccess(authenticatedUser);
      }, 500);
    } catch (err) {
      setIsLoading(false);
      setErrorMessage('Login failed. Please try again.');
    }
  };

  // Quick autofill demo credentials
  const fillDemo = (role, customId = null, customPass = null) => {
    setSelectedRole(role);
    setErrorMessage('');
    if (role === 'Customer') {
      setLoginId(customId || 'customer01');
      setPassword(customPass || 'customer123');
    } else if (role === 'Admin') {
      setLoginId(customId || 'admin01');
      setPassword(customPass || 'admin123');
    } else if (role === 'Farmer') {
      setLoginId(customId || 'farmer01');
      setPassword(customPass || 'farmer123');
    } else {
      setLoginId(customId || 'bhuvan01');
      setPassword(customPass || 'worker123');
    }
  };

  // 10 Service Categories
  const services = [
    {
      icon: Wrench,
      title: 'Plumbing',
      description: 'Leak fixes, pipe replacements, bathroom fittings, and drain cleaning.'
    },
    {
      icon: Zap,
      title: 'Electrical',
      description: 'Wiring, circuit repairs, switchboard installs, inverter setup, and lighting.'
    },
    {
      icon: Hammer,
      title: 'Carpentry',
      description: 'Furniture assembly, door lock repairs, custom woodcraft, and cabinet fixes.'
    },
    {
      icon: Paintbrush,
      title: 'Painting',
      description: 'Interior & exterior wall painting, waterproof coating, and texture finishing.'
    },
    {
      icon: Sparkles,
      title: 'Cleaning',
      description: 'Deep home cleaning, kitchen sanitation, sofa wash, and water tank hygiene.'
    },
    {
      icon: Cpu,
      title: 'Appliance Repair',
      description: 'AC servicing, refrigerator maintenance, washing machine and microwave repairs.'
    },
    {
      icon: Car,
      title: 'Vehicle Repair',
      description: 'On-demand two-wheeler & four-wheeler roadside assistance and minor servicing.'
    },
    {
      icon: Leaf,
      title: 'Gardening',
      description: 'Lawn trimming, hedge shaping, organic soil preparation, and terrace garden care.'
    },
    {
      icon: Home,
      title: 'Home Maintenance',
      description: 'Roof leakage treatment, tile grouting, glass fixes, and general upkeep.'
    },
    {
      icon: HeartHandshake,
      title: 'Community Services',
      description: 'Elderly assistance, community sanitation drives, and public facility maintenance.'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-emerald-100 selection:text-emerald-900">
      {/* 1. HEADER / NAVIGATION BAR */}
      <header className="bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          {/* Logo & Brand Name */}
          <div
            onClick={() => scrollToSection('home')}
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-900 text-white flex items-center justify-center text-xl shadow-md group-hover:scale-105 transition-transform">
              🇮🇳
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-slate-900">
                  {t('platformName')}
                </span>
                <span className="hidden sm:inline-flex text-[10px] uppercase font-bold tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-300">
                  Cooperative Platform
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium -mt-0.5">
                {t('tagline')}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
            <button
              onClick={() => scrollToSection('home')}
              className="hover:text-emerald-700 transition"
            >
              {t('home')}
            </button>
            <button
              onClick={() => scrollToSection('services')}
              className="hover:text-emerald-700 transition"
            >
              {t('services')}
            </button>
            <button
              onClick={() => scrollToSection('why-us')}
              className="hover:text-emerald-700 transition"
            >
              {t('whyUs')}
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="hover:text-emerald-700 transition"
            >
              {t('about')}
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="hover:text-emerald-700 transition"
            >
              {t('contact')}
            </button>
          </nav>

          {/* Login Action Button */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={() => scrollToSection('login')}
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all"
            >
              {t('login')}
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-200 px-4 py-4 space-y-3">
            <button
              onClick={() => scrollToSection('home')}
              className="block w-full text-left py-2 text-sm font-semibold text-slate-700"
            >
              {t('home')}
            </button>
            <button
              onClick={() => scrollToSection('services')}
              className="block w-full text-left py-2 text-sm font-semibold text-slate-700"
            >
              {t('services')}
            </button>
            <button
              onClick={() => scrollToSection('why-us')}
              className="block w-full text-left py-2 text-sm font-semibold text-slate-700"
            >
              {t('whyUs')}
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="block w-full text-left py-2 text-sm font-semibold text-slate-700"
            >
              {t('about')}
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block w-full text-left py-2 text-sm font-semibold text-slate-700"
            >
              {t('contact')}
            </button>
            <button
              onClick={() => scrollToSection('login')}
              className="w-full py-2.5 bg-emerald-700 text-white text-center font-bold text-sm rounded-xl"
            >
              {t('login')}
            </button>
          </div>
        )}
      </header>

      {/* 2. HERO SECTION — MINIMALIST */}
      <section
        id="home"
        className="relative overflow-hidden pt-16 pb-16 lg:pt-24 lg:pb-20 bg-white border-b border-slate-200"
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center relative z-10">
          {/* Main Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight">
            CoWork Connect
          </h1>

          {/* Section Subtitle */}
          <h2 className="mt-3 text-xl sm:text-2xl font-semibold text-emerald-800 tracking-tight">
            Empowering Workers. Connecting Communities.
          </h2>

          {/* Supporting Text */}
          <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto font-normal leading-relaxed">
            Find people, services, skills and resources near you.
          </p>

          {/* Main Actions: Find Help | Find Work | CoWork Agri */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => scrollToSection('login', 'Customer')}
              className="w-full sm:w-auto px-6 py-3 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white text-sm font-semibold rounded-lg shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Find Help</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => scrollToSection('login', 'Worker')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-sm font-semibold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wrench className="w-4 h-4 text-slate-700" />
              <span>Find Work</span>
            </button>

            <button
              onClick={() => {
                if (onNavigateToFarmer) onNavigateToFarmer();
                else scrollToSection('login', 'Farmer');
              }}
              className="w-full sm:w-auto px-6 py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-sm font-semibold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span className="text-sm">🌾</span>
              <span>CoWork Agri</span>
            </button>
          </div>

          {/* Key Trust Highlights — Clean & Simple */}
          <div className="mt-12 pt-8 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-2xl font-bold text-slate-900">8–10%</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">{t('fairCoopFee', 'Fair Co-op Fee')}</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">100%</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">{t('verifiedWorkers', 'Verified Workers')}</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">₹0 Surge</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">{t('zeroSurge', 'Zero Surge Pricing')}</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">100%</div>
              <div className="text-xs text-slate-500 font-medium mt-0.5">{t('workerOwnership', 'Worker Ownership')}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Agriculture Voice Seva Landing Section */}
      <AgriLandingSection onOpenFarmerDashboard={onNavigateToFarmer} />

      {/* 3. LOGIN SECTION — MINIMALIST CARD */}
      <section
        id="login"
        className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50"
      >
        <div className="max-w-md mx-auto">
          {/* Card Container */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Card Header — Minimalist Light */}
            <div className="p-6 text-center border-b border-slate-100">
              <h2 className="text-xl font-bold text-slate-900">Login to CoWork Connect</h2>
              <p className="text-xs text-slate-500 mt-1">
                Select your role and enter credentials to continue
              </p>
            </div>

            <div className="p-6 sm:p-8">
              {/* Error Message Display */}
              {errorMessage && (
                <div className="mb-5 p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs font-medium text-red-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Success Message Display */}
              {successMessage && (
                <div className="mb-5 p-3.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-medium text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{successMessage}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-5">
                {/* SELECT USER TYPE (4 UNIFIED MINIMALIST BUTTONS) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-2">
                    Select Role *
                  </label>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {/* CUSTOMER CARD */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedRole('Customer');
                        if (errorMessage) setErrorMessage('');
                      }}
                      className={`flex flex-col items-center justify-center p-3 rounded-lg border text-center transition cursor-pointer ${
                        selectedRole === 'Customer'
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                      }`}
                    >
                      <span className="text-lg mb-0.5">👤</span>
                      <span className="text-xs font-medium">
                        {t('customer', 'Customer')}
                      </span>
                    </button>

                    {/* WORKER CARD */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedRole('Worker');
                        if (errorMessage) setErrorMessage('');
                      }}
                      className={`flex flex-col items-center justify-center p-3 rounded-lg border text-center transition cursor-pointer ${
                        selectedRole === 'Worker'
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                      }`}
                    >
                      <span className="text-lg mb-0.5">🛠️</span>
                      <span className="text-xs font-medium">
                        {t('worker', 'Worker')}
                      </span>
                    </button>

                    {/* FARMER CARD (COWORK AGRI 🌾) */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedRole('Farmer');
                        if (errorMessage) setErrorMessage('');
                      }}
                      className={`flex flex-col items-center justify-center p-3 rounded-lg border text-center transition cursor-pointer ${
                        selectedRole === 'Farmer'
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                      }`}
                    >
                      <span className="text-lg mb-0.5">🌾</span>
                      <span className="text-xs font-medium">
                        {t('farmer', 'Farmer')}
                      </span>
                    </button>

                    {/* COOPERATIVE / ADMIN CARD */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedRole('Admin');
                        if (errorMessage) setErrorMessage('');
                      }}
                      className={`flex flex-col items-center justify-center p-3 rounded-lg border text-center transition cursor-pointer ${
                        selectedRole === 'Admin'
                          ? 'border-emerald-700 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                      }`}
                    >
                      <span className="text-lg mb-0.5">🏛️</span>
                      <span className="text-xs font-medium">
                        {t('admin', 'Admin')}
                      </span>
                    </button>
                  </div>
                </div>

                {/* LOGIN ID FIELD */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Login ID *
                  </label>
                  <input
                    type="text"
                    value={loginId}
                    onChange={(e) => {
                      setLoginId(e.target.value);
                      if (errorMessage) setErrorMessage('');
                    }}
                    placeholder="Enter your Login ID"
                    className="w-full px-4 py-3 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden transition bg-white"
                  />
                </div>

                {/* PASSWORD FIELD WITH SHOW/HIDE */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Password *
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setShowForgotPassword(true);
                        setForgotRole(selectedRole || 'Farmer');
                        setForgotIdOrPhone(loginId || '');
                        setForgotOtp('');
                        setForgotNewPassword('');
                        setForgotConfirmPassword('');
                        setForgotError('');
                        setForgotSuccess('');
                      }}
                      className="text-[11px] text-emerald-700 font-medium hover:underline cursor-pointer bg-transparent border-none p-0"
                    >
                      {t('forgotPassword', 'Forgot Password?')}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (errorMessage) setErrorMessage('');
                      }}
                      placeholder="Enter your password"
                      className="w-full px-4 py-3 pr-11 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden transition bg-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition cursor-pointer"
                      aria-label="Toggle password visibility"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* LOGIN SUBMIT BUTTON */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-extrabold text-sm tracking-wider uppercase rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {isLoading ? 'Authenticating...' : '[ LOGIN ]'}
                </button>
              </form>

              {/* DEMO CREDENTIALS QUICK PICKER (ALL 3 FARMERS + OTHER ROLES) */}
              <div className="mt-6 pt-5 border-t border-slate-200/80">
                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider text-center mb-3">
                  ⚡ Verified Accounts (Click to Autofill & Login)
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {/* Farmer 1: Ravi Gowda */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Farmer', 'farmer01', 'farmer123')}
                    className="p-2 rounded-xl border border-lime-400 bg-lime-50/80 hover:bg-lime-100 text-left transition cursor-pointer"
                  >
                    <span className="font-black text-lime-950 block text-[11px]">🌾 Ravi Gowda</span>
                    <span className="text-[10px] text-slate-600 block">Green Valley · Ragi</span>
                    <span className="text-[10px] text-lime-800 font-bold block mt-0.5">farmer01</span>
                  </button>

                  {/* Farmer 2: Suresh Nayak */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Farmer', 'farmer02', 'farmer123')}
                    className="p-2 rounded-xl border border-lime-400 bg-lime-50/80 hover:bg-lime-100 text-left transition cursor-pointer"
                  >
                    <span className="font-black text-lime-950 block text-[11px]">🌾 Suresh Nayak</span>
                    <span className="text-[10px] text-slate-600 block">Cauvery Farm · Tomato</span>
                    <span className="text-[10px] text-lime-800 font-bold block mt-0.5">farmer02</span>
                  </button>

                  {/* Farmer 3: Chennappa M */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Farmer', 'farmer03', 'farmer123')}
                    className="p-2 rounded-xl border border-lime-400 bg-lime-50/80 hover:bg-lime-100 text-left transition cursor-pointer"
                  >
                    <span className="font-black text-lime-950 block text-[11px]">🌾 Chennappa M</span>
                    <span className="text-[10px] text-slate-600 block">Shree Siddaganga · Groundnut</span>
                    <span className="text-[10px] text-lime-800 font-bold block mt-0.5">farmer03</span>
                  </button>

                  {/* Customer: Ananya */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Customer')}
                    className="p-2 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50/50 text-left transition cursor-pointer"
                  >
                    <span className="font-bold text-slate-800 block text-[11px]">👤 Customer</span>
                    <span className="text-[10px] text-slate-500 block">Ananya Sharma</span>
                    <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">customer01</span>
                  </button>

                  {/* Worker: Bhuvan */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Worker', 'bhuvan01', 'worker123')}
                    className="p-2 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50/50 text-left transition cursor-pointer"
                  >
                    <span className="font-bold text-slate-800 block text-[11px]">🛠️ Electrician</span>
                    <span className="text-[10px] text-slate-500 block">Bhuvan Bhuvi</span>
                    <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">bhuvan01</span>
                  </button>

                  {/* Cooperative/Admin: S. R. Patil */}
                  <button
                    type="button"
                    onClick={() => fillDemo('Admin', 'admin01', 'admin123')}
                    className="p-2 rounded-xl border border-purple-300 hover:border-purple-400 bg-purple-50/80 hover:bg-purple-100 text-left transition cursor-pointer"
                  >
                    <span className="font-bold text-purple-900 block text-[11px]">🏛️ Board Admin</span>
                    <span className="text-[10px] text-slate-600 block">S. R. Patil (Trustee)</span>
                    <span className="text-[10px] text-purple-800 font-bold block mt-0.5">admin01</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fillDemo('Worker', 'chandan01', 'worker123')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50/50 text-left transition"
                  >
                    <span className="font-bold text-slate-800 block text-[11px]">🪚 Carpenter</span>
                    <span className="text-[10px] text-slate-500 block">Chandan</span>
                    <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">chandan01</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fillDemo('Worker', 'pramod01', 'worker123')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50/50 text-left transition"
                  >
                    <span className="font-bold text-slate-800 block text-[11px]">🎨 Painter</span>
                    <span className="text-[10px] text-slate-500 block">Pramod</span>
                    <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">pramod01</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fillDemo('Worker', 'tushar01', 'worker123')}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-400 bg-slate-50 hover:bg-emerald-50/50 text-left transition"
                  >
                    <span className="font-bold text-slate-800 block text-[11px]">🧹 Cleaning</span>
                    <span className="text-[10px] text-slate-500 block">Tushar</span>
                    <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">tushar01</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fillDemo('Admin', 'admin01', 'admin123')}
                    className="col-span-2 sm:col-span-3 p-2.5 rounded-xl border border-indigo-200 hover:border-indigo-400 bg-indigo-50/70 hover:bg-indigo-50 text-left transition flex items-center justify-between"
                  >
                    <div>
                      <span className="font-extrabold text-indigo-950 block text-[11px]">🏛️ Co-op Union Admin</span>
                      <span className="text-[10px] text-indigo-700 block">S. R. Patil (District Registrar & Board Trustee)</span>
                    </div>
                    <span className="text-[10px] text-indigo-900 font-mono font-bold bg-white px-2 py-1 rounded border border-indigo-200">
                      admin01 / admin123
                    </span>
                  </button>
                </div>
              </div>

              {/* REGISTER NOW SECTION */}
              <div className="mt-6 pt-5 border-t border-slate-200/80 text-center">
                <p className="text-xs text-slate-600 font-medium">
                  Don't have an account?
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setRegisterInitialRole(selectedRole || 'Customer');
                    setIsRegisterOpen(true);
                  }}
                  className="mt-2 inline-flex items-center gap-1.5 px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition"
                >
                  [ Register Now ]
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. SERVICES PREVIEW SECTION */}
      <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Services Available
            </h2>
            <p className="mt-3 text-slate-600 text-base">
              Explore essential household and neighborhood services delivered by cooperative-verified professionals.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {services.map((svc, index) => {
              const IconComp = svc.icon;
              return (
                <div
                  key={index}
                  onClick={() => scrollToSection('login', 'Customer')}
                  className="p-5 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:shadow-lg transition-all bg-slate-50/50 hover:bg-white flex flex-col justify-between group cursor-pointer"
                >
                  <div>
                    <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-900 text-base mb-1.5">
                      {svc.title}
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      {svc.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center text-xs font-bold text-emerald-700 group-hover:text-emerald-800">
                    <span>Book via Customer Login</span>
                    <ArrowRight className="w-3.5 h-3.5 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5. WHY COWORK CONNECT? SECTION */}
      <section id="why-us" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              The Cooperative Difference
            </div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Why CoWork Connect?
            </h2>
            <p className="mt-3 text-slate-600 text-base">
              Built on democratic cooperative principles where workers co-own the platform and communities receive reliable service.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Card 1 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4 text-2xl">
                🤝
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                Worker Cooperative
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Workers become cooperative members and participate in the platform with democratic voting rights.
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4 text-2xl">
                💰
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                Transparent Earnings
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Workers can clearly see their earnings and cooperative contribution with a capped 8-10% fee.
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-800 flex items-center justify-center mb-4 text-2xl">
                🤖
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                Smart Matching
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                AI-driven proximity matching pairs neighborhood requests with nearby verified professionals.
              </p>
            </div>

            {/* Card 4 */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center mb-4 text-2xl">
                🛡️
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                Verified & Trusted
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Aadhaar e-KYC, police verification, and peer cooperative vetting for absolute household safety.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. ABOUT SECTION */}
      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200/80">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider mb-3">
                About the Initiative
              </div>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Reinventing the Indian Gig Economy as a Cooperative
              </h2>
              <p className="mt-4 text-slate-600 text-sm leading-relaxed">
                Under the <strong>Digital Cooperative Platform Initiative</strong>, CoWork Connect solves the predatory commission model of traditional aggregators.
              </p>
              <p className="mt-3 text-slate-600 text-sm leading-relaxed">
                Instead of corporate intermediaries pocketing 30% of each service, our platform operates on an open-cooperative model: workers earn fair wages, receive patronage dividends, and retain community ownership.
              </p>
              <div className="mt-6 flex items-center gap-4">
                <button
                  onClick={() => scrollToSection('login')}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition"
                >
                  Access Platform
                </button>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-3xl p-8 space-y-4">
              <h3 className="text-base font-bold text-slate-900">Cooperative Charter Highlights</h3>
              <ul className="space-y-3 text-xs text-slate-700">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Democratic Governance:</strong> 1 Worker = 1 Vote on tariff and cooperative policy.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Annual Profit Sharing:</strong> Unspent cooperative fees returned as annual dividends.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Zero Exploitation:</strong> Transparent dispute resolution with community peer committees.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Standardized Rates:</strong> Guaranteed fair market pricing without predatory surges.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 7. CONTACT SECTION */}
      <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">🇮🇳</span>
                <span className="text-xl font-black tracking-tight">CoWork Connect</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Registered District Cooperative Platform. Connecting households with certified cooperative gig and agricultural service professionals.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3">
                Cooperative Helpline
              </h4>
              <ul className="space-y-2 text-xs text-slate-400">
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>1800-COOP-GIG (Toll Free 24x7)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-emerald-400" />
                  <span>support@coworkconnect.gov.in</span>
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>Tumakuru District Urban Co-op Division, Karnataka</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3">
                Quick Navigation
              </h4>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => scrollToSection('home')}
                  className="text-xs bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg text-slate-300"
                >
                  Home
                </button>
                <button
                  onClick={() => scrollToSection('services')}
                  className="text-xs bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg text-slate-300"
                >
                  Services
                </button>
                <button
                  onClick={() => scrollToSection('login')}
                  className="text-xs bg-emerald-800 hover:bg-emerald-700 px-3 py-1.5 rounded-lg text-emerald-200 font-bold"
                >
                  Login
                </button>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <p>© 2026 CoWork Connect — Cooperative Gig & Agricultural Platform. Registered under Karnataka Cooperative Societies Act.</p>
            <div className="flex items-center gap-4">
              <span>Privacy Policy</span>
              <span>•</span>
              <span>Terms of Service</span>
              <span>•</span>
              <span>Cooperative Bylaws</span>
            </div>
          </div>
        </div>
      </section>

      {/* REGISTRATION MODAL */}
      <RegistrationModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        initialRole={registerInitialRole}
        onRegisterSuccess={(newAccount) => {
          setSelectedRole(newAccount.role);
          setLoginId(newAccount.loginId);
          setPassword(newAccount.password);
          setSuccessMessage(`Account created for ${newAccount.fullName}! You can now click [ LOGIN ].`);
          scrollToSection('login');
        }}
      />

      {/* FORGOT PASSWORD MODAL (Section 4 Requirement) */}
      {showForgotPassword && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl animate-scale-up border border-slate-200">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-900 to-emerald-950 p-6 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">🔐</span>
                <div>
                  <h3 className="font-black text-base">Reset Account Password</h3>
                  <p className="text-xs text-emerald-300">CoWork Connect Security Portal</p>
                </div>
              </div>
              <button
                onClick={() => setShowForgotPassword(false)}
                className="text-slate-400 hover:text-white font-bold p-1 text-lg"
              >
                ✕
              </button>
            </div>

            {/* Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setForgotError('');
                setForgotSuccess('');

                if (!forgotIdOrPhone.trim()) {
                  setForgotError('Please enter your Login ID or registered phone number.');
                  return;
                }
                if (forgotOtp.trim() !== '2026' && forgotOtp.trim().length !== 4) {
                  setForgotError('Please enter the 4-digit verification OTP (use 2026 for demo).');
                  return;
                }
                if (!forgotNewPassword || forgotNewPassword.length < 4) {
                  setForgotError('New password must be at least 4 characters long.');
                  return;
                }
                if (forgotNewPassword !== forgotConfirmPassword) {
                  setForgotError('New password and confirm password do not match.');
                  return;
                }

                // Update password via context
                if (resetUserPassword) {
                  resetUserPassword(forgotIdOrPhone.trim(), forgotNewPassword);
                }

                // Auto-fill login inputs with new credentials
                setSelectedRole(forgotRole);
                setLoginId(forgotIdOrPhone.trim());
                setPassword(forgotNewPassword);
                setSuccessMessage(`Password updated successfully for ${forgotIdOrPhone.trim()}! Please click [ LOGIN ].`);

                setForgotSuccess('✓ Password reset successful!');
                setTimeout(() => {
                  setShowForgotPassword(false);
                  scrollToSection('login');
                }, 900);
              }}
              className="p-6 space-y-4 text-slate-800"
            >
              {forgotError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{forgotError}</span>
                </div>
              )}

              {forgotSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{forgotSuccess}</span>
                </div>
              )}

              {/* Role Picker */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Account Type
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Farmer', 'Customer', 'Worker'].map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setForgotRole(r)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                        forgotRole === r
                          ? 'bg-emerald-50 border-emerald-600 text-emerald-800 font-black'
                          : 'bg-slate-50 border-slate-200 text-slate-600'
                      }`}
                    >
                      {r === 'Farmer' ? '🌾 Farmer' : r === 'Customer' ? '👤 Customer' : '🛠️ Worker'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Login ID or Phone */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Login ID or Mobile Number *
                </label>
                <input
                  type="text"
                  value={forgotIdOrPhone}
                  onChange={(e) => setForgotIdOrPhone(e.target.value)}
                  placeholder="e.g. farmer01 or 94480 12345"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* OTP Simulation */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Verification OTP *
                  </label>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
                    Demo OTP: 2026
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={4}
                  value={forgotOtp}
                  onChange={(e) => setForgotOtp(e.target.value)}
                  placeholder="Enter 2026"
                  className="w-full px-3.5 py-2.5 text-sm tracking-widest font-black border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* New Password */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  New Password *
                </label>
                <input
                  type="password"
                  value={forgotNewPassword}
                  onChange={(e) => setForgotNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Confirm New Password *
                </label>
                <input
                  type="password"
                  value={forgotConfirmPassword}
                  onChange={(e) => setForgotConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-black shadow-lg"
                >
                  Reset Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
