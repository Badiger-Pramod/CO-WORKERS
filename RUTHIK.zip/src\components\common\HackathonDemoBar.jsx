import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  PlayCircle,
  ArrowRight,
  CheckCircle2,
  X,
  Sparkles,
  Award
} from 'lucide-react';

export const HackathonDemoBar = () => {
  const {
    isDemoModeActive,
    setIsDemoModeActive,
    demoStep,
    handleNextDemoStep
  } = useCoop();

  if (!isDemoModeActive) return null;

  const stepDescriptions = [
    { step: 1, title: 'Customer Login', desc: 'Logged in as Ananya Sharma (Household in Tumakuru).' },
    { step: 2, title: 'Select Plumbing', desc: 'Selected Plumbing Category for household repair.' },
    { step: 3, title: 'Select Location', desc: 'Confirmed location: Siddaganga Extension, Tumakuru.' },
    { step: 4, title: 'Date & Time Slot', desc: 'Requested Today, 2:30 PM slot.' },
    { step: 5, title: '⚡ SmartMatch AI', desc: 'Running 6-factor algorithmic matching on Tumakuru worker registry.' },
    { step: 6, title: 'AI Recommendation', desc: 'Ravi Kumar recommended with 94% Compatibility Score!' },
    { step: 7, title: 'Confirm Booking', desc: 'Booking created with transparent ₹400/₹75/₹25 fee split.' },
    { step: 8, title: 'Switch to Worker', desc: 'Logged in as Ravi Kumar (Co-owner Hub in Tumakuru).' },
    { step: 9, title: 'Worker Accepts', desc: 'Ravi accepted the job request into his active schedule.' },
    { step: 10, title: 'Mark "On The Way"', desc: 'Simulating live dispatch status & GPS ETA (~8 mins).' },
    { step: 11, title: 'Mark "Job Completed"', desc: 'Work executed cleanly at customer residence.' },
    { step: 12, title: 'Switch to Customer', desc: 'Returning to Ananya Sharma’s live booking tracker.' },
    { step: 13, title: 'Simulated Payment', desc: 'Processing ₹500 via Indian UPI Escrow (GPay/PhonePe).' },
    { step: 14, title: '5-Star Rating & Review', desc: 'Customer submits 5-star rating; worker reputation updates.' },
    { step: 15, title: 'Cooperative Dashboard', desc: 'Opening Tumakuru Community Cooperative Admin view.' },
    { step: 16, title: 'Complete Hackathon Flow', desc: 'All metrics, worker earnings & co-op welfare pool updated!' }
  ];

  const currentInfo = stepDescriptions.find(s => s.step === demoStep) || stepDescriptions[0];

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-3xl bg-slate-900/95 text-white p-4 rounded-2xl shadow-2xl border-2 border-amber-400 backdrop-blur-md animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-sm shrink-0 shadow-md">
            {demoStep}/16
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/40">
                SIH26089 Interactive Demo Flow
              </span>
              <h4 className="font-bold text-sm text-white">{currentInfo.title}</h4>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">{currentInfo.desc}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => setIsDemoModeActive(false)}
            className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Exit
          </button>

          <button
            onClick={handleNextDemoStep}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 text-xs font-black shadow-lg shadow-amber-500/30 flex items-center gap-1.5 transform active:scale-95 transition-all"
          >
            <span>{demoStep === 16 ? 'Finish Demo' : 'Next Demo Step'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Progress line */}
      <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
        <div
          className="bg-amber-400 h-full transition-all duration-500 rounded-full"
          style={{ width: `${(demoStep / 16) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};
