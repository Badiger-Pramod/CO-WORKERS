import React, { useState, useRef, useEffect } from 'react';
import { useCoop } from '../../context/CoopContext';
import { AGRI_WORKERS } from '../../data/agriMockData';
import { LANGUAGES } from '../../data/translations';
import {
  Bot,
  X,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  User,
  Star,
  ShieldCheck,
  MapPin,
  Clock,
  ArrowRight,
  Maximize2,
  Minimize2,
  RotateCcw,
  Zap,
  CheckCircle2,
  Phone,
  MessageSquare,
  Camera,
  Image as ImageIcon,
  Sliders,
  DollarSign,
  AlertTriangle,
  Layers,
  Cpu,
  ChevronRight,
  Activity,
  Award,
  Radio,
  Share2
} from 'lucide-react';

export const CoWorkAIAssistant = ({ onNavigate }) => {
  const { workers, currentLanguage, showToast, createBooking } = useCoop();
  
  // View & Mode States
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [activeMode, setActiveMode] = useState('chat'); // 'chat' | 'voice_orb' | 'vision'
  const [selectedLang, setSelectedLang] = useState(currentLanguage || 'en');
  const [voiceEnabled, setVoiceEnabled] = useState(true);

  // Chat & Input States
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'ai',
      text: "Hello! I am your **CoWork Autonomous AI Agent**.\n\nI can analyze photos of equipment or crop defects, run live worker SmartMatching, calculate fair cooperative escrow pricing, and dispatch certified local providers.",
      quickReplies: [
        '📸 Diagnose a photo / problem',
        '⚡ Find emergency electrician',
        '🌾 Tomato crop inspection & disease test',
        '💰 Compare co-op fees vs corporate apps',
      ],
      time: 'Just now',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [reasoningStep, setReasoningStep] = useState(null);
  const [isListening, setIsListening] = useState(false);

  // Vision Diagnosis States
  const [selectedImage, setSelectedImage] = useState(null);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const fileInputRef = useRef(null);

  // Live Voice Orb States
  const [orbSpeaking, setOrbSpeaking] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');

  const messagesEndRef = useRef(null);
  const recognitionRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized && activeMode === 'chat') {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized, isTyping, reasoningStep, activeMode]);

  // Text-To-Speech Synthesis
  const speakText = (text) => {
    if (!voiceEnabled || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*_#`]/g, '');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      const langMap = {
        en: 'en-IN',
        kn: 'kn-IN',
        hi: 'hi-IN',
        te: 'te-IN',
        ta: 'ta-IN',
        mr: 'mr-IN',
        bn: 'bn-IN',
      };
      utterance.lang = langMap[selectedLang] || 'en-IN';
      utterance.onstart = () => setOrbSpeaking(true);
      utterance.onend = () => setOrbSpeaking(false);
      utterance.onerror = () => setOrbSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('TTS error:', e);
      setOrbSpeaking(false);
    }
  };

  // Speech-To-Text Recognition
  const toggleListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showToast('Speech recognition not supported in this browser.', 'warning');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      const langMap = {
        en: 'en-IN',
        kn: 'kn-IN',
        hi: 'hi-IN',
        te: 'te-IN',
        ta: 'ta-IN',
        mr: 'mr-IN',
        bn: 'bn-IN',
      };
      recognition.lang = langMap[selectedLang] || 'en-IN';
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        const text = final || interim;
        setLiveTranscript(text);
        if (final) {
          setInputValue(final);
          handleSend(final);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.warn('Speech Recognition error:', err);
      setIsListening(false);
    }
  };

  // Advanced Autonomous Tool Reasoning Pipeline
  const runAutonomousReasoning = async (query) => {
    const lower = query.toLowerCase();

    // Visual Diagnosis Triggers
    if (lower.includes('photo') || lower.includes('diagnos') || lower.includes('picture') || lower.includes('camera')) {
      setActiveMode('vision');
      return {
        text: "I've activated the **Visual Diagnosis Engine**. Please upload or select a photo of your electrical board, plumbing leak, or crop leaves so I can run defect identification.",
      };
    }

    // Interactive Comparison Trigger
    if (lower.includes('compare') || lower.includes('vs') || lower.includes('difference')) {
      const w1 = (workers || [])[0] || { name: 'Ravi Kumar', trade: 'Electrician', rating: 4.9, hourlyRate: 350, completedJobs: 184 };
      const w2 = (workers || [])[1] || { name: 'Suresh Gowda', trade: 'Electrician', rating: 4.8, hourlyRate: 320, completedJobs: 142 };
      return {
        text: "Here is an autonomous **Cooperative Side-by-Side Comparison** of our top two rated specialists in this category:",
        comparison: {
          workerA: w1,
          workerB: w2,
        },
      };
    }

    // Agriculture / Crop Health Inquiries
    if (
      lower.includes('crop') ||
      lower.includes('tomato') ||
      lower.includes('farm') ||
      lower.includes('pest') ||
      lower.includes('soil') ||
      lower.includes('leaf') ||
      lower.includes('blight')
    ) {
      const topAgri = AGRI_WORKERS.filter((w) => w.available).slice(0, 2);
      return {
        text: "### Autonomous Crop Health Assessment\n\nBased on regional telemetry for **Tumakuru District**, our agronomy model identified high humidity conditions that often accelerate fungal spots or leaf-miner pests.\n\n**Recommended Specialist Dispatch:**",
        workers: topAgri,
        action: { label: 'Open Farmer Voice Seva Portal', route: 'farmer-dashboard' },
        disclaimer: 'Notice: Field evaluations provide on-site guidance. For chemical pesticide guidelines, please consult the local Krishi Vigyan Kendra (KVK).',
      };
    }

    // Electrical Emergency
    if (lower.includes('electric') || lower.includes('mcb') || lower.includes('tripping') || lower.includes('wire') || lower.includes('spark')) {
      const electricians = (workers || []).filter((w) => w.trade === 'Electrician' && w.available).slice(0, 2);
      return {
        text: "### Priority Dispatch: Electrical Safety\n\n⚠️ **Urgent Safety Warning**: If you observe burning odor or sparks, switch off your main incoming breaker immediately.\n\nI have filtered the registry for **licensed electricians with insulation testing equipment**:",
        workers: electricians.length > 0 ? electricians : (workers || []).slice(0, 2),
        action: { label: 'Dispatch Electrician to Customer Portal', route: 'customer-dashboard' },
      };
    }

    // Co-op Fee & Transparency Breakdown
    if (lower.includes('fee') || lower.includes('commission') || lower.includes('percent') || lower.includes('cost') || lower.includes('cheap')) {
      return {
        text: "### Fair Cooperative Pricing Matrix\n\n| Platform Metric | CoWork Connect (Co-op) | Traditional Corporate Apps |\n| :--- | :--- | :--- |\n| **Worker Commission** | **8% - 10% (Fixed)** | 25% - 35% Deducted |\n| **Surge Pricing** | **₹0 (Guaranteed)** | Up to 2.5x Multiplier |\n| **Worker Equity** | **100% Co-owners** | 0% (Independent Contract) |\n| **Annual Dividends** | **Yes (Shared Profits)** | None |\n| **Customer Escrow** | **Held until approval** | Billed immediately |",
        action: { label: 'Book Fair Gig Service', route: 'customer-dashboard' },
      };
    }

    // Default Fallback with live workers
    const top2 = (workers || []).slice(0, 2);
    return {
      text: "I analyzed your request against our **active cooperative network**. You can request instant booking, compare rates, or speak in any of 7 Indian languages.\n\nHere are verified providers available nearby:",
      workers: top2,
      action: { label: 'Open Customer Portal', route: 'customer-dashboard' },
    };
  };

  const handleSend = async (overrideText = null) => {
    const textToSend = overrideText || inputValue;
    if (!textToSend || !textToSend.trim()) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      text: textToSend.trim(),
      time: 'Just now',
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Multi-Step Chain of Thought Simulation
    setReasoningStep('Parsing request intent & regional parameters...');
    await new Promise((r) => setTimeout(r, 400));
    setReasoningStep('Searching verified cooperative worker registry...');
    await new Promise((r) => setTimeout(r, 450));
    setReasoningStep('Applying 0% surge cooperative pricing matrix...');
    await new Promise((r) => setTimeout(r, 350));
    setReasoningStep(null);

    const result = await runAutonomousReasoning(textToSend);

    const aiMessage = {
      id: Date.now() + 1,
      sender: 'ai',
      text: result.text,
      workers: result.workers,
      comparison: result.comparison,
      action: result.action,
      disclaimer: result.disclaimer,
      time: 'Just now',
    };

    setMessages((prev) => [...prev, aiMessage]);
    setIsTyping(false);
    speakText(result.text);
  };

  // Preset Sample Diagnoses for Visual Diagnosis
  const handleSampleDiagnosis = (type) => {
    setIsAnalyzingImage(true);
    setTimeout(() => {
      setIsAnalyzingImage(false);
      setActiveMode('chat');
      let analysisText = '';
      let matchedWorkers = [];

      if (type === 'tomato') {
        analysisText = "📸 **Visual Diagnosis Result: Early Blight (Alternaria solani)**\n\n• **Detected Defect**: Dark concentric ring lesions on lower tomato foliage.\n• **Severity**: Moderate (Stage 2)\n• **Recommended Action**: Prune infected leaves, avoid overhead watering, apply copper-based fungicide.\n\nMatched certified plant pathologist from **Tumakuru Farmers Cooperative**:";
        matchedWorkers = AGRI_WORKERS.filter((w) => w.primarySkill.includes('Pest') || w.primarySkill.includes('Crop')).slice(0, 2);
      } else if (type === 'mcb') {
        analysisText = "📸 **Visual Diagnosis Result: High-Load Terminal Overheating**\n\n• **Detected Defect**: Charred neutral terminal wire at 32A Miniature Circuit Breaker.\n• **Hazard Level**: ⚠️ High (Fire Risk)\n• **Recommended Action**: Do not reset breaker. Busbar isolation and lug replacement required.\n\nMatched certified electrician with thermal testing equipment:";
        matchedWorkers = (workers || []).filter((w) => w.trade === 'Electrician').slice(0, 2);
      } else {
        analysisText = "📸 **Visual Diagnosis Result: Compression Joint Pipe Rupture**\n\n• **Detected Defect**: Degraded rubber gasket causing steady 1.2L/min leakage under kitchen sink.\n• **Severity**: Medium\n• **Recommended Action**: Replace 1.5-inch PVC compression trap & Teflon tape sealing.\n\nMatched certified cooperative plumber nearby:";
        matchedWorkers = (workers || []).filter((w) => w.trade === 'Plumber').slice(0, 2);
      }

      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          sender: 'ai',
          text: analysisText,
          workers: matchedWorkers,
          action: { label: 'Book Specialist Now', route: 'customer-dashboard' },
          time: 'Just now',
        },
      ]);
      speakText(analysisText);
    }, 1200);
  };

  return (
    <>
      {/* ============================================================ */}
      {/* ADVANCED FLOATING LAUNCHER BUTTON                             */}
      {/* ============================================================ */}
      {!isOpen && (
        <button
          onClick={() => {
            setIsOpen(true);
            setIsMinimized(false);
          }}
          className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-3 sm:px-5 sm:py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-full shadow-2xl shadow-emerald-950/70 border border-emerald-400/40 hover:scale-105 active:scale-95 transition-all group cursor-pointer"
          title="Launch Advanced AI Assistant"
        >
          {/* Animated Ambient Glow */}
          <span className="absolute -inset-1 rounded-full bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 opacity-35 blur-md group-hover:opacity-80 animate-pulse transition"></span>

          {/* Icon Badge */}
          <div className="relative w-8 h-8 rounded-full bg-[#0D121D] flex items-center justify-center border border-white/20">
            <Sparkles className="w-4 h-4 text-cyan-300 animate-spin [animation-duration:8s]" />
          </div>

          <div className="relative hidden sm:flex flex-col text-left">
            <span className="font-black text-xs tracking-wider flex items-center gap-1.5">
              <span>CoWork AI</span>
              <span className="px-1.5 py-0.2 rounded-full bg-cyan-400/20 text-cyan-300 text-[9px] font-extrabold border border-cyan-400/30">
                PRO
              </span>
            </span>
            <span className="text-[10px] text-emerald-200">Voice · Vision · SmartMatch</span>
          </div>

          <span className="relative w-2 h-2 rounded-full bg-emerald-300 animate-ping"></span>
        </button>
      )}

      {/* ============================================================ */}
      {/* EXPANDED ADVANCED AI WORKSPACE WINDOW                         */}
      {/* ============================================================ */}
      {isOpen && (
        <div
          className={`fixed bottom-6 right-6 z-50 bg-[#0B0F17]/95 backdrop-blur-2xl border border-cyan-500/40 rounded-3xl shadow-2xl shadow-black flex flex-col overflow-hidden transition-all duration-300 ${
            isMinimized
              ? 'w-72 h-14'
              : 'w-[94vw] sm:w-[480px] h-[640px] max-h-[88vh]'
          }`}
        >
          {/* ============================================================ */}
          {/* TOP CONTROL BAR & TELEMETRY                                  */}
          {/* ============================================================ */}
          <div className="bg-gradient-to-r from-[#0F1726] via-[#101F2C] to-[#0D1420] px-4 py-3 border-b border-cyan-500/20 flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 via-cyan-400 to-blue-500 p-[1px] shadow-lg shadow-cyan-950/50">
                <div className="w-full h-full bg-[#0B0F17] rounded-[11px] flex items-center justify-center">
                  <Bot className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-black text-xs text-white">CoWork Autonomous AI</h3>
                  <span className="px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[8px] font-bold">
                    v2.5
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>14ms Latency</span>
                  </span>
                  <span>•</span>
                  <span>Co-op Certified</span>
                </div>
              </div>
            </div>

            {/* Header Controls */}
            <div className="flex items-center gap-1.5">
              {/* Language Selector */}
              <select
                value={selectedLang}
                onChange={(e) => setSelectedLang(e.target.value)}
                className="bg-slate-800 text-slate-200 text-[10px] font-bold px-2 py-1 rounded-lg border border-white/10 focus:outline-none cursor-pointer"
                title="Change language"
              >
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName}
                  </option>
                ))}
              </select>

              {/* TTS Mute Toggle */}
              <button
                onClick={() => {
                  setVoiceEnabled(!voiceEnabled);
                  if (voiceEnabled && window.speechSynthesis) {
                    window.speechSynthesis.cancel();
                  }
                }}
                className={`p-1.5 rounded-lg border transition cursor-pointer ${
                  voiceEnabled
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
                title={voiceEnabled ? 'Mute AI voice output' : 'Enable AI voice output'}
              >
                {voiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              </button>

              {/* Minimize */}
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition cursor-pointer"
                title={isMinimized ? 'Expand' : 'Minimize'}
              >
                {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
              </button>

              {/* Close */}
              <button
                onClick={() => {
                  setIsOpen(false);
                  if (window.speechSynthesis) window.speechSynthesis.cancel();
                }}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition cursor-pointer"
                title="Close Assistant"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* ============================================================ */}
          {/* THREE ADVANCED SUB-MODE TABS (Chat, Live Voice Orb, Vision)   */}
          {/* ============================================================ */}
          {!isMinimized && (
            <div className="bg-[#0D131F] px-4 py-2 border-b border-white/[0.06] flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setActiveMode('chat')}
                  className={`px-3 py-1 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeMode === 'chat'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat & Tools</span>
                </button>

                <button
                  onClick={() => {
                    setActiveMode('voice_orb');
                    if (!isListening) toggleListening();
                  }}
                  className={`px-3 py-1 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeMode === 'voice_orb'
                      ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>Live Voice Orb</span>
                </button>

                <button
                  onClick={() => setActiveMode('vision')}
                  className={`px-3 py-1 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeMode === 'vision'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Visual Diagnosis</span>
                </button>
              </div>

              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider hidden sm:inline">
                Multimodal
              </span>
            </div>
          )}

          {/* ============================================================ */}
          {/* MODE 1: CHAT & AUTONOMOUS TOOLS                              */}
          {/* ============================================================ */}
          {!isMinimized && activeMode === 'chat' && (
            <>
              <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.sender === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[88%] rounded-2xl px-4 py-3 leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-br-xs shadow-md shadow-emerald-950/40'
                          : 'bg-[#151D2C] text-slate-200 border border-white/[0.08] rounded-bl-xs shadow-lg shadow-black/40'
                      }`}
                    >
                      {/* Message Body */}
                      <p className="whitespace-pre-line font-medium text-xs leading-relaxed">
                        {msg.text}
                      </p>

                      {/* Side-by-Side Worker Comparison Matrix */}
                      {msg.comparison && (
                        <div className="mt-3 p-3 bg-[#0E1522] rounded-xl border border-cyan-500/30">
                          <p className="text-[10px] text-cyan-400 font-extrabold uppercase tracking-wide mb-2 flex items-center gap-1">
                            <Zap className="w-3 h-3" /> Side-by-Side Worker Evaluation
                          </p>
                          <div className="grid grid-cols-2 gap-2 text-[11px]">
                            {/* Candidate A */}
                            <div className="p-2.5 rounded-lg bg-[#141D2E] border border-white/5">
                              <p className="font-black text-white text-xs">{msg.comparison.workerA.name}</p>
                              <p className="text-[10px] text-slate-400">{msg.comparison.workerA.trade}</p>
                              <div className="mt-2 space-y-1 text-[10px]">
                                <p className="text-amber-400 font-bold">⭐ {msg.comparison.workerA.rating} rating</p>
                                <p className="text-emerald-400 font-black">₹{msg.comparison.workerA.hourlyRate}/hr</p>
                                <p className="text-slate-400">{msg.comparison.workerA.completedJobs} jobs done</p>
                              </div>
                              <button
                                onClick={() => {
                                  showToast(`Selected ${msg.comparison.workerA.name}`, 'success');
                                  if (onNavigate) onNavigate('customer-dashboard');
                                }}
                                className="mt-2.5 w-full py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-md text-[10px] font-bold transition cursor-pointer"
                              >
                                Select
                              </button>
                            </div>

                            {/* Candidate B */}
                            <div className="p-2.5 rounded-lg bg-[#141D2E] border border-white/5">
                              <p className="font-black text-white text-xs">{msg.comparison.workerB.name}</p>
                              <p className="text-[10px] text-slate-400">{msg.comparison.workerB.trade}</p>
                              <div className="mt-2 space-y-1 text-[10px]">
                                <p className="text-amber-400 font-bold">⭐ {msg.comparison.workerB.rating} rating</p>
                                <p className="text-emerald-400 font-black">₹{msg.comparison.workerB.hourlyRate}/hr</p>
                                <p className="text-slate-400">{msg.comparison.workerB.completedJobs} jobs done</p>
                              </div>
                              <button
                                onClick={() => {
                                  showToast(`Selected ${msg.comparison.workerB.name}`, 'success');
                                  if (onNavigate) onNavigate('customer-dashboard');
                                }}
                                className="mt-2.5 w-full py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-md text-[10px] font-bold transition cursor-pointer"
                              >
                                Select
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Worker Recommendation Cards */}
                      {msg.workers && msg.workers.length > 0 && (
                        <div className="mt-3 space-y-2">
                          {msg.workers.map((w) => (
                            <div
                              key={w.id}
                              className="bg-[#0D1420] border border-emerald-500/30 rounded-xl p-2.5 flex items-center justify-between gap-2 hover:border-emerald-400 transition"
                            >
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-lg bg-emerald-900/60 flex items-center justify-center text-sm font-bold text-emerald-300">
                                  {w.avatar || '👨‍🔧'}
                                </div>
                                <div>
                                  <div className="flex items-center gap-1">
                                    <p className="font-bold text-white text-xs">{w.name}</p>
                                    <ShieldCheck className="w-3 h-3 text-cyan-400" />
                                  </div>
                                  <p className="text-[10px] text-slate-400">
                                    {w.primarySkill || w.trade} · ⭐ {w.rating}
                                  </p>
                                </div>
                              </div>

                              <div className="text-right">
                                <p className="text-xs font-black text-emerald-400">
                                  ₹{w.hourlyRate || 350}/hr
                                </p>
                                <button
                                  onClick={() => {
                                    showToast(`Connecting you with ${w.name}...`, 'success');
                                    if (onNavigate) onNavigate('customer-dashboard');
                                  }}
                                  className="mt-1 px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold transition cursor-pointer"
                                >
                                  Book Now
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Action Navigation */}
                      {msg.action && (
                        <button
                          onClick={() => {
                            if (onNavigate) onNavigate(msg.action.route);
                            showToast(`Navigating to ${msg.action.label}`, 'info');
                          }}
                          className="mt-3 w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-[11px] shadow-md flex items-center justify-center gap-1.5 transition cursor-pointer"
                        >
                          <span>{msg.action.label}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* Disclaimer */}
                      {msg.disclaimer && (
                        <div className="mt-2.5 p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-[10px] text-amber-300 leading-tight">
                          {msg.disclaimer}
                        </div>
                      )}

                      {/* Footer time & TTS playback */}
                      {msg.sender === 'ai' && (
                        <div className="mt-2 flex items-center justify-between text-[10px] text-slate-500 border-t border-white/[0.05] pt-1.5">
                          <span>{msg.time}</span>
                          <button
                            onClick={() => speakText(msg.text)}
                            className="text-slate-400 hover:text-cyan-400 flex items-center gap-1 transition cursor-pointer"
                            title="Listen to response"
                          >
                            <Volume2 className="w-3 h-3" />
                            <span>Listen</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Quick Replies */}
                    {msg.quickReplies && (
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        {msg.quickReplies.map((qr) => (
                          <button
                            key={qr}
                            onClick={() => handleSend(qr)}
                            className="px-2.5 py-1 rounded-full bg-slate-800/90 hover:bg-cyan-600/30 border border-slate-700 hover:border-cyan-500/50 text-[10px] text-slate-300 hover:text-white transition cursor-pointer"
                          >
                            {qr}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                {/* Chain-of-Thought Reasoning Visualizer */}
                {reasoningStep && (
                  <div className="p-3 bg-[#111927] border border-cyan-500/30 rounded-2xl text-xs space-y-1.5 animate-pulse">
                    <div className="flex items-center gap-2 text-cyan-400 font-bold text-[11px]">
                      <Cpu className="w-3.5 h-3.5 animate-spin" />
                      <span>Autonomous Co-op Reasoning</span>
                    </div>
                    <p className="text-slate-300 text-[11px] font-mono pl-5">
                      ✦ {reasoningStep}
                    </p>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* INPUT BAR */}
              <div className="p-3 bg-[#090D15] border-t border-white/[0.08] flex items-center gap-2 shrink-0">
                <button
                  onClick={toggleListening}
                  className={`p-2.5 rounded-xl transition flex items-center justify-center cursor-pointer ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/50'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-white/5'
                  }`}
                  title={isListening ? 'Listening...' : 'Speak in your regional language'}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>

                <input
                  type="text"
                  placeholder={
                    isListening
                      ? 'Listening to your speech...'
                      : 'Ask anything (e.g. Tomato blight, find plumber)...'
                  }
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSend();
                  }}
                  className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
                />

                <button
                  onClick={() => handleSend()}
                  disabled={!inputValue.trim()}
                  className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:opacity-95 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-md shadow-cyan-950/40 transition cursor-pointer"
                  title="Send query"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </>
          )}

          {/* ============================================================ */}
          {/* MODE 2: LIVE VOICE ORB MODE (Futuristic Gemini Live Siri UI) */}
          {/* ============================================================ */}
          {!isMinimized && activeMode === 'voice_orb' && (
            <div className="flex-1 flex flex-col items-center justify-between p-6 text-center bg-radial from-[#122336] via-[#0B0F17] to-[#070A10]">
              
              <div>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                  Gemini Live Audio Engine
                </span>
                <h4 className="text-lg font-black text-white mt-2">Hands-Free Live Voice Conversation</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Speak naturally in Kannada, Hindi, or English. The assistant will respond conversationally.
                </p>
              </div>

              {/* Glowing 3D Animated Pulsing Orb */}
              <div className="relative my-8 flex items-center justify-center">
                {/* Outer Glow Circles */}
                <div
                  className={`absolute w-56 h-56 rounded-full bg-gradient-to-tr from-cyan-500/30 via-emerald-500/20 to-blue-500/30 blur-2xl transition-all duration-500 ${
                    orbSpeaking || isListening ? 'scale-125 opacity-90' : 'scale-100 opacity-40'
                  }`}
                ></div>

                {/* Animated Rings */}
                <div
                  className={`w-40 h-40 rounded-full bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 p-[3px] shadow-2xl transition-transform duration-300 ${
                    isListening ? 'animate-spin [animation-duration:12s]' : ''
                  }`}
                >
                  <div className="w-full h-full bg-[#0B0F17] rounded-full flex flex-col items-center justify-center relative overflow-hidden">
                    {/* Simulated Voice Waveform Oscillators */}
                    <div className="flex items-center gap-1.5 h-12">
                      {[6, 14, 28, 42, 28, 14, 6].map((h, i) => (
                        <span
                          key={i}
                          className="w-1.5 bg-gradient-to-t from-cyan-400 to-emerald-400 rounded-full transition-all duration-150"
                          style={{
                            height: (orbSpeaking || isListening) ? `${Math.max(6, (h * (Math.random() + 0.5)))}px` : '6px',
                          }}
                        ></span>
                      ))}
                    </div>

                    <p className="text-[10px] font-bold text-cyan-300 mt-1">
                      {orbSpeaking ? 'Speaking...' : isListening ? 'Listening...' : 'Tap Mic to Talk'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Live Transcript / Prompt Preview */}
              <div className="w-full max-w-sm bg-slate-900/80 border border-white/10 rounded-2xl p-3 min-h-[56px] flex items-center justify-center">
                <p className="text-xs text-slate-300 italic">
                  {liveTranscript ? `"${liveTranscript}"` : 'Say "I need someone to inspect my tomato crop"'}
                </p>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-4 mt-4">
                <button
                  onClick={toggleListening}
                  className={`p-4 rounded-full shadow-xl transition-all cursor-pointer ${
                    isListening
                      ? 'bg-red-500 text-white ring-4 ring-red-500/30'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>

                <button
                  onClick={() => setActiveMode('chat')}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-white/10 cursor-pointer"
                >
                  Back to Text Chat
                </button>
              </div>

            </div>
          )}

          {/* ============================================================ */}
          {/* MODE 3: VISUAL DIAGNOSIS (Photos of crops / equipment)       */}
          {/* ============================================================ */}
          {!isMinimized && activeMode === 'vision' && (
            <div className="flex-1 flex flex-col p-4 overflow-y-auto text-xs space-y-4">
              <div className="bg-gradient-to-br from-amber-500/10 to-transparent p-4 rounded-2xl border border-amber-500/30">
                <div className="flex items-center gap-2 text-amber-400 font-bold mb-1">
                  <Camera className="w-4 h-4" />
                  <span>Multimodal Visual Defect Scanner</span>
                </div>
                <p className="text-slate-300 text-xs leading-relaxed">
                  Upload an image of a damaged motor, leaking plumbing joint, or diseased crop leaves. Our vision model identifies the fault and dispatches the exact cooperative technician.
                </p>
              </div>

              {/* Quick Sample Photos for Hackathon Testing */}
              <div>
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-2">
                  ⚡ Instant Test Photos (Click to Diagnose):
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    onClick={() => handleSampleDiagnosis('tomato')}
                    disabled={isAnalyzingImage}
                    className="p-3 bg-[#151D2C] hover:bg-[#1a2538] border border-white/10 hover:border-emerald-500/50 rounded-xl text-left transition group cursor-pointer"
                  >
                    <span className="text-2xl">🍅</span>
                    <p className="font-bold text-white text-xs mt-1 group-hover:text-emerald-400">Tomato Leaves</p>
                    <p className="text-[10px] text-slate-400">Yellow spots & blight</p>
                  </button>

                  <button
                    onClick={() => handleSampleDiagnosis('mcb')}
                    disabled={isAnalyzingImage}
                    className="p-3 bg-[#151D2C] hover:bg-[#1a2538] border border-white/10 hover:border-amber-500/50 rounded-xl text-left transition group cursor-pointer"
                  >
                    <span className="text-2xl">⚡</span>
                    <p className="font-bold text-white text-xs mt-1 group-hover:text-amber-400">MCB Tripping</p>
                    <p className="text-[10px] text-slate-400">Burnt breaker lug</p>
                  </button>

                  <button
                    onClick={() => handleSampleDiagnosis('pipe')}
                    disabled={isAnalyzingImage}
                    className="p-3 bg-[#151D2C] hover:bg-[#1a2538] border border-white/10 hover:border-cyan-500/50 rounded-xl text-left transition group cursor-pointer"
                  >
                    <span className="text-2xl">🚿</span>
                    <p className="font-bold text-white text-xs mt-1 group-hover:text-cyan-400">Pipe Leakage</p>
                    <p className="text-[10px] text-slate-400">Sink drain joint</p>
                  </button>
                </div>
              </div>

              {/* Custom Upload Dropzone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-700 hover:border-cyan-500/60 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition bg-slate-900/40 hover:bg-slate-900/80"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleSampleDiagnosis('tomato');
                    }
                  }}
                />
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-2">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <p className="text-white font-bold text-xs">
                  {isAnalyzingImage ? 'Analyzing Image with Gemini Vision...' : 'Upload Equipment or Crop Photo'}
                </p>
                <p className="text-slate-400 text-[10px] mt-1">PNG, JPG, or HEIC up to 10MB</p>
              </div>

              {isAnalyzingImage && (
                <div className="p-3 bg-cyan-950/60 border border-cyan-500/40 rounded-xl flex items-center gap-3">
                  <span className="w-4 h-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin"></span>
                  <span className="text-xs text-cyan-200 font-bold">Scanning features & diagnosing fault...</span>
                </div>
              )}
            </div>
          )}

        </div>
      )}
    </>
  );
};
