import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';
import { broadcastEvent } from '../services/socketService';

// GET /api/admin/overview
export const getAdminOverview = async (_req: Request, res: Response): Promise<void> => {
  try {
    const totalUsers = localStore.users.length;
    const customers = localStore.users.filter(u => u.role === 'CUSTOMER').length;
    const workers = localStore.users.filter(u => u.role === 'WORKER').length;
    const farmers = localStore.users.filter(u => u.role === 'FARMER').length;

    const totalBookings = localStore.job_requests.length;
    const completedBookings = localStore.job_requests.filter(
      j => j.status === 'COMPLETED' || j.status === 'PAID' || j.status === 'RATED'
    ).length;
    const activeBookings = localStore.job_requests.filter(
      j => j.status === 'REQUESTED' || j.status === 'ACCEPTED' || j.status === 'SCHEDULED' || j.status === 'ON_THE_WAY' || j.status === 'WORK_STARTED'
    ).length;

    const totalRevenue = localStore.job_requests
      .filter(j => j.payment_status === 'SUCCESS' || j.status === 'PAID' || j.status === 'RATED')
      .reduce((sum, j) => sum + (j.estimated_price || 0), 0);

    const coopWelfareFund = localStore.job_requests
      .filter(j => j.payment_status === 'SUCCESS' || j.status === 'PAID' || j.status === 'RATED')
      .reduce((sum, j) => sum + (j.coop_fund || 0), 0);

    const equipmentCount = localStore.equipment.length;
    const complaintsPending = localStore.complaints.filter(c => c.status === 'PENDING' || c.status === 'UNDER_REVIEW').length;
    const complaintsResolved = localStore.complaints.filter(c => c.status === 'RESOLVED').length;

    res.json({
      success: true,
      stats: {
        total_users: totalUsers,
        customer_count: customers,
        worker_count: workers,
        farmer_count: farmers,
        total_bookings: totalBookings,
        completed_bookings: completedBookings,
        active_bookings: activeBookings,
        total_revenue: totalRevenue,
        coop_welfare_fund: coopWelfareFund,
        equipment_listings_count: equipmentCount,
        pending_complaints_count: complaintsPending,
        resolved_complaints_count: complaintsResolved
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to calculate admin metrics.' });
  }
};

// PUT /api/admin/verify-worker/:id
export const verifyWorker = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { status = 'Verified' } = req.body;

    const wp = localStore.worker_profiles.find(w => w.user_id === userId);
    if (!wp) {
      res.status(404).json({ success: false, message: 'Worker profile not found.' });
      return;
    }

    wp.verification_status = status;
    wp.updated_at = new Date().toISOString();
    persistLocalStore();

    broadcastEvent(`user_${userId}`, 'verification_updated', {
      type: 'worker',
      verification_status: status
    });

    res.json({ success: true, message: `Worker verification status updated to ${status}` });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to verify worker.' });
  }
};

// PUT /api/admin/verify-farmer/:id
export const verifyFarmer = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { status = 'Verified' } = req.body;

    const fp = localStore.farmer_profiles.find(f => f.user_id === userId);
    if (!fp) {
      res.status(404).json({ success: false, message: 'Farmer profile not found.' });
      return;
    }

    fp.verification_status = status;
    fp.updated_at = new Date().toISOString();
    persistLocalStore();

    broadcastEvent(`user_${userId}`, 'verification_updated', {
      type: 'farmer',
      verification_status: status
    });

    res.json({ success: true, message: `Farmer verification status updated to ${status}` });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to verify farmer.' });
  }
};
