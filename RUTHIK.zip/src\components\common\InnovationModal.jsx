import React, { useEffect } from 'react';
import {
  ShieldCheck,
  Bot,
  Percent,
  CheckCircle2,
  Globe2,
  Users,
  HeartHandshake,
  BarChart3,
  X,
  Sparkles
} from 'lucide-react';

export const InnovationModal = ({ isOpen, onClose }) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const innovations = [
    {
      num: '01',
      title: 'Worker-Owned Cooperative Model',
      icon: Users,
      desc: 'Unlike predatory aggregators that charge 25-35% commission, CoWork Connect is legally registered as a multi-stakeholder cooperative where gig workers hold Class-A equity shares and participate in democratic board decisions (1 Worker = 1 Vote).'
    },
    {
      num: '02',
      title: 'AI-Based Worker-Job Matching (SmartMatch)',
      icon: Bot,
      desc: 'Our rule-based & ML-ready matching engine calculates compatibility using 6 transparent parameters: skill taxonomy, geo-proximity, live availability, peer customer ratings, verified experience, and automated workload fairness distribution.'
    },
    {
      num: '03',
      title: 'Transparent Earnings & Capped Co-op Fee',
      icon: Percent,
      desc: 'Guaranteed 8-10% transparent cooperative retention (80% worker payout, 15% co-op welfare & health fund, 5% digital platform maintenance). Every customer sees an upfront itemized bill with zero predatory surge pricing.'
    },
    {
      num: '04',
      title: '3-Layer Verified Local Workers',
      icon: ShieldCheck,
      desc: 'Rigorous onboarding combining Aadhaar e-KYC, police background clearance, and trade guild practical assessment. Verified badges (Identity Verified, Skill Verified, Co-op Member) give households complete peace of mind.'
    },
    {
      num: '05',
      title: 'Multilingual India-First Design',
      icon: Globe2,
      desc: 'Engineered for Bharat with seamless language switching across 8 Indian languages: English, Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, and Bengali. Optimized for voice prompts and local dialect navigation.'
    },
    {
      num: '06',
      title: 'Hyper-Local Employment Generation',
      icon: HeartHandshake,
      desc: 'Every rupee spent stays within the local municipal ward. We partner with Resident Welfare Associations (RWAs) and Town Cooperatives (e.g. Tumakuru Community Services Co-op) to build resilient micro-economies.'
    },
    {
      num: '07',
      title: 'Community-Focused Services & Peer Mediation',
      icon: CheckCircle2,
      desc: 'Includes specialized elder care, municipal mutual aid, and priority 24x7 SOS emergency dispatch. Disputes are arbitrated within 2 hours by an elected 3-member peer mediation committee rather than opaque AI bots.'
    },
    {
      num: '08',
      title: 'Data-Driven Open Cooperative Management',
      icon: BarChart3,
      desc: 'Real-time open accounting dashboard accessible by union registrars, board trustees, and workers. Unspent cooperative surplus is redistributed annually to active gig workers as patronage dividends.'
    }
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 sm:my-8 relative flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-950 text-white p-5 sm:p-7 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-md border border-white/20"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
            <span>Close ✕</span>
          </button>
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-extrabold uppercase tracking-wider mb-2 border border-emerald-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Platform Core Innovation Statement</span>
          </div>
          
          <h2 className="text-xl sm:text-2xl font-black tracking-tight pr-20">
            Why Our Platform Is Different
          </h2>
          <p className="text-slate-300 text-xs mt-1 max-w-2xl leading-relaxed">
            CoWork Connect reimagines the Indian gig economy from an extractive corporate monopoly into a democratic, tech-enabled worker cooperative.
          </p>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto flex-1 p-5 sm:p-7 space-y-6">
          {/* Comparison Table */}
          <div className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-2xl">
            <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-2.5">
              At A Glance: Corporate Aggregator vs. CoWork Connect Co-op
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                    <th className="pb-2">Dimension</th>
                    <th className="pb-2 text-red-600">Corporate Aggregators</th>
                    <th className="pb-2 text-emerald-800">CoWork Connect Co-op</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700 font-medium">
                  <tr>
                    <td className="py-2 font-bold">Commission / Fee</td>
                    <td className="py-2 text-red-600">25% - 35% commission + lead fees</td>
                    <td className="py-2 text-emerald-800 font-bold">8% - 10% capped co-op contribution</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold">Worker Status</td>
                    <td className="py-2 text-slate-600">Contractor with zero rights</td>
                    <td className="py-2 text-emerald-800 font-bold">Class-A Equity Co-owner with voting power</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold">Surge Pricing</td>
                    <td className="py-2 text-red-600">Surge multipliers (1.5x - 2.5x)</td>
                    <td className="py-2 text-emerald-800 font-bold">Zero surge, cooperative standardized tariffs</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold">Surplus Profits</td>
                    <td className="py-2 text-slate-600">Offshored to venture shareholders</td>
                    <td className="py-2 text-emerald-800 font-bold">Returned to workers as annual dividends</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 8 Innovations */}
          <div>
            <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-3">
              8 Core Innovation Pillars
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {innovations.map((item, idx) => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-emerald-300 transition flex flex-col justify-between shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center font-bold">
                          <IconComponent className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-black text-slate-300 font-mono">
                          {item.num}
                        </span>
                      </div>
                      <h4 className="font-extrabold text-xs text-slate-900 mb-1">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <p className="text-xs text-slate-500 font-medium text-center sm:text-left">
            Verified under Karnataka Cooperative Societies Act & Digital Platform Guidelines.
          </p>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
          >
            Dismiss / Close Window
          </button>
        </div>

      </div>
    </div>
  );
};
