import { Request, Response } from 'express';
import { dbQuery } from '../config/db';

// GET /api/cooperatives
export const getCooperatives = async (req: Request, res: Response): Promise<void> => {
  try {
    const coopRes = await dbQuery('SELECT * FROM cooperatives ORDER BY id ASC');
    res.status(200).json({
      success: true,
      cooperatives: coopRes.rows
    });
  } catch (err) {
    console.error('[Cooperative] Get error:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve cooperatives.' });
  }
};
