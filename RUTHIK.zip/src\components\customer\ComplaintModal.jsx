import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  X,
  AlertTriangle,
  Scale,
  ShieldAlert,
  Send,
  ArrowRight,
  Info
} from 'lucide-react';

export const ComplaintModal = () => {
  const {
    isComplaintModalOpen,
    setIsComplaintModalOpen,
    raiseComplaint,
    activeBookingId,
    bookings
  } = useCoop();

  const [category, setCategory] = useState("Worker didn't arrive / Late arrival");
  const [description, setDescription] = useState('Worker arrived 30 minutes later than the scheduled 2:30 PM slot without prior notice.');
  const [workerName, setWorkerName] = useState('Ravi Kumar');

  if (!isComplaintModalOpen) return null;

  const booking = bookings.find(b => b.id === activeBookingId) || bookings[0];

  const categories = [
    "Worker didn't arrive / Late arrival",
    "Poor service quality / Incomplete job",
    "Overcharging / Price dispute",
    "Payment / App issue",
    "Unprofessional conduct / Other"
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    raiseComplaint({
      category,
      description,
      workerName: booking ? booking.workerName : workerName
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-700 to-red-900 text-white p-6 flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Scale className="w-5 h-5 text-rose-200" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Raise Issue to Co-op Mediation Board</h3>
              <p className="text-xs text-rose-200 mt-0.5">
                Managed under Tumakuru Cooperative Fair Resolution Charter
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsComplaintModalOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Select Issue Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            >
              {categories.map((c, i) => (
                <option key={i} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Service Worker Associated
            </label>
            <input
              type="text"
              value={booking ? `${booking.workerName} (${booking.workerTrade})` : workerName}
              readOnly
              className="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-600 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Detailed Description & Evidence
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows="3"
              required
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
              placeholder="Explain exactly what happened so the Co-op Mediator can investigate..."
            />
          </div>

          {/* Guarantee Pill */}
          <div className="bg-amber-50 p-3.5 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              Every complaint is assigned directly to a local cooperative board member (S. R. Patil) with a guaranteed 4-hour review SLA and full money-back protection.
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsComplaintModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-lg shadow-rose-600/30 flex items-center gap-1.5 transition-all transform active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>Submit Ticket to Admin</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
