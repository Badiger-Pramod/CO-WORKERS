import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  AlertTriangle,
  Zap,
  Wrench,
  HeartHandshake,
  Clock,
  MapPin,
  ShieldAlert,
  ArrowRight,
  X,
  PhoneCall,
  CheckCircle2
} from 'lucide-react';

export const EmergencyBookingModal = () => {
  const {
    isEmergencyModalOpen,
    setIsEmergencyModalOpen,
    emergencyServices,
    createEmergencyBooking
  } = useCoop();

  const [selectedServiceId, setSelectedServiceId] = useState(emergencyServices[0].id);
  const [address, setAddress] = useState('Flat 402, Shanti Vihar, 12th Main, Indiranagar');
  const [notes, setNotes] = useState('Sparks from main switchboard, need rapid emergency isolation.');

  if (!isEmergencyModalOpen) return null;

  const currentService = emergencyServices.find(s => s.id === selectedServiceId) || emergencyServices[0];

  const handleSubmit = (e) => {
    e.preventDefault();
    createEmergencyBooking({
      trade: currentService.trade,
      serviceTitle: currentService.title,
      address,
      notes,
      estimatedMinutes: currentService.slaMinutes
    });
  };

  const icons = {
    electrical: Zap,
    plumbing: Wrench,
    caregiving: HeartHandshake
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full border-2 border-rose-500 overflow-hidden">
        
        {/* Urgent Header */}
        <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-red-900 text-white p-6 flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/30 text-rose-300 flex items-center justify-center border border-rose-400/40 animate-pulse">
              <ShieldAlert className="w-7 h-7 text-rose-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold">15-Minute Emergency SOS Dispatch</h3>
                <span className="bg-rose-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  Priority SLA
                </span>
              </div>
              <p className="text-xs text-rose-200 mt-0.5">
                Cooperative rapid mutual response for critical household safety hazards
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsEmergencyModalOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Service Category Radio selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Select Urgent Hazard Type:
            </label>
            <div className="grid grid-cols-1 gap-2.5">
              {emergencyServices.map((emg) => {
                const Icon = icons[emg.trade] || Zap;
                const isSelected = selectedServiceId === emg.id;
                return (
                  <label
                    key={emg.id}
                    className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'border-rose-600 bg-rose-50/50 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="emergencyType"
                      checked={isSelected}
                      onChange={() => setSelectedServiceId(emg.id)}
                      className="mt-1 accent-rose-600"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                          <Icon className="w-4 h-4 text-rose-600" />
                          {emg.title}
                        </span>
                        <span className="text-xs font-black text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full">
                          ~{emg.slaMinutes} min SLA
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{emg.description}</p>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Location & Instructions */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-rose-600" />
                Emergency Location:
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Hazard Details for Responding Tradesperson:
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows="2"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
                placeholder="E.g. Main water valve jammed, water overflowing into hallway..."
              />
            </div>
          </div>

          {/* Pricing Guarantee */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
            <div>
              <span className="text-slate-600 font-medium">Standard Emergency Base Tariff:</span>
              <p className="font-bold text-slate-900">Zero gouging — capped by Co-op Charter</p>
            </div>
            <div className="text-right">
              <span className="text-base font-black text-slate-900">₹{currentService.baseFee}</span>
              <span className="text-[10px] text-emerald-700 font-bold block">(85% to worker)</span>
            </div>
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsEmergencyModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-lg shadow-rose-600/30 flex items-center gap-2 transform active:scale-95 transition-all"
            >
              <AlertTriangle className="w-4 h-4" />
              Trigger 15-Min Emergency SOS
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
