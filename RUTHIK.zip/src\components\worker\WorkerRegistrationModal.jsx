import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Award,
  ShieldCheck,
  FileCheck,
  Upload,
  UserCheck,
  CheckCircle2,
  ArrowRight,
  X,
  Vote,
  Sparkles
} from 'lucide-react';

export const WorkerRegistrationModal = () => {
  const {
    isWorkerRegModalOpen,
    setIsWorkerRegModalOpen,
    registerWorker
  } = useCoop();

  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: 'Manoj Basavaraj',
    trade: 'electrical',
    experienceYears: 5,
    phone: '+91 98452 88129',
    email: 'manoj.electric@gmail.com',
    neighborhood: 'HSR Layout, Sector 4',
    bio: 'Experienced in 3-phase commercial panels, backup generator sync, and solar inverter installations.',
    agreedEquityPledge: true
  });

  if (!isWorkerRegModalOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    registerWorker(formData);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white p-6 flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-300" />
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-300">
                Member Co-ownership Portal
              </span>
            </div>
            <h3 className="text-xl font-bold mt-1 text-white">Join as a Worker Co-owner</h3>
            <p className="text-xs text-slate-300 mt-0.5">
              85% guaranteed fair pay • Class A voting share • Quarterly profit dividends
            </p>
          </div>
          <button
            onClick={() => setIsWorkerRegModalOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="bg-slate-100 px-6 py-2 border-b border-slate-200 flex justify-between text-xs font-bold text-slate-600">
          <span className={step >= 1 ? 'text-emerald-700' : ''}>1. Professional Details</span>
          <span className={step >= 2 ? 'text-emerald-700' : ''}>2. Credential Verification</span>
          <span className={step >= 3 ? 'text-emerald-700' : ''}>3. Equity Share Pledge</span>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {step === 1 && (
            <div className="space-y-3 animate-fade-in text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Legal Name:</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Trade Specialization:</label>
                  <select
                    value={formData.trade}
                    onChange={(e) => setFormData({ ...formData, trade: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-700 focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="electrical">Electrical & Solar</option>
                    <option value="plumbing">Plumbing & Water</option>
                    <option value="cleaning">Home Cleaning & Eco Sanitize</option>
                    <option value="caregiving">Elder Care & Nursing</option>
                    <option value="carpentry">Carpentry & Woodwork</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Years of Experience:</label>
                  <input
                    type="number"
                    min="1"
                    max="40"
                    value={formData.experienceYears}
                    onChange={(e) => setFormData({ ...formData, experienceYears: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contact Phone:</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Primary Neighborhood:</label>
                  <input
                    type="text"
                    value={formData.neighborhood}
                    onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold flex items-center gap-1.5"
                >
                  Continue to Documents <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3 animate-fade-in text-xs">
              <span className="font-bold text-slate-700 block">Simulated Document Verification:</span>
              
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-600" />
                  <div>
                    <span className="font-bold text-slate-800">Govt ITI / Trade Certification</span>
                    <p className="text-[10px] text-slate-500">iti_contractor_license_level5.pdf</p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Uploaded</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-indigo-600" />
                  <div>
                    <span className="font-bold text-slate-800">Police Verification Clearance</span>
                    <p className="text-[10px] text-slate-500">police_verification_form_blr.pdf</p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Uploaded</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-teal-600" />
                  <div>
                    <span className="font-bold text-slate-800">Aadhaar e-KYC Identity</span>
                    <p className="text-[10px] text-slate-500">aadhaar_uidai_verified.xml</p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Verified</span>
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-bold"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold flex items-center gap-1.5"
                >
                  Continue to Share Pledge <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4 animate-fade-in text-xs">
              <div className="bg-gradient-to-br from-emerald-50 to-amber-50 p-4 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 font-bold text-emerald-900">
                  <Vote className="w-4 h-4 text-emerald-700" />
                  <span>Class A Equity & Democratic Pledge:</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-[11px]">
                  "I hereby apply for 1 Class A Shareholder Equity in the Sahakari Gig Cooperative Society. I pledge to uphold cooperative craftsmanship, honor fair pricing, participate in democratic governance votes, and contribute to the mutual emergency welfare pool."
                </p>
              </div>

              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.agreedEquityPledge}
                  onChange={(e) => setFormData({ ...formData, agreedEquityPledge: e.target.checked })}
                  className="mt-0.5 accent-emerald-600"
                />
                <span className="text-slate-700 font-semibold">
                  I agree to the democratic co-op charter and accept 1 Member = 1 Equal Vote.
                </span>
              </label>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-bold"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={!formData.agreedEquityPledge}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Submit Application for Audit
                </button>
              </div>
            </div>
          )}

        </form>

      </div>
    </div>
  );
};
