import React from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Wrench,
  Tractor,
  PlusCircle,
  CheckCircle2,
  DollarSign,
  Star,
  Clock,
  ShieldCheck,
  TrendingUp,
  Settings2
} from 'lucide-react';

export const MyEquipmentTab = ({ onNavigateToListEquipment }) => {
  const { farmEquipment = [], setFarmEquipment, currentFarmer, showToast } = useCoop();
  const farmer = currentFarmer || {};

  // Filter equipment owned by the logged-in farmer
  const myEquipmentList = farmEquipment.filter(
    (e) => e.ownerId === farmer.id || e.ownerName === (farmer.fullName || farmer.name)
  );

  const toggleAvailability = (id) => {
    setFarmEquipment((prev) =>
      prev.map((eq) => {
        if (eq.id === id) {
          const nextStatus = eq.status === 'Available' ? 'In Use' : 'Available';
          showToast(`${eq.name} status updated to: ${nextStatus}`, 'info');
          return { ...eq, status: nextStatus, availability: nextStatus };
        }
        return eq;
      })
    );
  };

  const totalEarnings = myEquipmentList.reduce(
    (sum, eq) => sum + (eq.completedRentals || 0) * (eq.rentalPrice || 600),
    0
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Header & Income Summary ──────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">⚙️</span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              My Farm Equipment & Implements
            </h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Manage your listed machinery, toggle sharing availability, and monitor rental earnings.
          </p>
        </div>

        <button
          onClick={onNavigateToListEquipment}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-lg shadow-emerald-600/20 active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ List Another Machine</span>
        </button>
      </div>

      {/* ─── Equipment Earnings Stats Banner ───────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-950 border border-teal-800 flex items-center justify-center text-2xl text-teal-400 flex-shrink-0">
            🚜
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold block">Active Implements</span>
            <span className="text-2xl font-black text-white">{myEquipmentList.length}</span>
            <span className="text-[11px] text-teal-400 font-semibold block">Listed on platform</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-2xl text-emerald-400 flex-shrink-0">
            ₹
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold block">Estimated Rental Earnings</span>
            <span className="text-2xl font-black text-emerald-400">₹{totalEarnings.toLocaleString()}</span>
            <span className="text-[11px] text-slate-400 block">Across completed rentals</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-950 border border-purple-800 flex items-center justify-center text-2xl text-purple-400 flex-shrink-0">
            ⭐
          </div>
          <div>
            <span className="text-xs text-slate-400 font-bold block">Equipment Rating</span>
            <span className="text-2xl font-black text-amber-400">4.8 / 5.0</span>
            <span className="text-[11px] text-slate-400 block">Community verified</span>
          </div>
        </div>
      </div>

      {/* ─── Equipment List ────────────────────────────────────────── */}
      {myEquipmentList.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
          <span className="text-5xl">🚜</span>
          <h3 className="text-white font-bold text-lg">No equipment listed yet</h3>
          <p className="text-slate-400 text-xs max-w-sm mx-auto">
            You haven't listed any farm machinery yet. Earn rental income when your rotavator, tractor, or pump is idle!
          </p>
          <button
            onClick={onNavigateToListEquipment}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
          >
            List Your First Machine
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {myEquipmentList.map((eq) => {
            const isAvailable = eq.status === 'Available';

            return (
              <div
                key={eq.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 transition hover:border-slate-700"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-3xl flex-shrink-0">
                      {eq.icon || '⚙️'}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h3 className="text-white font-black text-base">{eq.name}</h3>
                        {eq.verified && (
                          <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        )}
                      </div>
                      <p className="text-slate-400 text-xs">
                        {eq.brand} · {eq.model}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-black px-3 py-1 rounded-full border ${
                      isAvailable
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                        : 'bg-amber-950 text-amber-300 border-amber-700'
                    }`}
                  >
                    {eq.status}
                  </span>
                </div>

                <p className="text-slate-400 text-xs leading-relaxed">
                  {eq.description}
                </p>

                <div className="grid grid-cols-3 gap-3 p-3 bg-slate-800/80 rounded-2xl text-center text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Rental Rate</span>
                    <span className="text-emerald-400 font-bold text-sm">₹{eq.rentalPrice}/day</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Rentals</span>
                    <span className="text-white font-bold text-sm">{eq.completedRentals || 0} times</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Operator</span>
                    <span className="text-slate-300 font-bold text-xs">
                      {eq.operatorAvailable ? `Yes (+₹${eq.operatorPricePerDay})` : 'No'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-xs">
                  <span className="text-slate-400">Availability Status:</span>
                  <button
                    onClick={() => toggleAvailability(eq.id)}
                    className={`px-3 py-1 rounded-xl font-bold transition text-xs ${
                      isAvailable
                        ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40'
                    }`}
                  >
                    Set as {isAvailable ? 'In Use / Busy' : 'Available for Rent'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
