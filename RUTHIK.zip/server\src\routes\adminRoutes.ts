import { Router } from 'express';
import {
  getAdminOverview,
  verifyWorker,
  verifyFarmer
} from '../controllers/adminController';

const router = Router();

router.get('/overview', getAdminOverview);
router.put('/verify-worker/:id', verifyWorker);
router.put('/verify-farmer/:id', verifyFarmer);

export default router;
