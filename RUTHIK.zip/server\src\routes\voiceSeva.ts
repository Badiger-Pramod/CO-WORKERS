/**
 * Voice Seva — Gemini Live API Route
 * 
 * SECURITY MODEL (Ephemeral Token Pattern):
 *   1. Server holds GEMINI_API_KEY — never sent to browser.
 *   2. POST /api/voice-seva/token  — mints a short-lived ephemeral token (1 use).
 *   3. Browser uses that token to connect directly to gemini-live-2.5-flash-preview.
 *   4. Function-call results are handled server-side via POST /api/voice-seva/tool-call.
 * 
 * This means audio streams DIRECTLY browser ↔ Gemini (low latency),
 * while the API key stays on the server forever.
 */

import { Router, Request, Response } from 'express';
import { GoogleGenAI, Modality } from '@google/genai';
import { dispatchTool } from '../controllers/voiceSevaTools.js';

const router = Router();

// ─── Validate API key at startup ─────────────────────────────────────────────
function getAI(): GoogleGenAI {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key.trim() === '') {
    throw new Error(
      'GEMINI_API_KEY is not configured. ' +
      'Set it in server/.env — never expose it to the browser.'
    );
  }
  return new GoogleGenAI({ apiKey: key, apiVersion: 'v1alpha' });
}

// ─── Tool declarations for Gemini ────────────────────────────────────────────
const VOICE_SEVA_TOOLS = [
  {
    name: 'searchWorkers',
    description: 'Search for available gig workers on the CoWork Connect platform by trade/skill and location.',
    parameters: {
      type: 'object',
      properties: {
        trade:     { type: 'string', description: 'Trade or skill to search for (e.g., Plumber, Electrician, Crop Inspector)' },
        location:  { type: 'string', description: 'Location to search near' },
        available: { type: 'boolean', description: 'If true, return only currently available workers' },
      },
    },
  },
  {
    name: 'findNearbyServices',
    description: 'Find nearby service categories and providers available in the cooperative network.',
    parameters: {
      type: 'object',
      properties: {
        location: { type: 'string', description: "User's location" },
        category: { type: 'string', description: 'Service category to filter by' },
      },
    },
  },
  {
    name: 'createServiceRequest',
    description: 'Create a service request for a gig worker on the CoWork Connect platform. Use this when the user confirms they want to book a service.',
    parameters: {
      type: 'object',
      required: ['serviceType'],
      properties: {
        serviceType:   { type: 'string', description: 'Type of service requested' },
        location:      { type: 'string', description: 'Service location' },
        preferredDate: { type: 'string', description: 'Preferred date (YYYY-MM-DD)' },
        preferredTime: { type: 'string', description: 'Preferred time' },
        notes:         { type: 'string', description: 'Additional notes' },
        urgency:       { type: 'string', enum: ['normal', 'urgent'], description: 'Urgency level' },
      },
    },
  },
  {
    name: 'findAgriculturalServices',
    description: 'Find verified agricultural service providers — crop inspectors, pest control specialists, soil testers, equipment technicians, and farm workers.',
    parameters: {
      type: 'object',
      properties: {
        serviceType:   { type: 'string', description: 'Agricultural service type' },
        maxDistanceKm: { type: 'number', description: 'Maximum distance in km' },
      },
    },
  },
  {
    name: 'createCropInspectionRequest',
    description: 'Create a crop inspection request for a farmer. Use this when the farmer describes a problem with their crops and wants a specialist to visit.',
    parameters: {
      type: 'object',
      required: ['cropType'],
      properties: {
        cropType: { type: 'string', description: 'Type of crop needing inspection (e.g., tomato, rice, wheat)' },
        problem:  { type: 'string', description: 'Description of the crop problem observed' },
        location: { type: 'string', description: "Farmer's field location" },
        urgency:  { type: 'string', enum: ['normal', 'urgent'], description: 'Urgency level' },
      },
    },
  },
  {
    name: 'getBookingStatus',
    description: "Get the current status of a farmer's service bookings.",
    parameters: {
      type: 'object',
      properties: {
        bookingId: { type: 'string', description: 'Specific booking ID to check' },
        farmerId:  { type: 'string', description: "Farmer's ID" },
      },
    },
  },
  {
    name: 'getBookingHistory',
    description: "Get the farmer's past service booking history.",
    parameters: {
      type: 'object',
      properties: {
        farmerId: { type: 'string', description: "Farmer's ID" },
        limit:    { type: 'number', description: 'Max results to return' },
      },
    },
  },
];

// ─── System prompt ─────────────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are Voice Seva, the AI agricultural assistant for CoWork Connect — India's first cooperative gig services platform for farmers and rural communities (SIH26089).

Your role:
- Help farmers and rural users find and book agricultural services in their language.
- Respond conversationally and naturally in whatever language the user speaks.
- Supported languages: English, Kannada (ಕನ್ನಡ), Hindi (हिन्दी), Telugu (తెలుగు), Tamil (தமிழ்), Marathi (मराठी), Bengali (বাংলা).
- Always respond in the SAME language the user speaks. If unsure, respond in English.

Platform context:
- CoWork Connect is a cooperative gig platform. Workers are co-owners, not employees.
- Transparent 8-10% cooperative fee. No surge pricing. 100% verified workers.
- Cooperative: Tumakuru Farmers Cooperative.

For agricultural queries:
- When a farmer describes a crop problem or asks for a service, ask ONE clarifying question if needed (e.g., crop type, location), then call the appropriate tool.
- For disease/pest concerns: always note that your response is informational and recommend consulting the local Krishi Vigyan Kendra (KVK) or a qualified agronomist for definitive diagnosis.
- Do NOT fabricate worker names, distances, ratings, or prices — always call the platform tools.

Voice behaviour:
- Be warm, helpful, and brief. Farmers may have limited connectivity.
- Confirm actions before creating bookings.
- After creating a request, confirm the worker's name, distance, and estimated cost.
- Keep responses concise for audio playback.`;

// ─── POST /api/voice-seva/token ───────────────────────────────────────────────
// Mints a short-lived ephemeral token the browser uses to connect to Gemini Live.
// The actual GEMINI_API_KEY is NEVER sent to the browser.
router.post('/token', async (req: Request, res: Response) => {
  try {
    const ai = getAI();
    const model = 'gemini-live-2.5-flash-preview';

    const token = await ai.authTokens.create({
      config: {
        uses: 1, // Single-use, expires after one Live connection
        liveConnectConstraints: {
          model,
          config: {
            responseModalities: [Modality.AUDIO],
            systemInstruction: SYSTEM_PROMPT,
            tools: [{ functionDeclarations: VOICE_SEVA_TOOLS }],
          },
        },
      },
    });

    // Return ephemeral token + model name — NOT the API key
    res.json({
      ok: true,
      ephemeralToken: token.name,
      model,
      apiVersion: 'v1alpha',
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    const isMissingKey = message.includes('GEMINI_API_KEY');
    res.status(isMissingKey ? 503 : 500).json({
      ok: false,
      error: isMissingKey
        ? 'GEMINI_API_KEY is not configured on the server. Add it to server/.env.'
        : `Failed to create Gemini session: ${message}`,
      configurationError: isMissingKey,
    });
  }
});

// ─── POST /api/voice-seva/tool-call ──────────────────────────────────────────
// Browser sends tool-call requests here; server executes them and returns results.
// Gemini's function calls are handled server-side — browser never touches the data layer directly.
router.post('/tool-call', async (req: Request, res: Response) => {
  const { name, args } = req.body as { name: string; args: Record<string, unknown> };

  if (!name) {
    res.status(400).json({ ok: false, error: 'Missing tool name' });
    return;
  }

  try {
    const result = dispatchTool(name, args || {});
    res.json({ ok: true, result });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ ok: false, error: message });
  }
});

// ─── GET /api/voice-seva/health ──────────────────────────────────────────────
router.get('/health', (_req: Request, res: Response) => {
  const key = process.env.GEMINI_API_KEY;
  const configured = Boolean(key && key.trim() !== '');
  res.json({
    ok: true,
    geminiConfigured: configured,
    message: configured
      ? 'Voice Seva is ready.'
      : 'GEMINI_API_KEY is missing. Add it to server/.env to enable Voice Seva.',
  });
});

export default router;
