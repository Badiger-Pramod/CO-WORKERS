import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  GraduationCap,
  Award,
  BookOpen,
  Users,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Sparkles,
  Plus,
  ArrowRight,
  ExternalLink,
  ShieldCheck,
  Download,
  X,
  Send,
  RefreshCw,
  Zap,
  ChevronRight,
  Check,
  AlertCircle,
  TrendingUp,
  FileCheck,
  Printer
} from 'lucide-react';

export const WorkerSkillExchange = () => {
  const {
    currentUser,
    teachingWorkshops,
    learningProgress,
    skillExchangeRequests,
    enrollInWorkshop,
    publishTeachingWorkshop,
    advanceLearningModule,
    respondToSkillExchangeRequest,
    proposeSkillExchange,
    showToast,
    t
  } = useCoop();

  // Active sub-tab
  const [activeSubTab, setActiveSubTab] = useState('progress'); // 'progress' | 'browse' | 'teach' | 'swap'
  
  // Selected category filter for browsing workshops
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Certificate Modal State
  const [selectedCertificate, setSelectedCertificate] = useState(null);

  // Skill Swap Proposal Modal
  const [swapTargetWorkshop, setSwapTargetWorkshop] = useState(null);
  const [swapMyOfferSkill, setSwapMyOfferSkill] = useState('');
  const [swapMessage, setSwapMessage] = useState('');

  // Form State for "Teach a Skill"
  const [newSkillForm, setNewSkillForm] = useState({
    skillName: '',
    skillCategory: 'Electrical',
    skillLevel: 'Advanced',
    experienceYears: 4,
    trainingMode: 'In Person + Online',
    availableDays: 'Saturdays & Sundays',
    availableTime: '10:00 AM - 1:00 PM',
    location: 'Tumakuru Urban Co-op Guild Workshop, Ward 12',
    maxLearners: 6,
    higherPayingRate: '₹750/hr',
    description: '',
    modulesInput: 'Foundational safety & tools\nHands-on connection wiring\nTroubleshooting & load balance\nDISCOM & Guild safety checklist'
  });

  const categories = ['All', 'Clean Energy & Solar', 'Electrical', 'Plumbing', 'Carpentry', 'Cleaning', 'Smart Home'];

  const filteredWorkshops = teachingWorkshops.filter(ws => {
    if (selectedCategory === 'All') return true;
    if (selectedCategory === 'Clean Energy & Solar') return ws.skillCategory.includes('Energy') || ws.skillCategory.includes('Solar');
    return ws.skillCategory.toLowerCase().includes(selectedCategory.toLowerCase());
  });

  // Handle Publish Workshop
  const handlePublishWorkshop = (e) => {
    e.preventDefault();
    if (!newSkillForm.skillName.trim()) {
      showToast('Please enter the skill name you want to teach', 'error');
      return;
    }

    const modules = newSkillForm.modulesInput
      .split('\n')
      .map(m => m.trim())
      .filter(m => m.length > 0);

    publishTeachingWorkshop({
      skillName: newSkillForm.skillName,
      skillCategory: newSkillForm.skillCategory,
      skillLevel: newSkillForm.skillLevel,
      experienceYears: Number(newSkillForm.experienceYears) || 3,
      trainingMode: newSkillForm.trainingMode,
      availableDays: newSkillForm.availableDays,
      availableTime: newSkillForm.availableTime,
      location: newSkillForm.location,
      maxLearners: Number(newSkillForm.maxLearners) || 6,
      trainingFee: 'Free (Co-op Subsidized Guild Training)',
      higherPayingRate: newSkillForm.higherPayingRate,
      description: newSkillForm.description || `Hands-on practical training taught by verified co-op guild mentor ${currentUser?.name || 'Worker'}.`,
      modules: modules.length > 0 ? modules : ['Fundamentals & Safety', 'Hands-on Execution', 'Commissioning Test', 'Guild Certification Verification']
    });

    // Reset form
    setNewSkillForm({
      skillName: '',
      skillCategory: 'Electrical',
      skillLevel: 'Advanced',
      experienceYears: 4,
      trainingMode: 'In Person + Online',
      availableDays: 'Saturdays & Sundays',
      availableTime: '10:00 AM - 1:00 PM',
      location: 'Tumakuru Urban Co-op Guild Workshop, Ward 12',
      maxLearners: 6,
      higherPayingRate: '₹750/hr',
      description: '',
      modulesInput: 'Foundational safety & tools\nHands-on connection wiring\nTroubleshooting & load balance\nDISCOM & Guild safety checklist'
    });

    setActiveSubTab('browse');
  };

  // Handle Propose Skill Swap
  const handleSendSwapProposal = (e) => {
    e.preventDefault();
    if (!swapMyOfferSkill.trim()) {
      showToast('Please enter what skill you offer in return', 'error');
      return;
    }

    proposeSkillExchange({
      targetWorkshopId: swapTargetWorkshop.id,
      toWorkerId: swapTargetWorkshop.teacherId,
      toWorkerName: swapTargetWorkshop.teacherName,
      offerSkill: swapMyOfferSkill,
      wantSkill: swapTargetWorkshop.skillName,
      message: swapMessage || `Hi ${swapTargetWorkshop.teacherName}, I would love to learn ${swapTargetWorkshop.skillName} from you and can teach you ${swapMyOfferSkill} in return!`
    });

    setSwapTargetWorkshop(null);
    setSwapMyOfferSkill('');
    setSwapMessage('');
    setActiveSubTab('swap');
  };

  return (
    <div className="space-y-6">
      {/* HEADER BANNER */}
      <div className="relative overflow-hidden rounded-3xl bg-white rounded-2xl border border-slate-200/90 p-6 md:p-7 shadow-2xs">
        <div className="absolute -right-8 -top-8 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Cooperative Peer-to-Peer Learning Hub</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
              Worker Skill Exchange & Guild Academy
            </h1>
            <p className="text-xs md:text-sm text-slate-500 max-w-2xl mt-1 leading-relaxed">
              Don't just find gig jobs — learn high-income trades from senior co-op peers, earn verified guild credentials, and qualify for premium ₹700–₹950/hr work orders!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveSubTab('teach')}
              className="px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center gap-2 transition shadow-lg shadow-emerald-950/50"
            >
              <Plus className="w-4 h-4" />
              <span>Teach a Skill</span>
            </button>
            <button
              onClick={() => setActiveSubTab('browse')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-2 transition"
            >
              <BookOpen className="w-4 h-4" />
              <span>Browse Workshops</span>
            </button>
          </div>
        </div>

        {/* QUICK STATS STRIP */}
        <div className="mt-6 pt-6 border-t border-slate-200/90/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <span className="text-xs text-slate-400 block">Enrolled Courses</span>
            <span className="text-xl font-black text-slate-900 mt-0.5 block">
              {learningProgress.length} Tracks
            </span>
          </div>
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <span className="text-xs text-slate-400 block">Verified Credentials</span>
            <span className="text-xl font-black text-emerald-700 mt-0.5 block">
              {learningProgress.filter(p => p.progressPercent === 100).length} Certifications
            </span>
          </div>
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <span className="text-xs text-slate-400 block">Co-op Mentor Workshops</span>
            <span className="text-xl font-black text-blue-400 mt-0.5 block">
              {teachingWorkshops.length} Active
            </span>
          </div>
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
            <span className="text-xs text-slate-400 block">Co-op Training Subsidy</span>
            <span className="text-xl font-black text-amber-400 mt-0.5 block">
              100% Free
            </span>
          </div>
        </div>
      </div>

      {/* SUB-NAVIGATION TABS */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200/90 pb-3">
        <button
          onClick={() => setActiveSubTab('progress')}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 ${
            activeSubTab === 'progress'
              ? 'bg-emerald-800 text-slate-900 shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          <span>My Learning Progress</span>
          <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-black/30 font-extrabold">
            {learningProgress.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('browse')}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 ${
            activeSubTab === 'browse'
              ? 'bg-emerald-800 text-slate-900 shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Available Skills & Mentors</span>
          <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-black/30 font-extrabold">
            {teachingWorkshops.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('teach')}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 ${
            activeSubTab === 'teach'
              ? 'bg-emerald-800 text-slate-900 shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Teach a Skill (Become a Mentor)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('swap')}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 ${
            activeSubTab === 'swap'
              ? 'bg-emerald-800 text-slate-900 shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <RefreshCw className="w-4 h-4" />
          <span>Skill Swap Requests</span>
          {skillExchangeRequests.filter(r => r.status === 'Pending').length > 0 && (
            <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-amber-500 text-slate-950 font-black animate-pulse">
              {skillExchangeRequests.filter(r => r.status === 'Pending').length}
            </span>
          )}
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. MY LEARNING PROGRESS TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'progress' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <span>My Active Guild Skill Tracks</span>
                <span className="text-xs font-normal text-slate-400">
                  (Simulate training milestone progress to unlock higher hourly pay)
                </span>
              </h2>
            </div>
            <button
              onClick={() => setActiveSubTab('browse')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              <span>+ Enroll in Another Skill</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {learningProgress.map((prog) => {
              const isDone = prog.progressPercent === 100;

              return (
                <div
                  key={prog.id}
                  className={`relative rounded-3xl p-6 border transition-all duration-200 flex flex-col justify-between ${
                    isDone
                      ? 'bg-gradient-to-b from-slate-900/90 to-emerald-950/40 border-emerald-500/40 shadow-lg shadow-emerald-950/20'
                      : 'bg-slate-50/70 border-slate-200/90 hover:border-slate-700'
                  }`}
                >
                  <div>
                    {/* Top Row: Tag & Status */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-600 text-[11px] font-bold border border-slate-700">
                        {prog.category} • {prog.level}
                      </span>
                      {isDone ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-800 text-xs font-black border border-emerald-500/30">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Skill Verified</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{prog.progressPercent}% Completed</span>
                        </span>
                      )}
                    </div>

                    {/* Skill Title */}
                    <h3 className="text-lg font-black text-slate-900 leading-snug">
                      {prog.skillName}
                    </h3>

                    {/* Mentor Name */}
                    <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                      <span>Co-op Mentor:</span>
                      <span className="font-bold text-slate-200">{prog.mentorName}</span>
                    </p>

                    {/* Progress Bar */}
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                        <span className="text-slate-400">
                          Module {prog.completedModules} of {prog.totalModules}
                        </span>
                        <span className={isDone ? 'text-emerald-700 font-black' : 'text-blue-400 font-black'}>
                          {prog.progressPercent}%
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isDone
                              ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500'
                              : 'bg-gradient-to-r from-blue-500 to-emerald-500'
                          }`}
                          style={{ width: `${prog.progressPercent}%` }}
                        />
                      </div>
                    </div>

                    {/* Milestone / Next Session Info */}
                    <div className="mt-4 p-3 rounded-2xl bg-slate-50 border border-slate-200/90/80 space-y-1 text-xs">
                      {isDone ? (
                        <div className="flex items-start gap-2 text-emerald-800">
                          <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-700" />
                          <div>
                            <span className="font-bold block">Guild Accredited & Certified</span>
                            <span className="text-[11px] text-slate-400">
                              Certificate ID: {prog.certificateId || 'COOP-CERT-ELEC-2025-091'}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <span className="text-slate-400 block text-[11px]">Next Milestone:</span>
                          <span className="font-semibold text-slate-200 block">
                            {prog.nextMilestone || 'Practical lab & safety test'}
                          </span>
                          {prog.nextSession && (
                            <span className="text-[11px] text-blue-400 font-medium block mt-0.5">
                              📅 {prog.nextSession}
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Unlocked Benefit */}
                    <div className="mt-3 flex items-center gap-2 text-xs">
                      <TrendingUp className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="text-slate-600">
                        <strong className="text-slate-900">Earnings Boost: </strong>
                        <span className={isDone ? 'text-emerald-700 font-bold' : 'text-amber-300 font-semibold'}>
                          {prog.unlockedJobTitle}
                        </span>
                      </span>
                    </div>
                  </div>

                  {/* Actions Row */}
                  <div className="mt-6 pt-4 border-t border-slate-200/90/80 flex items-center justify-between gap-3">
                    {isDone ? (
                      <>
                        <button
                          onClick={() => setSelectedCertificate(prog)}
                          className="w-full py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs flex items-center justify-center gap-2 transition shadow-xs"
                        >
                          <Award className="w-4 h-4" />
                          <span>View Co-op Certificate</span>
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => advanceLearningModule(prog.id)}
                          className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-slate-900 font-black text-xs flex items-center justify-center gap-2 transition shadow-xs"
                        >
                          <Zap className="w-4 h-4" />
                          <span>Practice Completed (Advance +25%)</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BROWSE SKILLS & MENTORS TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'browse' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-slate-900">
                Workshops & Mentorship Offered by Peer Workers
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Co-op subsidized training tracks to prepare you for high-paying green & specialized gig requests.
              </p>
            </div>

            <button
              onClick={() => setActiveSubTab('teach')}
              className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center gap-2 self-start sm:self-auto transition"
            >
              <Plus className="w-4 h-4" />
              <span>Offer to Teach a Skill</span>
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-emerald-500/20 text-emerald-800 border border-emerald-500/40'
                    : 'bg-slate-50 text-slate-400 border border-slate-200/90 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Workshop Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredWorkshops.map((ws) => {
              const isFull = ws.enrolledLearners >= ws.maxLearners;

              return (
                <div
                  key={ws.id}
                  className="rounded-3xl bg-slate-50/80 border border-slate-200/90 hover:border-emerald-500/30 p-5 flex flex-col justify-between transition-all duration-200 shadow-md group"
                >
                  <div>
                    {/* Mentor Bio Header */}
                    <div className="flex items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-xl shadow-xs">
                          {ws.teacherAvatar || '👷'}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-sm text-slate-900">
                              {ws.teacherName}
                            </span>
                            {ws.verifiedMentor && (
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400 block">
                            {ws.teacherTrade} • {ws.experienceYears} yrs exp
                          </span>
                        </div>
                      </div>

                      <div className="px-2 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold">
                        ★ {ws.teacherRating}
                      </div>
                    </div>

                    {/* Skill Title & Level */}
                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 text-[10px] font-extrabold">
                          {ws.skillCategory}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 text-[10px] font-bold">
                          {ws.skillLevel}
                        </span>
                      </div>
                      <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-800 transition-colors leading-snug">
                        {ws.skillName}
                      </h3>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed">
                      {ws.description}
                    </p>

                    {/* Earning Potential Unlock */}
                    {ws.higherPayingRate && (
                      <div className="p-2.5 rounded-xl bg-emerald-50/30 border border-emerald-500/20 mb-4 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                        <span className="text-xs text-emerald-200">
                          <strong className="text-slate-900">Unlocks: </strong>
                          {ws.higherPayingRate}
                        </span>
                      </div>
                    )}

                    {/* Workshop Meta Details */}
                    <div className="space-y-1.5 text-[11px] text-slate-400 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span>{ws.availableDays} • {ws.availableTime}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="truncate">{ws.location} ({ws.trainingMode})</span>
                      </div>
                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/90/80 font-bold">
                        <span className="text-slate-400">Seats:</span>
                        <span className={isFull ? 'text-rose-400' : 'text-emerald-700'}>
                          {ws.enrolledLearners} / {ws.maxLearners} Enrolled {isFull && '(Full)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-5 pt-4 border-t border-slate-200/90/80 flex items-center gap-2">
                    <button
                      onClick={() => enrollInWorkshop(ws.id)}
                      disabled={isFull}
                      className={`flex-1 py-2.5 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition ${
                        isFull
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-emerald-800 hover:bg-emerald-900 text-slate-900 shadow-xs'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isFull ? 'Batch Full' : 'Enroll Free'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setSwapTargetWorkshop(ws);
                        setSwapMyOfferSkill('');
                        setSwapMessage('');
                      }}
                      title="Propose Skill Barter (Teach a skill in return)"
                      className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1 transition"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Swap</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SKILLS I CAN TEACH (TEACH A SKILL FORM) */}
      {/* ========================================================================= */}
      {activeSubTab === 'teach' && (
        <div className="max-w-3xl mx-auto rounded-3xl bg-slate-50/90 border border-slate-200/90 p-6 md:p-8 shadow-xl animate-in fade-in duration-200">
          <div className="mb-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 text-xs font-bold mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>Co-op Mentorship Initiative</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-slate-900">
              Offer to Teach a Skill to Peer Workers
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Experienced workers receive Co-op Welfare Honorariums (₹500/session) and co-op patronage dividend credits when mentoring peer workers.
            </p>
          </div>

          <form onSubmit={handlePublishWorkshop} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Skill to Teach *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Solar Inverter Setup, Modular Kitchen Hinges"
                  value={newSkillForm.skillName}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, skillName: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Category
                </label>
                <select
                  value={newSkillForm.skillCategory}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, skillCategory: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                >
                  <option value="Electrical">Electrical</option>
                  <option value="Clean Energy & Solar">Clean Energy & Solar</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="Carpentry">Carpentry</option>
                  <option value="Cleaning">Cleaning & Hygiene</option>
                  <option value="Appliance Repair">Appliance Repair</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Skill Level
                </label>
                <select
                  value={newSkillForm.skillLevel}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, skillLevel: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                >
                  <option value="Beginner">Beginner Friendly</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced / Master Track</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Your Experience (Years)
                </label>
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={newSkillForm.experienceYears}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, experienceYears: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Max Learners per Batch
                </label>
                <input
                  type="number"
                  min="2"
                  max="15"
                  value={newSkillForm.maxLearners}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, maxLearners: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Training Mode
                </label>
                <select
                  value={newSkillForm.trainingMode}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, trainingMode: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                >
                  <option value="In Person + Online">In Person + Online Hybrid</option>
                  <option value="In Person Only">In Person Practical Lab</option>
                  <option value="Online Video Workshop">Online Guild Video Call</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Higher-Paying Rate Unlocked
                </label>
                <input
                  type="text"
                  placeholder="e.g. ₹800/hr (vs standard ₹450/hr)"
                  value={newSkillForm.higherPayingRate}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, higherPayingRate: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Available Days & Timing
                </label>
                <input
                  type="text"
                  value={newSkillForm.availableDays}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, availableDays: e.target.value })}
                  placeholder="e.g. Saturdays & Sundays, 10 AM - 1 PM"
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  Workshop Location / Guild Hub
                </label>
                <input
                  type="text"
                  value={newSkillForm.location}
                  onChange={(e) => setNewSkillForm({ ...newSkillForm, location: e.target.value })}
                  className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">
                Workshop Description
              </label>
              <textarea
                rows={2}
                placeholder="What practical techniques and tools will learners master in this workshop?"
                value={newSkillForm.description}
                onChange={(e) => setNewSkillForm({ ...newSkillForm, description: e.target.value })}
                className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">
                Syllabus / Modules (1 per line)
              </label>
              <textarea
                rows={4}
                value={newSkillForm.modulesInput}
                onChange={(e) => setNewSkillForm({ ...newSkillForm, modulesInput: e.target.value })}
                className="w-full bg-white border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-hidden font-mono text-[11px]"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs flex items-center justify-center gap-2 transition shadow-md shadow-emerald-950/40"
              >
                <Sparkles className="w-4 h-4" />
                <span>Publish Workshop to Cooperative Guild</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SKILL SWAP REQUESTS / BARTER TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'swap' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div>
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-emerald-700" />
              <span>Cooperative Skill Swap & Barter Desk</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              "Teach what you know, learn what you need" — Zero-cash peer trade barters between cooperative gig guild members.
            </p>
          </div>

          <div className="space-y-4">
            {skillExchangeRequests.map((req) => (
              <div
                key={req.id}
                className="rounded-3xl bg-slate-50/80 border border-slate-200/90 p-5 md:p-6 transition flex flex-col md:flex-row md:items-center justify-between gap-5"
              >
                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-slate-900 text-sm">
                      {req.fromWorkerName ? req.fromWorkerName.charAt(0) : 'W'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-slate-900">
                          {req.fromWorkerName}
                        </span>
                        <span className="text-xs text-slate-400">
                          ({req.fromWorkerTrade})
                        </span>
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
                          req.status === 'Accepted'
                            ? 'bg-emerald-500/20 text-emerald-800 border-emerald-500/30'
                            : req.status === 'Declined'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        }`}>
                          {req.status}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500">
                        Requested {req.date}
                      </span>
                    </div>
                  </div>

                  {/* Skills Exchanged Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-white/70 border border-slate-200/90/80 text-xs">
                    <div>
                      <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider block">
                        Offers to Teach You:
                      </span>
                      <span className="font-extrabold text-slate-900 mt-0.5 block">
                        {req.offerSkill}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-blue-400 font-bold uppercase tracking-wider block">
                        Wants to Learn from You:
                      </span>
                      <span className="font-extrabold text-slate-900 mt-0.5 block">
                        {req.wantSkill}
                      </span>
                    </div>
                  </div>

                  {req.message && (
                    <p className="text-xs text-slate-600 italic bg-slate-50/50 p-2.5 rounded-xl border border-slate-200/90">
                      "{req.message}"
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex md:flex-col items-center gap-2 shrink-0">
                  {req.status === 'Pending' ? (
                    <>
                      <button
                        onClick={() => respondToSkillExchangeRequest(req.id, 'Accepted')}
                        className="w-full px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Accept Swap</span>
                      </button>
                      <button
                        onClick={() => respondToSkillExchangeRequest(req.id, 'Declined')}
                        className="w-full px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 font-bold text-xs transition"
                      >
                        <span>Decline</span>
                      </button>
                    </>
                  ) : (
                    <span className="text-xs text-slate-400 font-medium">
                      Exchange {req.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PROPOSE SKILL SWAP */}
      {/* ========================================================================= */}
      {swapTargetWorkshop && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200/90 rounded-3xl p-6 w-full max-w-md animate-in zoom-in-95 duration-150 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200/90">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-emerald-700" />
                <span>Propose Cooperative Skill Swap</span>
              </h3>
              <button
                onClick={() => setSwapTargetWorkshop(null)}
                className="text-slate-400 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendSwapProposal} className="mt-4 space-y-3.5 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Target Workshop & Mentor:</span>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/90">
                  <span className="font-extrabold text-slate-900 block">
                    {swapTargetWorkshop.skillName}
                  </span>
                  <span className="text-emerald-700 font-semibold text-[11px] block mt-0.5">
                    Mentor: {swapTargetWorkshop.teacherName} ({swapTargetWorkshop.teacherTrade})
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">
                  What skill will you teach in return? *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Inverter Wiring, Concealed Plumbing, etc."
                  value={swapMyOfferSkill}
                  onChange={(e) => setSwapMyOfferSkill(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-slate-900 placeholder-slate-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">
                  Note to Mentor (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Describe your barter proposal or schedule flexibility..."
                  value={swapMessage}
                  onChange={(e) => setSwapMessage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200/90 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-slate-900 placeholder-slate-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSwapTargetWorkshop(null)}
                  className="w-1/3 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-800 text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-2/3 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black flex items-center justify-center gap-1.5 transition shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Proposal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CO-OP CERTIFICATE VIEWER */}
      {/* ========================================================================= */}
      {selectedCertificate && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border-2 border-amber-500/40 rounded-3xl p-6 md:p-8 w-full max-w-2xl animate-in zoom-in-95 duration-150 shadow-2xl relative">
            {/* Close Button */}
            <button
              onClick={() => setSelectedCertificate(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 p-2"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Certificate Canvas Frame */}
            <div className="border-4 border-double border-amber-500/30 p-6 md:p-8 rounded-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-center relative overflow-hidden">
              {/* Subtle Guilloche / Watermark Effect */}
              <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none text-9xl select-none">
                🏛️
              </div>

              {/* Guild Emblem */}
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 shadow-lg mb-3">
                <Award className="w-9 h-9" />
              </div>

              <span className="text-[11px] font-black uppercase tracking-widest text-amber-500 block mb-1">
                Karnataka Cooperative Societies Act • Certified Guild
              </span>
              <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-wide uppercase">
                Tumakuru District Cooperative Workers Guild
              </h2>
              <p className="text-xs text-slate-400 uppercase tracking-wider mb-6">
                Accredited Peer-to-Peer Gig Academy
              </p>

              <div className="h-px w-32 bg-amber-500/40 mx-auto mb-6" />

              <p className="text-xs text-slate-600 italic mb-2">
                This is to certify that
              </p>
              <h3 className="text-2xl md:text-3xl font-black text-amber-300 tracking-tight mb-2">
                {currentUser?.name || 'Bhuvan S (Master Electrician)'}
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed mb-4">
                has satisfactorily completed the intensive practical training modules, safety compliance protocols, and mentor-supervised commissioning in:
              </p>

              <div className="py-3 px-6 bg-amber-500/10 border border-amber-500/30 rounded-2xl inline-block max-w-lg mb-6">
                <span className="text-base md:text-lg font-black text-slate-900 block">
                  {selectedCertificate.skillName}
                </span>
                <span className="text-xs font-bold text-emerald-700 block mt-0.5">
                  Standard Verified Tier: {selectedCertificate.level} Grade
                </span>
              </div>

              {/* Signatures & Seal */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-200/90 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Verified Mentor</span>
                  <span className="font-bold text-slate-900 block mt-0.5">
                    {selectedCertificate.mentorName || 'Suresh M'}
                  </span>
                  <span className="text-[10px] text-emerald-700">✓ Digital Signature</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[10px]">Certificate ID</span>
                  <span className="font-mono font-bold text-amber-400 block mt-0.5 text-[11px]">
                    {selectedCertificate.certificateId || 'COOP-CERT-ELEC-2025-091'}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    Issued: {selectedCertificate.certifiedOn || 'Dec 2025'}
                  </span>
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <span className="text-slate-400 block text-[10px]">Guild Registrar</span>
                  <span className="font-bold text-slate-900 block mt-0.5">
                    CoWork Connect Trust
                  </span>
                  <span className="text-[10px] text-blue-400">✓ Cryptographic Hash</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-5 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-400">
                ⭐ Eligible for customer bookings at premium guild rates
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    showToast('Certificate PDF generated for offline verification.', 'success');
                    window.print();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-900 font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => {
                    showToast('Certificate downloaded successfully!', 'success');
                    setSelectedCertificate(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs flex items-center gap-1.5 transition shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Badge</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default WorkerSkillExchange;
