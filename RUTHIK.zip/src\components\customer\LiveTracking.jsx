import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  MessageSquare,
  ShieldAlert,
  ArrowRight,
  ShieldCheck,
  Send,
  X,
  Navigation,
  Sparkles,
  CreditCard,
  AlertTriangle,
  Award
} from 'lucide-react';

export const LiveTracking = () => {
  const {
    bookings,
    activeBookingId,
    updateBookingStatus,
    setIsPaymentModalOpen,
    setIsRatingModalOpen,
    setIsComplaintModalOpen
  } = useCoop();

  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { sender: 'worker', text: 'Namaste Ananya ji! I have accepted your plumbing booking. I am carrying standard pipe fittings and sealing tape.', time: '2:15 PM' },
    { sender: 'customer', text: 'Namaste Ravi ji, thank you! The security guard will guide you to 4th floor, Kaveri Nilaya.', time: '2:16 PM' }
  ]);
  const [inputMsg, setInputMsg] = useState('');

  const booking = bookings.find(b => b.id === activeBookingId) || bookings[0];

  if (!booking) {
    return (
      <div className="bg-white rounded-3xl p-10 text-center border border-slate-200">
        <p className="text-slate-500 font-medium">No active bookings right now. Pick a service above to get started!</p>
      </div>
    );
  }

  const steps = [
    { title: 'Pending', desc: 'Sent to co-op pool' },
    { title: 'Accepted', desc: 'Ravi Kumar confirmed' },
    { title: 'On The Way', desc: booking.etaMinutes > 0 ? `ETA ~${booking.etaMinutes} mins` : 'Arrived' },
    { title: 'Job Started', desc: 'In progress' },
    { title: 'Completed', desc: 'Verified & ready' }
  ];

  const handleAdvanceStep = () => {
    const nextStates = ['ACCEPTED', 'ON_THE_WAY', 'JOB_STARTED', 'COMPLETED'];
    const currentIdx = booking.currentStepIndex;
    if (currentIdx < 4) {
      updateBookingStatus(booking.id, nextStates[currentIdx]);
    }
  };

  const handleSendChat = (e) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;
    setChatMessages(prev => [...prev, { sender: 'customer', text: inputMsg, time: 'Just now' }]);
    setInputMsg('');
    setTimeout(() => {
      setChatMessages(prev => [
        ...prev,
        { sender: 'worker', text: 'Received! Arriving shortly with verified equipment.', time: 'Just now' }
      ]);
    }, 1000);
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden space-y-0">
      
      {/* Tracker Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold">
                Live Cooperative Order Tracker
              </span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-md font-mono">
                #{booking.id}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black mt-1 text-white">{booking.serviceTitle}</h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Scheduled: {booking.date} • {booking.timeSlot} • Tumakuru Cooperative
            </p>
          </div>

          {/* Quick Demo Step Trigger Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleAdvanceStep}
              disabled={booking.currentStepIndex >= 4}
              className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition-all shadow-md ${
                booking.currentStepIndex >= 4
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{booking.currentStepIndex >= 4 ? 'Order Finished' : 'Simulate Next Stage ➔'}</span>
            </button>
          </div>
        </div>

        {/* 5-Stage Timeline Stepper */}
        <div className="mt-8 pt-6 border-t border-slate-800/80">
          <div className="grid grid-cols-5 gap-2 relative">
            {steps.map((step, idx) => {
              const isPast = idx < booking.currentStepIndex;
              const isCurrent = idx === booking.currentStepIndex;
              return (
                <div key={idx} className="flex flex-col items-center text-center relative z-10">
                  <div
                    className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-black text-xs transition-all shadow-md ${
                      isPast
                        ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/20'
                        : isCurrent
                        ? 'bg-white text-emerald-800 ring-4 ring-white/30 animate-pulse'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {isPast ? <CheckCircle2 className="w-5 h-5" /> : idx + 1}
                  </div>
                  <span className={`text-[11px] sm:text-xs font-bold mt-2 ${isCurrent ? 'text-emerald-300' : isPast ? 'text-white' : 'text-slate-400'}`}>
                    {step.title}
                  </span>
                  <span className="text-[9px] sm:text-[10px] text-slate-400 hidden sm:inline-block mt-0.5">
                    {step.desc}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Map & Worker Interaction Body */}
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Simulated Live GPS Map View (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-100 rounded-2xl p-4 border border-slate-200 relative overflow-hidden min-h-[300px] flex flex-col justify-between">
          
          {/* Map Grid Pattern */}
          <div className="absolute inset-0 opacity-40 pointer-events-none bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:16px_16px]"></div>

          {/* Simulated SVG Roads */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-slate-300 stroke-2" fill="none">
            <path d="M 50,70 Q 220,130 380,80 T 680,220" strokeWidth="8" stroke="#e2e8f0" />
            <path d="M 50,70 Q 220,130 380,80 T 680,220" strokeDasharray="8,8" stroke="#10b981" />
            <circle cx="160" cy="115" r="5" fill="#059669" />
            <circle cx="360" cy="85" r="5" fill="#059669" />
            <circle cx="520" cy="145" r="5" fill="#059669" />
          </svg>

          {/* Top Status Bar on Map */}
          <div className="relative z-10 flex flex-wrap justify-between items-center bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-xl border border-slate-200 shadow-sm text-xs font-semibold text-slate-800 gap-2">
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-emerald-600 animate-spin" />
              <span>Tumakuru Smart City GPS Route</span>
            </div>
            <span className="bg-emerald-100 text-emerald-900 px-3 py-0.5 rounded-full font-extrabold text-[11px]">
              {booking.currentStepIndex === 0 && 'Waiting for Dispatch'}
              {booking.currentStepIndex === 1 && 'Accepted • Preparing Kit'}
              {booking.currentStepIndex === 2 && `On Route • ETA ~${booking.etaMinutes} mins`}
              {booking.currentStepIndex === 3 && 'At Residence • Work Started'}
              {booking.currentStepIndex === 4 && 'Service Done • Ready for Payment'}
            </span>
          </div>

          {/* Moving Map Pins */}
          <div className="relative z-10 my-10 flex items-center justify-around px-4 sm:px-12">
            {/* Worker Pin */}
            <div className={`flex flex-col items-center ${booking.currentStepIndex >= 2 ? 'animate-bounce' : ''}`}>
              <div className="p-2.5 bg-emerald-600 text-white rounded-2xl shadow-xl border-2 border-white ring-4 ring-emerald-500/20">
                <Navigation className="w-6 h-6 transform rotate-45" />
              </div>
              <span className="mt-1.5 text-[11px] font-black bg-slate-900 text-white px-2.5 py-0.5 rounded-lg shadow-md whitespace-nowrap">
                {booking.workerName} (Co-owner)
              </span>
            </div>

            {/* Destination Pin */}
            <div className="flex flex-col items-center">
              <div className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-xl border-2 border-white ring-4 ring-indigo-500/20">
                <MapPin className="w-6 h-6" />
              </div>
              <span className="mt-1.5 text-[11px] font-black bg-slate-900 text-white px-2.5 py-0.5 rounded-lg shadow-md whitespace-nowrap">
                Your Home (Kaveri Nilaya)
              </span>
            </div>
          </div>

          {/* Bottom Map Bar */}
          <div className="relative z-10 bg-white/90 backdrop-blur-sm p-2.5 rounded-xl border border-slate-200 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-2">
            <span className="font-medium">📍 {booking.customerAddress}</span>
            <span className="text-emerald-700 font-bold flex items-center gap-1 text-[11px]">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified Local Worker Route
            </span>
          </div>

        </div>

        {/* Worker Info & Financials (1 Col) */}
        <div className="flex flex-col justify-between space-y-4">
          
          {/* Worker Profile Card */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={booking.workerAvatar}
                alt={booking.workerName}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-bold text-slate-900 text-base">{booking.workerName}</h4>
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-xs text-slate-600 font-medium">{booking.workerTrade} Specialist</p>
                <p className="text-xs text-emerald-700 font-bold mt-0.5">{booking.workerPhone}</p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setChatOpen(true)}
                className="py-2.5 px-3 rounded-xl bg-white border border-slate-200 text-slate-800 text-xs font-bold hover:bg-slate-100 flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-indigo-600" />
                <span>Chat</span>
              </button>
              <a
                href={`tel:${booking.workerPhone}`}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all text-center"
              >
                <Phone className="w-4 h-4" />
                <span>Call</span>
              </a>
            </div>
          </div>

          {/* Transparent Cooperative Ledger Breakdown */}
          <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2.5 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-emerald-200">
              <span className="font-bold text-slate-900 text-sm">Transparent Price:</span>
              <span className="text-base font-black text-emerald-900">₹{booking.grossTotal}</span>
            </div>

            <div className="space-y-1.5 text-slate-700">
              <div className="flex justify-between">
                <span>• Direct Worker Pay (80%):</span>
                <span className="font-bold text-emerald-800">₹{booking.breakdown.workerPayout}</span>
              </div>
              <div className="flex justify-between">
                <span>• Co-op Welfare & Healthcare (15%):</span>
                <span className="font-semibold text-teal-800">₹{booking.breakdown.coopFee}</span>
              </div>
              <div className="flex justify-between">
                <span>• Platform Maintenance & Servers (5%):</span>
                <span className="font-medium text-slate-700">₹{booking.breakdown.platformFee}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 pt-1.5 border-t border-emerald-200">
              Zero middlemen commission. Kept in the local community.
            </p>
          </div>

          {/* Conditional Workflow Actions: Pay / Rate / Issue */}
          <div className="space-y-2">
            {booking.currentStepIndex >= 4 && !booking.isPaid && (
              <button
                onClick={() => setIsPaymentModalOpen(true)}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all transform active:scale-95 animate-pulse"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pay ₹{booking.grossTotal} (UPI / Card / Cash)</span>
              </button>
            )}

            {booking.isPaid && (
              <div className="p-3 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  Paid via {booking.paymentMethod || 'UPI Escrow'}
                </span>
                <button
                  onClick={() => setIsRatingModalOpen(true)}
                  className="px-3 py-1 bg-white rounded-lg text-xs font-bold text-emerald-800 hover:bg-emerald-50 shadow-2xs"
                >
                  Rate Worker ⭐
                </button>
              </div>
            )}

            <button
              onClick={() => setIsComplaintModalOpen(true)}
              className="w-full py-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Report an Issue to Co-op Board</span>
            </button>
          </div>

        </div>

      </div>

      {/* Live Messenger Modal */}
      {chatOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden flex flex-col h-[480px]">
            {/* Header */}
            <div className="bg-emerald-800 text-white p-4 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <img
                  src={booking.workerAvatar}
                  alt={booking.workerName}
                  className="w-10 h-10 rounded-xl object-cover border border-emerald-300"
                />
                <div>
                  <h4 className="font-bold text-sm">{booking.workerName}</h4>
                  <p className="text-[11px] text-emerald-200">Cooperative Secure Channel</p>
                </div>
              </div>
              <button onClick={() => setChatOpen(false)} className="text-white/80 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50 text-xs">
              <div className="text-center my-2">
                <span className="bg-slate-200 text-slate-600 text-[10px] px-2.5 py-0.5 rounded-full font-medium">
                  End-to-End Encrypted Co-op Line
                </span>
              </div>
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.sender === 'customer' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-3 ${
                      msg.sender === 'customer'
                        ? 'bg-emerald-600 text-white rounded-br-none'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none shadow-2xs'
                    }`}
                  >
                    <p>{msg.text}</p>
                    <span
                      className={`text-[9px] block mt-1 ${
                        msg.sender === 'customer' ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendChat} className="p-3 bg-white border-t border-slate-200 flex gap-2">
              <input
                type="text"
                value={inputMsg}
                onChange={(e) => setInputMsg(e.target.value)}
                placeholder={`Type a message to ${booking.workerName.split(' ')[0]}...`}
                className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
