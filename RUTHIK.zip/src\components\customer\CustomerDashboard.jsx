import React, { useState } from 'react';
import { useCoop, TRADE_DEFINITIONS, getTradeIcon } from '../../context/CoopContext';
import {
  LayoutDashboard,
  Search,
  Calendar,
  MapPin,
  AlertTriangle,
  CreditCard,
  Star,
  MessageSquareWarning,
  User,
  Settings,
  Bell,
  LogOut,
  Wrench,
  Zap,
  Hammer,
  Paintbrush,
  Sparkles,
  Cpu,
  Car,
  Leaf,
  Home,
  HeartHandshake,
  CheckCircle2,
  Clock,
  ChevronRight,
  ShieldCheck,
  Phone,
  Send,
  X,
  Bot,
  Filter,
  ArrowRight,
  ExternalLink,
  DollarSign,
  Layers,
  Menu,
  MoreHorizontal,
  ChevronDown
} from 'lucide-react';

export const CustomerDashboard = ({ onLogout }) => {
  const {
    currentUser,
    customerActiveTab,
    setCustomerActiveTab,
    selectedLocation,
    setSelectedLocation,
    notifications,
    bookings,
    customerStats,
    workersDirectory,
    createCustomerBooking,
    customerPayBooking,
    customerSubmitReview,
    customerSubmitComplaint,
    customerTriggerEmergency,
    emergencyAlert,
    reviews,
    complaints,
    calculateSmartMatch,
    showToast,
    t
  } = useCoop();

  // Sidebar & Mobile Menu State
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedServiceCategory, setSelectedServiceCategory] = useState('All');

  // SmartMatch AI Form State
  const [smartService, setSmartService] = useState('Plumbing');
  const [smartLocation, setSmartLocation] = useState('Tumakuru');
  const [smartDate, setSmartDate] = useState('Today');
  const [smartTime, setSmartTime] = useState('11:00 AM');
  const [smartUrgency, setSmartUrgency] = useState('Standard');
  const [smartMatchResult, setSmartMatchResult] = useState(null);
  const [isMatchingLoading, setIsMatchingLoading] = useState(false);

  // Booking Modal State
  const [bookingModalWorker, setBookingModalWorker] = useState(null);
  const [bookingFormDate, setBookingFormDate] = useState('Today');
  const [bookingFormTime, setBookingFormTime] = useState('11:00 AM');
  const [bookingFormDesc, setBookingFormDesc] = useState('');

  // Payment Modal State
  const [paymentModalBooking, setPaymentModalBooking] = useState(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('UPI');

  // Review Modal State
  const [reviewModalBooking, setReviewModalBooking] = useState(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [selectedReviewTags, setSelectedReviewTags] = useState(['Punctual', 'Honest Pricing']);

  // Complaint Form State
  const [complaintCategory, setComplaintCategory] = useState('Poor Service');
  const [complaintDesc, setComplaintDesc] = useState('');
  const [complaintWorker, setComplaintWorker] = useState('Ravi Kumar');

  // Contact Worker Modal
  const [contactModalWorker, setContactModalWorker] = useState(null);

  // Bookings Tab Filter
  const [bookingStatusTab, setBookingStatusTab] = useState('Active'); // 'Upcoming' | 'Active' | 'Completed' | 'Cancelled'

  // Service Categories (Multilingual)
  const categories = [
    { id: 'Plumbing', name: t('plumbing', 'Plumbing'), icon: Wrench, color: 'emerald' },
    { id: 'Electrical', name: t('electrical', 'Electrical'), icon: Zap, color: 'amber' },
    { id: 'Carpentry', name: t('carpentry', 'Carpentry'), icon: Hammer, color: 'orange' },
    { id: 'Painting', name: t('painting', 'Painting'), icon: Paintbrush, color: 'purple' },
    { id: 'Cleaning', name: t('cleaning', 'Cleaning'), icon: Sparkles, color: 'blue' },
    { id: 'Appliance Repair', name: t('appliance', 'Appliance Repair'), icon: Cpu, color: 'cyan' },
    { id: 'Vehicle Repair', name: t('vehicle', 'Vehicle Repair'), icon: Car, color: 'red' },
    { id: 'Gardening', name: t('gardening', 'Gardening'), icon: Leaf, color: 'lime' },
    { id: 'Home Maintenance', name: t('maintenance', 'Home Maintenance'), icon: Home, color: 'teal' },
    { id: 'Community Services', name: t('community', 'Community Services'), icon: HeartHandshake, color: 'pink' }
  ];

  // Run SmartMatch calculation
  const handleRunSmartMatch = () => {
    setIsMatchingLoading(true);
    setTimeout(() => {
      setIsMatchingLoading(false);
      const matches = calculateSmartMatch(smartService, smartLocation);
      const topMatch = matches[0] || workersDirectory[0];
      setSmartMatchResult({
        worker: topMatch,
        matchScore: topMatch.matchScore || 96,
        reason: topMatch.reason || `Certified ${topMatch.primaryTrade || topMatch.trade} specialist • Top rated (${topMatch.rating} ⭐) • ${topMatch.experience}y experience in ${topMatch.location} • Available now.`
      });
    }, 450);
  };

  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  // Primary Minimalist Nav Items (Section 9: Home | Find | Bookings | Payments | Profile)
  const primaryNavItems = [
    { id: 'dashboard', label: t('dashboard', 'Home'), icon: LayoutDashboard },
    { id: 'find-services', label: t('findServices', 'Find Services'), icon: Search },
    { id: 'bookings', label: t('myBookings', 'Bookings'), icon: Calendar },
    { id: 'payments', label: t('payments', 'Payments'), icon: CreditCard },
    { id: 'profile', label: t('myProfile', 'Profile'), icon: User }
  ];

  // Secondary Tools under 'More'
  const secondaryNavItems = [
    { id: 'smartmatch', label: t('smartMatch', 'SmartMatch AI'), icon: Bot },
    { id: 'tracking', label: t('liveTracking', 'Live Tracking'), icon: MapPin },
    { id: 'sos', label: t('sosEmergency', 'SOS Emergency'), icon: AlertTriangle },
    { id: 'reviews', label: t('reviewsRatings', 'Reviews & Ratings'), icon: Star },
    { id: 'complaints', label: t('complaintsSupport', 'Complaints & Support'), icon: MessageSquareWarning },
    { id: 'settings', label: t('settings', 'Settings'), icon: Settings }
  ];

  const navItems = [...primaryNavItems, ...secondaryNavItems];

  // === DYNAMIC CUSTOMER IDENTITY ===
  const customerName = currentUser?.name || currentUser?.fullName || 'Customer';
  const customerInitials = customerName.split(' ').map(n => n[0]).filter(Boolean).slice(0, 2).join('').toUpperCase() || 'CU';
  const customerId = currentUser?.loginId || 'customer01';
  const customerPhone = currentUser?.phone || '+91 98860 44210';
  const customerEmail = currentUser?.email || `${customerId}@example.com`;
  const customerLocation = currentUser?.location || `${selectedLocation}, Tumakuru`;

  // Active tracking booking (filtered by logged-in customer)
  const activeTrackingBooking = bookings.find((b) => b.customerId === customerId && (b.status === 'On the Way' || b.status === 'Worker Assigned' || b.status === 'Work in Progress')) || bookings.find((b) => b.customerId === customerId);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* ==================================================== */}
      {/* TOP NAVIGATION BAR                                   */}
      {/* ==================================================== */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Brand & Mobile Hamburger */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div
              onClick={() => setCustomerActiveTab('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer select-none"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-700 text-white flex items-center justify-center text-lg shadow-sm">
                🇮🇳
              </div>
              <div>
                <span className="font-black text-slate-900 text-lg tracking-tight">
                  CoWork <span className="text-emerald-700">Connect</span>
                </span>
                <span className="ml-2 hidden sm:inline-block text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  Customer Portal
                </span>
              </div>
            </div>
          </div>

          {/* Search bar & Location selector */}
          <div className="hidden md:flex items-center gap-3 flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search for services, e.g. plumber, electrician..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => {
                  if (customerActiveTab !== 'find-services') setCustomerActiveTab('find-services');
                }}
                className="w-full pl-9.5 pr-4 py-2 text-xs bg-slate-100 hover:bg-slate-50 focus:bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden transition"
              />
            </div>

            {/* Location Pill */}
            <button
              onClick={() => setLocationModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200/80 rounded-xl text-xs font-semibold text-slate-700 transition shrink-0"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-700" />
              <span>{selectedLocation}</span>
            </button>
          </div>

          {/* Right actions: Notifications, Profile, Logout */}
          <div className="flex items-center gap-3">
            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl relative transition"
              >
                <Bell className="w-5 h-5" />
                {notifications.filter((n) => !n.read && n.forRole === 'Customer').length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-emerald-600 rounded-full ring-2 ring-white"></span>
                )}
              </button>

              {/* Notifications Dropdown */}
              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Notifications</span>
                    <span className="text-[11px] text-emerald-700 font-semibold cursor-pointer">
                      Mark all read
                    </span>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.filter((n) => n.forRole === 'Customer').length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400">No new notifications</div>
                    ) : (
                      notifications
                        .filter((n) => n.forRole === 'Customer')
                        .map((n) => (
                          <div key={n.id} className="p-3 hover:bg-slate-50 transition text-left">
                            <p className="text-xs font-bold text-slate-800">{n.title}</p>
                            <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                            <span className="text-[10px] text-slate-400 mt-1 block">{n.time}</span>
                          </div>
                        ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Profile Info */}
            <div
              onClick={() => setCustomerActiveTab('profile')}
              className="flex items-center gap-2 cursor-pointer p-1.5 rounded-xl hover:bg-slate-100 transition"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-800 font-bold text-xs">
                {customerInitials}
              </div>
              <div className="hidden sm:block text-left text-xs leading-tight">
                <div className="font-bold text-slate-800">
                  {customerName}
                </div>
                <div className="text-[10px] text-emerald-700 font-medium">Customer</div>
              </div>
            </div>

            {/* Logout Button */}
            <button
              onClick={onLogout}
              title="Logout"
              className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-xl transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* ==================================================== */}
      {/* MAIN LAYOUT: SIDEBAR + CONTENT                       */}
      {/* ==================================================== */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex gap-6">
        {/* LEFT SIDEBAR (Desktop) */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-3 sticky top-22 space-y-4">
            {/* Primary Minimalist Navigation */}
            <div>
              <div className="px-3 py-1 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Primary Menu
                </span>
              </div>
              <div className="space-y-1">
                {primaryNavItems.map((item) => {
                  const IconComp = item.icon;
                  const isActive = customerActiveTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setCustomerActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <IconComp
                          className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`}
                        />
                        <span>{item.label}</span>
                      </div>
                      {item.id === 'bookings' && customerStats.activeBookings > 0 && (
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isActive ? 'bg-emerald-900 text-white' : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {customerStats.activeBookings}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Secondary Tools & Services */}
            <div>
              <div className="px-3 py-1 mb-1 border-t border-slate-100 pt-3">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  More Services
                </span>
              </div>
              <div className="space-y-1">
                {secondaryNavItems.map((item) => {
                  const IconComp = item.icon;
                  const isActive = customerActiveTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setCustomerActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <IconComp
                          className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`}
                        />
                        <span>{item.label}</span>
                      </div>
                      {item.id === 'sos' && (
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Cooperative Support Banner */}
            <div className="mt-2 pt-3 border-t border-slate-100 px-3 py-2">
              <div className="flex items-center gap-2 text-emerald-800 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Tumakuru Co-op</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Standardized rates • Zero surge fees
              </p>
            </div>
          </div>
        </aside>

        {/* MOBILE SLIDE-OUT NAV */}
        {mobileNavOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex">
            <div className="w-72 bg-white h-full p-4 flex flex-col shadow-2xl animate-in slide-in-from-left duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🇮🇳</span>
                  <span className="font-extrabold text-slate-900 text-sm">CoWork Connect</span>
                </div>
                <button
                  onClick={() => setMobileNavOpen(false)}
                  className="p-1 rounded-lg text-slate-500 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-3 space-y-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 block mb-1">
                    Primary
                  </span>
                  <div className="space-y-1">
                    {primaryNavItems.map((item) => {
                      const IconComp = item.icon;
                      const isActive = customerActiveTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setCustomerActiveTab(item.id);
                            setMobileNavOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                            isActive
                              ? 'bg-emerald-800 text-white'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className="w-4 h-4" />
                            <span>{item.label}</span>
                          </div>
                          {item.id === 'bookings' && customerStats.activeBookings > 0 && (
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                              {customerStats.activeBookings}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 block mb-1 border-t border-slate-100 pt-3">
                    More Services
                  </span>
                  <div className="space-y-1">
                    {secondaryNavItems.map((item) => {
                      const IconComp = item.icon;
                      const isActive = customerActiveTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setCustomerActiveTab(item.id);
                            setMobileNavOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
                            isActive
                              ? 'bg-emerald-800 text-white'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className="w-4 h-4" />
                            <span>{item.label}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
                <div className="text-xs">
                  <div className="font-bold text-slate-800">
                    {customerName}
                  </div>
                  <div className="text-[10px] text-slate-400">Customer</div>
                </div>
                <button
                  onClick={onLogout}
                  className="text-xs font-bold text-red-600 hover:underline"
                >
                  Logout
                </button>
              </div>
            </div>
            <div className="flex-1" onClick={() => setMobileNavOpen(false)}></div>
          </div>
        )}

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 min-w-0">
          {/* Minimalist Top Nav Header on Desktop */}
          <div className="mb-6 bg-white border border-slate-200/90 rounded-2xl p-2 shadow-2xs flex items-center justify-between gap-2 overflow-x-auto">
            <div className="flex items-center gap-1">
              {primaryNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = customerActiveTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCustomerActiveTab(item.id)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                      isActive
                        ? 'bg-emerald-800 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.label}</span>
                    {item.id === 'bookings' && customerStats.activeBookings > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${isActive ? 'bg-emerald-900 text-white' : 'bg-emerald-100 text-emerald-800'}`}>
                        {customerStats.activeBookings}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* More Menu Dropdown */}
            <div className="relative">
              <button
                onClick={() => setMoreMenuOpen(!moreMenuOpen)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition ${
                  secondaryNavItems.some(i => i.id === customerActiveTab)
                    ? 'border-emerald-700 bg-emerald-50 text-emerald-800'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <MoreHorizontal className="w-4 h-4" />
                <span>More</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {moreMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Additional Tools
                  </div>
                  {secondaryNavItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = customerActiveTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setCustomerActiveTab(item.id);
                          setMoreMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3.5 py-2 text-xs font-semibold text-left transition ${
                          isActive
                            ? 'bg-emerald-50 text-emerald-800 font-bold'
                            : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className="w-4 h-4 text-slate-500" />
                          <span>{item.label}</span>
                        </div>
                        {item.id === 'sos' && (
                          <span className="w-2 h-2 rounded-full bg-red-500"></span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* ==================================================== */}
          {/* TAB 1: DASHBOARD HOME                                */}
          {/* ==================================================== */}
          {customerActiveTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Minimalist Welcome Card */}
              <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-2xs relative">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-[11px] font-bold text-emerald-800 mb-2">
                      <span>📍 Tumakuru District Cooperative</span>
                      <span>•</span>
                      <span>Ward 12</span>
                    </div>
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                      {t('goodMorning', 'Good Morning')}, {customerName} 👋
                    </h1>
                    <p className="text-slate-500 text-xs sm:text-sm mt-1">
                      {t('heroSubtitle', 'Find trusted local service professionals from our cooperative network.')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCustomerActiveTab('find-services')}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>{t('bookService', 'Book a Service')}</span>
                    </button>
                    <button
                      onClick={() => setCustomerActiveTab('smartmatch')}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Bot className="w-3.5 h-3.5 text-emerald-700" />
                      <span>SmartMatch AI</span>
                    </button>
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-600">
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('verifiedWorkers', 'Verified Workers')}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('fairCoopFee', 'Fair Standardized Prices')}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('zeroSurge', 'Zero Surge Pricing')}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('workerOwnership', 'Community Powered')}
                  </span>
                </div>
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {t('activeBookings', 'Active Bookings')}
                  </span>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-3xl font-black text-slate-900">
                      {customerStats.activeBookings}
                    </span>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                      Live
                    </span>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {t('completedJobs', 'Completed Services')}
                  </span>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-3xl font-black text-slate-900">
                      {customerStats.completedServices}
                    </span>
                    <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                      All Time
                    </span>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {t('averageRating', 'Average Rating')}
                  </span>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-3xl font-black text-amber-600">
                      {customerStats.averageRating}
                    </span>
                    <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                      ⭐ 5 Stars
                    </span>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {t('totalSpent', 'Total Spent')}
                  </span>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-3xl font-black text-slate-900">
                      ₹{customerStats.totalSpent.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                      8% Co-op fee
                    </span>
                  </div>
                </div>
              </div>

              {/* Service Search Section */}
              <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs p-6 sm:p-8">
                <div className="max-w-2xl">
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {t('findService', 'What service do you need?')}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-1">
                    Book verified cooperative professionals with upfront, transparent tariffs.
                  </p>
                </div>

                <div className="mt-6 grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-5 relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search for a service, e.g. plumber, electrician..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <select
                      value={selectedLocation}
                      onChange={(e) => setSelectedLocation(e.target.value)}
                      className="w-full px-3 py-3 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    >
                      <option value="Tumakuru">Tumakuru</option>
                      <option value="Gubbi">Gubbi</option>
                      <option value="Kunigal">Kunigal</option>
                      <option value="Sira">Sira</option>
                      <option value="Bengaluru">Bengaluru</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <select
                      value={bookingFormDate}
                      onChange={(e) => setBookingFormDate(e.target.value)}
                      className="w-full px-3 py-3 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    >
                      <option value="Today">Today</option>
                      <option value="Tomorrow">Tomorrow</option>
                      <option value="This Weekend">Weekend</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <button
                      onClick={() => setCustomerActiveTab('find-services')}
                      className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Find Service</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Service Categories (10 Cards) */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-black text-slate-900">Service Categories</h3>
                  <span
                    onClick={() => setCustomerActiveTab('find-services')}
                    className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                  >
                    View All Categories →
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
                  {categories.map((cat) => {
                    const IconComponent = cat.icon;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setSelectedServiceCategory(cat.id);
                          setCustomerActiveTab('find-services');
                        }}
                        className="p-4 bg-white hover:bg-emerald-50/50 rounded-2xl border border-slate-200/90 hover:border-emerald-300 shadow-2xs hover:shadow-md transition text-left group cursor-pointer"
                      >
                        <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <IconComponent className="w-5 h-5" />
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 group-hover:text-emerald-800">
                          {cat.name}
                        </h4>
                        <span className="text-[11px] text-slate-400 mt-0.5 block">
                          Verified co-op
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Booking Tracker Bar */}
              {activeTrackingBooking && (
                <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl font-bold">
                      {activeTrackingBooking.workerAvatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                          Active Service • {activeTrackingBooking.id}
                        </span>
                        <span className="text-xs font-extrabold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                          {activeTrackingBooking.status}
                        </span>
                      </div>
                      <h4 className="text-base font-extrabold text-slate-900 mt-0.5">
                        {activeTrackingBooking.service} with {activeTrackingBooking.worker}
                      </h4>
                      <p className="text-xs text-slate-500">
                        {activeTrackingBooking.location} • ETA {activeTrackingBooking.etaMinutes} mins
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <button
                      onClick={() => setCustomerActiveTab('tracking')}
                      className="flex-1 sm:flex-none px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Live Track</span>
                    </button>
                    <button
                      onClick={() => setContactModalWorker(activeTrackingBooking)}
                      className="flex-1 sm:flex-none px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
                    >
                      <Phone className="w-3.5 h-3.5 text-slate-600" />
                      <span>Contact</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 2: FIND SERVICES                                 */}
          {/* ==================================================== */}
          {customerActiveTab === 'find-services' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    Find Verified Services
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Select a trade or search certified cooperative professionals in {selectedLocation}.
                  </p>
                </div>

                <button
                  onClick={() => setCustomerActiveTab('smartmatch')}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-700 to-teal-800 text-white text-xs font-bold rounded-xl shadow-sm hover:shadow-md transition"
                >
                  <Bot className="w-4 h-4" />
                  <span>Try SmartMatch AI</span>
                </button>
              </div>

              {/* Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                <button
                  onClick={() => setSelectedServiceCategory('All')}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition ${
                    selectedServiceCategory === 'All'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  All Trades
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedServiceCategory(c.id)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition ${
                      selectedServiceCategory === c.id
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>

              {/* Workers Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {workersDirectory
                  .filter((w) => {
                    if (selectedServiceCategory === 'All') return true;
                    const cat = selectedServiceCategory.toLowerCase();
                    const trade = (w.primaryTrade || w.trade || w.skill || '').toLowerCase();
                    const additional = (w.additionalSkills || []).join(' ').toLowerCase();
                    return trade.includes(cat) || cat.includes(trade) || additional.includes(cat) ||
                           (cat.includes('plumb') && trade.includes('plumb')) ||
                           (cat.includes('elect') && trade.includes('elect')) ||
                           (cat.includes('carpent') && trade.includes('carpent')) ||
                           (cat.includes('paint') && trade.includes('paint')) ||
                           (cat.includes('clean') && trade.includes('clean')) ||
                           (cat.includes('appliance') && (trade.includes('appliance') || trade.includes('ac'))) ||
                           (cat.includes('vehicle') && (trade.includes('vehicle') || trade.includes('mechanic'))) ||
                           (cat.includes('garden') && trade.includes('garden')) ||
                           (cat.includes('maintenance') && trade.includes('maintenance')) ||
                           (cat.includes('community') && trade.includes('community'));
                  })
                  .map((worker) => {
                    const workerTrade = worker.primaryTrade || worker.trade || worker.skill || 'General Services';
                    const icon = getTradeIcon(workerTrade);
                    const startingPrice = worker.startingPrice || worker.hourlyRate || 350;
                    const isAvail = worker.available !== undefined ? worker.available : (worker.isAvailable !== undefined ? worker.isAvailable : true);
                    const distance = worker.distanceKm || (worker.serviceRadius ? `${Math.min(worker.serviceRadius, 3.2)}` : '2.4');
                    const expYears = worker.experienceText || `${worker.experience || 4} yrs exp`;

                    return (
                      <div
                        key={worker.id}
                        className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:shadow-md transition flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-2xl">
                                {worker.avatar || icon}
                              </div>
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <h3 className="font-extrabold text-base text-slate-900">
                                    {worker.fullName || worker.name}
                                  </h3>
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800" title="Cooperative Verified">
                                    ✓ Verified
                                  </span>
                                </div>
                                <p className="text-xs font-semibold text-emerald-800 flex items-center gap-1 mt-0.5">
                                  <span>{icon}</span>
                                  <span>{workerTrade}</span>
                                </p>
                                <span className="text-[11px] text-slate-400">{expYears}</span>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="text-sm font-extrabold text-slate-900 block">
                                ₹{startingPrice}
                              </span>
                              <span className="text-[10px] text-slate-500 font-medium">starting</span>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                            <span className="flex items-center gap-1 font-semibold text-amber-700">
                              ⭐ {worker.rating || 4.8} ({worker.reviewCount || 30}+ reviews)
                            </span>
                            <span className="flex items-center gap-1 text-slate-500">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              {distance} km away
                            </span>
                            <span
                              className={`font-bold flex items-center gap-1 ${
                                isAvail ? 'text-emerald-700' : 'text-slate-400'
                              }`}
                            >
                              <span>{isAvail ? '🟢' : '⚪'}</span>
                              <span>{isAvail ? 'Available' : 'Offline'}</span>
                            </span>
                          </div>
                        </div>

                        <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-3">
                          <button
                            onClick={() => {
                              setBookingModalWorker(worker);
                              setBookingFormDesc(`Standard ${workerTrade} callout in Tumakuru.`);
                            }}
                            className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition text-center cursor-pointer"
                          >
                            Book Now
                          </button>
                          <button
                            onClick={() => setContactModalWorker(worker)}
                            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition"
                          >
                            View Profile
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 3: SMARTMATCH AI                                 */}
          {/* ==================================================== */}
          {customerActiveTab === 'smartmatch' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
                <div className="flex items-center gap-2.5 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
                  <Bot className="w-4 h-4" />
                  <span>AI Matching Engine</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight">SmartMatch AI</h2>
                <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl">
                  Our cooperative algorithm pairs your request with the best-fit local worker based on skill proximity, peer rating, availability, and workload fairness.
                </p>

                {/* Match Form Controls */}
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      Service
                    </label>
                    <select
                      value={smartService}
                      onChange={(e) => setSmartService(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-hidden"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      value={smartLocation}
                      onChange={(e) => setSmartLocation(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      Date
                    </label>
                    <select
                      value={smartDate}
                      onChange={(e) => setSmartDate(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-hidden"
                    >
                      <option value="Today">Today</option>
                      <option value="Tomorrow">Tomorrow</option>
                      <option value="Next Day">Next Day</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      Time Slot
                    </label>
                    <select
                      value={smartTime}
                      onChange={(e) => setSmartTime(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-hidden"
                    >
                      <option value="11:00 AM">11:00 AM - 12:00 PM</option>
                      <option value="2:30 PM">2:30 PM - 3:30 PM</option>
                      <option value="5:00 PM">5:00 PM - 6:00 PM</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      Urgency
                    </label>
                    <select
                      value={smartUrgency}
                      onChange={(e) => setSmartUrgency(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-hidden"
                    >
                      <option value="Standard">Standard Schedule</option>
                      <option value="Urgent">Within 1 Hour</option>
                    </select>
                  </div>
                </div>

                <div className="mt-6">
                  <button
                    onClick={handleRunSmartMatch}
                    disabled={isMatchingLoading}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Bot className="w-4 h-4" />
                    <span>{isMatchingLoading ? 'Computing Match...' : 'Find Best Worker'}</span>
                  </button>
                </div>
              </div>

              {/* Match Result Display */}
              {smartMatchResult && (
                <div className="bg-white rounded-3xl border border-emerald-300 shadow-md p-6 sm:p-8 animate-in zoom-in-95 duration-200">
                  <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-xs uppercase tracking-wider">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>AI Recommended Top Match</span>
                    </div>
                    <span className="text-xs font-black bg-emerald-100 text-emerald-900 px-3 py-1 rounded-full">
                      {smartMatchResult.matchScore}% Match Score
                    </span>
                  </div>

                  <div className="mt-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-3xl shadow-xs">
                        {smartMatchResult.worker.avatar || getTradeIcon(smartMatchResult.worker.primaryTrade || smartMatchResult.worker.trade)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-xl font-black text-slate-900">
                            {smartMatchResult.worker.fullName || smartMatchResult.worker.name}
                          </h3>
                          <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-md">
                            ✓ Verified Co-owner
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-600 mt-0.5 flex items-center gap-1">
                          <span>{getTradeIcon(smartMatchResult.worker.primaryTrade || smartMatchResult.worker.trade || smartMatchResult.worker.skill)}</span>
                          <span>{smartMatchResult.worker.primaryTrade || smartMatchResult.worker.trade || smartMatchResult.worker.skill}</span>
                          <span>•</span>
                          <span>{smartMatchResult.worker.experienceText || `${smartMatchResult.worker.experience || 4} yrs exp`}</span>
                        </p>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                          <span className="text-amber-700 font-bold">
                            ⭐ {smartMatchResult.worker.rating || 4.8}
                          </span>
                          <span>•</span>
                          <span>{smartMatchResult.worker.distanceKm || '2.4'} km away</span>
                          <span>•</span>
                          <span className="text-emerald-700 font-bold">Available Now</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-2xl font-black text-slate-900 block">
                        ₹{smartMatchResult.worker.startingPrice || smartMatchResult.worker.hourlyRate || 350}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">
                        Standard Starting Tariff
                      </span>
                    </div>
                  </div>

                  {/* Why recommended explanation */}
                  <div className="mt-6 p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl">
                    <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider block mb-1">
                      Why recommended?
                    </span>
                    <p className="text-xs text-emerald-800 leading-relaxed font-medium">
                      {smartMatchResult.reason}
                    </p>
                  </div>

                  <div className="mt-6 flex items-center gap-3">
                    <button
                      onClick={() => {
                        setBookingModalWorker(smartMatchResult.worker);
                        setBookingFormDate(smartDate);
                        setBookingFormTime(smartTime);
                        setBookingFormDesc(`AI SmartMatch Booking for ${smartService} (${smartUrgency}).`);
                      }}
                      className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold rounded-xl shadow-md transition flex items-center gap-2"
                    >
                      <span>Book Now</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setContactModalWorker(smartMatchResult.worker)}
                      className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition"
                    >
                      View Profile
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 4: MY BOOKINGS                                   */}
          {/* ==================================================== */}
          {customerActiveTab === 'bookings' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    My Bookings
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    View schedule, track arrival, contact professionals, or complete payment.
                  </p>
                </div>

                <button
                  onClick={() => setCustomerActiveTab('find-services')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl hover:bg-emerald-800 transition"
                >
                  + New Service Request
                </button>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                {['Active', 'Upcoming', 'Completed', 'Cancelled'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setBookingStatusTab(tab)}
                    className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
                      bookingStatusTab === tab
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {tab} Bookings
                  </button>
                ))}
              </div>

              {/* Bookings List */}
              <div className="space-y-4">
                {bookings
                  .filter((b) => b.customerId === customerId)
                  .filter((b) => {
                    if (bookingStatusTab === 'Active') {
                      return ['Confirmed', 'Worker Assigned', 'On the Way', 'Work in Progress'].includes(b.status);
                    }
                    if (bookingStatusTab === 'Upcoming') {
                      return ['Confirmed', 'Worker Assigned'].includes(b.status);
                    }
                    if (bookingStatusTab === 'Completed') {
                      return b.status === 'Completed';
                    }
                    return b.status === 'Cancelled';
                  })
                  .map((booking) => (
                    <div
                      key={booking.id}
                      className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:shadow-xs transition"
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-2xl">
                            {booking.workerAvatar}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-base text-slate-900">
                                {booking.service}
                              </span>
                              <span
                                className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-full ${
                                  booking.status === 'Completed'
                                    ? 'bg-slate-100 text-slate-700'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {booking.status}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Booking ID: <code className="text-slate-700 font-bold">{booking.id}</code>
                            </p>
                          </div>
                        </div>

                        <div className="text-left md:text-right">
                          <span className="text-lg font-black text-slate-900">
                            ₹{booking.totalPrice}
                          </span>
                          <span className="text-xs text-slate-400 block">
                            (Service: ₹{booking.price} + Co-op Fee: ₹{booking.coopFee})
                          </span>
                        </div>
                      </div>

                      <div className="py-3 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-600">
                        <div>
                          <span className="text-slate-400 block text-[11px]">Worker:</span>
                          <span className="font-bold text-slate-800">{booking.worker}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px]">Date & Time:</span>
                          <span className="font-semibold text-slate-700">
                            {booking.date}, {booking.time}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px]">Location:</span>
                          <span className="font-semibold text-slate-700 truncate block">
                            {booking.location}
                          </span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          {booking.status !== 'Completed' && booking.status !== 'Cancelled' && (
                            <button
                              onClick={() => setCustomerActiveTab('tracking')}
                              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
                            >
                              <MapPin className="w-3.5 h-3.5" />
                              <span>Track Worker</span>
                            </button>
                          )}

                          <button
                            onClick={() => setContactModalWorker(booking)}
                            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition flex items-center gap-1.5"
                          >
                            <Phone className="w-3.5 h-3.5 text-slate-500" />
                            <span>Contact</span>
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          {booking.status === 'Completed' && booking.paymentStatus === 'Pending' && (
                            <button
                              onClick={() => setPaymentModalBooking(booking)}
                              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span>Pay ₹{booking.totalPrice}</span>
                            </button>
                          )}

                          {booking.status === 'Completed' && booking.paymentStatus === 'Paid' && !booking.reviewed && (
                            <button
                              onClick={() => setReviewModalBooking(booking)}
                              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
                            >
                              <Star className="w-3.5 h-3.5" />
                              <span>Leave Review</span>
                            </button>
                          )}

                          {booking.status !== 'Completed' && booking.status !== 'Cancelled' && (
                            <button
                              onClick={() => {
                                if (window.confirm('Are you sure you want to cancel this booking?')) {
                                  showToast('Booking cancelled.', 'info');
                                }
                              }}
                              className="px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 rounded-xl transition"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 5: LIVE TRACKING                                 */}
          {/* ==================================================== */}
          {customerActiveTab === 'tracking' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    Live Worker Dispatch & Tracking
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Real-time status updates and proximity mapping for your active service.
                  </p>
                </div>
              </div>

              {/* Tracking Details Card */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-3xl">
                      {activeTrackingBooking?.workerAvatar || '👨‍🔧'}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase">
                        Assigned Professional
                      </span>
                      <h3 className="text-xl font-black text-slate-900">
                        {activeTrackingBooking?.worker || 'Ravi Kumar'}
                      </h3>
                      <p className="text-xs font-semibold text-emerald-800">
                        {activeTrackingBooking?.service || 'Plumbing'} Specialist
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase block">
                        Distance
                      </span>
                      <span className="text-lg font-black text-slate-900">
                        {activeTrackingBooking?.distanceKm || 1.2} km
                      </span>
                    </div>
                    <div className="w-px h-8 bg-slate-200"></div>
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase block">
                        ETA
                      </span>
                      <span className="text-lg font-black text-emerald-700">
                        {activeTrackingBooking?.etaMinutes || 8} minutes
                      </span>
                    </div>
                  </div>
                </div>

                {/* Workflow Progress Steps */}
                <div className="mt-8">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-4">
                    Service Progression:
                  </span>
                  <div className="grid grid-cols-5 gap-2 text-center text-xs">
                    {[
                      { step: 'Assigned', active: true },
                      { step: 'On the Way', active: ['On the Way', 'Arrived', 'Work Started', 'Completed'].includes(activeTrackingBooking?.status) },
                      { step: 'Arrived', active: ['Arrived', 'Work Started', 'Completed'].includes(activeTrackingBooking?.status) },
                      { step: 'Work Started', active: ['Work Started', 'Completed'].includes(activeTrackingBooking?.status) },
                      { step: 'Completed', active: activeTrackingBooking?.status === 'Completed' }
                    ].map((s, idx) => (
                      <div key={idx} className="flex flex-col items-center">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs mb-1.5 transition-all ${
                            s.active
                              ? 'bg-emerald-700 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-400'
                          }`}
                        >
                          {s.active ? '✓' : idx + 1}
                        </div>
                        <span
                          className={`text-[11px] font-bold ${
                            s.active ? 'text-emerald-900' : 'text-slate-400'
                          }`}
                        >
                          {s.step}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Simulated Map Interface */}
                <div className="mt-8 relative bg-slate-900 rounded-2xl h-64 overflow-hidden border border-slate-700 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>

                  {/* Simulated Path Line */}
                  <svg className="absolute inset-0 w-full h-full">
                    <path
                      d="M 120 180 Q 250 80 400 130 T 600 90"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="3"
                      strokeDasharray="6 6"
                      className="animate-pulse"
                    />
                  </svg>

                  {/* Worker Marker */}
                  <div className="absolute left-1/4 top-1/2 -translate-y-1/2 flex flex-col items-center animate-bounce">
                    <div className="bg-emerald-600 text-white p-2 rounded-xl shadow-lg border-2 border-white text-xs font-bold flex items-center gap-1.5">
                      <span>👨‍🔧</span>
                      <span>Ravi Kumar (1.2 km)</span>
                    </div>
                    <div className="w-2 h-2 bg-emerald-600 rotate-45 -mt-1"></div>
                  </div>

                  {/* Customer Destination Marker */}
                  <div className="absolute right-1/4 top-1/3 flex flex-col items-center">
                    <div className="bg-slate-800 text-white px-3 py-1.5 rounded-xl shadow-lg border border-slate-600 text-xs font-bold flex items-center gap-1.5">
                      <Home className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Your Residence</span>
                    </div>
                  </div>

                  <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-xs text-white text-[11px] px-3 py-1.5 rounded-lg border border-slate-700">
                    📍 Tumakuru Ward 12 • Live GPS Active
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    Need to modify directions? Contact your assigned worker directly.
                  </span>
                  <button
                    onClick={() => setContactModalWorker(activeTrackingBooking)}
                    className="px-4 py-2 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Call Worker</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 6: SOS EMERGENCY                                 */}
          {/* ==================================================== */}
          {customerActiveTab === 'sos' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-gradient-to-r from-red-800 via-rose-700 to-red-900 text-white rounded-3xl p-6 sm:p-8 shadow-lg">
                <div className="flex items-center gap-2 text-red-200 text-xs font-bold uppercase tracking-wider mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-300" />
                  <span>Immediate Response Protocol</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight">Emergency SOS</h2>
                <p className="text-red-100 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                  For critical home hazards requiring priority response from verified neighborhood cooperative professionals.
                </p>

                <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { type: 'Gas Leak', icon: '🔥', desc: 'LPG valve / pipeline leak' },
                    { type: 'Electrical Fault', icon: '⚡', desc: 'Short circuit / spark hazard' },
                    { type: 'Water Burst', icon: '💧', desc: 'Main line burst / flooding' },
                    { type: 'Home Emergency', icon: '🏠', desc: 'Structural lock / gate block' }
                  ].map((item) => (
                    <button
                      key={item.type}
                      onClick={() => customerTriggerEmergency(item.type)}
                      className="p-4 bg-white/10 hover:bg-white/20 active:bg-white/25 rounded-2xl border border-white/20 text-left transition cursor-pointer"
                    >
                      <span className="text-2xl block mb-2">{item.icon}</span>
                      <h4 className="font-extrabold text-sm text-white">{item.type}</h4>
                      <p className="text-[11px] text-red-200 mt-0.5">{item.desc}</p>
                    </button>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t border-red-700/60 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <button
                    onClick={() => customerTriggerEmergency('Water Burst')}
                    className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-red-50 text-red-700 font-black text-sm tracking-wider uppercase rounded-2xl shadow-xl transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <AlertTriangle className="w-5 h-5 text-red-600 animate-pulse" />
                    <span>🚨 REQUEST EMERGENCY HELP</span>
                  </button>

                  <span className="text-[11px] text-red-200">
                    * Simulated cooperative emergency dispatch workflow for demonstration.
                  </span>
                </div>
              </div>

              {/* Confirmation / Alert Status */}
              {emergencyAlert && (
                <div className="bg-white rounded-3xl border-2 border-red-400 p-6 sm:p-8 shadow-md animate-in zoom-in-95 duration-200">
                  <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2 text-red-700 font-black text-sm uppercase tracking-wide">
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Emergency request sent.</span>
                    </div>
                    <span className="text-xs font-black bg-red-100 text-red-800 px-3 py-1 rounded-full">
                      Priority Active
                    </span>
                  </div>

                  <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <span className="text-xs text-slate-400 font-bold uppercase block">
                        Hazard Category
                      </span>
                      <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
                        {emergencyAlert.type}
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <span className="text-xs text-slate-400 font-bold uppercase block">
                        Nearest Verified Worker
                      </span>
                      <span className="text-base font-extrabold text-slate-900 mt-0.5 block">
                        {emergencyAlert.nearestWorker}
                      </span>
                      <span className="text-xs text-slate-500">{emergencyAlert.workerPhone}</span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <span className="text-xs text-slate-400 font-bold uppercase block">
                        Estimated Arrival
                      </span>
                      <span className="text-base font-extrabold text-red-700 mt-0.5 block">
                        {emergencyAlert.etaMinutes} minutes
                      </span>
                      <span className="text-xs text-slate-500">Status: {emergencyAlert.status}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 7: PAYMENTS                                      */}
          {/* ==================================================== */}
          {customerActiveTab === 'payments' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">Payments</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Transparent cooperative billing: fair worker compensation + capped 8% co-op fee.
                  </p>
                </div>
              </div>

              {/* Payments Ledger Table */}
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-2xs">
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-extrabold text-slate-900 text-base">Payment History</h3>
                  <span className="text-xs font-semibold text-slate-500">
                    Total Lifetime Spend: ₹{customerStats.totalSpent.toLocaleString()}
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-3.5">Booking / Service</th>
                        <th className="px-6 py-3.5">Worker</th>
                        <th className="px-6 py-3.5">Service Cost</th>
                        <th className="px-6 py-3.5">Co-op Fee (8%)</th>
                        <th className="px-6 py-3.5">Total Paid</th>
                        <th className="px-6 py-3.5">Method</th>
                        <th className="px-6 py-3.5">Status</th>
                        <th className="px-6 py-3.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {bookings.map((b) => (
                        <tr key={b.id} className="hover:bg-slate-50/70 transition">
                          <td className="px-6 py-4">
                            <span className="font-bold text-slate-900 block">{b.service}</span>
                            <span className="text-[11px] text-slate-400">{b.id}</span>
                          </td>
                          <td className="px-6 py-4 font-medium text-slate-800">{b.worker}</td>
                          <td className="px-6 py-4 font-semibold text-slate-700">₹{b.price}</td>
                          <td className="px-6 py-4 font-semibold text-emerald-700">₹{b.coopFee}</td>
                          <td className="px-6 py-4 font-black text-slate-900">₹{b.totalPrice}</td>
                          <td className="px-6 py-4 font-medium text-slate-600">{b.paymentMethod}</td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                b.paymentStatus === 'Paid'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {b.paymentStatus}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            {b.paymentStatus === 'Pending' ? (
                              <button
                                onClick={() => setPaymentModalBooking(b)}
                                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[11px] rounded-lg shadow-2xs transition"
                              >
                                Pay Now
                              </button>
                            ) : (
                              <span className="text-emerald-700 font-bold text-[11px]">✓ Settled</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 8: REVIEWS & RATINGS                             */}
          {/* ==================================================== */}
          {customerActiveTab === 'reviews' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    Reviews & Ratings
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Your feedback strengthens cooperative reputation and ensures fair service quality.
                  </p>
                </div>
              </div>

              {/* Review Input Box */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <h3 className="text-base font-extrabold text-slate-900 mb-4">
                  Rate your recent service with Ravi Kumar
                </h3>

                <div className="flex items-center gap-2 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setReviewRating(star)}
                      className="text-2xl focus:outline-hidden hover:scale-110 transition-transform cursor-pointer"
                    >
                      {star <= reviewRating ? '⭐' : '☆'}
                    </button>
                  ))}
                  <span className="text-xs font-bold text-slate-600 ml-2">
                    {reviewRating} out of 5 stars
                  </span>
                </div>

                <textarea
                  rows="3"
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  placeholder="Share details about punctuality, craftsmanship, and courteous behavior..."
                  className="w-full p-4 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                ></textarea>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {['Punctual', 'Honest Pricing', 'Clean Work'].map((t) => (
                      <span
                        key={t}
                        className="text-[11px] font-bold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg"
                      >
                        ✓ {t}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      if (!reviewText.trim()) {
                        showToast('Please enter your review comments.', 'error');
                        return;
                      }
                      customerSubmitReview({
                        bookingId: 'BK-2026-001',
                        workerName: 'Ravi Kumar',
                        rating: reviewRating,
                        comment: reviewText
                      });
                      setReviewText('');
                    }}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Submit Review
                  </button>
                </div>
              </div>

              {/* Previous Reviews */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <h3 className="text-base font-extrabold text-slate-900 mb-4">
                  Past Customer Reviews ({reviews.length})
                </h3>

                <div className="space-y-4">
                  {reviews.map((rev) => (
                    <div key={rev.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{rev.customer}</span>
                          <span className="text-[11px] text-slate-400">• for {rev.worker} ({rev.workerTrade})</span>
                        </div>
                        <span className="text-xs font-bold text-amber-700">
                          {'⭐'.repeat(Math.round(rev.rating))}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>
                      <div className="mt-2 flex items-center gap-2">
                        {rev.tags?.map((t) => (
                          <span key={t} className="text-[10px] bg-white border border-slate-200 text-slate-600 px-2 py-0.5 rounded-md font-semibold">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 9: COMPLAINTS & SUPPORT                          */}
          {/* ==================================================== */}
          {customerActiveTab === 'complaints' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                  Complaints & Peer Resolution
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Cooperative disputes are resolved transparently by our community peer committee.
                </p>
              </div>

              {/* Complaint Submission Card */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <h3 className="text-base font-extrabold text-slate-900 mb-4">File a Support Ticket</h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                      Complaint Category *
                    </label>
                    <select
                      value={complaintCategory}
                      onChange={(e) => setComplaintCategory(e.target.value)}
                      className="w-full px-3 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    >
                      <option value="Poor Service">Poor Service</option>
                      <option value="Worker Didn't Arrive">Worker Didn't Arrive</option>
                      <option value="Payment Issue">Payment Issue</option>
                      <option value="Overcharging">Overcharging</option>
                      <option value="Safety Issue">Safety Issue</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                      Service Worker Involved
                    </label>
                    <input
                      type="text"
                      value={complaintWorker}
                      onChange={(e) => setComplaintWorker(e.target.value)}
                      className="w-full px-3 py-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Describe the Issue *
                  </label>
                  <textarea
                    rows="3"
                    value={complaintDesc}
                    onChange={(e) => setComplaintDesc(e.target.value)}
                    placeholder="Provide details of the issue so the cooperative review committee can arbitrate..."
                    className="w-full p-3 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  ></textarea>
                </div>

                <button
                  onClick={() => {
                    if (!complaintDesc.trim()) {
                      showToast('Please provide a description of the complaint.', 'error');
                      return;
                    }
                    customerSubmitComplaint({
                      category: complaintCategory,
                      description: complaintDesc,
                      worker: complaintWorker
                    });
                    setComplaintDesc('');
                  }}
                  className="px-6 py-2.5 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl shadow-xs transition"
                >
                  Submit Complaint Ticket
                </button>
              </div>

              {/* Complaint History */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <h3 className="text-base font-extrabold text-slate-900 mb-4">
                  Complaint History ({complaints.length})
                </h3>

                <div className="space-y-3">
                  {complaints.map((c) => (
                    <div key={c.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-slate-900">
                            Ticket #{c.ticketNo}
                          </span>
                          <span className="text-xs bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded-md">
                            {c.category}
                          </span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                            c.status === 'Resolved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {c.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">{c.description}</p>
                      {c.resolutionNote && (
                        <div className="mt-2 text-xs font-semibold text-emerald-800 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
                          Resolution: {c.resolutionNote}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 10: MY PROFILE                                   */}
          {/* ==================================================== */}
          {customerActiveTab === 'profile' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Customer Profile</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage your personal details, verified addresses, and cooperative contact preferences.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
                <div className="flex items-center gap-4 pb-6 border-b border-slate-100">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 font-black text-xl flex items-center justify-center border-2 border-emerald-300">
                    {customerInitials}
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-900">
                      {customerName}
                    </h3>
                    <p className="text-xs text-emerald-800 font-bold">
                      Household Member • Tumakuru Urban Cooperative
                    </p>
                    <span className="text-[11px] text-slate-400">Customer ID: {customerId}</span>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block text-slate-400 font-bold uppercase text-[11px] mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      defaultValue={customerName}
                      key={`name-${customerId}`}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-bold uppercase text-[11px] mb-1">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      defaultValue={customerPhone}
                      key={`phone-${customerId}`}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-bold uppercase text-[11px] mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      defaultValue={customerEmail}
                      key={`email-${customerId}`}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-bold uppercase text-[11px] mb-1">
                      Default Service Address
                    </label>
                    <input
                      type="text"
                      defaultValue={customerLocation}
                      key={`location-${customerId}`}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50"
                    />
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={() => showToast('Profile details updated successfully.', 'success')}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 11: SETTINGS                                     */}
          {/* ==================================================== */}
          {customerActiveTab === 'settings' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Settings</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Platform preferences, notifications, and language configuration.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="font-extrabold text-sm text-slate-900 block">
                      SMS & WhatsApp Dispatch Alerts
                    </span>
                    <span className="text-xs text-slate-500">
                      Receive real-time worker ETA updates via SMS/WhatsApp
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-5 h-5 accent-emerald-600 rounded"
                  />
                </div>

                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="font-extrabold text-sm text-slate-900 block">
                      Interface Language
                    </span>
                    <span className="text-xs text-slate-500">Select preferred display language</span>
                  </div>
                  <select className="px-3 py-1.5 text-xs border border-slate-300 rounded-xl bg-white">
                    <option value="en">English</option>
                    <option value="kn">ಕನ್ನಡ (Kannada)</option>
                    <option value="hi">हिन्दी (Hindi)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="font-extrabold text-sm text-slate-900 block">
                      Location Privacy
                    </span>
                    <span className="text-xs text-slate-500">
                      Share exact GPS only after worker acceptance
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-5 h-5 accent-emerald-600 rounded"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => showToast('Settings preferences saved.', 'success')}
                    className="px-5 py-2.5 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ==================================================== */}
      {/* MODAL: DIRECT BOOKING MODAL                          */}
      {/* ==================================================== */}
      {bookingModalWorker && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="bg-emerald-800 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base">Book Service</h3>
                <p className="text-xs text-emerald-200">
                  {bookingModalWorker.name} ({bookingModalWorker.skill})
                </p>
              </div>
              <button
                onClick={() => setBookingModalWorker(null)}
                className="p-1 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Date
                </label>
                <select
                  value={bookingFormDate}
                  onChange={(e) => setBookingFormDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white"
                >
                  <option value="Today">Today</option>
                  <option value="Tomorrow">Tomorrow</option>
                  <option value="Saturday">Saturday</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Time Slot
                </label>
                <select
                  value={bookingFormTime}
                  onChange={(e) => setBookingFormTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white"
                >
                  <option value="11:00 AM">11:00 AM - 12:00 PM</option>
                  <option value="2:30 PM">2:30 PM - 3:30 PM</option>
                  <option value="5:00 PM">5:00 PM - 6:00 PM</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Work Details / Issue
                </label>
                <textarea
                  rows="2"
                  value={bookingFormDesc}
                  onChange={(e) => setBookingFormDesc(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                ></textarea>
              </div>

              {/* Price Breakdown */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Standard Service Callout:</span>
                  <span>₹{bookingModalWorker.hourlyRate}</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-medium">
                  <span>Co-op Platform Fee (8%):</span>
                  <span>₹{Math.round(bookingModalWorker.hourlyRate * 0.08)}</span>
                </div>
                <div className="flex justify-between font-black text-slate-900 pt-1 border-t border-slate-200 text-sm">
                  <span>Total Amount Payable:</span>
                  <span>₹{bookingModalWorker.hourlyRate + Math.round(bookingModalWorker.hourlyRate * 0.08)}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  createCustomerBooking({
                    service: bookingModalWorker.primaryTrade || bookingModalWorker.trade || bookingModalWorker.skill,
                    workerId: bookingModalWorker.id,
                    date: bookingFormDate,
                    time: bookingFormTime,
                    issueDescription: bookingFormDesc
                  });
                  setBookingModalWorker(null);
                  setCustomerActiveTab('bookings');
                }}
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition"
              >
                Confirm Booking & Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: PAYMENT MODAL                                 */}
      {/* ==================================================== */}
      {paymentModalBooking && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <h3 className="font-extrabold text-base">Complete Payment</h3>
              <button
                onClick={() => setPaymentModalBooking(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
                <span className="text-xs text-slate-500 block">Total Due Amount</span>
                <span className="text-3xl font-black text-emerald-900">
                  ₹{paymentModalBooking.totalPrice}
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Service: ₹{paymentModalBooking.price} + Co-op Fee: ₹{paymentModalBooking.coopFee}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Payment Method
                </label>
                <div className="space-y-2">
                  {['UPI (GPay / PhonePe)', 'Credit / Debit Card', 'Cash on Service'].map((method) => (
                    <label
                      key={method}
                      className={`flex items-center gap-2 p-3 rounded-xl border cursor-pointer transition ${
                        selectedPaymentMethod === method
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                          : 'border-slate-200 text-slate-700'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payMethod"
                        checked={selectedPaymentMethod === method}
                        onChange={() => setSelectedPaymentMethod(method)}
                        className="accent-emerald-600"
                      />
                      <span>{method}</span>
                    </label>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  customerPayBooking(paymentModalBooking.id, selectedPaymentMethod);
                  setPaymentModalBooking(null);
                }}
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition"
              >
                Pay ₹{paymentModalBooking.totalPrice}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: WORKER PROFILE MODAL                          */}
      {/* ==================================================== */}
      {contactModalWorker && (() => {
        const workerTrade = contactModalWorker.primaryTrade || contactModalWorker.trade || contactModalWorker.service || contactModalWorker.skill || 'General Services';
        const tradeIcon = getTradeIcon(workerTrade);
        const name = contactModalWorker.fullName || contactModalWorker.worker || contactModalWorker.name;
        const startingRate = contactModalWorker.startingPrice || contactModalWorker.hourlyRate || 350;
        const phone = contactModalWorker.phone || contactModalWorker.workerPhone || '+91 98860 11928';
        const skills = contactModalWorker.additionalSkills || [];

        return (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 p-6 animate-in zoom-in-95 duration-150">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 text-3xl flex items-center justify-center shadow-xs">
                    {contactModalWorker.workerAvatar || contactModalWorker.avatar || tradeIcon}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-lg font-black text-slate-900">{name}</h3>
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        ✓ Verified
                      </span>
                    </div>
                    <p className="text-xs font-bold text-emerald-800 flex items-center gap-1 mt-0.5">
                      <span>{tradeIcon}</span>
                      <span>{workerTrade} Specialist</span>
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      📍 {contactModalWorker.location || 'Tumakuru'} • Tumakuru Cooperative Union
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setContactModalWorker(null)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Stats row */}
              <div className="mt-4 grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Rating</span>
                  <span className="text-sm font-black text-slate-900 flex items-center justify-center gap-1">
                    ⭐ {contactModalWorker.rating || 4.8}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Experience</span>
                  <span className="text-sm font-black text-slate-900">
                    {contactModalWorker.experienceText || `${contactModalWorker.experience || 4}y exp`}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Starting At</span>
                  <span className="text-sm font-black text-emerald-800">
                    ₹{startingRate}
                  </span>
                </div>
              </div>

              {/* Specialized Skills */}
              {skills.length > 0 && (
                <div className="mt-4">
                  <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wide block mb-1.5">
                    Specialized Skills & Expertise
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px] font-semibold rounded-lg"
                      >
                        ✓ {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Contact and booking actions */}
              <div className="mt-6 space-y-2">
                <button
                  onClick={() => {
                    const targetWorker = contactModalWorker;
                    setContactModalWorker(null);
                    setBookingModalWorker(targetWorker);
                    setBookingFormDesc(`Service callout for ${workerTrade} in ${targetWorker.location || 'Tumakuru'}.`);
                  }}
                  className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Book Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${phone}`}
                    className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5 text-slate-600" />
                    <span>Call ({phone})</span>
                  </a>
                  <button
                    onClick={() => {
                      showToast(`SMS request link dispatched to ${name}`, 'success');
                      setContactModalWorker(null);
                    }}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
                  >
                    Message
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ==================================================== */}
      {/* MODAL: LOCATION SELECTOR MODAL                       */}
      {/* ==================================================== */}
      {locationModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl border border-slate-200 p-6 animate-in zoom-in-95 duration-150">
            <h3 className="text-base font-black text-slate-900 mb-3">Select Location</h3>
            <div className="space-y-2 text-xs">
              {['Tumakuru', 'Gubbi', 'Kunigal', 'Sira', 'Bengaluru'].map((loc) => (
                <button
                  key={loc}
                  onClick={() => {
                    setSelectedLocation(loc);
                    setLocationModalOpen(false);
                    showToast(`Location set to ${loc}`, 'info');
                  }}
                  className={`w-full p-3 rounded-xl border text-left font-bold transition ${
                    selectedLocation === loc
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  📍 {loc}
                </button>
              ))}
            </div>
            <button
              onClick={() => setLocationModalOpen(false)}
              className="mt-4 w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
