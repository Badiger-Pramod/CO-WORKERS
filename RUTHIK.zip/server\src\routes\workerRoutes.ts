import { Router } from 'express';
import {
  getWorkers,
  getWorkerById,
  updateAvailability,
  updateWorkerSkills,
  getWorkerEarnings
} from '../controllers/workerController';

const router = Router();

router.get('/', getWorkers);
router.get('/:id', getWorkerById);
router.put('/:id/availability', updateAvailability);
router.put('/:id/skills', updateWorkerSkills);
router.get('/:id/earnings', getWorkerEarnings);

export default router;
