import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  GraduationCap,
  Sparkles,
  Users,
  Award,
  Star,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  MapPin,
  Languages
} from 'lucide-react';
import {
  AGRICULTURAL_SKILLS_CATALOG,
  FARMER_SKILL_MENTORS
} from '../../data/agriMockData';

export const SkillExchangeTab = ({ onNavigateToMySkills }) => {
  const { currentFarmer, requestSkillExchange } = useCoop();
  const farmer = currentFarmer || {};

  const [selectedMentor, setSelectedMentor] = useState(null);
  const [selectedSkill, setSelectedSkill] = useState('Drip Irrigation');
  const [learningObjective, setLearningObjective] = useState('Learn pressure compensation emitter maintenance and filter flushing');

  const handleOpenMentorModal = (mentor) => {
    setSelectedMentor(mentor);
    setSelectedSkill(mentor.specialties?.[0] || 'Drip Irrigation');
  };

  const handleConfirmRequest = () => {
    if (!selectedMentor) return;

    requestSkillExchange(selectedMentor.id, selectedSkill);
    setSelectedMentor(null);

    if (onNavigateToMySkills) {
      onNavigateToMySkills();
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ─── Header ──────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🌱</span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Farmer Agricultural Skill Exchange & Mentorship
            </h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Peer-to-peer knowledge barter between experienced farmers. Learn sustainable techniques and gain cooperative skill certifications.
          </p>
        </div>

        <button
          onClick={onNavigateToMySkills}
          className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-md shadow-purple-600/20"
        >
          <GraduationCap className="w-4 h-4" />
          <span>My Farm Skills & Progress</span>
        </button>
      </div>

      {/* ─── Skill Mentors Section (Section 11 & 12) ────────────────── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-white font-black text-base flex items-center gap-2">
            👨‍🌾 Verified Agricultural Mentors in Tumakuru District
          </h3>
          <p className="text-slate-400 text-xs">
            Connect with master growers for 1-on-1 on-farm practical guidance or skill barter.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {FARMER_SKILL_MENTORS.map((mentor) => (
            <div
              key={mentor.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 sm:p-6 flex flex-col justify-between transition group"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-purple-950 border border-purple-800 flex items-center justify-center text-3xl flex-shrink-0">
                      {mentor.avatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-white font-black text-base">{mentor.name}</h4>
                        <ShieldCheck className="w-4 h-4 text-purple-400" title="Cooperative Certified Mentor" />
                      </div>
                      <p className="text-purple-400 text-xs font-semibold">
                        {mentor.primarySkill}
                      </p>
                    </div>
                  </div>

                  <span className="bg-purple-950 text-purple-300 border border-purple-800 text-[10px] font-black px-2.5 py-1 rounded-full whitespace-nowrap">
                    ⭐ {mentor.rating} · {mentor.farmersTrained} Trained
                  </span>
                </div>

                <p className="text-slate-300 text-xs mt-3 leading-relaxed">
                  {mentor.bio}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-400">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-purple-400" /> {mentor.location}
                    </span>
                    <span className="font-semibold text-slate-300">{mentor.experience} yrs farming</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Languages className="w-3.5 h-3.5 text-slate-500" /> Languages:
                    </span>
                    <span className="uppercase text-slate-300 font-bold text-[10px]">
                      {mentor.teachingLanguage?.join(', ')}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mt-3">
                  {mentor.specialties?.map((spec) => (
                    <span
                      key={spec}
                      className="bg-slate-800 text-purple-300 text-[10px] px-2 py-0.5 rounded-md font-medium"
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800">
                <button
                  onClick={() => handleOpenMentorModal(mentor)}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md shadow-purple-600/20"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Request Mentorship / Barter</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Agricultural Skills Catalog (Section 12) ─────────────── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-white font-black text-base flex items-center gap-2">
            📚 CoWork Agri Skill Training Catalog (12 Domains)
          </h3>
          <p className="text-slate-400 text-xs">
            Complete self-study modules and field practice to earn formal Cooperative Certification.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {AGRICULTURAL_SKILLS_CATALOG.map((skill) => (
            <div
              key={skill.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{skill.icon}</span>
                  <div>
                    <h4 className="text-white font-bold text-sm">{skill.name}</h4>
                    <span className="text-[10px] text-purple-400 font-semibold">{skill.category}</span>
                  </div>
                </div>
                <p className="text-slate-400 text-xs mt-2 line-clamp-2 leading-relaxed">
                  {skill.desc}
                </p>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500 text-[11px]">Practical Guild Track</span>
                <span className="text-purple-400 font-bold hover:underline cursor-pointer">
                  Explore Syllabus →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Mentor Request Modal ──────────────────────────────────── */}
      {selectedMentor && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-5 animate-scale-up">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-white font-black text-base">
                  Request Mentorship Session
                </h3>
                <p className="text-purple-400 text-xs font-semibold mt-0.5">
                  Mentor: {selectedMentor.name} ({selectedMentor.primarySkill})
                </p>
              </div>
              <button
                onClick={() => setSelectedMentor(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Select Skill to Learn</label>
                <select
                  value={selectedSkill}
                  onChange={(e) => setSelectedSkill(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  {selectedMentor.specialties?.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                  <option value="Drip Irrigation">Drip Irrigation</option>
                  <option value="Organic Farming">Organic Farming</option>
                  <option value="Composting & Vermiculture">Composting & Vermiculture</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Learning Objective / Farm Need</label>
                <textarea
                  rows="3"
                  value={learningObjective}
                  onChange={(e) => setLearningObjective(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="bg-purple-950/40 border border-purple-800/60 rounded-xl p-3 text-[11px] text-purple-200">
                Cooperative Skill Barter Policy: Mentorship is free for registered cooperative members. You may exchange advice or volunteer 2 hours of field help in return.
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedMentor(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRequest}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs shadow-md shadow-purple-600/20 active:scale-95"
              >
                Send Barter Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
