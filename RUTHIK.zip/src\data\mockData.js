// SevaSetu — Cooperative Gig Services Platform (SIH26089)
// Primary Demo Cooperative: Tumakuru Community Services Cooperative

export const INITIAL_SERVICES = [
  {
    id: 'plumbing',
    name: 'Plumbing',
    icon: 'Wrench',
    description: 'Pipe leaks, taps, sanitary fittings, water tanks & drain hydro-jetting',
    availableWorkers: 18,
    baseRate: 400,
    unit: 'service'
  },
  {
    id: 'electrical',
    name: 'Electrical',
    icon: 'Zap',
    description: 'Wiring, MCB repairs, switchboards, EV chargers & solar inverter setup',
    availableWorkers: 24,
    baseRate: 450,
    unit: 'service'
  },
  {
    id: 'carpentry',
    name: 'Carpentry',
    icon: 'Hammer',
    description: 'Furniture assembly, door hinges, modular kitchen repair & custom woodwork',
    availableWorkers: 14,
    baseRate: 450,
    unit: 'service'
  },
  {
    id: 'painting',
    name: 'Painting',
    icon: 'Paintbrush',
    description: 'Interior wall painting, waterproof primer, touch-ups & exterior coating',
    availableWorkers: 12,
    baseRate: 500,
    unit: 'day'
  },
  {
    id: 'cleaning',
    name: 'Cleaning',
    icon: 'Sparkles',
    description: 'Deep home cleaning, eco-friendly kitchen degreasing & sofa steam wash',
    availableWorkers: 32,
    baseRate: 350,
    unit: 'service'
  },
  {
    id: 'appliance',
    name: 'Appliance Repair',
    icon: 'Cpu',
    description: 'AC gas refill, refrigerator cooling, washing machine & microwave repairs',
    availableWorkers: 16,
    baseRate: 450,
    unit: 'service'
  },
  {
    id: 'vehicle',
    name: 'Vehicle Repair',
    icon: 'Wrench',
    description: 'Two-wheeler puncture, mobile oil service, battery jumpstart & tuning',
    availableWorkers: 15,
    baseRate: 300,
    unit: 'service'
  },
  {
    id: 'gardening',
    name: 'Gardening',
    icon: 'Leaf',
    description: 'Lawn trimming, balcony plants setup, compost soil & organic pest control',
    availableWorkers: 9,
    baseRate: 350,
    unit: 'service'
  },
  {
    id: 'maintenance',
    name: 'Home Maintenance',
    icon: 'Home',
    description: 'Roof waterproofing, tile grouting, ceiling repairs & general handywork',
    availableWorkers: 19,
    baseRate: 500,
    unit: 'day'
  },
  {
    id: 'community',
    name: 'Community Services',
    icon: 'HeartHandshake',
    description: 'Elderly companionship, post-op patient mobility assistance & mutual aid',
    availableWorkers: 11,
    baseRate: 500,
    unit: 'service'
  }
];

export const INITIAL_WORKERS = [
  {
    id: 'w-ravi',
    name: 'Ravi Kumar',
    trade: 'plumbing',
    title: 'Certified Master Plumber',
    experienceYears: 6,
    rating: 4.8,
    reviewCount: 94,
    completedJobs: 247,
    location: 'Tumakuru',
    neighborhood: 'Siddaganga Extension, Tumakuru',
    distanceKm: 1.2,
    hourlyRate: 400,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=150&auto=format&fit=crop&q=80',
    phone: '+91 98451 44820',
    cooperative: 'Tumakuru Community Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2023',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Leak Detection', 'Pipe Relining', 'Water Tank Cleaning', 'Drainage Hydro-Jetting'],
    bio: 'Proud co-owner of Tumakuru Cooperative. 6 years experience solving persistent plumbing and drainage issues with guaranteed fair pricing.'
  },
  {
    id: 'w-priya',
    name: 'Priya Murthy',
    trade: 'electrical',
    title: 'Licensed Electrical & EV Technician',
    experienceYears: 8,
    rating: 4.9,
    reviewCount: 128,
    completedJobs: 310,
    location: 'Bengaluru',
    neighborhood: 'Indiranagar 100ft Road, Bengaluru',
    distanceKm: 2.1,
    hourlyRate: 480,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    phone: '+91 98860 33912',
    cooperative: 'Bengaluru Urban Artisans & Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2022',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['MCB Board Repair', 'EV Home Charger', 'Solar Inverter Sync', 'Concealed Wiring'],
    bio: 'ITI Gold Medalist in Electrical Installations. Committed to high safety standards and zero price-gouging.'
  },
  {
    id: 'w-suresh',
    name: 'Suresh Naik',
    trade: 'carpentry',
    title: 'Precision Woodcrafter & Joiner',
    experienceYears: 10,
    rating: 4.75,
    reviewCount: 82,
    completedJobs: 180,
    location: 'Mysuru',
    neighborhood: 'Kuvempunagar, Mysuru',
    distanceKm: 3.4,
    hourlyRate: 450,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    phone: '+91 97412 88201',
    cooperative: 'Mysuru Heritage District Workers Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2022',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Modular Kitchen Repair', 'Door Planing', 'Teak Wood Restoration', 'Bed Assembly'],
    bio: 'Specialized in modular fittings, wardrobe locks, and custom hardwood restoration.'
  },
  {
    id: 'w-lakshmi',
    name: 'Lakshmi Devi',
    trade: 'cleaning',
    title: 'Eco-Friendly Deep Sanitization Lead',
    experienceYears: 5,
    rating: 4.95,
    reviewCount: 164,
    completedJobs: 420,
    location: 'Tumakuru',
    neighborhood: 'Batawadi, Tumakuru',
    distanceKm: 1.8,
    hourlyRate: 360,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    phone: '+91 99014 55190',
    cooperative: 'Tumakuru Community Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2023',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Non-toxic Kitchen Degreasing', 'Bathroom Descaling', 'Sofa Steam Wash', 'Move-out Clean'],
    bio: 'Elected Lead of Tumakuru Cleaners Guild. We use non-toxic bio-cleaners safe for kids and elderly pets.'
  },
  {
    id: 'w-zameer',
    name: 'Mohammed Zameer',
    trade: 'vehicle',
    title: 'Mobile Two-Wheeler Specialist',
    experienceYears: 7,
    rating: 4.8,
    reviewCount: 79,
    completedJobs: 195,
    location: 'Mangaluru',
    neighborhood: 'Kodialbail, Mangaluru',
    distanceKm: 2.7,
    hourlyRate: 350,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    phone: '+91 98440 11984',
    cooperative: 'Coastal Karnataka Mechanics Collective',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2024',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Doorstep Oil Service', 'Tubeless Puncture', 'Carburetor Tuning', 'Brake Pad Replacement'],
    bio: 'Equipped with mobile toolkit van to repair scooters and motorcycles directly at your home.'
  },
  {
    id: 'w-ramesh',
    name: 'Ramesh Gowda',
    trade: 'appliance',
    title: 'HVAC & Refrigeration Technician',
    experienceYears: 9,
    rating: 4.85,
    reviewCount: 112,
    completedJobs: 260,
    location: 'Bengaluru',
    neighborhood: 'Malleshwaram, Bengaluru',
    distanceKm: 3.1,
    hourlyRate: 450,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    phone: '+91 97410 77332',
    cooperative: 'Bengaluru Urban Artisans & Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2022',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['AC Gas Charging', 'Inverter PCB Repair', 'Washing Machine Drum', 'Microwave Magnetron'],
    bio: 'Factory certified for LG, Samsung, and Daikin. Zero false quotes; genuine replacement parts only.'
  },
  {
    id: 'w-anitha',
    name: 'Sister Anitha Rao',
    trade: 'community',
    title: 'Registered Caregiver & Elder Companion',
    experienceYears: 12,
    rating: 4.98,
    reviewCount: 145,
    completedJobs: 340,
    location: 'Tumakuru',
    neighborhood: 'Ashok Nagar, Tumakuru',
    distanceKm: 1.5,
    hourlyRate: 500,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1594824813580-ff64f9f74a00?w=150&auto=format&fit=crop&q=80',
    phone: '+91 98455 22001',
    cooperative: 'Tumakuru Community Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2021',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Geriatric Bedside Care', 'Post-Op Mobility', 'Vitals & BP Monitoring', 'Dementia Companion'],
    bio: 'Dedicated community health worker providing compassionate home care for bedridden seniors and elders.'
  },
  {
    id: 'w-ganesh',
    name: 'Ganesh Patil',
    trade: 'painting',
    title: 'Waterproof Primer & Wall Finisher',
    experienceYears: 6,
    rating: 4.75,
    reviewCount: 68,
    completedJobs: 140,
    location: 'Mysuru',
    neighborhood: 'Saraswathipuram, Mysuru',
    distanceKm: 4.2,
    hourlyRate: 500,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
    phone: '+91 99002 44109',
    cooperative: 'Mysuru Heritage District Workers Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2023',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Damp Proofing', 'Dr. Fixit Coating', 'Roller Texture Paint', 'Wood Varnish'],
    bio: 'Dust-free sanding and odorless paints. Protects your walls from monsoon dampness.'
  },
  {
    id: 'w-manju',
    name: 'Manjunath K',
    trade: 'gardening',
    title: 'Urban Botanist & Landscape Maintainer',
    experienceYears: 4,
    rating: 4.7,
    reviewCount: 52,
    completedJobs: 115,
    location: 'Tumakuru',
    neighborhood: 'Kyatsandra, Tumakuru',
    distanceKm: 3.8,
    hourlyRate: 350,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    phone: '+91 98864 12390',
    cooperative: 'Tumakuru Community Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2024',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Lawn Mowing', 'Organic Neem Spray', 'Bonsai Pruning', 'Terrace Garden Drip'],
    bio: 'Certified organic gardener. Helping urban homes grow fresh herbs and flowering balconies.'
  },
  {
    id: 'w-deepa',
    name: 'Deepa Hegde',
    trade: 'maintenance',
    title: 'Solar Rooftop & Roof Waterproofer',
    experienceYears: 8,
    rating: 4.9,
    reviewCount: 96,
    completedJobs: 210,
    location: 'Bengaluru',
    neighborhood: 'Rajajinagar, Bengaluru',
    distanceKm: 2.5,
    hourlyRate: 500,
    status: 'Available',
    isAvailable: true,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    phone: '+91 97418 66210',
    cooperative: 'Bengaluru Urban Artisans & Services Cooperative',
    coopShareClass: 'Class A Voting Member',
    coopMemberSince: '2023',
    badges: {
      identityVerified: true,
      skillVerified: true,
      coopMember: true,
      policeCleared: true
    },
    skills: ['Solar Panel Cleaning', 'Terrace Crack Sealing', 'Gutter De-clogging', 'Pressure Wash'],
    bio: 'Certified solar operations technician. Ensuring zero leakage and maximum solar generation.'
  }
];

export const INITIAL_BOOKINGS = [
  {
    id: 'BK-2026-001',
    workerId: 'w-ravi',
    workerName: 'Ravi Kumar',
    workerTrade: 'plumbing',
    workerAvatar: 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=150&auto=format&fit=crop&q=80',
    workerPhone: '+91 98451 44820',
    customerName: 'Ananya Sharma',
    customerPhone: '+91 98860 11928',
    customerAddress: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    serviceTitle: 'Main Overhead Tank Float Valve Replacement & Leak Fix',
    date: 'Today, 2:30 PM',
    timeSlot: '2:30 PM - 3:30 PM',
    durationHours: 1,
    hourlyRate: 400,
    grossTotal: 500, // Includes parts / standard callout
    breakdown: {
      workerPayout: 400, // 80%
      coopFee: 75,       // 15% cooperative welfare & health pool
      platformFee: 25    // 5% platform maintenance
    },
    status: 'ACCEPTED', // PENDING, ACCEPTED, ON_THE_WAY, JOB_STARTED, COMPLETED
    currentStepIndex: 1, // 0: Pending, 1: Accepted, 2: On The Way, 3: Job Started, 4: Completed
    paymentStatus: 'PAID_ESCROW', // PENDING_PAYMENT, PAID_ESCROW, RELEASED_TO_WORKER
    paymentMethod: 'UPI (GPay)',
    etaMinutes: 8,
    distanceKm: 1.2,
    notes: 'Please bring pipe sealant and 1-inch brass nipple fitting. Bell rings twice.',
    createdTimestamp: '15 mins ago',
    driverCoordinates: {
      workerPos: { x: 32, y: 44 },
      destPos: { x: 68, y: 56 }
    }
  },
  {
    id: 'BK-2026-002',
    workerId: 'w-lakshmi',
    workerName: 'Lakshmi Devi',
    workerTrade: 'cleaning',
    workerAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    workerPhone: '+91 99014 55190',
    customerName: 'Ananya Sharma',
    customerPhone: '+91 98860 11928',
    customerAddress: 'Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru',
    serviceTitle: 'Eco Kitchen Deep Degreasing & Disinfection',
    date: 'Yesterday, 10:00 AM',
    timeSlot: '10:00 AM - 1:00 PM',
    durationHours: 3,
    hourlyRate: 360,
    grossTotal: 1080,
    breakdown: {
      workerPayout: 864,
      coopFee: 162,
      platformFee: 54
    },
    status: 'COMPLETED',
    currentStepIndex: 4,
    paymentStatus: 'RELEASED_TO_WORKER',
    paymentMethod: 'Co-op Member Wallet',
    etaMinutes: 0,
    distanceKm: 0,
    notes: 'Non-toxic bio cleaners used. Inspection passed.',
    createdTimestamp: '1 day ago'
  }
];

export const INITIAL_DISPATCH_REQUESTS = [
  {
    id: 'REQ-501',
    customerName: 'Dr. Ramesh Chandra',
    customerAddress: 'House 42, 5th Cross, SS Puram, Tumakuru (1.4 km away)',
    serviceTitle: 'Emergency Kitchen Sink Drain Backflow Remediation',
    trade: 'plumbing',
    durationHours: 1.5,
    estimatedPayment: 500,
    workerPayout: 400,
    coopFundContribution: 75,
    dateTime: 'Today, 4:00 PM',
    distanceKm: 1.4,
    notes: 'Blocked pipe caused overflow in utility balcony. Needs urgent clearing.',
    customerRating: 4.9,
    coopCustomerBadge: 'Verified Household Member'
  },
  {
    id: 'REQ-502',
    customerName: 'Smt. Malini Prasad',
    customerAddress: 'Villa 18, Maralur Ring Road, Tumakuru (2.2 km away)',
    serviceTitle: 'Solar Geyser Hot Water Inlet Pressure Valve Repair',
    trade: 'plumbing',
    durationHours: 2,
    estimatedPayment: 600,
    workerPayout: 480,
    coopFundContribution: 90,
    dateTime: 'Tomorrow, 9:30 AM',
    distanceKm: 2.2,
    notes: 'Hot water line leaking from terrace tank connector.',
    customerRating: 4.85,
    coopCustomerBadge: 'Co-op Patron Member'
  }
];

export const INITIAL_COOPERATIVES = [
  {
    id: 'coop-tumakuru',
    name: 'Tumakuru Community Services Cooperative',
    district: 'Tumakuru',
    state: 'Karnataka',
    regNumber: 'COOP-KA-TMK-2021-042',
    leadDirector: 'S. R. Patil',
    activeWorkers: 124,
    totalHouseholdsServed: 1840,
    welfareFundBalance: 342000,
    coopContributionRate: '15%',
    toolBankUnits: 28,
    isPrimaryDemo: true
  },
  {
    id: 'coop-bengaluru',
    name: 'Bengaluru Urban Artisans & Services Cooperative',
    district: 'Bengaluru Urban',
    state: 'Karnataka',
    regNumber: 'COOP-KA-BLR-2020-098',
    leadDirector: 'Meera Sengupta',
    activeWorkers: 640,
    totalHouseholdsServed: 9800,
    welfareFundBalance: 1480000,
    coopContributionRate: '15%',
    toolBankUnits: 94,
    isPrimaryDemo: false
  },
  {
    id: 'coop-mysuru',
    name: 'Mysuru Heritage District Workers Cooperative',
    district: 'Mysuru',
    state: 'Karnataka',
    regNumber: 'COOP-KA-MYS-2022-019',
    leadDirector: 'K. Venkatesh',
    activeWorkers: 185,
    totalHouseholdsServed: 2450,
    welfareFundBalance: 420000,
    coopContributionRate: '15%',
    toolBankUnits: 36,
    isPrimaryDemo: false
  }
];

export const INITIAL_COMPLAINTS = [
  {
    id: 'CMP-101',
    ticketNo: 'TKT-TMK-892',
    customerName: 'Vinod Hegde',
    customerPhone: '+91 98450 77123',
    workerName: 'Ravi Kumar',
    trade: 'Plumbing',
    category: 'Slight Post-Service Leak',
    severity: 'Medium',
    status: 'Pending', // Pending -> Under Review -> Resolved
    date: 'Sep 11, 2026',
    description: 'A slight drip noticed on the threaded elbow connector after overhead water pump was switched on.',
    assignedAdmin: 'S. R. Patil',
    resolutionNote: ''
  },
  {
    id: 'CMP-102',
    ticketNo: 'TKT-TMK-889',
    customerName: 'Savita Kulkarni',
    customerPhone: '+91 99011 22894',
    workerName: 'Suresh Naik',
    trade: 'Carpentry',
    category: 'Billing Query for Hardware',
    severity: 'Low',
    status: 'Under Review',
    date: 'Sep 10, 2026',
    description: 'Customer requested invoice verification for imported soft-close drawer runners.',
    assignedAdmin: 'S. R. Patil',
    resolutionNote: 'Worker provided retail tax invoice receipt showing exact MRP.'
  },
  {
    id: 'CMP-103',
    ticketNo: 'TKT-BLR-742',
    customerName: 'Deepak Joshi',
    customerPhone: '+91 97410 88912',
    workerName: 'Priya Murthy',
    trade: 'Electrical',
    category: 'Arrival Delay due to Rain',
    severity: 'Low',
    status: 'Resolved',
    date: 'Sep 08, 2026',
    description: 'Technician was delayed by 20 minutes due to waterlogged roads in Indiranagar.',
    assignedAdmin: 'Meera Sengupta',
    resolutionNote: 'Customer acknowledged weather delay; 10% courtesy credit applied.'
  }
];

export const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif-1',
    role: 'customer',
    title: 'Worker Dispatched',
    message: 'Ravi Kumar is 8 minutes away from your location in Tumakuru.',
    time: '5 mins ago',
    read: false,
    type: 'dispatch'
  },
  {
    id: 'notif-2',
    role: 'worker',
    title: 'New Service Request',
    message: 'New plumbing request from Dr. Ramesh Chandra in SS Puram (₹500 estimated).',
    time: '12 mins ago',
    read: false,
    type: 'request'
  },
  {
    id: 'notif-3',
    role: 'admin',
    title: 'Verification Request',
    message: 'Dinesh Manjunath submitted Govt ITI Carpentry certificate for audit.',
    time: '1 hr ago',
    read: false,
    type: 'verification'
  }
];

export const INITIAL_RATINGS = [
  {
    id: 'rat-1',
    workerId: 'w-ravi',
    workerName: 'Ravi Kumar',
    customerName: 'Ananya Sharma',
    serviceTitle: 'Main Overhead Tank Float Valve Replacement & Leak Fix',
    rating: 5,
    date: 'Sep 10, 2026',
    comment: 'Ravi arrived right on time, explained the tank valve problem cleanly, and replaced the broken float. Knowing 80% goes straight to him and 15% to his cooperative welfare makes SevaSetu my go-to app!',
    tags: ['Punctual', 'Honest Pricing', 'Co-op Pride', 'Clean Workmanship']
  },
  {
    id: 'rat-2',
    workerId: 'w-lakshmi',
    workerName: 'Lakshmi Devi',
    customerName: 'Dr. Ramesh Chandra',
    serviceTitle: 'Eco Kitchen Deep Degreasing & Disinfection',
    rating: 5,
    date: 'Sep 08, 2026',
    comment: 'Non-toxic bio-degreaser worked wonders on our chimney. Polite and highly professional team.',
    tags: ['Eco-Friendly', 'Polite', 'Thorough Clean']
  }
];

export const COOP_ANALYTICS = {
  totalMembers: 9540,
  activeWorkers: 948,
  jobsCompleted: 8430,
  totalPlatformVolume: 3250000, // ₹32.5 Lakhs
  workerEarningsGenerated: 2600000, // ₹26 Lakhs (80%)
  welfarePoolAccrued: 487500, // ₹4.87 Lakhs (15%)
  platformOpsGenerated: 162500, // ₹1.62 Lakhs (5%)
  pendingVerificationCount: 3,
  customerSatisfactionPercent: 96.4,
  monthlyData: [
    { month: 'Apr', bookings: 980, volume: 490000, workerShare: 392000, coopFund: 73500 },
    { month: 'May', bookings: 1150, volume: 575000, workerShare: 460000, coopFund: 86250 },
    { month: 'Jun', bookings: 1320, volume: 660000, workerShare: 528000, coopFund: 99000 },
    { month: 'Jul', bookings: 1480, volume: 740000, workerShare: 592000, coopFund: 111000 },
    { month: 'Aug', bookings: 1640, volume: 820000, workerShare: 656000, coopFund: 123000 },
    { month: 'Sep', bookings: 1860, volume: 930000, workerShare: 744000, coopFund: 139500 }
  ],
  serviceDemandBreakdown: [
    { name: 'Plumbing', value: 28, fill: '#059669' },
    { name: 'Electrical', value: 24, fill: '#4f46e5' },
    { name: 'Cleaning', value: 20, fill: '#0d9488' },
    { name: 'Appliance', value: 14, fill: '#d97706' },
    { name: 'Community Care', value: 14, fill: '#e11d48' }
  ],
  regionalHeatmap: [
    { region: 'Tumakuru Central & Siddaganga', demandLevel: 'High', activeGigs: 48, workersOnDuty: 32 },
    { region: 'Bengaluru East (Indiranagar/Whitefield)', demandLevel: 'Very High', activeGigs: 94, workersOnDuty: 58 },
    { region: 'Mysuru Heritage & Kuvempunagar', demandLevel: 'Medium', activeGigs: 36, workersOnDuty: 24 },
    { region: 'Mangaluru Coastal Zone', demandLevel: 'Medium', activeGigs: 28, workersOnDuty: 19 }
  ]
};

export const INDIA_EXPANSION_NODES = [
  { state: 'Karnataka', city: 'Tumakuru & Bengaluru', coops: 8, workers: 948, status: 'Active Operating Hub' },
  { state: 'Maharashtra', city: 'Pune & Nashik', coops: 4, workers: 420, status: 'Pilot Launch' },
  { state: 'Tamil Nadu', city: 'Coimbatore & Madurai', coops: 3, workers: 310, status: 'Registered' },
  { state: 'Telangana', city: 'Hyderabad & Warangal', coops: 3, workers: 280, status: 'Pilot Launch' },
  { state: 'Kerala', city: 'Kochi & Kozhikode', coops: 2, workers: 240, status: 'Registered' },
  { state: 'Andhra Pradesh', city: 'Visakhapatnam', coops: 2, workers: 190, status: 'In Formation' },
  { state: 'Delhi NCR', city: 'New Delhi & Noida', coops: 1, workers: 150, status: 'Incubating' },
  { state: 'Rajasthan', city: 'Jaipur & Jodhpur', coops: 1, workers: 120, status: 'Incubating' }
];

export const LOCALIZATION_TEXT = {
  en: {
    brandName: 'SevaSetu',
    tagline: 'Empowering Local Workers. Connecting Every Community.',
    heroSubtitle: 'A cooperative-powered platform connecting households and communities with trusted local service professionals.',
    findService: 'Find a Service',
    joinWorker: 'Join as a Worker',
    explorePlatform: 'Explore Platform',
    hackathonDemo: '🎯 3-Min Hackathon Demo',
    currencySymbol: '₹'
  },
  kn: {
    brandName: 'ಸೇವಾಸೇತು',
    tagline: 'ಸ್ಥಳೀಯ ಕಾರ್ಮಿಕರ ಸಬಲೀಕರಣ. ಪ್ರತಿಯೊಂದು ಸಮುದಾಯದ ಸಂಪರ್ಕ.',
    heroSubtitle: 'ವಿಶ್ವಾಸಾರ್ಹ ಸ್ಥಳೀಯ ಸೇವಾ ವೃತ್ತಿಪರರೊಂದಿಗೆ ಮನೆಗಳನ್ನು ಸಂಪರ್ಕಿಸುವ ಸಹಕಾರಿ ವೇದಿಕೆ.',
    findService: 'ಸೇವೆ ಹುಡುಕಿ',
    joinWorker: 'ಕಾರ್ಮಿಕರಾಗಿ ಸೇರಿ',
    explorePlatform: 'ವೇದಿಕೆ ಅನ್ವೇಷಿಸಿ',
    hackathonDemo: '🎯 3-ನಿಮಿಷಗಳ ಡೆಮೊ',
    currencySymbol: '₹'
  },
  hi: {
    brandName: 'सेवासेतु',
    tagline: 'स्थानीय श्रमिकों का सशक्तिकरण। हर समुदाय का जुड़ाव।',
    heroSubtitle: 'एक सहकारी संचालित मंच जो घरों को विश्वसनीय स्थानीय सेवा पेशेवरों से जोड़ता है।',
    findService: 'सेवा खोजें',
    joinWorker: 'श्रमिक के रूप में जुड़ें',
    explorePlatform: 'मंच देखें',
    hackathonDemo: '🎯 3-मिनट हैकथॉन डेमो',
    currencySymbol: '₹'
  }
};
