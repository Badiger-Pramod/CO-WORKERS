import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Sparkles,
  CheckCircle2,
  Tractor,
  CreditCard,
  Star,
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  Play,
  RotateCcw,
  X
} from 'lucide-react';

export const FarmerDemoWalkthrough = ({ isOpen, onClose, onNavigateTab }) => {
  const {
    currentFarmer,
    bookFarmEquipment,
    payFarmerBooking,
    rateFarmerBooking,
    verifyFarmerSkill,
    completeSkillPractice,
    farmerBookings = [],
    farmerSkills = [],
    showToast
  } = useCoop();

  const [currentStep, setCurrentStep] = useState(1);
  const [isAutoRunning, setIsAutoRunning] = useState(false);
  const [createdBookingId, setCreatedBookingId] = useState(null);

  if (!isOpen) return null;

  const handleStep1 = () => {
    // Step 1: Logged in as Ravi Gowda
    onNavigateTab?.('overview');
    showToast('Step 1 Complete: Farmer Ravi Gowda active session verified!', 'success');
    setCurrentStep(2);
  };

  const handleStep2 = () => {
    // Step 2: Browse equipment & find Mahindra 575 DI
    onNavigateTab?.('equipment');
    showToast('Step 2 Complete: Found Mahindra 575 DI Tractor (₹1,200/day, 2.5 km away)!', 'info');
    setCurrentStep(3);
  };

  const handleStep3 = () => {
    // Step 3: Book Mahindra tractor for 2 days (₹2,400)
    const newBooking = bookFarmEquipment('eq01', {
      date: '06 - 07 October 2026',
      duration: '2 Days',
      operatorIncluded: false,
      finalCost: 2400,
      estimatedCost: 2400,
      budget: 2400,
      workType: 'Field Ploughing & Sowing Prep',
      crop: 'Ragi'
    });

    setCreatedBookingId(newBooking.id);
    onNavigateTab?.('bookings');
    showToast(`Step 3 Complete: Booked Mahindra Tractor for 2 days (₹2,400)! Booking #${newBooking.id}`, 'success');
    setCurrentStep(4);
  };

  const handleStep4 = () => {
    // Step 4: Pay ₹2,400 via UPI and rate 5 stars
    const targetBooking = createdBookingId
      ? farmerBookings.find((b) => b.id === createdBookingId)
      : farmerBookings.find((b) => b.equipmentId === 'eq01') || farmerBookings[0];

    if (targetBooking) {
      payFarmerBooking(targetBooking.id, 'UPI (BHIM / PhonePe)');
      rateFarmerBooking(targetBooking.id, {
        rating: 5,
        notes: 'Excellent tractor, very well maintained! Punctual delivery and powerful engine for Ragi field ploughing.'
      });
      showToast('Step 4 Complete: Settled ₹2,400 via UPI & submitted 5-Star review!', 'success');
    }

    onNavigateTab?.('bookings');
    setCurrentStep(5);
  };

  const handleStep5 = () => {
    // Step 5: Check Drip Irrigation (80%), practice or verify
    completeSkillPractice('Drip Irrigation');
    verifyFarmerSkill('farmer01', 'Drip Irrigation');
    onNavigateTab?.('my-skills');
    showToast('Step 5 Complete: Drip Irrigation certified with Cooperative Verification Badge ✓!', 'success');
    setCurrentStep(6);
  };

  const handleAutoRun = async () => {
    setIsAutoRunning(true);
    setCurrentStep(1);

    // Step 1
    handleStep1();
    await new Promise((r) => setTimeout(r, 1200));

    // Step 2
    handleStep2();
    await new Promise((r) => setTimeout(r, 1200));

    // Step 3
    const newBooking = bookFarmEquipment('eq01', {
      date: '06 - 07 October 2026',
      duration: '2 Days',
      operatorIncluded: false,
      finalCost: 2400,
      estimatedCost: 2400,
      budget: 2400,
      workType: 'Field Ploughing & Sowing Prep',
      crop: 'Ragi'
    });
    setCreatedBookingId(newBooking.id);
    onNavigateTab?.('bookings');
    showToast(`Booked Mahindra Tractor (₹2,400)! Booking #${newBooking.id}`, 'success');
    setCurrentStep(4);
    await new Promise((r) => setTimeout(r, 1400));

    // Step 4
    payFarmerBooking(newBooking.id, 'UPI (BHIM / PhonePe)');
    rateFarmerBooking(newBooking.id, {
      rating: 5,
      notes: 'Excellent tractor, very well maintained! Punctual delivery and powerful engine for Ragi field ploughing.'
    });
    showToast('Settled ₹2,400 via UPI & submitted 5-Star review!', 'success');
    setCurrentStep(5);
    await new Promise((r) => setTimeout(r, 1400));

    // Step 5
    completeSkillPractice('Drip Irrigation');
    verifyFarmerSkill('farmer01', 'Drip Irrigation');
    onNavigateTab?.('my-skills');
    showToast('Drip Irrigation certified with Cooperative Verification Badge ✓!', 'success');
    setCurrentStep(6);

    setIsAutoRunning(false);
  };

  const STEPS = [
    {
      num: 1,
      title: 'Farmer Ravi Login',
      desc: 'Active as Ravi Gowda (Green Valley Farm, 5 Acres, Tumakuru)',
      action: handleStep1,
      btnLabel: 'Verify Login'
    },
    {
      num: 2,
      title: 'Browse Equipment Sharing',
      desc: 'Locate Mahindra 575 DI Tractor (₹1,200/day, 2.5 km away, operator option)',
      action: handleStep2,
      btnLabel: 'Browse Equipment'
    },
    {
      num: 3,
      title: 'Book Tractor for 2 Days',
      desc: 'Create booking for ₹2,400 with escrow guarantee',
      action: handleStep3,
      btnLabel: 'Book Tractor'
    },
    {
      num: 4,
      title: 'Pay UPI & Rate 5-Stars',
      desc: 'Simulate instant UPI settlement and submit glowing feedback',
      action: handleStep4,
      btnLabel: 'Pay & Rate'
    },
    {
      num: 5,
      title: 'Verify Drip Irrigation Skill',
      desc: 'Inspect 80% Advanced skill and trigger official Cooperative Guild Certification badge',
      action: handleStep5,
      btnLabel: 'Verify Skill'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-emerald-500/80 rounded-3xl max-w-xl w-full p-6 sm:p-7 space-y-5 animate-scale-up shadow-2xl shadow-emerald-500/10">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl">
              🌾
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full">
                  Hackathon Evaluation Script
                </span>
                <span className="text-xs text-slate-400 font-bold">Section 26</span>
              </div>
              <h3 className="text-lg font-black text-white mt-0.5">
                CoWork Agri Demo Walkthrough
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-slate-300 text-xs leading-relaxed">
          This wizard executes the complete end-to-end journey specified in the problem statement: Farmer Ravi browses machinery, books a tractor, completes UPI payment & rating, and validates his Drip Irrigation skill with the cooperative.
        </p>

        {/* 1-Click Auto Run Banner */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-800 to-teal-950 border border-emerald-700/60 rounded-2xl p-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-white font-black text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              1-Click Presentation Auto-Run
            </p>
            <p className="text-emerald-300 text-[11px] mt-0.5">
              Automatically navigates and updates live state across all 5 steps.
            </p>
          </div>

          <button
            disabled={isAutoRunning}
            onClick={handleAutoRun}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 active:scale-95 disabled:opacity-50 whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>{isAutoRunning ? 'Running Demo...' : 'Auto-Run All'}</span>
          </button>
        </div>

        {/* Steps List */}
        <div className="space-y-2.5 text-xs">
          {STEPS.map((s) => {
            const isCompleted = currentStep > s.num;
            const isCurrent = currentStep === s.num;

            return (
              <div
                key={s.num}
                className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                  isCompleted
                    ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
                    : isCurrent
                    ? 'bg-slate-800 border-amber-500/80 text-white'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                      isCompleted
                        ? 'bg-emerald-500 text-slate-950'
                        : isCurrent
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {isCompleted ? '✓' : s.num}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-xs">{s.title}</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">{s.desc}</p>
                  </div>
                </div>

                <button
                  onClick={s.action}
                  disabled={isAutoRunning}
                  className={`px-3 py-1.5 rounded-xl font-black text-[11px] transition active:scale-95 whitespace-nowrap ${
                    isCompleted
                      ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                      : isCurrent
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
                  }`}
                >
                  {isCompleted ? 'Done ✓' : s.btnLabel}
                </button>
              </div>
            );
          })}
        </div>

        {/* Completion Celebration Message */}
        {currentStep === 6 && (
          <div className="bg-emerald-950/80 border border-emerald-600 rounded-2xl p-4 text-center space-y-2">
            <span className="text-3xl">🎉</span>
            <p className="text-white font-black text-sm">Demo Scenario Successfully Completed!</p>
            <p className="text-emerald-300 text-xs">
              Farmer Ravi has booked equipment, paid via UPI, submitted review, and certified his Drip Irrigation skill. Switch to the Admin Portal to view the cooperative audit logs!
            </p>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
          >
            Close Walkthrough
          </button>
        </div>
      </div>
    </div>
  );
};
