import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';

// GET /api/workers
export const getWorkers = async (req: Request, res: Response): Promise<void> => {
  try {
    const { skill, availability, minRating } = req.query;

    const workers = localStore.worker_profiles.map(wp => {
      const u = localStore.users.find(user => user.id === wp.user_id);
      return {
        id: wp.user_id,
        profile_id: wp.id,
        name: u?.full_name || 'Worker',
        email: u?.email || '',
        phone: u?.mobile || '',
        mobile: u?.mobile || '',
        city: u?.city || 'Tumakuru',
        address: u?.address || '',
        primary_skill: wp.primary_skill,
        skills: wp.skills || [wp.primary_skill],
        experience_years: wp.experience_years,
        availability: wp.availability,
        verification_status: wp.verification_status,
        rating: wp.rating,
        completed_jobs: wp.completed_jobs,
        hourly_rate: wp.hourly_rate || 400,
        bio: wp.bio,
        cooperative: 'Tumakuru Community Services Cooperative'
      };
    });

    let filtered = workers;
    if (skill) {
      const s = String(skill).toLowerCase();
      filtered = filtered.filter(w =>
        w.primary_skill.toLowerCase().includes(s) ||
        w.skills.some(sk => sk.toLowerCase().includes(s))
      );
    }

    if (availability) {
      filtered = filtered.filter(w => w.availability.toLowerCase() === String(availability).toLowerCase());
    }

    if (minRating) {
      filtered = filtered.filter(w => w.rating >= Number(minRating));
    }

    res.json({ success: true, count: filtered.length, workers: filtered });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch workers.' });
  }
};

// GET /api/workers/:id
export const getWorkerById = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const wp = localStore.worker_profiles.find(w => w.user_id === userId);
    const u = localStore.users.find(user => user.id === userId);

    if (!wp || !u) {
      res.status(404).json({ success: false, message: 'Worker profile not found.' });
      return;
    }

    res.json({
      success: true,
      worker: {
        id: wp.user_id,
        profile_id: wp.id,
        name: u.full_name,
        email: u.email,
        mobile: u.mobile,
        city: u.city,
        address: u.address,
        primary_skill: wp.primary_skill,
        skills: wp.skills || [wp.primary_skill],
        experience_years: wp.experience_years,
        availability: wp.availability,
        verification_status: wp.verification_status,
        rating: wp.rating,
        completed_jobs: wp.completed_jobs,
        hourly_rate: wp.hourly_rate || 400,
        bio: wp.bio
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Error retrieving worker profile.' });
  }
};

// PUT /api/workers/:id/availability
export const updateAvailability = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { availability } = req.body;

    const wp = localStore.worker_profiles.find(w => w.user_id === userId);
    if (!wp) {
      res.status(404).json({ success: false, message: 'Worker profile not found.' });
      return;
    }

    wp.availability = availability === 'Available' ? 'Available' : 'Not Available';
    wp.updated_at = new Date().toISOString();
    persistLocalStore();

    res.json({
      success: true,
      message: `Availability updated to: ${wp.availability}`,
      availability: wp.availability
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update availability.' });
  }
};

// PUT /api/workers/:id/skills
export const updateWorkerSkills = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { primary_skill, skills, bio } = req.body;

    const wp = localStore.worker_profiles.find(w => w.user_id === userId);
    if (!wp) {
      res.status(404).json({ success: false, message: 'Worker profile not found.' });
      return;
    }

    if (primary_skill) wp.primary_skill = primary_skill;
    if (Array.isArray(skills)) wp.skills = skills;
    if (bio !== undefined) wp.bio = bio;
    wp.updated_at = new Date().toISOString();

    persistLocalStore();

    res.json({
      success: true,
      message: 'Worker skills updated successfully!',
      workerProfile: wp
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update skills.' });
  }
};

// GET /api/workers/:id/earnings
export const getWorkerEarnings = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const completedJobs = localStore.job_requests.filter(
      j => j.worker_id === userId && (j.status === 'COMPLETED' || j.status === 'PAID' || j.status === 'RATED')
    );

    const grossEarnings = completedJobs.reduce((sum, j) => sum + (j.estimated_price || 0), 0);
    const netEarnings = completedJobs.reduce((sum, j) => sum + (j.worker_payout || 0), 0);
    const coopContribution = completedJobs.reduce((sum, j) => sum + (j.coop_fund || 0), 0);
    const platformFee = completedJobs.reduce((sum, j) => sum + (j.platform_fee || 0), 0);

    const paidJobs = completedJobs.filter(j => j.payment_status === 'SUCCESS' || j.status === 'PAID' || j.status === 'RATED');
    const paidAmount = paidJobs.reduce((sum, j) => sum + (j.worker_payout || 0), 0);
    const pendingAmount = netEarnings - paidAmount;

    res.json({
      success: true,
      earnings: {
        completed_jobs_count: completedJobs.length,
        gross_earnings: grossEarnings,
        net_worker_earnings: netEarnings,
        cooperative_welfare_share: coopContribution,
        platform_maintenance_share: platformFee,
        paid_amount: paidAmount,
        pending_payout: pendingAmount
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to calculate earnings.' });
  }
};
