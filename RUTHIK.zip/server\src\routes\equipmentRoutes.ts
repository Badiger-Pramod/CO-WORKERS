import { Router } from 'express';
import {
  getEquipmentList,
  createEquipmentListing,
  bookEquipment
} from '../controllers/equipmentController';

const router = Router();

router.get('/', getEquipmentList);
router.post('/', createEquipmentListing);
router.post('/:id/book', bookEquipment);

export default router;
