import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import { BookingModal } from './BookingModal';
import { PaymentModal } from './PaymentModal';
import { RatingModal } from './RatingModal';
import { ComplaintModal } from './ComplaintModal';
import { InvoiceModal } from './InvoiceModal';
import { LiveTracking } from './LiveTracking';
import {
  Search,
  MapPin,
  ShieldCheck,
  Star,
  Clock,
  Sparkles,
  Zap,
  Wrench,
  Hammer,
  Paintbrush,
  HeartHandshake,
  CheckCircle2,
  CalendarCheck,
  CreditCard,
  AlertTriangle,
  Award,
  ArrowRight,
  TrendingUp,
  FileText,
  Sliders,
  Flame,
  ChevronRight,
  Home,
  Percent,
  Layers,
  Mic,
  Printer
} from 'lucide-react';

export const CustomerPortal = () => {
  const {
    services,
    workers,
    bookings,
    activeBookingId,
    setActiveBookingId,
    customerLocation,
    setCustomerLocation,
    selectedService,
    setSelectedService,
    searchQuery,
    setSearchQuery,
    activeCustomerTab,
    setActiveCustomerTab,
    setIsBookingModalOpen,
    setBookingWorker,
    setIsPaymentModalOpen,
    setIsRatingModalOpen,
    setIsComplaintModalOpen,
    calculateSmartMatch,
    lang,
    showToast
  } = useCoop();

  const [filterTrade, setFilterTrade] = useState('all');
  const [selectedInvoiceBooking, setSelectedInvoiceBooking] = useState(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const [voiceSimModal, setVoiceSimModal] = useState(false);

  // Multilingual greeting strings
  const greetings = {
    en: {
      title: 'Good morning, Ananya 👋',
      subtitle: 'Book verified local service workers with transparent 80% fair pay, zero corporate surge markups, and mutual cooperative backing.',
      locationLabel: 'Your Service Location:'
    },
    kn: {
      title: 'ಶುಭೋದಯ, ಅನನ್ಯಾ 👋',
      subtitle: 'ಪಾರದರ್ಶಕ 80% ನ್ಯಾಯಯುತ ವೇತನ, ಶೂನ್ಯ ಕಾರ್ಪೊರೇಟ್ ಕಮಿಷನ್ ಮತ್ತು ತುಮಕೂರು ಸಹಕಾರಿ ಬೆಂಬಲದೊಂದಿಗೆ ಪರಿಶೀಲಿಸಿದ ಸ್ಥಳೀಯ ಕಾರ್ಮಿಕರನ್ನು ಬುಕ್ ಮಾಡಿ.',
      locationLabel: 'ನಿಮ್ಮ ಸೇವಾ ಸ್ಥಳ:'
    },
    hi: {
      title: 'सुप्रभात, अनन्य 👋',
      subtitle: 'पारदर्शी 80% उचित भुगतान, शून्य बिचौलिया कमीशन और स्थानीय सहकारी समर्थन के साथ सत्यापित सेवा श्रमिकों को बुक करें।',
      locationLabel: 'आपका सेवा स्थान:'
    }
  };

  const currentGreeting = greetings[lang] || greetings['en'];

  // Icon mapping for 10 service categories
  const serviceIconMap = {
    'Wrench': Wrench,
    'Zap': Zap,
    'Hammer': Hammer,
    'Paintbrush': Paintbrush,
    'Sparkles': Sparkles,
    'Cpu': Zap,
    'Car': Wrench,
    'Leaf': HeartHandshake,
    'Home': Home,
    'HeartHandshake': HeartHandshake
  };

  // Find active booking
  const activeBooking = bookings.find(b => b.status !== 'COMPLETED') || bookings[0];
  const hasActiveBooking = !!activeBooking;

  // Run SmartMatch AI
  const smartMatchResults = calculateSmartMatch(selectedService || 'plumbing', customerLocation);
  const topMatchedWorker = smartMatchResults[0] || workers[0];

  // Filtered workers list
  const filteredWorkers = workers.filter(w => {
    if (filterTrade !== 'all' && w.trade !== filterTrade) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = w.name.toLowerCase().includes(q);
      const matchTitle = w.title.toLowerCase().includes(q);
      const matchTrade = w.trade.toLowerCase().includes(q);
      const matchLoc = w.location.toLowerCase().includes(q);
      const matchSkill = w.skills.some(s => s.toLowerCase().includes(q));
      return matchName || matchTitle || matchTrade || matchLoc || matchSkill;
    }
    return true;
  });

  const handleBookWorker = (worker) => {
    setBookingWorker(worker);
    setIsBookingModalOpen(true);
  };

  const handleOpenInvoice = (b) => {
    setSelectedInvoiceBooking(b);
    setIsInvoiceOpen(true);
  };

  const handleVoiceCommand = (cmdText, targetService) => {
    setVoiceSimModal(false);
    setSelectedService(targetService);
    setActiveCustomerTab('smartmatch');
    showToast(`🎙️ Voice Command Detected: "${cmdText}" ➔ Running SmartMatch AI!`, 'info');
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Header Greeting & Location Strip */}
      <section className="bg-gradient-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
              <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
                Household Customer Dashboard • SevaSetu
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white">
              {currentGreeting.title}
            </h1>
            <p className="text-emerald-100/90 text-xs sm:text-sm max-w-xl leading-relaxed">
              {currentGreeting.subtitle}
            </p>
          </div>

          {/* Location Selector Pill */}
          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/20 w-full sm:w-auto">
            <label className="block text-[10px] font-bold text-emerald-200 uppercase tracking-wider mb-1">
              {currentGreeting.locationLabel}
            </label>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-300 shrink-0" />
              <select
                value={customerLocation}
                onChange={(e) => {
                  setCustomerLocation(e.target.value);
                  showToast(`Location set to ${e.target.value}`, 'info');
                }}
                className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
              >
                <option value="Tumakuru, Karnataka" className="text-slate-900">Tumakuru, Karnataka (Primary Co-op Hub)</option>
                <option value="Bengaluru, Karnataka" className="text-slate-900">Bengaluru, Karnataka</option>
                <option value="Mysuru, Karnataka" className="text-slate-900">Mysuru, Karnataka</option>
                <option value="Mangaluru, Karnataka" className="text-slate-900">Mangaluru, Karnataka</option>
              </select>
            </div>
          </div>

        </div>
      </section>

      {/* 2. Top 4 Dashboard Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Active Booking */}
        <div
          onClick={() => setActiveCustomerTab('tracking')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Active Booking</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
          </div>
          <p className="text-lg font-black text-slate-900 mt-2">
            {activeBooking?.workerTrade || 'Plumbing'}
          </p>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-xs">
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
              {activeBooking?.status || 'ON_THE_WAY'}
            </span>
            <span className="text-slate-500 group-hover:text-emerald-700 font-semibold flex items-center gap-0.5">
              Track Live ➔
            </span>
          </div>
        </div>

        {/* Card 2: Upcoming Service */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Upcoming Slot</span>
            <CalendarCheck className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-lg font-black text-slate-900 mt-2">Today, 2:30 PM</p>
          <p className="text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100">
            Assigned: <strong className="text-slate-800">Ravi Kumar</strong> (Tumakuru)
          </p>
        </div>

        {/* Card 3: Completed Services */}
        <div
          onClick={() => setActiveCustomerTab('bookings')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-400 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-center text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Completed Services</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-lg font-black text-slate-900 mt-2">14 Gigs</p>
          <p className="text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
            <span>₹5,600 Total Paid</span>
            <span className="text-emerald-700 font-semibold group-hover:underline">View Invoices ➔</span>
          </p>
        </div>

        {/* Card 4: Saved Co-op Workers */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider">Saved Co-owners</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
          </div>
          <p className="text-lg font-black text-slate-900 mt-2">3 Workers</p>
          <p className="text-xs text-slate-500 mt-2 pt-2 border-t border-slate-100 truncate">
            Ravi Kumar (4.8 ★), Priya M. (4.9 ★)
          </p>
        </div>

      </div>

      {/* 3. Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'dashboard', label: '10 Nearby Services', icon: Sparkles },
          { id: 'smartmatch', label: '⚡ SmartMatch AI Engine', icon: Zap, badge: '6-Factor Algorithm' },
          { id: 'tracking', label: 'Live Order Tracker', icon: Clock, pulse: hasActiveBooking },
          { id: 'bookings', label: 'Past Bookings & Receipts', icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeCustomerTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveCustomerTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 transition-all whitespace-nowrap ${
                isActive
                  ? 'border-emerald-600 text-emerald-800 bg-emerald-50/60 rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="text-[10px] font-extrabold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full border border-amber-300">
                  {tab.badge}
                </span>
              )}
              {tab.pulse && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              )}
            </button>
          );
        })}
      </div>

      {/* =========================================================================
          TAB 1: 10 Nearby Service Categories
      ========================================================================= */}
      {activeCustomerTab === 'dashboard' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Search & Voice Strip */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:w-96 flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search electrician, plumber, cleaner in Tumakuru..."
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Multilingual Voice Query Simulator Button */}
              <button
                onClick={() => setVoiceSimModal(true)}
                className="p-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 transition-colors shrink-0 flex items-center gap-1 text-xs font-bold"
                title="Voice Assistant (Kannada / Hindi / English)"
              >
                <Mic className="w-4 h-4 text-amber-800 animate-pulse" />
                <span className="hidden sm:inline">Voice Search</span>
              </button>
            </div>

            {/* Filter by Category */}
            <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <span className="text-xs font-bold text-slate-600 whitespace-nowrap">Filter:</span>
              <button
                onClick={() => setFilterTrade('all')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  filterTrade === 'all' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All (10)
              </button>
              <button
                onClick={() => setFilterTrade('plumbing')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  filterTrade === 'plumbing' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Plumbing
              </button>
              <button
                onClick={() => setFilterTrade('electrical')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  filterTrade === 'electrical' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Electrical
              </button>
              <button
                onClick={() => setFilterTrade('cleaning')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  filterTrade === 'cleaning' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Cleaning
              </button>
            </div>
          </div>

          {/* 10 Service Categories Grid */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Cooperative Service Categories</h3>
                <p className="text-xs text-slate-500">
                  Fixed transparent base rates • Verified background checks • 100% mutual guarantee
                </p>
              </div>
              <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-3 py-1 rounded-lg border border-emerald-200">
                10 Verified Categories
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {services.map((srv) => {
                const Icon = serviceIconMap[srv.icon] || Sparkles;
                const isSelected = selectedService === srv.id;
                return (
                  <div
                    key={srv.id}
                    onClick={() => {
                      setSelectedService(srv.id);
                      setActiveCustomerTab('smartmatch');
                    }}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between group ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-md ring-2 ring-emerald-500/20'
                        : 'border-slate-200 bg-white hover:border-emerald-300 hover:shadow-md'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Icon className="w-6 h-6 text-emerald-700" />
                      </div>

                      <div>
                        <h4 className="font-bold text-slate-900 text-sm group-hover:text-emerald-700 transition-colors">
                          {srv.name}
                        </h4>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                          {srv.description}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">Base Rate</span>
                        <span className="font-black text-slate-800">₹{srv.baseRate}/hr</span>
                      </div>
                      <span className="text-emerald-700 font-bold flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                        Match ➔
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Service Providers Grid (Filtered) */}
          <div className="space-y-4 pt-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Verified Service Co-owners Nearby</h3>
                <p className="text-xs text-slate-500">
                  Showing {filteredWorkers.length} co-owners in {customerLocation}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredWorkers.map((w) => (
                <div
                  key={w.id}
                  className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4 hover:border-emerald-300 group"
                >
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="relative">
                        <img
                          src={w.avatar}
                          alt={w.name}
                          className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
                        />
                        <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white p-0.5 rounded-full ring-2 ring-white">
                          <ShieldCheck className="w-3.5 h-3.5" />
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-slate-900 text-base group-hover:text-emerald-700 transition-colors truncate">
                            {w.name}
                          </h4>
                          <span className="flex items-center gap-1 text-xs font-bold text-amber-600">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                            {w.rating}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 font-medium">{w.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          📍 {w.location} • {w.distanceKm} km away
                        </p>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl text-center text-xs border border-slate-100">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Experience</span>
                        <span className="font-bold text-slate-800">{w.experienceYears} Years</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Gigs Done</span>
                        <span className="font-bold text-slate-800">{w.completedJobs}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Hourly Rate</span>
                        <span className="font-bold text-emerald-700">₹{w.hourlyRate}</span>
                      </div>
                    </div>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-1">
                      {w.skills.slice(0, 3).map((s, i) => (
                        <span key={i} className="text-[10px] font-medium bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                          {s}
                        </span>
                      ))}
                      {w.skills.length > 3 && (
                        <span className="text-[10px] text-slate-500 self-center">
                          +{w.skills.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold">Fair Rate</span>
                      <p className="text-base font-black text-slate-900">₹500 <span className="text-xs text-slate-400 font-normal">/ gig</span></p>
                    </div>

                    <button
                      onClick={() => handleBookWorker(w)}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all transform active:scale-95"
                    >
                      <CalendarCheck className="w-3.5 h-3.5" />
                      <span>Book Service</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 2: ⚡ SmartMatch AI Engine Showcase
      ========================================================================= */}
      {activeCustomerTab === 'smartmatch' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* SmartMatch AI Banner with 6-Factor Weights */}
          <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-emerald-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-indigo-900/60 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-amber-400 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-500/40 inline-flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  SIH26089 Algorithmic Engine
                </span>
                <h2 className="text-2xl sm:text-3xl font-black mt-2">
                  ⚡ SmartMatch AI Dispatch Engine
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
                  Unlike opaque corporate algorithms that penalize gig workers, SevaSetu uses an open, transparent 6-factor matching formula for optimal community pairing.
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center shrink-0">
                <span className="text-xs text-emerald-300 font-bold block">Selected Service</span>
                <span className="text-lg font-black text-white capitalize">{selectedService}</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Hub: Tumakuru, Karnataka</span>
              </div>
            </div>

            {/* 6-Factor Weight Breakdown Strip */}
            <div className="pt-4 border-t border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-3">
                Algorithmic Weight Configuration:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">30%</span>
                  <span className="font-bold text-slate-200">Skill Match</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Trade competency</span>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">20%</span>
                  <span className="font-bold text-slate-200">Distance</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Under 5 km radius</span>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">20%</span>
                  <span className="font-bold text-slate-200">Availability</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">🟢 Online status</span>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">15%</span>
                  <span className="font-bold text-slate-200">Rating</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Customer feedback</span>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">10%</span>
                  <span className="font-bold text-slate-200">Experience</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Years in trade</span>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <span className="text-emerald-400 font-black text-base block">5%</span>
                  <span className="font-bold text-slate-200">Performance</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Completion rate</span>
                </div>
              </div>
            </div>
          </div>

          {/* Top Recommendation Highlight Card */}
          <div className="bg-gradient-to-br from-emerald-50 via-teal-50 to-white p-6 sm:p-8 rounded-3xl border-2 border-emerald-500 shadow-lg space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img
                    src={topMatchedWorker.avatar}
                    alt={topMatchedWorker.name}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-emerald-600 shadow-md"
                  />
                  <span className="absolute -bottom-1 -right-1 bg-amber-400 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-white">
                    #1 Top Match
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl sm:text-2xl font-black text-slate-900">{topMatchedWorker.name}</h3>
                    <span className="bg-emerald-200 text-emerald-900 text-xs font-bold px-2.5 py-0.5 rounded-full">
                      {topMatchedWorker.trade}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">{topMatchedWorker.title} • Tumakuru Community Cooperative</p>
                  <p className="text-xs text-emerald-800 font-bold mt-1">
                    {topMatchedWorker.experienceYears} Years Exp • {topMatchedWorker.rating} ⭐ ({topMatchedWorker.reviewCount} reviews) • {topMatchedWorker.completedJobs} Jobs
                  </p>
                </div>
              </div>

              {/* Match Score Badge */}
              <div className="bg-slate-900 text-white p-4 rounded-2xl text-center shrink-0 border border-emerald-400/40 shadow-md">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 block">AI Match Score</span>
                <span className="text-3xl font-black text-emerald-400">{topMatchedWorker.matchScore || 94}%</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Top Compatibility</span>
              </div>
            </div>

            {/* AI Recommendation Reason */}
            <div className="bg-white p-4 rounded-2xl border border-emerald-200 text-xs text-slate-700 leading-relaxed space-y-1">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                Why AI Recommends {topMatchedWorker.name.split(' ')[0]}:
              </span>
              <p>{topMatchedWorker.reasonText}</p>
            </div>

            {/* One-Click Action */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-emerald-200">
              <div className="text-xs text-slate-600">
                <span>Transparent standard booking: </span>
                <strong className="text-slate-900 font-bold">₹500 Total</strong>
                <span className="text-emerald-700 font-semibold"> (₹400 Worker • ₹75 Co-op • ₹25 Platform)</span>
              </div>

              <button
                onClick={() => handleBookWorker(topMatchedWorker)}
                className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all transform active:scale-95"
              >
                <Zap className="w-4 h-4" />
                <span>Instant Book {topMatchedWorker.name.split(' ')[0]} Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Secondary Matched Candidates */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              Alternative High-Scoring Matches:
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {smartMatchResults.slice(1, 5).map((worker) => (
                <div
                  key={worker.id}
                  className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={worker.avatar}
                      alt={worker.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-300"
                    />
                    <div>
                      <h5 className="font-bold text-slate-900 text-sm">{worker.name}</h5>
                      <p className="text-xs text-slate-500">{worker.title} • {worker.distanceKm} km</p>
                      <p className="text-[11px] text-amber-600 font-bold">{worker.rating} ⭐ ({worker.reviewCount})</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-black text-emerald-700 block">{worker.matchScore}% Match</span>
                    <button
                      onClick={() => handleBookWorker(worker)}
                      className="mt-1 px-3 py-1 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-lg text-xs font-bold"
                    >
                      Book
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 3: Live Order Tracking
      ========================================================================= */}
      {activeCustomerTab === 'tracking' && (
        <div className="space-y-6 animate-fade-in">
          <LiveTracking />
        </div>
      )}

      {/* =========================================================================
          TAB 4: Past Bookings & Receipts
      ========================================================================= */}
      {activeCustomerTab === 'bookings' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Your Booking History & Transparent Invoices</h3>
              <p className="text-xs text-slate-500">
                All receipts detail the 80/15/5 cooperative economic split under Karnataka Sahakara Act.
              </p>
            </div>
            <button
              onClick={() => showToast('Exporting all cooperative tax invoices for FY 2026...', 'info')}
              className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-700" />
              <span>Export All Statements (PDF)</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider font-bold border-b border-slate-200 text-[11px]">
                  <tr>
                    <th className="p-4">Booking ID</th>
                    <th className="p-4">Service & Co-owner</th>
                    <th className="p-4">Scheduled Date</th>
                    <th className="p-4">Transparent Amount</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Tax Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {bookings.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="p-4 font-mono font-bold text-slate-900">{b.id}</td>
                      <td className="p-4">
                        <div className="font-bold text-slate-900">{b.serviceTitle}</div>
                        <div className="text-[11px] text-slate-500">{b.workerName} ({b.workerPhone})</div>
                      </td>
                      <td className="p-4">
                        <div>{b.date}</div>
                        <div className="text-[10px] text-slate-400">{b.timeSlot}</div>
                      </td>
                      <td className="p-4">
                        <div className="font-bold text-slate-900">₹{b.grossTotal}</div>
                        <div className="text-[10px] text-emerald-700">
                          ₹{b.breakdown.workerPayout} Worker • ₹{b.breakdown.coopFee} Co-op
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          b.status === 'COMPLETED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : b.status === 'ON_THE_WAY'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => handleOpenInvoice(b)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs inline-flex items-center gap-1 shadow-2xs"
                        >
                          <Printer className="w-3 h-3" />
                          <span>View Invoice</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveBookingId(b.id);
                            setActiveCustomerTab('tracking');
                          }}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 font-semibold text-xs text-slate-700"
                        >
                          Track
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* Multilingual Voice Query Simulation Modal */}
      {voiceSimModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Mic className="w-5 h-5 text-amber-600 animate-pulse" />
                <h3 className="font-bold text-base text-slate-900">SevaSetu Multilingual Voice AI</h3>
              </div>
              <button onClick={() => setVoiceSimModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Designed for voice-first accessibility across India. Click any spoken query below to simulate voice processing:
            </p>

            <div className="space-y-2">
              <button
                onClick={() => handleVoiceCommand('ನನಗೆ ಪ್ಲಂಬಿಂಗ್ ಕೆಲಸದವರು ಬೇಕು (I need a plumber in Kannada)', 'plumbing')}
                className="w-full text-left p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 text-xs font-semibold text-slate-800 transition-colors flex justify-between items-center"
              >
                <div>
                  <span className="text-[10px] text-emerald-800 font-bold block uppercase">Kannada</span>
                  <span>"ನನಗೆ ಪ್ಲಂಬಿಂಗ್ ಕೆಲಸದವರು ಬೇಕು"</span>
                </div>
                <span className="text-emerald-700 text-xs font-bold">➔ Match</span>
              </button>

              <button
                onClick={() => handleVoiceCommand('मुझे इलेक्ट्रीशियन की जरूरत है (I need an electrician in Hindi)', 'electrical')}
                className="w-full text-left p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 text-xs font-semibold text-slate-800 transition-colors flex justify-between items-center"
              >
                <div>
                  <span className="text-[10px] text-emerald-800 font-bold block uppercase">Hindi</span>
                  <span>"मुझे तुरंत इलेक्ट्रीशियन चाहिए"</span>
                </div>
                <span className="text-emerald-700 text-xs font-bold">➔ Match</span>
              </button>

              <button
                onClick={() => handleVoiceCommand('Need deep home cleaning in Tumakuru', 'cleaning')}
                className="w-full text-left p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 text-xs font-semibold text-slate-800 transition-colors flex justify-between items-center"
              >
                <div>
                  <span className="text-[10px] text-emerald-800 font-bold block uppercase">English</span>
                  <span>"Book house deep cleaning service"</span>
                </div>
                <span className="text-emerald-700 text-xs font-bold">➔ Match</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Popups, Drawers & Invoice Modal */}
      <BookingModal />
      <PaymentModal />
      <RatingModal />
      <ComplaintModal />
      <InvoiceModal
        booking={selectedInvoiceBooking}
        isOpen={isInvoiceOpen}
        onClose={() => setIsInvoiceOpen(false)}
      />

    </div>
  );
};
