import { Server, Socket } from 'socket.io';

let ioInstance: Server | null = null;

export const initSocket = (io: Server) => {
  ioInstance = io;

  io.on('connection', (socket: Socket) => {
    // Join user-specific room
    socket.on('join_user', (userId: string | number) => {
      const room = `user_${userId}`;
      socket.join(room);
    });

    // Join role-specific broadcast room (e.g., 'role_WORKER', 'role_FARMER')
    socket.on('join_role', (role: string) => {
      const room = `role_${role.toUpperCase()}`;
      socket.join(room);
    });

    // Join community feed
    socket.on('join_community', () => {
      socket.join('community_feed');
    });

    socket.on('disconnect', () => {
      // client disconnected
    });
  });
};

export const broadcastEvent = (roomOrEvent: string, eventName?: string, payload?: any) => {
  if (!ioInstance) return;

  if (eventName && payload !== undefined) {
    // Room-targeted emit: broadcastEvent('user_1', 'booking_update', data)
    ioInstance.to(roomOrEvent).emit(eventName, payload);
  } else {
    // Global emit: broadcastEvent('global_booking_created', data)
    ioInstance.emit(roomOrEvent, eventName);
  }
};

export const getIO = () => ioInstance;
