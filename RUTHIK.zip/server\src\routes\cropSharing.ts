/**
 * Crop Sharing API Routes — CoWork Agri
 *
 * Implements:
 *   - crop_posts
 *   - crop_comments
 *   - crop_media
 * Supports community feed, peer advice, visibility filtering, and persistent storage.
 */

import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { broadcastEvent } from '../services/socketService';
import { localStore, persistLocalStore } from '../config/db';
import { Notification } from '../types';

export interface CropMedia {
  id: string;
  crop_post_id: string;
  media_type: 'image' | 'video';
  media_url: string;
  created_at: string;
}

export interface CropComment {
  id: string;
  crop_post_id: string;
  user_id: string;
  user_name: string;
  user_role?: string;
  comment: string;
  created_at: string;
}

export interface CropPost {
  id: string;
  farmer_id: string;
  farmer_name: string;
  crop_name: string;
  farm_name: string;
  image_url: string;
  description: string;
  location: string;
  date: string;
  visibility: 'Only Me' | 'My Cooperative' | 'Other Farmers' | 'People I Share With';
  created_at: string;
  likes?: number;
  media: CropMedia[];
  comments: CropComment[];
}

const cropStoreFile = path.resolve(__dirname, '../../../server/data/crop_posts.json');

// Initial seed
let CROP_POSTS: CropPost[] = [
  {
    id: 'crop_post_001',
    farmer_id: 'farmer01',
    farmer_name: 'Ravi Gowda',
    crop_name: 'Ragi (Finger Millet)',
    farm_name: 'Green Valley Farm',
    image_url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=900&q=80',
    description: 'Changed irrigation timing from midday to early dawn (5:30 AM). Soil moisture retention has improved significantly, reducing water demand by 25%.',
    location: 'Tumakuru Rural',
    date: '26 Sep 2026',
    visibility: 'My Cooperative',
    likes: 14,
    created_at: new Date(Date.now() - 86400000).toISOString(),
    media: [
      {
        id: 'media_001',
        crop_post_id: 'crop_post_001',
        media_type: 'image',
        media_url: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=900&q=80',
        created_at: new Date(Date.now() - 86400000).toISOString()
      }
    ],
    comments: [
      {
        id: 'comment_001',
        crop_post_id: 'crop_post_001',
        user_id: 'farmer02',
        user_name: 'Suresh Nayak',
        user_role: 'Farmer',
        comment: 'I adopted this schedule last month in Sira. It completely stopped root heat stress. Highly recommended for red sandy loam.',
        created_at: new Date(Date.now() - 50000000).toISOString()
      },
      {
        id: 'comment_002',
        crop_post_id: 'crop_post_001',
        user_id: 'mentor_01',
        user_name: 'Prof. Basavaraj (Co-op Agri Mentor)',
        user_role: 'Agronomist',
        comment: 'Excellent observation Ravi. Dawn irrigation minimizes evaporative loss and matches peak transpiration hours.',
        created_at: new Date(Date.now() - 20000000).toISOString()
      }
    ]
  },
  {
    id: 'crop_post_002',
    farmer_id: 'farmer02',
    farmer_name: 'Suresh Nayak',
    crop_name: 'Tomato',
    farm_name: 'Cauvery Organic Orchards',
    image_url: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?auto=format&fit=crop&w=900&q=80',
    description: 'Flower drop noticed in row 3 after the recent humidity spike. Using drip irrigation for 25 minutes twice daily. Looking for organic preventive measures.',
    location: 'Sira, Tumakuru',
    date: '25 Sep 2026',
    visibility: 'My Cooperative',
    likes: 8,
    created_at: new Date(Date.now() - 172800000).toISOString(),
    media: [
      {
        id: 'media_002',
        crop_post_id: 'crop_post_002',
        media_type: 'image',
        media_url: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?auto=format&fit=crop&w=900&q=80',
        created_at: new Date(Date.now() - 172800000).toISOString()
      }
    ],
    comments: [
      {
        id: 'comment_003',
        crop_post_id: 'crop_post_002',
        user_id: 'farmer01',
        user_name: 'Ravi Gowda',
        user_role: 'Farmer',
        comment: 'Spray fermented butter-milk (sour buttermilk diluted 1:10) in the early morning. It supplies micro-nutrients and controls blossom rot.',
        created_at: new Date(Date.now() - 100000000).toISOString()
      }
    ]
  }
];

// Load persisted posts
try {
  if (fs.existsSync(cropStoreFile)) {
    const data = fs.readFileSync(cropStoreFile, 'utf8');
    CROP_POSTS = JSON.parse(data);
  } else {
    const parentDir = path.dirname(cropStoreFile);
    if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
    fs.writeFileSync(cropStoreFile, JSON.stringify(CROP_POSTS, null, 2), 'utf8');
  }
} catch (e) {
  console.warn('[CropSharing] Storage file error:', e);
}

const persistPosts = () => {
  try {
    const parentDir = path.dirname(cropStoreFile);
    if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
    fs.writeFileSync(cropStoreFile, JSON.stringify(CROP_POSTS, null, 2), 'utf8');
  } catch (e) {
    console.error('[CropSharing] Failed to persist posts:', e);
  }
};

const router = Router();

// GET /api/crop-sharing/posts
router.get('/posts', (req: Request, res: Response) => {
  try {
    const { farmer_id, crop, visibility } = req.query;
    let filtered = [...CROP_POSTS];

    if (farmer_id) {
      filtered = filtered.filter((p) => p.farmer_id === String(farmer_id));
    }
    if (crop) {
      filtered = filtered.filter((p) => p.crop_name.toLowerCase().includes(String(crop).toLowerCase()));
    }
    if (visibility) {
      filtered = filtered.filter((p) => p.visibility === String(visibility));
    }

    // Sort newest first
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return res.json({
      success: true,
      count: filtered.length,
      data: filtered
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/crop-sharing/posts/:id
router.get('/posts/:id', (req: Request, res: Response) => {
  const post = CROP_POSTS.find((p) => p.id === req.params.id);
  if (!post) {
    return res.status(404).json({ success: false, message: 'Crop post not found' });
  }
  return res.json({ success: true, data: post });
});

// POST /api/crop-sharing/posts
router.post('/posts', (req: Request, res: Response) => {
  try {
    const {
      farmer_id,
      farmer_name,
      crop_name,
      farm_name,
      image_url,
      description,
      location,
      date,
      visibility = 'My Cooperative'
    } = req.body;

    if (!crop_name) {
      return res.status(400).json({
        success: false,
        message: 'crop_name is required'
      });
    }

    const postId = `crop_post_${Date.now()}`;
    const img = image_url || 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=900&q=80';

    const newMedia: CropMedia = {
      id: `media_${Date.now()}`,
      crop_post_id: postId,
      media_type: 'image',
      media_url: img,
      created_at: new Date().toISOString()
    };

    const newPost: CropPost = {
      id: postId,
      farmer_id: farmer_id || 'farmer01',
      farmer_name: farmer_name || 'Ravi Gowda',
      crop_name,
      farm_name: farm_name || 'Green Valley Farm',
      image_url: img,
      description: description || '',
      location: location || 'Tumakuru Rural',
      date: date || new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      visibility: visibility || 'My Cooperative',
      likes: 1,
      created_at: new Date().toISOString(),
      media: [newMedia],
      comments: []
    };

    CROP_POSTS.unshift(newPost);
    persistPosts();

    // Broadcast in real-time to community feed and role_FARMER
    broadcastEvent('community_feed', 'new_crop_post', newPost);
    broadcastEvent('role_FARMER', 'new_crop_post', newPost);

    return res.status(201).json({
      success: true,
      message: 'Crop post & idea shared successfully to community feed!',
      data: newPost
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/crop-sharing/posts/:id/comments
router.post('/posts/:id/comments', (req: Request, res: Response) => {
  try {
    const post = CROP_POSTS.find((p) => p.id === req.params.id);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Crop post not found' });
    }

    const { user_id, user_name, comment, user_role = 'Farmer' } = req.body;
    if (!comment || comment.trim() === '') {
      return res.status(400).json({ success: false, message: 'Comment cannot be empty' });
    }

    const newComment: CropComment = {
      id: `comment_${Date.now()}`,
      crop_post_id: post.id,
      user_id: user_id || 'anon',
      user_name: user_name || 'Fellow Farmer',
      user_role,
      comment: comment.trim(),
      created_at: new Date().toISOString()
    };

    post.comments.push(newComment);
    persistPosts();

    // Notify post owner
    if (post.farmer_id) {
      const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
      const notif: Notification = {
        id: notifId,
        user_id: post.farmer_id === 'farmer01' ? 7 : Number(post.farmer_id) || 7,
        title: 'New Comment on Your Crop Post 💬',
        message: `${user_name || 'A fellow farmer'} commented: "${comment.slice(0, 60)}..."`,
        type: 'community',
        is_read: false,
        link: '/farmer-dashboard',
        created_at: new Date().toISOString()
      };
      localStore.notifications.unshift(notif);
      persistLocalStore();

      broadcastEvent(`user_${notif.user_id}`, 'new_notification', notif);
    }

    // Broadcast comment to community
    broadcastEvent('community_feed', 'new_crop_comment', {
      postId: post.id,
      comment: newComment
    });

    return res.status(201).json({
      success: true,
      message: 'Comment added',
      data: newComment
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/crop-sharing/posts/:id/like
router.post('/posts/:id/like', (req: Request, res: Response) => {
  try {
    const post = CROP_POSTS.find((p) => p.id === req.params.id);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Crop post not found' });
    }

    post.likes = (post.likes || 0) + 1;
    persistPosts();

    broadcastEvent('community_feed', 'crop_post_liked', {
      postId: post.id,
      likes: post.likes
    });

    return res.json({ success: true, likes: post.likes });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
