import React from 'react';
import { MapPin, ShieldCheck, Star, Phone, Clock } from 'lucide-react';
import { AGRI_WORKERS, AGRI_SERVICE_CATEGORIES } from '../../data/agriMockData';

export const NearbyAgriServices = ({ isLowConnectivity = false, onSelectCategory, selectedCategory = null }) => {
  const availableWorkers = AGRI_WORKERS.filter(w => w.available).sort((a, b) => a.distanceKm - b.distanceKm);

  return (
    <div className="space-y-5">
      {/* Service Category Filter */}
      <div>
        <h4 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Service Categories</h4>
        <div className={`flex flex-wrap gap-2`}>
          <button
            onClick={() => onSelectCategory?.(null)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              !selectedCategory ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All
          </button>
          {AGRI_SERVICE_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory?.(cat.label)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                selectedCategory === cat.label
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat.icon} {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Workers List */}
      <div>
        <h4 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">
          📍 Nearest Available Providers ({availableWorkers.length})
        </h4>
        <div className="space-y-3">
          {availableWorkers
            .filter(w => !selectedCategory || w.serviceCategories?.includes(selectedCategory))
            .map((worker, idx) => (
              <div
                key={worker.id}
                className={`bg-slate-800 border border-slate-700 rounded-2xl flex items-center gap-3 ${isLowConnectivity ? 'p-4' : 'p-3'}`}
              >
                {/* Distance indicator */}
                <div className="flex-shrink-0 flex flex-col items-center gap-1 w-12">
                  <span className={`text-2xl`}>{worker.avatar}</span>
                  <span className={`text-emerald-400 font-black text-xs`}>{worker.distanceKm} km</span>
                </div>

                {/* Divider */}
                <div className="w-px h-10 bg-slate-700 flex-shrink-0" />

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <p className={`text-white font-bold ${isLowConnectivity ? 'text-base' : 'text-sm'}`}>{worker.name}</p>
                    {worker.verified && <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />}
                    {worker.coopMember && <span className="text-[10px] text-emerald-400 font-bold">🤝</span>}
                  </div>
                  <p className="text-emerald-400 text-xs">{worker.primarySkill}</p>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                    <span className="flex items-center gap-0.5">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> {worker.rating}
                    </span>
                    <span>·</span>
                    <span>{worker.experience} yrs</span>
                    <span>·</span>
                    <span className="text-white font-bold">₹{worker.hourlyRate}/hr</span>
                  </div>
                </div>

                {/* CTA */}
                <div className="flex-shrink-0">
                  <div className="flex items-center gap-1 bg-emerald-900 border border-emerald-700 text-emerald-300 text-[10px] font-bold px-2 py-1 rounded-lg">
                    <Clock className="w-2.5 h-2.5" />
                    <span>Now</span>
                  </div>
                </div>
              </div>
            ))}

          {availableWorkers.filter(w => !selectedCategory || w.serviceCategories?.includes(selectedCategory)).length === 0 && (
            <div className="text-center py-6 text-slate-500 text-sm">
              No available providers for this category right now.
            </div>
          )}
        </div>
      </div>

      <p className="text-center text-[10px] text-slate-500">
        📌 Verified cooperative providers mapped within your service radius.
      </p>
    </div>
  );
};
