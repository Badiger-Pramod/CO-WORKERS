export type UserRole = 'CUSTOMER' | 'WORKER' | 'FARMER' | 'ADMIN';

export interface User {
  id: number;
  full_name: string;
  email: string;
  mobile: string;
  password_hash: string;
  role: UserRole;
  city: string;
  address?: string;
  created_at?: string;
  updated_at?: string;
}

export interface WorkerProfile {
  id: number;
  user_id: number;
  primary_skill: string;
  skills?: string[];
  experience_years: number;
  availability: 'Available' | 'Not Available';
  working_hours?: string;
  service_radius_km?: number;
  verification_status: 'Pending' | 'Verified' | 'Rejected';
  rating: number;
  completed_jobs: number;
  hourly_rate?: number;
  bio?: string;
  created_at?: string;
  updated_at?: string;
}

export interface FarmerProfile {
  id: number;
  user_id: number;
  farm_name: string;
  farm_size_acres: number;
  crops: string[];
  soil_type?: string;
  water_source?: string;
  irrigation_type?: string;
  location?: string;
  verification_status: 'Pending' | 'Verified' | 'Rejected';
  created_at?: string;
  updated_at?: string;
}

export interface Service {
  id: number;
  name: string;
  description: string;
  category: string;
  base_price: number;
  icon?: string;
  created_at?: string;
}

export interface Cooperative {
  id: number;
  name: string;
  city: string;
  description?: string;
  registration_no?: string;
  member_count?: number;
  created_at?: string;
}

export interface WorkerCooperative {
  id: number;
  worker_id: number;
  cooperative_id: number;
  joined_at?: string;
  status: 'ACTIVE' | 'PENDING' | 'SUSPENDED';
  share_class?: string;
}

export type BookingStatus =
  | 'REQUESTED'
  | 'ACCEPTED'
  | 'SCHEDULED'
  | 'ON_THE_WAY'
  | 'WORK_STARTED'
  | 'COMPLETED'
  | 'PAID'
  | 'RATED'
  | 'CANCELLED';

export interface BookingStatusAudit {
  status: BookingStatus;
  changed_at: string;
  note?: string;
}

export interface JobRequest {
  id: number;
  booking_code?: string;
  customer_id: number;
  worker_id?: number;
  service_id?: number;
  service_title: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  city: string;
  requested_date: string;
  requested_time: string;
  estimated_price: number;
  worker_payout: number;
  coop_fund: number;
  platform_fee: number;
  status: BookingStatus;
  status_history?: BookingStatusAudit[];
  payment_status?: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED';
  payment_id?: string;
  payment_method?: string;
  payment_amount?: number;
  rating?: number;
  review?: string;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Equipment {
  id: number;
  owner_id: number;
  owner_name: string;
  name: string;
  type: string;
  daily_rate: number;
  location: string;
  availability: 'Available' | 'Rented' | 'Maintenance';
  operator_provided: boolean;
  condition: string;
  image_url?: string;
  rating?: number;
  description?: string;
  created_at?: string;
}

export interface EquipmentBooking {
  id: number;
  equipment_id: number;
  equipment_name: string;
  farmer_id: number;
  farmer_name: string;
  start_date: string;
  end_date: string;
  days: number;
  total_price: number;
  status: 'PENDING' | 'CONFIRMED' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  created_at?: string;
}

export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  type: 'booking' | 'payment' | 'community' | 'verification' | 'system';
  is_read: boolean;
  link?: string;
  created_at: string;
}

export interface Complaint {
  id: number;
  booking_id?: number;
  user_id: number;
  user_name: string;
  category: 'Poor service' | 'Worker did not arrive' | 'Payment issue' | 'Overcharging' | 'Behaviour issue' | 'Other';
  description: string;
  status: 'PENDING' | 'UNDER_REVIEW' | 'RESOLVED';
  resolution_note?: string;
  created_at: string;
  updated_at?: string;
}

export interface Review {
  id: number;
  booking_id: number;
  reviewer_id: number;
  reviewer_name: string;
  reviewee_id: number;
  reviewee_name: string;
  rating: number;
  review_text: string;
  created_at: string;
}

export interface AuthPayload {
  userId: number;
  email: string;
  role: UserRole;
  name: string;
}
