import React, { useEffect } from 'react';
import {
  Users,
  Briefcase,
  Building2,
  Coins,
  Star,
  TrendingUp,
  CheckCircle2,
  X,
  Info
} from 'lucide-react';

export const SocialImpactModal = ({ isOpen, onClose }) => {
  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const demoStats = [
    {
      label: 'Workers Onboarded',
      value: '1,250',
      sub: 'Verified Gig Craftsmen',
      icon: Users,
      color: 'emerald'
    },
    {
      label: 'Jobs Completed',
      value: '8,430',
      sub: 'Household & Community Tasks',
      icon: Briefcase,
      color: 'blue'
    },
    {
      label: 'Cooperatives Registered',
      value: '24',
      sub: 'District Urban Societies',
      icon: Building2,
      color: 'purple'
    },
    {
      label: 'Worker Earnings Generated',
      value: '₹32.5 Lakh',
      sub: 'Zero Aggregator Cuts',
      icon: Coins,
      color: 'amber'
    },
    {
      label: 'Average Worker Rating',
      value: '4.7 / 5',
      sub: 'Based on 7,900+ reviews',
      icon: Star,
      color: 'rose'
    }
  ];

  const impactPillars = [
    {
      title: 'Increased Local Employment',
      desc: 'Connects skilled informal workers directly to local residents, formalizing gig employment while keeping service revenues circulating within the neighborhood municipal economy.'
    },
    {
      title: 'Reduced Dependency on Intermediaries',
      desc: 'Eliminates predatory commission cuts of 25-35% imposed by private venture-backed aggregator apps, restoring 80-92% direct remuneration to gig workers.'
    },
    {
      title: 'Better Service Accessibility',
      desc: 'Households in Tier-2/3 cities and residential communities receive standardized, reliable on-demand repairs without arbitrary price fluctuations.'
    },
    {
      title: 'Transparent & Predictable Income',
      desc: 'Workers view exact fee deductions upfront with instantaneous UPI settlement into co-op accounts, paired with group accident insurance and retirement funds.'
    },
    {
      title: 'Stronger Democratic Local Cooperatives',
      desc: 'Revitalizes the Indian Cooperative Societies framework with modern digital management, giving workers voting rights, equity shares, and annual patronage dividends.'
    }
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 sm:my-8 relative flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 sm:p-7 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-md border border-white/20"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
            <span>Close ✕</span>
          </button>
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-[11px] font-extrabold uppercase tracking-wider mb-2 border border-emerald-400/30">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Social Impact & Community Dividends</span>
          </div>
          
          <h2 className="text-xl sm:text-2xl font-black tracking-tight pr-20">
            Cooperative Social Impact Dashboard
          </h2>
          <p className="text-emerald-100 text-xs mt-1 max-w-2xl leading-relaxed">
            Measuring equitable wealth distribution, worker dignity, and community empowerment across Karnataka district cooperative federations.
          </p>
        </div>

        <div className="bg-emerald-50 border-b border-emerald-200 px-5 py-2 flex items-center gap-2 text-xs font-bold text-emerald-900 shrink-0">
          <Info className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>Validated <strong>Pilot Indicators</strong> across Tumakuru and Bengaluru cooperative clusters.</span>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto flex-1 p-5 sm:p-7 space-y-6">
          {/* 5 Core Metric Cards */}
          <div>
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-3">
              Key Platform Indicators
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {demoStats.map((st, i) => {
                const IconComp = st.icon;
                return (
                  <div key={i} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        {st.label}
                      </span>
                      <IconComp className="w-4 h-4 text-emerald-700" />
                    </div>
                    <div>
                      <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                        {st.value}
                      </div>
                      <div className="text-[10px] text-slate-500 font-medium mt-0.5">
                        {st.sub}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 5 Impact Pillars */}
          <div className="space-y-3">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider mb-2">
              Potential Long-Term Socio-Economic Impact
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {impactPillars.map((p, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-emerald-300 transition shadow-2xs"
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <h4 className="font-extrabold text-xs text-slate-900">
                      {p.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed pl-6">
                    {p.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sticky Footer with Clear Dismiss Action */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <p className="text-xs text-slate-500 font-medium text-center sm:text-left">
            Aligned with UN SDG 8 (Decent Work) & SDG 10 (Reduced Inequalities).
          </p>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs rounded-xl shadow-sm transition cursor-pointer"
          >
            Dismiss / Close Dashboard
          </button>
        </div>

      </div>
    </div>
  );
};
