import React from 'react';
import { WifiOff, Mic, Phone } from 'lucide-react';

export const LowConnectivityMode = ({ isOnline, onSpeakTap, farmerName = 'Farmer', onCallHelp }) => {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-between p-6 gap-6">

      {/* Network Status Banner */}
      <div className={`w-full rounded-2xl px-5 py-3 flex items-center gap-3 text-sm font-bold ${
        isOnline
          ? 'bg-emerald-900 border border-emerald-700 text-emerald-200'
          : 'bg-red-950 border border-red-700 text-red-200'
      }`}>
        {isOnline
          ? <><span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse inline-block" /> Connected — Low Connectivity Mode</>
          : <><WifiOff className="w-5 h-5" /> No Internet Connection</>
        }
      </div>

      {/* Welcome */}
      <div className="text-center">
        <p className="text-slate-400 text-lg font-medium">Welcome,</p>
        <p className="text-white text-4xl font-black mt-1">{farmerName}</p>
        <p className="text-slate-500 text-base mt-2">CoWork Farmer App</p>
      </div>

      {/* Giant Mic Button */}
      <div className="flex flex-col items-center gap-5">
        <button
          onClick={onSpeakTap}
          className="w-52 h-52 rounded-full bg-emerald-600 hover:bg-emerald-500 active:scale-95 transition-all shadow-2xl flex flex-col items-center justify-center gap-3"
          aria-label="Tap to speak to Voice Seva"
        >
          <Mic className="w-20 h-20 text-white" />
          <span className="text-white font-black text-xl">🎙️ Speak</span>
        </button>
        <p className="text-slate-300 text-lg font-semibold text-center">
          Tap the button<br />and speak in your language
        </p>
      </div>

      {/* Quick action buttons */}
      <div className="w-full grid grid-cols-2 gap-4">
        <button className="bg-slate-800 border border-slate-700 rounded-2xl p-5 flex flex-col items-center gap-3 active:scale-95 transition">
          <span className="text-4xl">🌾</span>
          <span className="text-white font-bold text-base text-center">My Crops</span>
        </button>
        <button className="bg-slate-800 border border-slate-700 rounded-2xl p-5 flex flex-col items-center gap-3 active:scale-95 transition">
          <span className="text-4xl">📋</span>
          <span className="text-white font-bold text-base text-center">My Requests</span>
        </button>
      </div>

      {/* Help line */}
      <button
        onClick={onCallHelp}
        className="w-full bg-amber-600 hover:bg-amber-500 active:scale-95 transition rounded-2xl p-4 flex items-center justify-center gap-3"
      >
        <Phone className="w-6 h-6 text-white" />
        <span className="text-white font-black text-lg">📞 Call Help</span>
      </button>

      {/* Offline note */}
      {!isOnline && (
        <p className="text-center text-slate-600 text-sm">
          You are offline. Your requests will be saved and sent when you reconnect.
        </p>
      )}
    </div>
  );
};
