import { Router } from 'express';
import {
  register,
  registerCustomer,
  registerWorker,
  registerFarmer,
  login,
  getCurrentUser,
  changePassword
} from '../controllers/authController';

const router = Router();

router.post('/register', register);
router.post('/customer/register', registerCustomer);
router.post('/worker/register', registerWorker);
router.post('/farmer/register', registerFarmer);
router.post('/login', login);
router.get('/me', getCurrentUser);
router.post('/change-password', changePassword);

export default router;
