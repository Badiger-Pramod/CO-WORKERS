import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { dbQuery, localStore, persistLocalStore } from '../config/db';
import { User, AuthPayload, UserRole, WorkerProfile, FarmerProfile } from '../types';

const generateToken = (payload: AuthPayload): string => {
  const secret = process.env.JWT_SECRET || 'cowork_connect_jwt_secure_secret_prod_2026';
  return jwt.sign(payload, secret, { expiresIn: '7d' });
};

// POST /api/auth/register (Universal register with role)
export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      full_name,
      email,
      mobile,
      password,
      confirmPassword,
      role = 'CUSTOMER',
      city = 'Tumakuru',
      address = '',
      // Worker-specific
      primary_skill,
      experience_years,
      // Farmer-specific
      farm_name,
      farm_size_acres,
      crops
    } = req.body;

    if (!full_name || !email || !mobile || !password) {
      res.status(400).json({
        success: false,
        message: 'Please provide full name, email or login ID, mobile number and password.'
      });
      return;
    }

    if (confirmPassword && password !== confirmPassword) {
      res.status(400).json({
        success: false,
        message: 'Passwords do not match.'
      });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
      return;
    }

    const cleanEmail = email.toLowerCase().trim();
    // Check if user already exists
    const existing = await dbQuery('SELECT * FROM users WHERE email = $1', [cleanEmail]);
    if (existing.rows.length > 0) {
      res.status(409).json({
        success: false,
        message: 'An account with this email/ID already exists.'
      });
      return;
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    const validRole: UserRole = ['CUSTOMER', 'WORKER', 'FARMER', 'ADMIN'].includes(role.toUpperCase())
      ? (role.toUpperCase() as UserRole)
      : 'CUSTOMER';

    const insertUserRes = await dbQuery(
      'INSERT INTO users (full_name, email, mobile, password_hash, role, city, address) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id, full_name, email, mobile, role, city, address',
      [full_name.trim(), cleanEmail, mobile.trim(), password_hash, validRole, city.trim(), address.trim()]
    );

    const newUser = insertUserRes.rows[0];

    // Role-specific profile initialization
    let workerProfile: WorkerProfile | null = null;
    let farmerProfile: FarmerProfile | null = null;

    if (validRole === 'WORKER') {
      const exp = Number(experience_years) || 1;
      const skill = primary_skill || 'General Handyman';
      const insertProfileRes = await dbQuery(
        'INSERT INTO worker_profiles (user_id, primary_skill, experience_years, availability, verification_status, bio) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, user_id, primary_skill, experience_years, availability, verification_status, rating, completed_jobs',
        [newUser.id, skill, exp, 'Available', 'Verified', `${skill} specialist with ${exp} years experience.`]
      );
      workerProfile = insertProfileRes.rows[0];
    } else if (validRole === 'FARMER') {
      const fName = farm_name || `${full_name}'s Farm`;
      const acres = Number(farm_size_acres) || 3.0;
      const cropList = Array.isArray(crops) && crops.length > 0 ? crops : ['Ragi', 'Tomato'];
      const insertFarmerRes = await dbQuery(
        'INSERT INTO farmer_profiles (user_id, farm_name, farm_size_acres, crops, soil_type, water_source, irrigation_type, location) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id, user_id, farm_name, farm_size_acres, crops',
        [newUser.id, fName, acres, cropList, 'Red Loam', 'Borewell', 'Drip', city || 'Tumakuru Rural']
      );
      farmerProfile = insertFarmerRes.rows[0];
    }

    const token = generateToken({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role,
      name: newUser.full_name
    });

    res.status(201).json({
      success: true,
      message: `${validRole.charAt(0) + validRole.slice(1).toLowerCase()} account created successfully!`,
      token,
      user: {
        id: newUser.id,
        name: newUser.full_name,
        fullName: newUser.full_name,
        email: newUser.email,
        mobile: newUser.mobile,
        role: newUser.role === 'CUSTOMER' ? 'Customer' : newUser.role === 'WORKER' ? 'Worker' : newUser.role === 'FARMER' ? 'Farmer' : 'Admin',
        city: newUser.city,
        address: newUser.address
      },
      workerProfile,
      farmerProfile
    });
  } catch (err: any) {
    console.error('[Auth] Registration error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during registration. Please try again.'
    });
  }
};

// POST /api/auth/customer/register
export const registerCustomer = async (req: Request, res: Response): Promise<void> => {
  req.body.role = 'CUSTOMER';
  return register(req, res);
};

// POST /api/auth/worker/register
export const registerWorker = async (req: Request, res: Response): Promise<void> => {
  req.body.role = 'WORKER';
  return register(req, res);
};

// POST /api/auth/farmer/register
export const registerFarmer = async (req: Request, res: Response): Promise<void> => {
  req.body.role = 'FARMER';
  return register(req, res);
};

// POST /api/auth/login
export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password, expectedRole } = req.body;

    if (!email || !password) {
      res.status(400).json({
        success: false,
        message: 'Please provide both username/email and password.'
      });
      return;
    }

    const userRes = await dbQuery('SELECT * FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (userRes.rows.length === 0) {
      res.status(401).json({
        success: false,
        message: 'Invalid credentials. Please verify your login ID and password.'
      });
      return;
    }

    const user: User = userRes.rows[0];

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      res.status(401).json({
        success: false,
        message: 'Invalid credentials. Please verify your login ID and password.'
      });
      return;
    }

    // Role check if portal-specific
    if (expectedRole) {
      const normalizedExpected = expectedRole.toUpperCase();
      if (user.role !== normalizedExpected) {
        res.status(403).json({
          success: false,
          message: `This account is registered as a ${user.role}. Please log in through the correct portal.`
        });
        return;
      }
    }

    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      name: user.full_name
    });

    let workerProfile: WorkerProfile | null = null;
    let farmerProfile: FarmerProfile | null = null;

    if (user.role === 'WORKER') {
      const wp = localStore.worker_profiles.find(w => w.user_id === user.id);
      if (wp) workerProfile = wp;
    } else if (user.role === 'FARMER') {
      const fp = localStore.farmer_profiles.find(f => f.user_id === user.id);
      if (fp) farmerProfile = fp;
    }

    const friendlyRole =
      user.role === 'CUSTOMER' ? 'Customer' :
      user.role === 'WORKER' ? 'Worker' :
      user.role === 'FARMER' ? 'Farmer' : 'Admin';

    res.status(200).json({
      success: true,
      message: `Welcome back, ${user.full_name}!`,
      token,
      user: {
        id: user.id,
        name: user.full_name,
        fullName: user.full_name,
        email: user.email,
        mobile: user.mobile,
        role: friendlyRole,
        city: user.city,
        address: user.address,
        farmName: farmerProfile?.farm_name || 'Green Valley Farm',
        farmSize: farmerProfile?.farm_size_acres || 4.5,
        crops: farmerProfile?.crops || ['Ragi', 'Tomato']
      },
      workerProfile,
      farmerProfile
    });
  } catch (err: any) {
    console.error('[Auth] Login error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during login. Please try again.'
    });
  }
};

// GET /api/auth/me
export const getCurrentUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ success: false, message: 'Authorization required.' });
      return;
    }

    const token = authHeader.split(' ')[1];
    const secret = process.env.JWT_SECRET || 'cowork_connect_jwt_secure_secret_prod_2026';
    const decoded = jwt.verify(token, secret) as AuthPayload;

    const user = localStore.users.find(u => u.id === decoded.userId);
    if (!user) {
      res.status(404).json({ success: false, message: 'User account not found.' });
      return;
    }

    const workerProfile = localStore.worker_profiles.find(w => w.user_id === user.id) || null;
    const farmerProfile = localStore.farmer_profiles.find(f => f.user_id === user.id) || null;

    const friendlyRole =
      user.role === 'CUSTOMER' ? 'Customer' :
      user.role === 'WORKER' ? 'Worker' :
      user.role === 'FARMER' ? 'Farmer' : 'Admin';

    res.json({
      success: true,
      user: {
        id: user.id,
        name: user.full_name,
        fullName: user.full_name,
        email: user.email,
        mobile: user.mobile,
        role: friendlyRole,
        city: user.city,
        address: user.address,
        farmName: farmerProfile?.farm_name,
        farmSize: farmerProfile?.farm_size_acres,
        crops: farmerProfile?.crops
      },
      workerProfile,
      farmerProfile
    });
  } catch (err) {
    res.status(401).json({ success: false, message: 'Invalid or expired session token.' });
  }
};

// POST /api/auth/change-password
export const changePassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, oldPassword, newPassword } = req.body;
    if (!userId || !oldPassword || !newPassword) {
      res.status(400).json({ success: false, message: 'Please provide current and new password.' });
      return;
    }

    const user = localStore.users.find(u => u.id === Number(userId));
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    const isMatch = await bcrypt.compare(oldPassword, user.password_hash);
    if (!isMatch) {
      res.status(400).json({ success: false, message: 'Current password incorrect.' });
      return;
    }

    const salt = await bcrypt.genSalt(10);
    user.password_hash = await bcrypt.hash(newPassword, salt);
    user.updated_at = new Date().toISOString();
    persistLocalStore();

    res.json({ success: true, message: 'Password updated successfully!' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Password update failed.' });
  }
};
