import React from 'react';
import { useCoop } from '../../context/CoopContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const Toast = () => {
  const { toast } = useCoop();

  if (!toast) return null;

  const icons = {
    success: CheckCircle2,
    error: AlertCircle,
    info: Info,
  };

  const colors = {
    success: 'bg-emerald-950 text-emerald-100 border-emerald-600/40 shadow-emerald-900/30',
    error: 'bg-rose-950 text-rose-100 border-rose-600/40 shadow-rose-900/30',
    info: 'bg-indigo-950 text-indigo-100 border-indigo-600/40 shadow-indigo-900/30',
  };

  const Icon = icons[toast.type] || Info;

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-fade-in">
      <div
        className={`flex items-start gap-3 p-4 rounded-xl border shadow-xl backdrop-blur-md ${
          colors[toast.type] || colors.info
        }`}
      >
        <Icon className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
        <div className="text-sm font-medium leading-relaxed pr-2">
          {toast.message}
        </div>
      </div>
    </div>
  );
};
