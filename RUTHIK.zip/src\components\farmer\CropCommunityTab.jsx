import React, { useState, useMemo } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Camera,
  MessageSquare,
  Share2,
  MapPin,
  Calendar,
  Sparkles,
  ShieldCheck,
  Eye,
  HelpCircle,
  Send,
  CheckCircle2,
  Image as ImageIcon,
  Filter,
  Clock,
  ArrowRight,
  Maximize2,
  X,
  UserCheck,
  Lock,
  Building2,
  Users
} from 'lucide-react';

export const CropCommunityTab = ({ onOpenShowCrop, onNavigateToSkills }) => {
  const {
    currentFarmer,
    cropPosts = [],
    addCropComment,
    t
  } = useCoop();

  const farmer = currentFarmer || {};

  // View state: 'feed' | 'my-crops' | 'compare'
  const [activeSubTab, setActiveSubTab] = useState('feed');
  const [selectedCropFilter, setSelectedCropFilter] = useState('All');
  
  // Discussion / comment input state per post: { [postId]: string }
  const [commentInputs, setCommentInputs] = useState({});
  const [expandedComments, setExpandedComments] = useState({});
  const [sharingExpPostId, setSharingExpPostId] = useState(null);

  // Lightbox Modal for enlarged photo inspection
  const [lightboxPost, setLightboxPost] = useState(null);

  // Compare mode: select two photos to inspect side-by-side
  const [compareSelection, setCompareSelection] = useState([]);

  // Filtered community posts based on visibility & crop filter
  const visibleCommunityPosts = useMemo(() => {
    return cropPosts.filter((post) => {
      // Visibility filter
      const isOwner = post.farmer_id === farmer.id || post.farmer_id === farmer.loginId;
      if (post.visibility === 'Only Me' && !isOwner) return false;
      
      // Crop filter
      if (selectedCropFilter !== 'All' && post.crop_name !== selectedCropFilter) {
        return false;
      }
      return true;
    });
  }, [cropPosts, farmer, selectedCropFilter]);

  // Logged-in farmer's crop photos grouped by crop and month
  const myCropHistory = useMemo(() => {
    const myPosts = cropPosts.filter(
      (p) => p.farmer_id === farmer.id || p.farmer_id === farmer.loginId || p.farmer_name === (farmer.fullName || farmer.name)
    );

    // Group by crop_name -> month_year
    const groups = {};
    myPosts.forEach((post) => {
      const crop = post.crop_name || 'Crop';
      const postDate = new Date(post.created_at || Date.now());
      const monthYear = postDate.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
      const groupKey = `${crop}__${monthYear}`;

      if (!groups[groupKey]) {
        groups[groupKey] = {
          crop,
          monthYear,
          posts: []
        };
      }
      groups[groupKey].posts.push(post);
    });

    return Object.values(groups);
  }, [cropPosts, farmer]);

  // Handle Comment Submission
  const handleCommentSubmit = async (postId) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    await addCropComment(postId, text, 'Farmer');
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
    setExpandedComments((prev) => ({ ...prev, [postId]: true }));
    setSharingExpPostId(null);
  };

  // Quick experience chips for farmers
  const QUICK_EXPERIENCE_SNIPPETS = [
    'I had the same issue last season. My field used a different irrigation schedule.',
    'Looks like slight moisture stress in red soil. Try evening drip for 20 mins.',
    'Spraying neem oil (5ml/L) or Jeevamrutha helped resolve this for my neighbors.',
    'Check underside of leaves for early aphids or mites before harvesting.'
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Top Banner with Show My Crop Action ──────────────────── */}
      <div className="relative overflow-hidden rounded-3xl bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-7 shadow-2xs">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
                🌾 {t('cropCommunityFeed', 'Crop Community')}
              </span>
              <span className="bg-amber-50 text-amber-800 border border-amber-200 text-xs px-3 py-1 rounded-full font-bold">
                🤝 {t('farmerToFarmerHelp', 'Farmer-to-Farmer Support')}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              “{t('seeItShareIt', 'See it. Share it. Get connected.')}”
            </h1>

            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
              {t(
                'cropCommunitySubtitle',
                'Photograph your field conditions, share observations with cooperative members, and get real-world insights from fellow farmers and agronomists.'
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenShowCrop}
              className="px-5 py-3 rounded-2xl bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-sm flex items-center gap-2.5 transition shadow-lg shadow-emerald-500/25 active:scale-95 cursor-pointer"
            >
              <Camera className="w-5 h-5 text-slate-900" />
              <span>{t('showMyCrop', '📷 Show My Crop')}</span>
            </button>
          </div>
        </div>

        {/* Decorative background circle */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* ─── Navigation Sub-Tabs ───────────────────────────────────── */}
      <div className="flex items-center justify-between gap-3 flex-wrap border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('feed')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'feed'
                ? 'bg-emerald-800 text-slate-900 shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>🌾 {t('cropCommunityFeed', 'Crop Community Feed')}</span>
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full text-[10px]">
              {visibleCommunityPosts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('my-crops')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'my-crops'
                ? 'bg-emerald-800 text-slate-900 shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>📷 {t('myCropPhotos', 'My Crop Photos (History)')}</span>
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full text-[10px]">
              {myCropHistory.reduce((sum, g) => sum + g.posts.length, 0)}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('compare')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'compare'
                ? 'bg-emerald-800 text-slate-900 shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <span>🔄 {t('compareProgress', 'Growth Comparison')}</span>
          </button>
        </div>

        {/* Crop Filter Dropdown (in Feed mode) */}
        {activeSubTab === 'feed' && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 hidden sm:inline flex items-center gap-1 font-bold">
              <Filter className="w-3.5 h-3.5" /> Filter Crop:
            </span>
            <select
              value={selectedCropFilter}
              onChange={(e) => setSelectedCropFilter(e.target.value)}
              className="bg-white text-slate-800 border border-slate-300 rounded-xl px-3 py-1.5 font-bold text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="All">All Crops ({cropPosts.length})</option>
              <option value="Ragi">🌾 Ragi</option>
              <option value="Tomato">🍅 Tomato</option>
              <option value="Groundnut">🥜 Groundnut</option>
              <option value="Paddy">🌾 Paddy</option>
              <option value="Maize">🌽 Maize</option>
              <option value="Vegetables">🌱 Vegetables</option>
            </select>
          </div>
        )}
      </div>

      {/* ─── TAB 1: COMMUNITY FEED ─────────────────────────────────── */}
      {activeSubTab === 'feed' && (
        <div className="space-y-6">
          {visibleCommunityPosts.length === 0 ? (
            <div className="text-center py-16 bg-white border border-slate-100 rounded-3xl p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-950/80 border border-emerald-800 flex items-center justify-center text-3xl mx-auto">
                📷
              </div>
              <h3 className="text-slate-900 font-bold text-base">No crop photos found in this category</h3>
              <p className="text-slate-400 text-xs max-w-md mx-auto">
                Be the first farmer to take a photo of your field and share observations with your cooperative!
              </p>
              <button
                onClick={onOpenShowCrop}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-900 rounded-xl text-xs font-black shadow-lg"
              >
                📷 Take Crop Photo Now
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {visibleCommunityPosts.map((post) => {
                const isCommentsOpen = Boolean(expandedComments[post.id]);
                const isSharingExp = sharingExpPostId === post.id;
                const comments = post.comments || [];

                return (
                  <div
                    key={post.id}
                    className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-2xs transition flex flex-col justify-between"
                  >
                    <div>
                      {/* Post Header: Farmer Details & Visibility */}
                      <div className="p-4 sm:p-5 flex items-center justify-between gap-3 border-b border-slate-100">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-lg font-black text-slate-900 shadow-sm flex-shrink-0">
                            {post.farmer_name ? post.farmer_name.charAt(0) : '👨‍🌾'}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="text-slate-900 font-black text-sm">
                                {post.farmer_name || 'Ravi Gowda'}
                              </h4>
                              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.2 rounded-full">
                                ✓ Verified Member
                              </span>
                            </div>
                            <p className="text-slate-400 text-xs flex items-center gap-2 mt-0.5">
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-500" />
                                {post.location || 'Tumakuru'}
                              </span>
                              <span>·</span>
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-slate-500" />
                                {post.date || 'Today'}
                              </span>
                            </p>
                          </div>
                        </div>

                        {/* Visibility Badge */}
                        <div className="flex items-center gap-1 text-[11px] font-bold text-slate-400 bg-slate-100 px-2.5 py-1 rounded-xl border border-slate-200 text-slate-700">
                          {post.visibility === 'My Cooperative' ? (
                            <Building2 className="w-3 h-3 text-emerald-400" />
                          ) : post.visibility === 'Other Farmers' ? (
                            <Users className="w-3 h-3 text-blue-400" />
                          ) : (
                            <Lock className="w-3 h-3 text-amber-400" />
                          )}
                          <span className="hidden sm:inline">{post.visibility}</span>
                        </div>
                      </div>

                      {/* Crop Tag & Description */}
                      <div className="px-5 pt-3.5 pb-2">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full text-xs font-black">
                            🌾 {post.crop_name}
                          </span>
                          {post.farm_name && (
                            <span className="text-xs text-slate-400 font-semibold truncate max-w-[200px]">
                              {post.farm_name}
                            </span>
                          )}
                        </div>
                        {post.description && (
                          <p className="text-slate-800 text-xs sm:text-sm leading-relaxed">
                            “{post.description}”
                          </p>
                        )}
                      </div>

                      {/* Crop Photo with Lightbox trigger */}
                      {post.image_url && (
                        <div className="relative group px-5 py-2">
                          <div className="relative rounded-2xl overflow-hidden border border-slate-100 bg-white aspect-video flex items-center justify-center">
                            <img
                              src={post.image_url}
                              alt={post.crop_name}
                              className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                              loading="lazy"
                            />
                            {/* Overlay zoom button */}
                            <button
                              onClick={() => setLightboxPost(post)}
                              className="absolute bottom-3 right-3 bg-slate-50/80 hover:bg-slate-50 text-slate-900 p-2 rounded-xl backdrop-blur border border-slate-700 opacity-90 hover:opacity-100 transition shadow cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                              title="Enlarge crop photo"
                            >
                              <Maximize2 className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">{t('viewCrop', '📷 View Crop')}</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Post Action Buttons (Section 13 & 14) */}
                    <div>
                      <div className="p-4 sm:px-5 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap bg-slate-50">
                        <div className="flex items-center gap-2">
                          {/* Discuss Button */}
                          <button
                            onClick={() =>
                              setExpandedComments((prev) => ({
                                ...prev,
                                [post.id]: !prev[post.id]
                              }))
                            }
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                              isCommentsOpen
                                ? 'bg-emerald-600 text-slate-900'
                                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                            }`}
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>{t('discuss', '💬 Discuss')}</span>
                            <span className="text-[10px] opacity-80">({comments.length})</span>
                          </button>

                          {/* Share Experience Button */}
                          <button
                            onClick={() => {
                              setSharingExpPostId(isSharingExp ? null : post.id);
                              setExpandedComments((prev) => ({ ...prev, [post.id]: true }));
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                              isSharingExp
                                ? 'bg-amber-500 text-slate-900 font-black'
                                : 'bg-slate-800 text-amber-300 hover:bg-amber-950/40 border border-amber-800/60'
                            }`}
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            <span>{t('shareExperience', '🤝 Share Experience')}</span>
                          </button>
                        </div>

                        {/* Ask Farmer / Connect via Skill Exchange */}
                        <button
                          onClick={() => {
                            if (onNavigateToSkills) {
                              onNavigateToSkills();
                            } else {
                              alert(`Connecting with ${post.farmer_name} via Cooperative Agricultural Exchange.`);
                            }
                          }}
                          className="text-xs text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 transition"
                        >
                          <span>{t('askFarmer', '🙋 Ask Farmer')}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Expandable Discussions & Comments Section */}
                      {isCommentsOpen && (
                        <div className="p-4 sm:p-5 bg-white/80 border-t border-slate-100 space-y-3">
                          {/* Disclaimer */}
                          <div className="flex items-center gap-2 p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-[11px] text-amber-300/90">
                            <HelpCircle className="w-3.5 h-3.5 flex-shrink-0 text-amber-400" />
                            <span>
                              Peer farmer-to-farmer insights. Does not replace accredited agronomist advice.
                            </span>
                          </div>

                          {/* Quick Experience Snippets Picker */}
                          {isSharingExp && (
                            <div className="p-3 bg-slate-50 border border-amber-500/40 rounded-2xl space-y-2">
                              <p className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                                💡 Tap a standard observation to reply quickly:
                              </p>
                              <div className="flex flex-col gap-1.5">
                                {QUICK_EXPERIENCE_SNIPPETS.map((snippet, sIdx) => (
                                  <button
                                    key={sIdx}
                                    type="button"
                                    onClick={() =>
                                      setCommentInputs((prev) => ({
                                        ...prev,
                                        [post.id]: snippet
                                      }))
                                    }
                                    className="text-left text-xs bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-slate-900 p-2 rounded-xl transition border border-slate-700/60"
                                  >
                                    “{snippet}”
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Comments List */}
                          <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                            {comments.length === 0 ? (
                              <p className="text-center py-3 text-slate-500 text-xs italic">
                                No comments yet. Share your experience or ask a question!
                              </p>
                            ) : (
                              comments.map((comm) => (
                                <div
                                  key={comm.id}
                                  className="bg-slate-50/90 border border-slate-100 rounded-2xl p-3 text-xs space-y-1"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                                      {comm.user_name}
                                      {comm.user_role === 'Agronomist' && (
                                        <span className="text-[9px] bg-purple-900 text-purple-200 px-1.5 py-0.2 rounded-full font-bold">
                                          Agronomist
                                        </span>
                                      )}
                                      {comm.user_role === 'Farmer' && (
                                        <span className="text-[9px] bg-emerald-900 text-emerald-200 px-1.5 py-0.2 rounded-full font-bold">
                                          Farmer
                                        </span>
                                      )}
                                    </span>
                                    <span className="text-[10px] text-slate-500">
                                      {new Date(comm.created_at).toLocaleDateString('en-GB', {
                                        day: '2-digit',
                                        month: 'short'
                                      })}
                                    </span>
                                  </div>
                                  <p className="text-slate-300 leading-relaxed">{comm.comment}</p>
                                </div>
                              ))
                            )}
                          </div>

                          {/* Add Comment Input Bar */}
                          <div className="flex items-center gap-2 pt-1">
                            <input
                              type="text"
                              value={commentInputs[post.id] || ''}
                              onChange={(e) =>
                                setCommentInputs((prev) => ({
                                  ...prev,
                                  [post.id]: e.target.value
                                }))
                              }
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleCommentSubmit(post.id);
                              }}
                              placeholder={t('writeResponse', 'Share your observation or experience...')}
                              className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-3.5 py-2 text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                            />
                            <button
                              onClick={() => handleCommentSubmit(post.id)}
                              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-900 rounded-xl text-xs font-bold flex items-center gap-1 transition"
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Reply</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ─── TAB 2: MY CROP PHOTOS (HISTORY & GROWTH TIMELINE) ─────── */}
      {activeSubTab === 'my-crops' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap bg-slate-50 border border-slate-100 rounded-2xl p-4">
            <div>
              <h3 className="text-slate-900 font-bold text-sm">
                📷 {t('myCropPhotos', 'My Crop Photos')} ({myCropHistory.reduce((s, g) => s + g.posts.length, 0)} total)
              </h3>
              <p className="text-slate-400 text-xs">
                Photos are chronologically categorized to help you compare progress and spot growth patterns.
              </p>
            </div>
            <button
              onClick={onOpenShowCrop}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-900 rounded-xl text-xs font-bold flex items-center gap-2"
            >
              <Camera className="w-4 h-4" />
              <span>{t('takeCropPhoto', 'Take Photo')}</span>
            </button>
          </div>

          {myCropHistory.length === 0 ? (
            <div className="text-center py-16 bg-white border border-slate-100 rounded-3xl p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-3xl mx-auto">
                🌱
              </div>
              <h3 className="text-slate-900 font-bold text-base">You haven't uploaded any crop photos yet</h3>
              <p className="text-slate-400 text-xs max-w-md mx-auto">
                Take a quick snapshot of your Ragi, Tomato, or vegetables to start tracking your crop history.
              </p>
              <button
                onClick={onOpenShowCrop}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-900 rounded-xl text-xs font-bold"
              >
                📷 Show My Crop
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {myCropHistory.map((group, gIdx) => (
                <div
                  key={gIdx}
                  className="bg-slate-50 border border-slate-100 rounded-3xl p-5 sm:p-6 space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🌾</span>
                      <div>
                        <h4 className="text-slate-900 font-black text-sm sm:text-base">
                          {group.crop}
                        </h4>
                        <p className="text-emerald-400 text-xs font-bold">{group.monthYear}</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full text-xs font-bold">
                      📷 {group.posts.length} {group.posts.length === 1 ? 'Photo' : 'Photos'}
                    </span>
                  </div>

                  {/* Thumbnail Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {group.posts.map((post) => {
                      const isSelectedForCompare = compareSelection.includes(post.id);

                      return (
                        <div
                          key={post.id}
                          className="bg-white border border-slate-100 rounded-2xl overflow-hidden flex flex-col justify-between group hover:border-emerald-600/60 transition"
                        >
                          <div className="relative aspect-video overflow-hidden">
                            <img
                              src={post.image_url}
                              alt={post.crop_name}
                              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                            />
                            <div className="absolute top-2 left-2 bg-white/80 px-2 py-0.5 rounded-lg text-[10px] text-slate-900 font-bold backdrop-blur">
                              {post.date}
                            </div>
                            <button
                              onClick={() => setLightboxPost(post)}
                              className="absolute bottom-2 right-2 bg-slate-50/80 hover:bg-slate-50 text-slate-900 p-1.5 rounded-lg backdrop-blur text-xs"
                              title="Enlarge photo"
                            >
                              <Maximize2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="p-3.5 space-y-2">
                            <p className="text-slate-300 text-xs line-clamp-2">
                              {post.description || 'No notes added.'}
                            </p>

                            <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100">
                              <span className="text-slate-500">
                                💬 {post.comments ? post.comments.length : 0} replies
                              </span>
                              <button
                                onClick={() => {
                                  if (isSelectedForCompare) {
                                    setCompareSelection((prev) => prev.filter((id) => id !== post.id));
                                  } else {
                                    if (compareSelection.length >= 2) {
                                      setCompareSelection([compareSelection[1], post.id]);
                                    } else {
                                      setCompareSelection((prev) => [...prev, post.id]);
                                    }
                                  }
                                }}
                                className={`px-2 py-1 rounded-lg font-bold text-[10px] transition ${
                                  isSelectedForCompare
                                    ? 'bg-amber-500 text-slate-900'
                                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                                }`}
                              >
                                {isSelectedForCompare ? '✓ In Compare' : '+ Compare'}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ─── TAB 3: GROWTH COMPARISON ───────────────────────────────── */}
      {activeSubTab === 'compare' && (
        <div className="bg-slate-50 border border-slate-100 rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 flex-wrap gap-2">
            <div>
              <h3 className="text-slate-900 font-black text-base flex items-center gap-2">
                🔄 Crop Growth Comparison Tool
              </h3>
              <p className="text-slate-400 text-xs">
                Compare two stages of your crop side-by-side to monitor leaf color, height, and pest recovery.
              </p>
            </div>
            {compareSelection.length > 0 && (
              <button
                onClick={() => setCompareSelection([])}
                className="text-xs text-rose-400 hover:text-rose-300 font-bold"
              >
                Clear Selection
              </button>
            )}
          </div>

          {compareSelection.length < 2 ? (
            <div className="p-8 text-center bg-slate-100 text-slate-700 border border-dashed border-slate-100 rounded-2xl space-y-3">
              <p className="text-slate-400 text-xs">
                Please select 2 photos from the <strong>"My Crop Photos"</strong> tab using the <strong>"+ Compare"</strong> button.
              </p>
              <button
                onClick={() => setActiveSubTab('my-crops')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-900 rounded-xl text-xs font-bold"
              >
                Go to My Crop Photos
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {compareSelection.map((id, idx) => {
                const post = cropPosts.find((p) => p.id === id);
                if (!post) return null;

                return (
                  <div
                    key={post.id}
                    className="bg-white border border-slate-100 rounded-2xl overflow-hidden p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-emerald-400 uppercase tracking-wider">
                        Stage {idx + 1}: {post.date}
                      </span>
                      <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded-full text-[10px] font-bold">
                        🌾 {post.crop_name}
                      </span>
                    </div>

                    <div className="aspect-video rounded-xl overflow-hidden border border-slate-100">
                      <img
                        src={post.image_url}
                        alt={post.crop_name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div>
                      <p className="text-slate-300 text-xs leading-relaxed">
                        <strong>Notes:</strong> {post.description || 'No description entered.'}
                      </p>
                      <p className="text-slate-500 text-[11px] mt-1">
                        📍 {post.location} · 🏡 {post.farm_name}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ─── Lightbox Photo Inspection Modal ──────────────────────── */}
      {lightboxPost && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-3xl w-full bg-slate-50 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl animate-scale-up space-y-4">
            <div className="bg-white px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">🌾</span>
                <div>
                  <h4 className="text-slate-900 font-bold text-sm">
                    {lightboxPost.crop_name} · {lightboxPost.farmer_name}
                  </h4>
                  <p className="text-slate-400 text-[11px]">
                    {lightboxPost.location} · {lightboxPost.date}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setLightboxPost(null)}
                className="text-slate-400 hover:text-slate-900 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-4">
              <div className="max-h-[60vh] overflow-hidden rounded-2xl border border-slate-100 bg-black flex items-center justify-center">
                <img
                  src={lightboxPost.image_url}
                  alt={lightboxPost.crop_name}
                  className="max-h-[60vh] w-auto object-contain"
                />
              </div>
            </div>

            <div className="px-5 pb-5 space-y-2">
              <p className="text-slate-800 text-xs leading-relaxed">
                “{lightboxPost.description || 'No detailed observations recorded.'}”
              </p>
              <div className="flex justify-end pt-2 border-t border-slate-100">
                <button
                  onClick={() => setLightboxPost(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-900 rounded-xl text-xs font-bold"
                >
                  Close Inspection
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
