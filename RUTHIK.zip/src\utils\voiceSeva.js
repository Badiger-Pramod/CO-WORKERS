// Voice Seva Intent Engine — SIH26089
// Rule-based NLP: No real AI API required.
// Real STT/TTS APIs can be plugged in at the clearly defined interface boundaries.

import { VOICE_INTENTS, DEMO_VOICE_SCRIPTS } from '../data/agriMockData';

// ─── Language Detection ──────────────────────────────────────────────────────
// Simple script-range detection (covers Indian scripts used in our platform)
export const detectLanguage = (text) => {
  if (!text || typeof text !== 'string') return 'en';
  const t = text.trim();

  // Kannada Unicode range: \u0C80–\u0CFF
  if (/[\u0C80-\u0CFF]/.test(t)) return 'kn';
  // Telugu: \u0C00–\u0C7F
  if (/[\u0C00-\u0C7F]/.test(t)) return 'te';
  // Tamil: \u0B80–\u0BFF
  if (/[\u0B80-\u0BFF]/.test(t)) return 'ta';
  // Devanagari (Hindi/Marathi): \u0900–\u097F
  if (/[\u0900-\u097F]/.test(t)) {
    // Marathi-specific characters (ळ, ॅ)
    if (/[\u0933\u093D]/.test(t)) return 'mr';
    return 'hi';
  }
  // Bengali: \u0980–\u09FF
  if (/[\u0980-\u09FF]/.test(t)) return 'bn';
  // Malayalam: \u0D00–\u0D7F
  if (/[\u0D00-\u0D7F]/.test(t)) return 'ml';

  return 'en';
};

// ─── Intent Matching ─────────────────────────────────────────────────────────
// Scores each intent by keyword overlap. Returns the best matching intentId or null.
export const detectIntent = (text, langCode = 'en') => {
  if (!text) return null;
  const lower = text.toLowerCase();

  let bestScore = 0;
  let bestIntent = null;

  for (const [intentId, intent] of Object.entries(VOICE_INTENTS)) {
    const keywordsForLang = intent.keywords[langCode] || intent.keywords['en'] || [];
    let score = 0;
    for (const kw of keywordsForLang) {
      if (lower.includes(kw.toLowerCase())) {
        // Longer keywords score more (more specific)
        score += kw.length > 4 ? 2 : 1;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestIntent = intentId;
    }
  }

  // Minimum threshold — at least 1 keyword must match
  return bestScore > 0 ? bestIntent : 'general_farming';
};

// ─── Response Generator ──────────────────────────────────────────────────────
export const generateResponse = (intentId, langCode = 'en') => {
  const intent = VOICE_INTENTS[intentId];
  if (!intent) {
    return {
      text: getNotUnderstoodMessage(langCode),
      disclaimer: null,
      requiresWorker: false,
      serviceCategory: null,
      intentId: null,
    };
  }

  const langResponses = intent.responses;
  const responseText = langResponses[langCode] || langResponses['en'];
  const disclaimer = intent.disclaimer
    ? (intent.disclaimerText?.[langCode] || intent.disclaimerText?.['en'] || null)
    : null;

  return {
    text: responseText,
    disclaimer,
    requiresWorker: intent.requiresWorker,
    serviceCategory: intent.serviceCategory,
    intentId,
    priority: intent.priority || 'normal',
  };
};

// ─── Full Pipeline ────────────────────────────────────────────────────────────
// Single entry point: text → { lang, intent, response, ... }
export const processVoiceInput = (spokenText, preferredLang = null) => {
  const detectedLang = preferredLang || detectLanguage(spokenText);
  const intentId = detectIntent(spokenText, detectedLang);
  const response = generateResponse(intentId, detectedLang);

  return {
    originalText: spokenText,
    detectedLang,
    intentId,
    ...response,
  };
};

// ─── Fallback Messages ────────────────────────────────────────────────────────
export const getNotUnderstoodMessage = (lang = 'en') => {
  const messages = {
    en: "I didn't quite understand that. Please try speaking again about your farm or crop needs.",
    kn: "ನನಗೆ ಅರ್ಥವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ನಿಮ್ಮ ಕೃಷಿ ಅಥವಾ ಬೆಳೆಯ ಅಗತ್ಯಗಳ ಬಗ್ಗೆ ಮತ್ತೆ ಮಾತನಾಡಿ.",
    hi: "मैं समझ नहीं पाया। कृपया अपनी खेती या फसल की जरूरत के बारे में फिर से बोलें।",
    te: "నాకు అర్థం కాలేదు. మీ వ్యవసాయం లేదా పంట అవసరాల గురించి మళ్ళీ చెప్పండి.",
    ta: "புரியவில்லை. உங்கள் விவசாயம் அல்லது பயிர் தேவைகளைப் பற்றி மீண்டும் பேசுங்கள்.",
    mr: "मला समजले नाही. कृपया तुमच्या शेती किंवा पिकाच्या गरजांबद्दल पुन्हा बोला.",
    bn: "বুঝতে পারিনি। আপনার কৃষি বা ফসলের প্রয়োজন সম্পর্কে আবার বলুন।",
  };
  return messages[lang] || messages.en;
};

// ─── TTS Mock Interface ───────────────────────────────────────────────────────
// Uses Web Speech API (built into modern browsers) — no API key needed.
// Clearly marked as a browser-native feature, not a real AI TTS service.

export const speakText = (text, langCode = 'en') => {
  return new Promise((resolve, reject) => {
    if (!window.speechSynthesis) {
      console.warn('[VoiceSeva] Web Speech API not available in this browser.');
      resolve(); // Fail gracefully
      return;
    }

    window.speechSynthesis.cancel(); // Stop any ongoing speech

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = langCodeToLocale(langCode);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.onend = resolve;
    utterance.onerror = (e) => {
      console.warn('[VoiceSeva] TTS error:', e);
      resolve(); // Fail gracefully
    };

    window.speechSynthesis.speak(utterance);
  });
};

export const stopSpeaking = () => {
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
};

// ─── STT Mock Interface ───────────────────────────────────────────────────────
// Uses Web Speech API for real STT when available.
// Falls back to simulated demo mode clearly labeled as "DEMO".

export const startListening = (langCode = 'en', onResult, onEnd, onError) => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    console.warn('[VoiceSeva] SpeechRecognition not available. Demo mode will be used.');
    onError && onError('not_supported');
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = langCodeToLocale(langCode);
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.continuous = false;

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    onResult && onResult(transcript);
  };

  recognition.onend = () => onEnd && onEnd();
  recognition.onerror = (e) => {
    console.warn('[VoiceSeva] STT error:', e.error);
    onError && onError(e.error);
  };

  recognition.start();
  return recognition;
};

// ─── Demo Mode STT Simulation ─────────────────────────────────────────────────
// Returns the pre-scripted demo sentence for the given language.
// Clearly marked as DEMO simulation.
export const getDemoScript = (langCode = 'en') => {
  return DEMO_VOICE_SCRIPTS[langCode] || DEMO_VOICE_SCRIPTS['en'];
};

// ─── Language Code → Browser Locale ──────────────────────────────────────────
export const langCodeToLocale = (code) => {
  const map = {
    en: 'en-IN',
    kn: 'kn-IN',
    hi: 'hi-IN',
    te: 'te-IN',
    ta: 'ta-IN',
    mr: 'mr-IN',
    bn: 'bn-IN',
    ml: 'ml-IN',
  };
  return map[code] || 'en-IN';
};

// ─── SmartMatch Scoring for Agriculture Workers ───────────────────────────────
export const calculateAgriSmartMatch = (workers, serviceCategory, farmerLang = 'en') => {
  return workers
    .map((worker) => {
      let score = 0;
      const reasons = [];

      // 1. Skill match (35 pts)
      const skillMatch = worker.serviceCategories?.some(
        (cat) => cat.toLowerCase().includes(serviceCategory?.toLowerCase() || '')
      );
      if (skillMatch) {
        score += 35;
        reasons.push('Skill match');
      } else if (worker.skills?.some((s) => s.toLowerCase().includes(serviceCategory?.toLowerCase() || ''))) {
        score += 20;
        reasons.push('Partial skill match');
      }

      // 2. Distance (25 pts) — closer = better
      const distScore = Math.max(0, 25 - worker.distanceKm * 1.5);
      score += distScore;
      if (distScore > 15) reasons.push(`${worker.distanceKm} km away`);

      // 3. Availability (20 pts)
      if (worker.available) {
        score += 20;
        reasons.push('Available now');
      }

      // 4. Rating (10 pts)
      score += (worker.rating / 5) * 10;

      // 5. Experience (10 pts)
      score += Math.min(10, worker.experience);

      // 6. Language bonus (10 pts)
      if (worker.languages?.includes(farmerLang)) {
        score += 10;
        reasons.push(`Speaks ${farmerLang}`);
      }

      // 7. Cooperative membership bonus (5 pts)
      if (worker.coopMember) {
        score += 5;
        reasons.push('Co-op member');
      }

      return { ...worker, matchScore: Math.round(score), matchReasons: reasons };
    })
    .sort((a, b) => b.matchScore - a.matchScore);
};
