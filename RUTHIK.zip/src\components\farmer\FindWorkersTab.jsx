import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Users,
  Sparkles,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  ShieldCheck,
  Star,
  Award,
  Filter,
  DollarSign,
  ArrowRight,
  PhoneCall,
  ChevronDown
} from 'lucide-react';
import { FARM_WORK_TYPES, AGRI_WORKERS } from '../../data/agriMockData';

export const FindWorkersTab = ({ onBookingCreated }) => {
  const { currentFarmer, createFarmerLabourRequest, t } = useCoop();
  const farmer = currentFarmer || {};

  const [workType, setWorkType] = useState('Harvesting');
  const [crop, setCrop] = useState(farmer.primaryCrop || 'Ragi');
  const [workersCount, setWorkersCount] = useState(2);
  const [date, setDate] = useState('Tomorrow (06 Oct 2026)');
  const [duration, setDuration] = useState('1 Day');
  const [durationDays, setDurationDays] = useState(1);
  const [location, setLocation] = useState(farmer.location || 'Tumakuru Rural');
  const [dailyWage, setDailyWage] = useState(350);
  const [specialReq, setSpecialReq] = useState('Require sickle harvesting and bundle tying');
  const [isSearching, setIsSearching] = useState(false);
  const [searchInitiated, setSearchInitiated] = useState(true);

  // Compute calculated budget
  const estimatedTotalBudget = Number(workersCount) * Number(dailyWage) * Number(durationDays);

  // Available agricultural workers
  const matchedWorkers = AGRI_WORKERS.filter(w => w.primaryTrade === 'Agricultural Worker' || w.skills.includes(workType) || w.available);

  const handleSearchSubmit = (e) => {
    e?.preventDefault();
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setSearchInitiated(true);
    }, 600);
  };

  const handleHireWorker = (worker) => {
    const booking = createFarmerLabourRequest({
      workType,
      crop,
      workersCount,
      date,
      duration,
      durationDays,
      location,
      budget: estimatedTotalBudget,
      workerId: worker.id,
      workerName: `${worker.name} (Crew of ${workersCount})`,
      specialRequirements: specialReq
    });

    if (onBookingCreated) {
      onBookingCreated(booking);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ─── Header & Description ──────────────────────────────────── */}
      <div>
        <div className="flex items-center gap-2">
          <span className="text-2xl">🌾</span>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            Find Farm Labour & Harvesting Crew
          </h2>
        </div>
        <p className="text-slate-500 text-xs sm:text-sm mt-1">
          SmartMatch AI connects you with verified local agricultural workers, cooperative labour pools, and harvesting crews.
        </p>
      </div>

      {/* ─── Labour Request Form (Section 5) ────────────────────────── */}
      <form onSubmit={handleSearchSubmit} className="bg-white border border-slate-200/90 rounded-2xl shadow-2xs p-5 sm:p-7 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <h3 className="text-slate-900 font-bold text-base flex items-center gap-2">
            📝 Farm Labour Request Specification
          </h3>
          <span className="text-xs text-emerald-800 font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800 px-3 py-1 rounded-full">
            Standard Rate: ₹350 - ₹400 / worker / day
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Work Type */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Work Type <span className="text-rose-400">*</span>
            </label>
            <select
              value={workType}
              onChange={(e) => setWorkType(e.target.value)}
              className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
            >
              {FARM_WORK_TYPES.map((wt) => (
                <option key={wt} value={wt}>{wt}</option>
              ))}
            </select>
          </div>

          {/* Crop */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Target Crop <span className="text-rose-400">*</span>
            </label>
            <select
              value={crop}
              onChange={(e) => setCrop(e.target.value)}
              className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
            >
              <option value="Ragi">Ragi (Finger Millet)</option>
              <option value="Groundnut">Groundnut</option>
              <option value="Tomato">Tomato</option>
              <option value="Paddy">Paddy / Rice</option>
              <option value="Maize">Maize / Corn</option>
              <option value="Sugarcane">Sugarcane</option>
              <option value="Chilli">Chilli / Pepper</option>
              <option value="Pulses">Pulses / Tur Dal</option>
              <option value="Mixed">Mixed Farm / General</option>
            </select>
          </div>

          {/* Number of Workers */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Number of Workers <span className="text-rose-400">*</span>
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="25"
                value={workersCount}
                onChange={(e) => setWorkersCount(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
              />
              <span className="text-xs text-slate-400 font-bold whitespace-nowrap">People</span>
            </div>
          </div>

          {/* Expected Duration */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Expected Duration
            </label>
            <select
              value={duration}
              onChange={(e) => {
                setDuration(e.target.value);
                setDurationDays(e.target.value.includes('2') ? 2 : e.target.value.includes('3') ? 3 : e.target.value.includes('Week') ? 7 : 1);
              }}
              className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
            >
              <option value="1 Day">1 Day (7 AM - 2 PM)</option>
              <option value="2 Days">2 Days</option>
              <option value="3 Days">3 Days</option>
              <option value="1 Week">1 Week (6 Working Days)</option>
              <option value="Half Day">Half Day (4 Hours)</option>
            </select>
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Start Date
            </label>
            <input
              type="text"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Farm Location */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Farm Location (Village / Land)
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Daily Wage / Worker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Daily Wage Rate (₹ / Day)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-xs">₹</span>
              <input
                type="number"
                min="250"
                step="25"
                value={dailyWage}
                onChange={(e) => setDailyWage(Math.max(250, parseInt(e.target.value) || 350))}
                className="w-full pl-7 pr-3 bg-white border border-slate-300 text-slate-800 rounded-xl py-2.5 text-xs font-semibold focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Estimated Total Budget */}
          <div>
            <label className="block text-xs font-bold text-emerald-800 mb-1.5">
              Total Estimated Budget
            </label>
            <div className="bg-emerald-950/70 border border-emerald-800 rounded-xl px-3.5 py-2.5 flex items-center justify-between text-xs">
              <span className="text-slate-300 font-semibold">{workersCount} × ₹{dailyWage} × {durationDays}d</span>
              <span className="text-emerald-800 font-black text-sm">₹{estimatedTotalBudget}</span>
            </div>
          </div>
        </div>

        {/* Special Requirements */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1.5">
            Special Notes / Requirements
          </label>
          <input
            type="text"
            value={specialReq}
            onChange={(e) => setSpecialReq(e.target.value)}
            placeholder="e.g. Early morning shift, bring harvesting sickles, tea will be provided"
            className="w-full bg-white border border-slate-300 text-slate-800 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            disabled={isSearching}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 transition shadow-lg shadow-emerald-500/20 active:scale-95 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            {isSearching ? 'Calculating SmartMatch Scores...' : 'Match Farm Labour with SmartMatch AI'}
          </button>
        </div>
      </form>

      {/* ─── SmartMatch AI Recommendations (Section 6) ─────────────── */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-white font-black text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-800" />
              SmartMatch AI Recommended Workers & Crews ({matchedWorkers.length})
            </h3>
            <p className="text-slate-400 text-xs">
              Scored by agricultural skill match (35%), proximity (25%), availability (20%), and community rating (20%).
            </p>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span>Available for {date}</span>
          </div>
        </div>

        {/* Worker Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {matchedWorkers.map((worker, idx) => {
            const isTopMatch = idx === 0; // Manjunath Gowda
            const matchScore = isTopMatch ? 96 : 89 - (idx * 5);

            return (
              <div
                key={worker.id}
                className={`relative bg-white border rounded-2xl shadow-2xs p-5 flex flex-col justify-between transition-all group ${
                  isTopMatch
                    ? 'border-emerald-500/80 shadow-lg shadow-emerald-500/10'
                    : 'border-slate-200 hover:border-emerald-600'
                }`}
              >
                {/* Top Match Tag */}
                {isTopMatch && (
                  <div className="absolute -top-3 left-6 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-[10px] font-black uppercase tracking-wider px-3 py-0.5 rounded-full shadow">
                    🏆 Top SmartMatch Candidate
                  </div>
                )}

                <div>
                  {/* Top row */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-2xl flex-shrink-0">
                        {worker.avatar}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-white font-black text-sm">{worker.name}</h4>
                          {worker.verified && (
                            <ShieldCheck className="w-4 h-4 text-emerald-800" title="Cooperative Verified" />
                          )}
                        </div>
                        <p className="text-emerald-800 text-xs font-semibold">
                          {worker.primarySkill}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="bg-emerald-900/80 text-emerald-800 text-xs font-black px-2.5 py-1 rounded-full border border-emerald-700">
                        {matchScore}% Match
                      </span>
                    </div>
                  </div>

                  {/* Worker Stats */}
                  <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-100 text-center text-xs">
                    <div>
                      <span className="text-slate-400 text-[10px] block">Rating</span>
                      <span className="text-amber-400 font-bold flex items-center justify-center gap-0.5">
                        <Star className="w-3 h-3 fill-amber-400" /> {worker.rating}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">Experience</span>
                      <span className="text-white font-bold">{worker.experience} yrs</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">Jobs Done</span>
                      <span className="text-emerald-800 font-bold">{worker.completedFarmJobs || worker.completedJobs}</span>
                    </div>
                  </div>

                  {/* Location & Wage */}
                  <div className="mt-4 space-y-1.5 text-xs text-slate-300">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-emerald-800" /> {worker.location}
                      </span>
                      <span className="text-slate-400 font-semibold">{worker.distanceKm} km away</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Daily Rate:</span>
                      <span className="text-white font-bold">{worker.expectedCost || `₹${worker.dailyRate}/day`}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Languages:</span>
                      <span className="text-slate-200 uppercase font-semibold text-[10px]">
                        {worker.languages?.join(', ')}
                      </span>
                    </div>
                  </div>

                  {/* Skill Badges */}
                  <div className="flex flex-wrap gap-1 mt-3">
                    {worker.skills?.slice(0, 3).map((skill) => (
                      <span
                        key={skill}
                        className="bg-slate-100 text-slate-700 text-slate-300 text-[10px] px-2 py-0.5 rounded-md font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Hire CTA */}
                <div className="mt-5 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => handleHireWorker(worker)}
                    className="w-full py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-black text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md shadow-emerald-600/20"
                  >
                    <span>Hire {workersCount > 1 ? `Crew (${workersCount} Workers)` : 'Worker'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
