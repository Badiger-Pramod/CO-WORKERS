import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  X,
  ShieldCheck,
  Calendar,
  Clock,
  MapPin,
  FileText,
  Percent,
  HeartHandshake,
  ArrowRight,
  Info,
  Award,
  Sparkles
} from 'lucide-react';

export const BookingModal = () => {
  const {
    isBookingModalOpen,
    setIsBookingModalOpen,
    bookingWorker,
    createBooking
  } = useCoop();

  const [durationHours, setDurationHours] = useState(1.5);
  const [date, setDate] = useState('Today');
  const [timeSlot, setTimeSlot] = useState('2:30 PM - 3:30 PM');
  const [address, setAddress] = useState('Flat 402, Kaveri Nilaya, Siddaganga Ext, Tumakuru');
  const [notes, setNotes] = useState('Pipe leakage under kitchen sink, please bring sealing washers.');

  if (!isBookingModalOpen || !bookingWorker) return null;

  const worker = bookingWorker;
  const grossTotal = 500;
  const workerPayout = 400; // 80%
  const coopFee = 75;       // 15%
  const platformFee = 25;   // 5%

  const handleSubmit = (e) => {
    e.preventDefault();
    createBooking({
      worker,
      durationHours,
      date,
      timeSlot,
      address,
      notes
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-indigo-950 text-white p-6 flex justify-between items-start">
          <div className="flex items-center gap-4">
            <img
              src={worker.avatar}
              alt={worker.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-300 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold">{worker.name}</h3>
                <span className="bg-emerald-400/20 text-emerald-100 text-xs px-2.5 py-0.5 rounded-full border border-emerald-300/40 flex items-center gap-1 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
                  Class A Co-owner
                </span>
              </div>
              <p className="text-emerald-100 text-xs mt-0.5">{worker.title} • {worker.experienceYears}y exp • {worker.rating} ⭐</p>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">
                📍 {worker.location} ({worker.distanceKm} km away)
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsBookingModalOpen(false)}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Scheduling Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                Service Date
              </label>
              <select
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="Today">Today (Immediate)</option>
                <option value="Tomorrow">Tomorrow</option>
                <option value="Day After">Day After</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                Time Slot
              </label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="2:30 PM - 3:30 PM">2:30 PM - 3:30 PM (Recommended)</option>
                <option value="10:00 AM - 11:30 AM">10:00 AM - 11:30 AM</option>
                <option value="4:30 PM - 5:30 PM">4:30 PM - 5:30 PM</option>
                <option value="6:00 PM - 7:30 PM">6:00 PM - 7:30 PM</option>
              </select>
            </div>
          </div>

          {/* Address & Instructions */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              Service Address in Tumakuru
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              placeholder="House/Apartment number, street, area"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-600" />
              Special Notes / Task Description
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows="2"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              placeholder="Explain the job requirement..."
            />
          </div>

          {/* Transparent Cooperative Fee Breakdown Card */}
          <div className="bg-gradient-to-br from-emerald-50 via-teal-50/50 to-slate-50 p-4 rounded-2xl border border-emerald-200 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-emerald-200">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-700" />
                <span className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Transparent Democratic Price Breakdown
                </span>
              </div>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                100% Fair Pay
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-emerald-100 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-[11px]">
                    80%
                  </span>
                  <div>
                    <span className="font-bold text-slate-800">Direct Worker Compensation</span>
                    <p className="text-[10px] text-slate-500">Goes 100% directly to {worker.name.split(' ')[0]}</p>
                  </div>
                </div>
                <span className="font-black text-emerald-800">₹{workerPayout}</span>
              </div>

              <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-[11px]">
                    15%
                  </span>
                  <div>
                    <span className="font-bold text-slate-800">Co-op Welfare & Healthcare Fund</span>
                    <p className="text-[10px] text-slate-500">Mutual emergency medical pool and tool subsidies</p>
                  </div>
                </div>
                <span className="font-bold text-teal-700">₹{coopFee}</span>
              </div>

              <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-[11px]">
                    5%
                  </span>
                  <div>
                    <span className="font-bold text-slate-800">Platform Maintenance & Servers</span>
                    <p className="text-[10px] text-slate-500">Cloud hosting & open-source infrastructure</p>
                  </div>
                </div>
                <span className="font-bold text-indigo-700">₹{platformFee}</span>
              </div>

              {/* Total */}
              <div className="pt-2 flex justify-between items-center text-sm border-t border-emerald-200 font-black text-slate-900">
                <span>Total Amount Due on Completion:</span>
                <span className="text-lg text-emerald-900 font-black">₹{grossTotal}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsBookingModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all transform active:scale-95"
            >
              <span>Confirm Booking & Dispatch</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
