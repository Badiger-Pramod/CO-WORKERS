import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    cors: true,
    proxy: {
      // Forward /api/* to the Express server
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
      // Forward WebSocket /socket.io to the Express + Socket.io server
      '/socket.io': {
        target: 'http://localhost:5000',
        ws: true,
        changeOrigin: true,
      }
    },
  },
})
