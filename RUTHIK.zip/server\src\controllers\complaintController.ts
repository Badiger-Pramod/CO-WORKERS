import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';
import { Complaint, Notification } from '../types';
import { broadcastEvent } from '../services/socketService';

// GET /api/complaints
export const getComplaints = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, status } = req.query;
    let list = [...localStore.complaints];

    if (userId) {
      const uid = Number(userId);
      list = list.filter(c => c.user_id === uid);
    }

    if (status) {
      list = list.filter(c => c.status === status);
    }

    list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    res.json({ success: true, count: list.length, complaints: list });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch complaints.' });
  }
};

// POST /api/complaints
export const createComplaint = async (req: Request, res: Response): Promise<void> => {
  try {
    const { booking_id, user_id, user_name, category, description } = req.body;

    if (!user_id || !description || !category) {
      res.status(400).json({ success: false, message: 'User ID, category, and description are required.' });
      return;
    }

    const nextId = localStore.complaints.length ? Math.max(...localStore.complaints.map(c => c.id)) + 1 : 1;

    const newComplaint: Complaint = {
      id: nextId,
      booking_id: booking_id ? Number(booking_id) : undefined,
      user_id: Number(user_id),
      user_name: user_name || 'User',
      category: category as any,
      description,
      status: 'PENDING',
      created_at: new Date().toISOString()
    };

    localStore.complaints.unshift(newComplaint);

    // Notify Admin
    broadcastEvent('role_ADMIN', 'new_complaint', newComplaint);

    persistLocalStore();

    res.status(201).json({
      success: true,
      message: 'Complaint submitted to District Cooperative Board. Case ID #' + nextId,
      complaint: newComplaint
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to submit complaint.' });
  }
};

// PUT /api/complaints/:id/status
export const updateComplaintStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const { status, resolution_note } = req.body;

    const complaint = localStore.complaints.find(c => c.id === id);
    if (!complaint) {
      res.status(404).json({ success: false, message: 'Complaint not found.' });
      return;
    }

    complaint.status = status;
    if (resolution_note !== undefined) {
      complaint.resolution_note = resolution_note;
    }
    complaint.updated_at = new Date().toISOString();

    // Notify user of update
    const notifId = localStore.notifications.length ? Math.max(...localStore.notifications.map(n => n.id)) + 1 : 1;
    const notif: Notification = {
      id: notifId,
      user_id: complaint.user_id,
      title: `Complaint Status: ${status}`,
      message: resolution_note ? `Note from Co-op: ${resolution_note}` : `Your complaint #${complaint.id} is now ${status}.`,
      type: 'system',
      is_read: false,
      created_at: new Date().toISOString()
    };
    localStore.notifications.unshift(notif);

    persistLocalStore();

    broadcastEvent(`user_${complaint.user_id}`, 'complaint_updated', complaint);
    broadcastEvent(`user_${complaint.user_id}`, 'new_notification', notif);

    res.json({
      success: true,
      message: `Complaint #${id} updated to ${status}`,
      complaint
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update complaint status.' });
  }
};
