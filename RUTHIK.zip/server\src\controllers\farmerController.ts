import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';
import { FarmerProfile } from '../types';

// GET /api/farmers/:id
export const getFarmerProfile = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const u = localStore.users.find(user => user.id === userId);
    let fp = localStore.farmer_profiles.find(f => f.user_id === userId);

    if (!u) {
      res.status(404).json({ success: false, message: 'Farmer not found.' });
      return;
    }

    if (!fp) {
      // Auto-create initial farmer profile if missing
      fp = {
        id: localStore.farmer_profiles.length + 1,
        user_id: u.id,
        farm_name: `${u.full_name}'s Farm`,
        farm_size_acres: 3.5,
        crops: ['Ragi (Finger Millet)', 'Tomato'],
        soil_type: 'Red Loam',
        water_source: 'Borewell',
        irrigation_type: 'Drip',
        location: u.city || 'Tumakuru Rural',
        verification_status: 'Verified',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      localStore.farmer_profiles.push(fp);
      persistLocalStore();
    }

    res.json({
      success: true,
      farmer: {
        id: u.id,
        name: u.full_name,
        fullName: u.full_name,
        email: u.email,
        mobile: u.mobile,
        city: u.city,
        address: u.address,
        farm_name: fp.farm_name,
        farm_size_acres: fp.farm_size_acres,
        crops: fp.crops,
        soil_type: fp.soil_type,
        water_source: fp.water_source,
        irrigation_type: fp.irrigation_type,
        verification_status: fp.verification_status
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to retrieve farmer profile.' });
  }
};

// PUT /api/farmers/:id
export const updateFarmerProfile = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { farm_name, farm_size_acres, crops, soil_type, water_source, irrigation_type } = req.body;

    let fp = localStore.farmer_profiles.find(f => f.user_id === userId);
    if (!fp) {
      fp = {
        id: localStore.farmer_profiles.length + 1,
        user_id: userId,
        farm_name: farm_name || 'My Farm',
        farm_size_acres: Number(farm_size_acres) || 3.0,
        crops: Array.isArray(crops) ? crops : ['Ragi'],
        soil_type: soil_type || 'Red Sandy Loam',
        water_source: water_source || 'Borewell',
        irrigation_type: irrigation_type || 'Drip',
        verification_status: 'Verified',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      localStore.farmer_profiles.push(fp);
    } else {
      if (farm_name) fp.farm_name = farm_name;
      if (farm_size_acres) fp.farm_size_acres = Number(farm_size_acres);
      if (Array.isArray(crops)) fp.crops = crops;
      if (soil_type) fp.soil_type = soil_type;
      if (water_source) fp.water_source = water_source;
      if (irrigation_type) fp.irrigation_type = irrigation_type;
      fp.updated_at = new Date().toISOString();
    }

    persistLocalStore();

    res.json({
      success: true,
      message: 'Farm profile updated successfully!',
      farmerProfile: fp
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update farm profile.' });
  }
};

// POST /api/farmers/:id/crops
export const addCrop = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = Number(req.params.id);
    const { cropName } = req.body;

    if (!cropName || !cropName.trim()) {
      res.status(400).json({ success: false, message: 'Crop name is required.' });
      return;
    }

    const fp = localStore.farmer_profiles.find(f => f.user_id === userId);
    if (!fp) {
      res.status(404).json({ success: false, message: 'Farmer profile not found.' });
      return;
    }

    if (!fp.crops.includes(cropName.trim())) {
      fp.crops.push(cropName.trim());
      fp.updated_at = new Date().toISOString();
      persistLocalStore();
    }

    res.json({
      success: true,
      message: `Crop '${cropName}' added successfully!`,
      crops: fp.crops
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to add crop.' });
  }
};
