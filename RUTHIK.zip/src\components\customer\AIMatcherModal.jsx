import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Sparkles,
  Bot,
  Zap,
  ShieldCheck,
  Star,
  MapPin,
  CheckCircle2,
  ArrowRight,
  X,
  Sliders,
  Award,
  Clock
} from 'lucide-react';

export const AIMatcherModal = () => {
  const {
    isAIMatcherOpen,
    setIsAIMatcherOpen,
    workers,
    setBookingModalWorker,
    createBooking
  } = useCoop();

  const [promptText, setPromptText] = useState('My main circuit breaker is tripping whenever I turn on the kitchen geyser or microwave. Need an experienced technician with testing meter.');
  const [selectedUrgency, setSelectedUrgency] = useState('High');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [matchResults, setMatchResults] = useState(null);

  if (!isAIMatcherOpen) return null;

  const samplePrompts = [
    'MCB tripping & burning smell from electrical board in Indiranagar',
    'Kitchen sink drain pipe joint leaking water heavily onto cabinets',
    'Post-surgery elderly mobility care & vitals monitoring for grandmother',
    'Eco-friendly non-toxic deep kitchen degreasing & sofa steam wash'
  ];

  const handleRunAIMatch = (e) => {
    if (e) e.preventDefault();
    setIsAnalyzing(true);
    setMatchResults(null);

    setTimeout(() => {
      // Analyze text keywords to rank workers
      const text = promptText.toLowerCase();
      let matchedTrade = 'electrical';
      if (text.includes('leak') || text.includes('drain') || text.includes('pipe') || text.includes('pump')) {
        matchedTrade = 'plumbing';
      } else if (text.includes('elder') || text.includes('care') || text.includes('nurse') || text.includes('surgery')) {
        matchedTrade = 'caregiving';
      } else if (text.includes('clean') || text.includes('kitchen') || text.includes('sofa') || text.includes('stain')) {
        matchedTrade = 'cleaning';
      }

      // Rank workers: matched trade workers first with high AI scores
      const scored = workers.map(w => {
        let baseScore = 75;
        if (w.trade === matchedTrade) baseScore += 20;
        baseScore += (w.rating - 4.5) * 6;
        baseScore -= w.distanceKm * 1.5;
        const finalScore = Math.min(99, Math.max(70, Math.round(baseScore)));
        return {
          ...w,
          aiScore: finalScore,
          matchReasons: [
            w.trade === matchedTrade ? `Direct Trade Expert (${w.title})` : 'Multi-disciplinary Co-op Tradesperson',
            `${w.distanceKm} km nearby (~${Math.round(w.distanceKm * 4 + 4)} mins dispatch)`,
            `${w.rating} ★ Customer Satisfaction (${w.completedGigs} completed gigs)`
          ]
        };
      }).sort((a, b) => b.aiScore - a.aiScore);

      setMatchResults(scored.slice(0, 3));
      setIsAnalyzing(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white p-6 flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold">Sahakari AI Job Matcher</h3>
                <span className="bg-emerald-400/20 text-emerald-300 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border border-emerald-400/30">
                  Algorithmic Fairness
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Multi-objective matching: Trade Skills + Proximity + Member Equity + Fair 85% Wage
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAIMatcherOpen(false)}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          
          {/* Natural Language Prompt Input */}
          <form onSubmit={handleRunAIMatch} className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Describe your service requirement or problem symptoms:
            </label>
            <div className="relative">
              <textarea
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                rows="3"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                placeholder="E.g. Main MCB breaker tripping in Indiranagar, need certified electrician today..."
              />
            </div>

            {/* Quick Sample Suggestions */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] font-semibold text-slate-400">Suggestions:</span>
              {samplePrompts.map((sp, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => {
                    setPromptText(sp);
                  }}
                  className="text-[10px] bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-800 px-2.5 py-1 rounded-full border border-slate-200 transition-colors"
                >
                  {sp.slice(0, 35)}...
                </button>
              ))}
            </div>

            {/* Run Button */}
            <div className="flex justify-end pt-1">
              <button
                type="submit"
                disabled={isAnalyzing}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-xs font-bold shadow-md shadow-emerald-600/30 flex items-center gap-2 hover:opacity-95 transition-all"
              >
                <Sparkles className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
                {isAnalyzing ? 'Analyzing Co-op Registry...' : 'Compute AI Matches'}
              </button>
            </div>
          </form>

          {/* Matches Output List */}
          {matchResults && (
            <div className="space-y-3 pt-3 border-t border-slate-100 animate-fade-in">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Top Ranked Co-owner Matches:
                </span>
                <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  3 Optimal Candidates
                </span>
              </div>

              <div className="space-y-3">
                {matchResults.map((worker, rank) => (
                  <div
                    key={worker.id}
                    className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-400 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <div className="relative">
                        <img
                          src={worker.avatar}
                          alt={worker.name}
                          className="w-12 h-12 rounded-xl object-cover border border-emerald-400 shadow-xs"
                        />
                        <span className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] font-black flex items-center justify-center">
                          #{rank + 1}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-900 text-sm">{worker.name}</h4>
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                            {worker.aiScore}% Match
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">{worker.title}</p>
                        <div className="flex flex-wrap gap-1 pt-1">
                          {worker.matchReasons.map((r, i) => (
                            <span key={i} className="text-[10px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                              ✓ {r}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-end justify-between w-full sm:w-auto gap-2 shrink-0">
                      <div className="text-right">
                        <span className="text-base font-extrabold text-slate-900">₹{worker.hourlyRate}</span>
                        <span className="text-xs text-slate-500">/hr</span>
                      </div>
                      <button
                        onClick={() => {
                          setIsAIMatcherOpen(false);
                          setBookingModalWorker(worker);
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all"
                      >
                        Book Worker
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
