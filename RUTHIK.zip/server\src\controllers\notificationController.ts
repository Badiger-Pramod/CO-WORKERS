import { Request, Response } from 'express';
import { localStore, persistLocalStore } from '../config/db';

// GET /api/notifications
export const getNotifications = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.query;
    let notifs = [...localStore.notifications];

    if (userId) {
      const uid = Number(userId);
      notifs = notifs.filter(n => n.user_id === uid);
    }

    notifs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    res.json({
      success: true,
      unread_count: notifs.filter(n => !n.is_read).length,
      notifications: notifs
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch notifications.' });
  }
};

// PUT /api/notifications/:id/read
export const markNotificationRead = async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const notif = localStore.notifications.find(n => n.id === id);
    if (!notif) {
      res.status(404).json({ success: false, message: 'Notification not found.' });
      return;
    }

    notif.is_read = true;
    persistLocalStore();

    res.json({ success: true, notification: notif });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update notification.' });
  }
};

// PUT /api/notifications/read-all
export const markAllNotificationsRead = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.body;
    if (userId) {
      const uid = Number(userId);
      localStore.notifications.forEach(n => {
        if (n.user_id === uid) n.is_read = true;
      });
    } else {
      localStore.notifications.forEach(n => {
        n.is_read = true;
      });
    }

    persistLocalStore();
    res.json({ success: true, message: 'All notifications marked as read.' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to mark notifications.' });
  }
};
