import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Wrench,
  Zap,
  Droplets,
  Tractor,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowRight,
  Filter,
  DollarSign
} from 'lucide-react';
import { FARM_SERVICES_MARKETPLACE } from '../../data/agriMockData';

export const FarmServicesTab = ({ onBookingCreated }) => {
  const { currentFarmer, setFarmerBookings, addNotification, showToast } = useCoop();
  const farmer = currentFarmer || {};

  const [selectedService, setSelectedService] = useState(null);
  const [scheduledDate, setScheduledDate] = useState('Tomorrow (06 Oct 2026)');
  const [scheduledTime, setScheduledTime] = useState('9:00 AM');
  const [location, setLocation] = useState(farmer.location || 'Tumakuru Rural');
  const [serviceNotes, setServiceNotes] = useState('Please bring necessary test kit / equipment');

  const handleBookService = (service) => {
    setSelectedService(service);
  };

  const handleConfirmServiceBooking = () => {
    if (!selectedService) return;

    const bookingId = `AGSRV-${Date.now().toString().slice(-6)}`;
    const cost = selectedService.basePrice;

    const newBooking = {
      id: bookingId,
      farmerId: farmer.id || 'farmer01',
      farmerName: farmer.fullName || farmer.name || 'Ravi Gowda',
      farmName: farmer.farmName || 'Green Valley Farm',
      bookingType: 'Service',
      title: selectedService.name,
      equipmentPhoto: selectedService.icon,
      serviceId: selectedService.id,
      category: selectedService.category,
      associatedWorkerTrade: selectedService.associatedWorkerTrade,
      date: scheduledDate,
      duration: 'Standard Visit',
      location: location,
      estimatedCost: cost,
      finalCost: cost,
      budget: cost,
      status: 'Scheduled',
      paymentStatus: 'Pending',
      paymentMethod: 'UPI (Co-op Escrow)',
      reviewed: false,
      rating: null,
      notes: serviceNotes,
      createdAt: new Date().toISOString()
    };

    setFarmerBookings((prev) => [newBooking, ...prev]);

    addNotification({
      forRole: 'Farmer',
      forUserId: farmer.id,
      title: `🌾 Service Booked: ${selectedService.name}`,
      message: `Your cooperative service request #${bookingId} has been confirmed for ${scheduledDate}.`
    });

    showToast(`Service "${selectedService.name}" booked successfully!`, 'success');
    setSelectedService(null);

    if (onBookingCreated) {
      onBookingCreated(newBooking);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Header ──────────────────────────────────────────────── */}
      <div className="border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">⚡</span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Farm Services & Technical Trades Marketplace
          </h2>
        </div>
        <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
          Connect your farm directly with cooperative trades specialists: electricians for borewells, plumbers for drip lines, and mechanization teams.
        </p>
      </div>

      {/* ─── Services Grid ────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {FARM_SERVICES_MARKETPLACE.map((srv) => (
          <div
            key={srv.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 flex flex-col justify-between transition group"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-2xl flex-shrink-0">
                    {srv.icon}
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-sm">{srv.name}</h3>
                    <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800">
                      Trade: {srv.associatedWorkerTrade}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-emerald-400 font-black text-sm block">₹{srv.basePrice}</span>
                  <span className="text-slate-500 text-[10px]">{srv.priceUnit}</span>
                </div>
              </div>

              <p className="text-slate-400 text-xs mt-3 leading-relaxed">
                {srv.description}
              </p>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-500 text-[11px]">Co-op Escrow Protected</span>
              <button
                onClick={() => handleBookService(srv)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-md shadow-emerald-600/20"
              >
                <span>Book Service</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ─── Service Booking Modal ─────────────────────────────────── */}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-5 animate-scale-up">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-white font-black text-base">
                  Confirm Service Booking
                </h3>
                <p className="text-emerald-400 text-xs font-semibold mt-0.5">
                  {selectedService.name} · ₹{selectedService.basePrice} ({selectedService.priceUnit})
                </p>
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-bold mb-1">Preferred Date</label>
                <input
                  type="text"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Preferred Time Window</label>
                <select
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="7:00 AM - 10:00 AM">Early Morning (7:00 AM - 10:00 AM)</option>
                  <option value="10:00 AM - 1:00 PM">Morning (10:00 AM - 1:00 PM)</option>
                  <option value="2:00 PM - 5:00 PM">Afternoon (2:00 PM - 5:00 PM)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Farm Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Issue Description / Instructions</label>
                <textarea
                  rows="2"
                  value={serviceNotes}
                  onChange={(e) => setServiceNotes(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="bg-slate-800 rounded-xl p-3 flex justify-between items-center text-xs">
                <span className="text-slate-400">Total Service Fee:</span>
                <span className="text-emerald-400 font-black text-sm">₹{selectedService.basePrice}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedService(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmServiceBooking}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95"
              >
                Confirm Service Visit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
