import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Briefcase,
  TrendingUp,
  Vote,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  MapPin,
  Sparkles,
  Award,
  DollarSign,
  HeartHandshake,
  Calendar,
  Layers,
  ChevronRight,
  FileCheck,
  AlertCircle,
  Users,
  Percent,
  PlusCircle,
  Phone,
  MessageSquare,
  Navigation,
  Star,
  ArrowRight,
  ShieldAlert,
  Radio,
  HelpCircle
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

export const WorkerPortal = () => {
  const {
    workers,
    bookings,
    dispatchRequests,
    acceptJobRequest,
    rejectJobRequest,
    updateBookingStatus,
    workerLedger,
    ratings,
    isWorkerAvailable,
    setIsWorkerAvailable,
    activeWorkerTab,
    setActiveWorkerTab,
    lang,
    showToast,
    addNotification
  } = useCoop();

  // Ravi Kumar profile
  const ravi = workers.find(w => w.id === 'w-ravi') || workers[0];

  // Active jobs assigned to Ravi
  const activeJobs = bookings.filter(b => b.workerId === ravi.id && b.status !== 'COMPLETED');

  // Democratic ballot state
  const [hasVoted, setHasVoted] = useState(false);
  const [voteChoice, setVoteChoice] = useState('yes');
  const [ballotVotes, setBallotVotes] = useState(301);

  // Emergency SOS Modal
  const [sosModalOpen, setSosModalOpen] = useState(false);
  const [sosSent, setSosSent] = useState(false);

  // Multilingual greetings
  const workerGreetings = {
    en: 'Welcome back, Ravi 👋',
    kn: 'ಮತ್ತೆ ಸುಸ್ವಾಗತ, ರವಿ 👋',
    hi: 'स्वागत है, रवि 👋'
  };

  // Recharts monthly data
  const monthlyEarningsData = [
    { month: 'Apr', takeHome: 22400, dividend: 2100 },
    { month: 'May', takeHome: 24800, dividend: 2400 },
    { month: 'Jun', takeHome: 26100, dividend: 2800 },
    { month: 'Jul', takeHome: 25400, dividend: 2600 },
    { month: 'Aug', takeHome: 27900, dividend: 3100 },
    { month: 'Sep', takeHome: 28450, dividend: 3450 }
  ];

  const handleToggleAvailability = () => {
    const newState = !isWorkerAvailable;
    setIsWorkerAvailable(newState);
    showToast(
      newState ? '🟢 You are now AVAILABLE for immediate dispatch in Tumakuru!' : '🔴 You are now OFFLINE.',
      newState ? 'success' : 'info'
    );
  };

  const handleCastVote = (choice) => {
    setHasVoted(true);
    setVoteChoice(choice);
    if (choice === 'yes') setBallotVotes(prev => prev + 1);
    showToast('Your vote has been recorded on the immutable cooperative ledger!', 'success');
  };

  const handleTriggerSOS = () => {
    setSosSent(true);
    addNotification({
      role: 'admin',
      title: '🚨 WORKER EMERGENCY DISTRESS BEACON',
      message: 'Ravi Kumar triggered Emergency SOS at Siddaganga Ext, Tumakuru! Nearest 6 co-owners notified.',
      type: 'sos'
    });
    showToast('🚨 SOS DISTRESS BEACON SENT! Nearest 6 Tumakuru Co-owners & Admin S. R. Patil notified.', 'error');
    setTimeout(() => {
      setSosModalOpen(false);
      setSosSent(false);
    }, 2500);
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Worker Profile Header Banner */}
      <section className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-700/50">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          
          <div className="flex items-start gap-4 sm:gap-5">
            <div className="relative">
              <img
                src={ravi.avatar}
                alt={ravi.name}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-emerald-400 shadow-md"
              />
              <span className="absolute -bottom-2 -right-1 bg-emerald-500 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-white">
                Co-owner
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-white">
                  {workerGreetings[lang] || workerGreetings['en']}
                </h1>
                <span className="bg-emerald-500/20 text-emerald-300 text-xs px-2.5 py-0.5 rounded-full border border-emerald-400/30 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Class A Co-owner
                </span>
              </div>
              <p className="text-slate-300 text-sm font-medium">
                {ravi.title} • {ravi.experienceYears} Years Experience
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1">
                <span>Hub: <strong className="text-white">Tumakuru Community Cooperative</strong></span>
                <span>• Rating: <strong className="text-amber-400">{ravi.rating} ⭐</strong> ({ravi.reviewCount} reviews)</span>
                <span>• Member ID: <strong className="text-white font-mono">KA-TMK-0428</strong></span>
              </div>
            </div>
          </div>

          {/* Controls: Availability Switch & Emergency SOS */}
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            {/* Availability Toggle */}
            <div className="bg-slate-800/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 flex items-center justify-between sm:justify-start gap-3 flex-1 sm:flex-initial">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                  Dispatch Status
                </span>
                <span className={`text-xs font-black flex items-center gap-1.5 ${isWorkerAvailable ? 'text-emerald-400' : 'text-slate-400'}`}>
                  <span className={`w-2 h-2 rounded-full ${isWorkerAvailable ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`}></span>
                  {isWorkerAvailable ? '🟢 Online' : '🔴 Offline'}
                </span>
              </div>

              <button
                onClick={handleToggleAvailability}
                className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all shadow-md ${
                  isWorkerAvailable
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                    : 'bg-slate-700 hover:bg-slate-600 text-white'
                }`}
              >
                {isWorkerAvailable ? 'Go Offline' : 'Go Online'}
              </button>
            </div>

            {/* Emergency SOS Button */}
            <button
              onClick={() => setSosModalOpen(true)}
              className="p-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-lg shadow-rose-600/30 flex items-center gap-2 transition-transform active:scale-95"
              title="Emergency SOS / Mutual Aid"
            >
              <ShieldAlert className="w-4 h-4 text-white animate-bounce" />
              <span>Co-op SOS</span>
            </button>
          </div>

        </div>
      </section>

      {/* 2. 6 KPI Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* KPI 1: Today's Jobs */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Today's Jobs</span>
          <p className="text-2xl font-black text-slate-900 mt-1">2</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">1 Completed</span>
        </div>

        {/* KPI 2: Pending Requests */}
        <div
          onClick={() => setActiveWorkerTab('requests')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-500 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Requests</span>
            {dispatchRequests.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            )}
          </div>
          <p className="text-2xl font-black text-rose-600 mt-1">{dispatchRequests.length}</p>
          <span className="text-[10px] text-slate-500 group-hover:text-emerald-700 font-semibold mt-1 block">
            Review Now ➔
          </span>
        </div>

        {/* KPI 3: Today's Earnings */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Today's Earnings</span>
          <p className="text-2xl font-black text-emerald-700 mt-1">₹{workerLedger.todayEarnings.toLocaleString()}</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">80% Net Pay</span>
        </div>

        {/* KPI 4: Monthly Earnings */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">September Total</span>
          <p className="text-2xl font-black text-slate-900 mt-1">₹{workerLedger.monthlyEarnings.toLocaleString()}</p>
          <span className="text-[10px] text-indigo-600 font-semibold mt-1 block">+14% vs Aug</span>
        </div>

        {/* KPI 5: Rating */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Reputation</span>
          <p className="text-2xl font-black text-amber-500 mt-1 flex items-center gap-1">
            {workerLedger.rating} <span className="text-base font-normal">⭐</span>
          </p>
          <span className="text-[10px] text-slate-500 font-semibold mt-1 block">189 Reviews</span>
        </div>

        {/* KPI 6: Completed Jobs */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Total Gigs</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{workerLedger.completedJobs}</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">99.2% on-time</span>
        </div>

      </div>

      {/* 3. Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'requests', label: 'Incoming Requests', icon: Briefcase, count: dispatchRequests.length },
          { id: 'jobs', label: 'Upcoming & Active Jobs', icon: Calendar, count: activeJobs.length },
          { id: 'earnings', label: 'Earnings & Co-op Ledger', icon: TrendingUp },
          { id: 'reviews', label: 'Customer Reviews', icon: Star },
          { id: 'cooperative', label: 'Tumakuru Co-op Hub', icon: Users }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeWorkerTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveWorkerTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 transition-all whitespace-nowrap ${
                isActive
                  ? 'border-emerald-600 text-emerald-800 bg-emerald-50/60 rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className={`px-2 py-0.5 text-[10px] rounded-full font-extrabold ${
                  isActive ? 'bg-emerald-600 text-white' : 'bg-rose-500 text-white'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* =========================================================================
          TAB 1: Incoming Job Requests
      ========================================================================= */}
      {activeWorkerTab === 'requests' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Nearby Customer Dispatch Requests</h3>
              <p className="text-xs text-slate-500">
                Matched via SmartMatch AI based on your proximity in Tumakuru. Zero forced acceptance penalties.
              </p>
            </div>
            <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-3 py-1 rounded-lg border border-emerald-200">
              {dispatchRequests.length} Pending Requests
            </span>
          </div>

          {dispatchRequests.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h4 className="text-lg font-bold text-slate-800">Dispatch Queue is Clear!</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                You have handled all incoming service requests. As soon as a customer books a plumbing gig in Tumakuru, it will pop up right here!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {dispatchRequests.map((req) => (
                <div
                  key={req.id}
                  className="bg-white rounded-3xl p-6 border-2 border-emerald-400/80 shadow-md hover:shadow-lg transition-all space-y-5 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded">
                          {req.id}
                        </span>
                        <h4 className="text-lg font-bold text-slate-900 mt-1">{req.serviceTitle}</h4>
                        <p className="text-xs text-slate-500">Customer: <strong className="text-slate-800">{req.customerName}</strong> ({req.coopCustomerBadge})</p>
                      </div>

                      <div className="text-right bg-emerald-50 p-2.5 rounded-2xl border border-emerald-200">
                        <span className="text-[10px] uppercase font-bold text-emerald-800 block">Your Fair Pay</span>
                        <span className="text-xl font-black text-emerald-700">₹{req.workerPayout}</span>
                        <span className="text-[10px] text-emerald-600 block">(80% Guaranteed)</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100 text-slate-700">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Address: <strong>{req.customerAddress}</strong> ({req.distanceKm} km)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>Requested Slot: <strong>{req.dateTime}</strong></span>
                      </div>
                    </div>

                    {req.notes && (
                      <p className="text-xs text-slate-600 italic bg-amber-50/70 p-3 rounded-xl border border-amber-200/60">
                        "{req.notes}"
                      </p>
                    )}
                  </div>

                  {/* Accept / Decline Action Buttons */}
                  <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => rejectJobRequest(req.id)}
                      className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                    >
                      <XCircle className="w-4 h-4 text-slate-400" />
                      <span>Pass to Peer</span>
                    </button>
                    <button
                      onClick={() => acceptJobRequest(req.id)}
                      className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-1.5 transform active:scale-95"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Accept Job (₹400)</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* =========================================================================
          TAB 2: Upcoming & Active Assigned Jobs
      ========================================================================= */}
      {activeWorkerTab === 'jobs' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Active Work Schedule</h3>
              <p className="text-xs text-slate-500">
                Update job stages in real-time to notify the customer and update the cooperative dispatch ledger.
              </p>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-800 font-bold px-3 py-1 rounded-lg border border-indigo-200">
              {activeJobs.length} Ongoing Gigs
            </span>
          </div>

          {activeJobs.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-2">
              <Clock className="w-10 h-10 text-slate-400 mx-auto" />
              <h4 className="font-bold text-slate-800">No Active Jobs Underway</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Check incoming requests to accept a new customer booking!
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {activeJobs.map((job) => (
                <div
                  key={job.id}
                  className="bg-white rounded-3xl border-2 border-emerald-500 p-6 sm:p-8 shadow-lg space-y-6"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                        <span className="text-xs font-bold uppercase tracking-widest text-emerald-700">
                          Active Dispatch Pipeline
                        </span>
                        <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                          #{job.id}
                        </span>
                      </div>
                      <h3 className="text-xl font-black text-slate-900 mt-1">{job.serviceTitle}</h3>
                      <p className="text-xs text-slate-500">{job.date} • {job.timeSlot}</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs bg-emerald-100 text-emerald-900 font-extrabold px-3 py-1 rounded-full">
                        Status: {job.status}
                      </span>
                    </div>
                  </div>

                  {/* Customer & Address Details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1">
                      <span className="font-bold text-slate-500 uppercase tracking-wider block text-[10px]">Customer</span>
                      <p className="text-sm font-black text-slate-900">{job.customerName}</p>
                      <p className="text-xs text-emerald-700 font-bold">{job.customerPhone}</p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1">
                      <span className="font-bold text-slate-500 uppercase tracking-wider block text-[10px]">Destination</span>
                      <p className="text-xs font-bold text-slate-900">{job.customerAddress}</p>
                      <p className="text-[11px] text-slate-500">Distance: {job.distanceKm} km</p>
                    </div>

                    <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 space-y-1">
                      <span className="font-bold text-emerald-800 uppercase tracking-wider block text-[10px]">Net Worker Share</span>
                      <p className="text-xl font-black text-emerald-800">₹{job.breakdown.workerPayout}</p>
                      <p className="text-[10px] text-emerald-700">Plus ₹{job.breakdown.coopFee} Co-op Fund</p>
                    </div>
                  </div>

                  {/* Step Transition Controls */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Update Dispatch Status:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => updateBookingStatus(job.id, 'ON_THE_WAY')}
                        disabled={job.status === 'ON_THE_WAY' || job.status === 'JOB_STARTED'}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                          job.status === 'ON_THE_WAY'
                            ? 'bg-purple-600 text-white ring-2 ring-purple-400'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <Navigation className="w-3.5 h-3.5" />
                        <span>1. Mark "On The Way"</span>
                      </button>

                      <button
                        onClick={() => updateBookingStatus(job.id, 'JOB_STARTED')}
                        disabled={job.status === 'JOB_STARTED'}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                          job.status === 'JOB_STARTED'
                            ? 'bg-amber-600 text-white ring-2 ring-amber-400'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>2. Mark "Job Started"</span>
                      </button>

                      <button
                        onClick={() => updateBookingStatus(job.id, 'COMPLETED')}
                        className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-md flex items-center gap-1.5 ml-auto"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>3. Mark "Completed" ➔ Release ₹400</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* =========================================================================
          TAB 3: Earnings & Co-op Ledger (Recharts)
      ========================================================================= */}
      {activeWorkerTab === 'earnings' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* 3 Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Monthly Net Payout</span>
              <p className="text-3xl font-black text-emerald-700 mt-2">₹{workerLedger.monthlyEarnings.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">Guaranteed 80% take-home</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Co-op Welfare Contribution</span>
              <p className="text-3xl font-black text-teal-700 mt-2">₹{workerLedger.coopContribution.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">Funds your health & accident cover</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Projected Q3 Dividend</span>
              <p className="text-3xl font-black text-amber-600 mt-2">₹3,450</p>
              <p className="text-xs text-slate-500 mt-1">Quarterly democratic profit share</p>
            </div>
          </div>

          {/* Recharts AreaChart of Earnings & Dividend */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h3 className="text-base font-bold text-slate-900">Monthly Take-Home & Patronage Dividend Growth</h3>
                <p className="text-xs text-slate-500">Ravi's verified earnings over the last 6 months in Tumakuru Hub</p>
              </div>
              <div className="flex items-center gap-4 text-xs font-bold">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <span>Net Pay (80%)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-amber-400"></span>
                  <span>Patronage Dividend</span>
                </div>
              </div>
            </div>

            <div className="h-72 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyEarningsData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="takeHomeGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                    </linearGradient>
                    <linearGradient id="divGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} tickFormatter={(val) => `₹${val/1000}k`} />
                  <Tooltip
                    formatter={(val) => [`₹${Number(val).toLocaleString()}`, '']}
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="takeHome" name="Worker Pay (80%)" stroke="#059669" strokeWidth={2.5} fillOpacity={1} fill="url(#takeHomeGrad)" />
                  <Area type="monotone" dataKey="dividend" name="Patronage Dividend" stroke="#d97706" strokeWidth={2.5} fillOpacity={1} fill="url(#divGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Patronage Dividend Formula Card */}
          <div className="bg-gradient-to-br from-amber-50 via-orange-50/40 to-slate-50 p-6 rounded-3xl border border-amber-200 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-600" />
                  Democratic Co-owner Dividend Formula
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-1">
                  How Ravi's Quarterly Profit Share is Computed
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              Unlike corporate platforms where excess commissions enrich venture capitalists, 100% of SevaSetu’s net operational surplus is distributed to worker members based on hours logged (ICA Principle 3).
            </p>

            <div className="bg-white p-4 rounded-2xl border border-amber-200 font-mono text-xs text-slate-800">
              <code className="text-amber-900 font-bold">
                Your Dividend = (Tumakuru Co-op Quarterly Surplus) × (Your Logged Hours ÷ Total Co-op Hours)
              </code>
            </div>
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 4: Customer Reviews
      ========================================================================= */}
      {activeWorkerTab === 'reviews' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Customer Feedback & Commendations</h3>
              <p className="text-xs text-slate-500">
                189 verified ratings across Tumakuru with a 4.8 / 5.0 overall score.
              </p>
            </div>
            <span className="text-xs bg-amber-100 text-amber-900 font-bold px-3 py-1 rounded-lg border border-amber-300">
              Top Rated in Tumakuru
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ratings.map((rev) => (
              <div
                key={rev.id}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{rev.customerName}</h4>
                    <p className="text-[11px] text-slate-400">{rev.serviceTitle} • {rev.date}</p>
                  </div>
                  <div className="flex items-center gap-1 text-amber-500 font-bold text-xs">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                    <span>{rev.rating}.0</span>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed italic">
                  "{rev.comment}"
                </p>

                <div className="flex flex-wrap gap-1.5 pt-2">
                  {rev.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-200"
                    >
                      ✓ {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* =========================================================================
          TAB 5: Tumakuru Co-op Hub & Democratic Voting
      ========================================================================= */}
      {activeWorkerTab === 'cooperative' && (
        <div className="space-y-6 animate-fade-in">
          
          <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 text-white p-6 sm:p-8 rounded-3xl shadow-xl space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-emerald-400">
              Federated District Society
            </span>
            <h2 className="text-2xl sm:text-3xl font-black">
              Tumakuru Community Services Cooperative Society Ltd.
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Reg #2026-KA-TMK-019 • Registered under Karnataka Souharda Sahakari Act. Operated by local workers with equal voting power.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">
                <span className="text-[10px] text-emerald-300 block">Worker Members</span>
                <span className="text-xl font-black text-white">342 Co-owners</span>
              </div>
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">
                <span className="text-[10px] text-emerald-300 block">Welfare Pool</span>
                <span className="text-xl font-black text-emerald-400">₹4.8 Lakhs</span>
              </div>
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">
                <span className="text-[10px] text-emerald-300 block">Your Voting Power</span>
                <span className="text-xl font-black text-amber-400">1 Equal Vote</span>
              </div>
              <div className="bg-white/10 p-3 rounded-2xl border border-white/10">
                <span className="text-[10px] text-emerald-300 block">Next Assembly</span>
                <span className="text-xl font-black text-white">Oct 12, 2026</span>
              </div>
            </div>
          </div>

          {/* Interactive Democratic Poll */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  Active Co-owner Ballot • 1 Member = 1 Vote
                </span>
                <h4 className="text-base font-bold text-slate-900 mt-1">
                  Proposal 2026-B4: Increase Emergency Medical Grant cap to ₹35,000
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Proposed by Tumakuru Guild Committee • Quorum: {Math.round((ballotVotes / 342) * 100)}% voted
                </p>
              </div>

              {hasVoted ? (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                  Your Vote Cast: {voteChoice.toUpperCase()} ✓
                </span>
              ) : (
                <span className="text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
                  Awaiting Your Vote
                </span>
              )}
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Allocates an additional ₹75,000 from the Tumakuru Welfare Surplus to cover unforeseen medical hospitalizations, emergency ambulance transit, and critical tool loss without requiring repayments.
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between font-bold text-slate-800">
                <span>In Favor: {ballotVotes} Votes ({Math.round((ballotVotes / 342) * 100)}%)</span>
                <span>Against: 18 Votes (5%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(95, (ballotVotes / 342) * 100)}%` }}
                ></div>
              </div>
            </div>

            {/* Voting Action Buttons */}
            {!hasVoted && (
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => handleCastVote('yes')}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Vote "IN FAVOR"</span>
                </button>
                <button
                  onClick={() => handleCastVote('no')}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Vote "AGAINST"</span>
                </button>
              </div>
            )}
          </div>

        </div>
      )}

      {/* Emergency Worker SOS Modal */}
      {sosModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-5 border-2 border-rose-500 text-center">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto ring-8 ring-rose-50 animate-bounce">
              <ShieldAlert className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-slate-900">Cooperative Emergency Mutual Aid</h3>
              <p className="text-xs text-slate-500">
                Instantly broadcast your live GPS distress beacon to the nearest Tumakuru cooperative workers & admin office.
              </p>
            </div>

            <div className="bg-rose-50 p-3.5 rounded-2xl border border-rose-200 text-xs text-rose-900 text-left space-y-1">
              <p>📍 <strong>Your Current Location:</strong> Siddaganga Extension, Tumakuru</p>
              <p>🚑 <strong>Mutual Network:</strong> 6 Co-owners within 1.5 km on standby</p>
              <p>📞 <strong>Co-op Helpline:</strong> 1800-COOP-AID</p>
            </div>

            {sosSent ? (
              <div className="p-3 bg-emerald-100 text-emerald-900 text-xs font-bold rounded-xl animate-pulse">
                ✓ SOS Broadcasted! Help is en-route from Tumakuru Central Hub.
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => setSosModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleTriggerSOS}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1.5"
                >
                  <Radio className="w-4 h-4 animate-ping" />
                  <span>BROADCAST SOS</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
