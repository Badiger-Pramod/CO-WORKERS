import React, { useState } from 'react';
import { useCoop } from '../../context/CoopContext';
import {
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Star,
  QrCode,
  ShieldCheck,
  DollarSign,
  ArrowRight,
  Filter,
  UserCheck,
  Tractor
} from 'lucide-react';

const STATUS_STEPS = ['Requested', 'Accepted', 'Scheduled', 'In Use', 'Completed'];

export const FarmerBookingsTab = () => {
  const {
    farmerBookings = [],
    setFarmerBookings,
    payFarmerBooking,
    rateFarmerBooking,
    currentFarmer
  } = useCoop();

  const [filter, setFilter] = useState('ALL'); // ALL | ACTIVE | COMPLETED | PENDING
  const [selectedBookingForPayment, setSelectedBookingForPayment] = useState(null);
  const [selectedBookingForRating, setSelectedBookingForRating] = useState(null);

  // Payment Modal state
  const [paymentMethod, setPaymentMethod] = useState('UPI (BHIM / GPay / PhonePe)');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Rating Modal state
  const [ratingScore, setRatingScore] = useState(5);
  const [ratingNotes, setRatingNotes] = useState('Excellent tractor and equipment condition! Very punctual and smooth field operation.');
  const [selectedTags, setSelectedTags] = useState(['Punctual', 'Well-Maintained Machine', 'Fair Price']);

  const PRAISE_TAGS = [
    'Punctual',
    'Skilled Operator',
    'Well-Maintained Machine',
    'Careful with Crop',
    'Fair Cooperative Price',
    'Friendly'
  ];

  const toggleTag = (tag) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  // Filter bookings
  const filteredBookings = farmerBookings.filter((b) => {
    if (filter === 'ACTIVE') return b.status === 'Scheduled' || b.status === 'In Use' || b.status === 'Accepted';
    if (filter === 'COMPLETED') return b.status === 'Completed';
    if (filter === 'PENDING') return b.paymentStatus !== 'Paid';
    return true;
  });

  const handleConfirmPayment = () => {
    if (!selectedBookingForPayment) return;
    setIsProcessingPayment(true);

    setTimeout(() => {
      payFarmerBooking(selectedBookingForPayment.id, paymentMethod);
      setIsProcessingPayment(false);
      const updatedId = selectedBookingForPayment.id;
      setSelectedBookingForPayment(null);

      // Prompt for rating after payment!
      const justPaid = farmerBookings.find((b) => b.id === updatedId);
      if (justPaid && !justPaid.reviewed) {
        setSelectedBookingForRating(justPaid);
      }
    }, 800);
  };

  const handleConfirmRating = () => {
    if (!selectedBookingForRating) return;

    const fullNotes = `${ratingNotes} [Tags: ${selectedTags.join(', ')}]`;
    rateFarmerBooking(selectedBookingForRating.id, {
      rating: ratingScore,
      notes: fullNotes
    });
    setSelectedBookingForRating(null);
  };

  const advanceBookingStatus = (bookingId, nextStatus) => {
    setFarmerBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: nextStatus } : b))
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ─── Header & Filters ─────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">📋</span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              My Farm Bookings & Service History
            </h2>
          </div>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Monitor real-time status of your agricultural workers, equipment rentals, and service requests.
          </p>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-2xl flex-shrink-0">
          {[
            { id: 'ALL', label: `All (${farmerBookings.length})` },
            { id: 'ACTIVE', label: 'Active & In Use' },
            { id: 'COMPLETED', label: 'Completed' },
            { id: 'PENDING', label: 'Unpaid Escrow' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                filter === tab.id
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Bookings List ────────────────────────────────────────── */}
      {filteredBookings.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <span className="text-5xl">🌾</span>
          <h3 className="text-white font-bold text-base">No bookings match this filter</h3>
          <p className="text-slate-400 text-xs">Explore equipment sharing or hire agricultural workers to create your first booking.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {filteredBookings.map((booking) => {
            const currentStepIdx = STATUS_STEPS.indexOf(booking.status);
            const isCompleted = booking.status === 'Completed';
            const isPaid = booking.paymentStatus === 'Paid';

            return (
              <div
                key={booking.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-5 transition hover:border-slate-700"
              >
                {/* Top Row: Title, ID & Cost */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-3xl flex-shrink-0">
                      {booking.equipmentPhoto || booking.workerAvatar || '🚜'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-white font-black text-base">{booking.title}</h3>
                        <span className="bg-slate-800 text-slate-300 text-xs font-bold px-2.5 py-0.5 rounded-md border border-slate-700">
                          #{booking.id}
                        </span>
                        <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                          {booking.bookingType || 'Equipment'}
                        </span>
                      </div>
                      <p className="text-slate-400 text-xs mt-1">
                        {booking.date} · {booking.duration} · {booking.location}
                      </p>
                    </div>
                  </div>

                  <div className="text-right flex sm:flex-col items-center sm:items-end justify-between">
                    <span className="text-xl font-black text-emerald-400">
                      ₹{booking.finalCost || booking.estimatedCost}
                    </span>
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded-full mt-1 ${
                        isPaid
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {isPaid ? '✓ Paid & Settled' : 'Payment: Pending Escrow'}
                    </span>
                  </div>
                </div>

                {/* Status Timeline (Section 19: Requested → Accepted → Scheduled → In Use → Completed) */}
                <div className="py-2 px-1">
                  <div className="relative flex items-center justify-between">
                    <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-800 -translate-y-1/2 z-0" />
                    <div
                      className="absolute top-1/2 left-0 h-1 bg-emerald-500 -translate-y-1/2 z-0 transition-all duration-500"
                      style={{
                        width: `${Math.max(0, (currentStepIdx / (STATUS_STEPS.length - 1)) * 100)}%`
                      }}
                    />

                    {STATUS_STEPS.map((step, idx) => {
                      const isPastOrCurrent = idx <= currentStepIdx;
                      const isCurrent = idx === currentStepIdx;

                      return (
                        <div key={step} className="relative z-10 flex flex-col items-center">
                          <div
                            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                              isPastOrCurrent
                                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                                : 'bg-slate-800 text-slate-500 border border-slate-700'
                            }`}
                          >
                            {isPastOrCurrent ? '✓' : idx + 1}
                          </div>
                          <span
                            className={`text-[10px] mt-1.5 font-bold whitespace-nowrap ${
                              isCurrent
                                ? 'text-emerald-400 font-black'
                                : isPastOrCurrent
                                ? 'text-slate-300'
                                : 'text-slate-600'
                            }`}
                          >
                            {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Additional Details Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-800/60 rounded-2xl p-3.5 text-xs text-slate-300">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Field Task</span>
                    <span className="font-semibold text-white">{booking.workType || 'Field Preparation'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Target Crop</span>
                    <span className="font-semibold text-white">{booking.crop || 'Ragi'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Provider / Operator</span>
                    <span className="font-semibold text-emerald-300">
                      {booking.operatorName || booking.ownerName || booking.workerName || 'Tumakuru Guild'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Escrow Guarantee</span>
                    <span className="font-semibold text-white">Co-op SafeShield ✓</span>
                  </div>
                </div>

                {/* Review if completed */}
                {booking.reviewed && (
                  <div className="bg-amber-950/30 border border-amber-800/40 rounded-2xl p-3.5 flex items-center gap-3 text-xs">
                    <div className="flex">
                      {Array.from({ length: 5 }, (_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < (booking.rating || 5) ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-slate-200 italic font-medium">"{booking.reviewNotes}"</p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  {/* Status advance shortcuts for smooth demo presentation */}
                  <div className="flex items-center gap-2">
                    {booking.status === 'Scheduled' && (
                      <button
                        onClick={() => advanceBookingStatus(booking.id, 'In Use')}
                        className="px-3 py-1.5 rounded-xl bg-blue-900/60 hover:bg-blue-900 text-blue-200 border border-blue-700 text-xs font-bold"
                      >
                        Start Field Work (Set In Use)
                      </button>
                    )}
                    {booking.status === 'In Use' && (
                      <button
                        onClick={() => advanceBookingStatus(booking.id, 'Completed')}
                        className="px-3 py-1.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-900 text-emerald-200 border border-emerald-700 text-xs font-bold"
                      >
                        Mark Completed
                      </button>
                    )}
                  </div>

                  {/* Payment & Rating Triggers */}
                  <div className="flex items-center gap-2 ml-auto">
                    {!isPaid ? (
                      <button
                        onClick={() => setSelectedBookingForPayment(booking)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition shadow-lg shadow-emerald-500/20 active:scale-95"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Pay ₹{booking.finalCost || booking.estimatedCost} (UPI / Escrow)</span>
                      </button>
                    ) : !booking.reviewed ? (
                      <button
                        onClick={() => setSelectedBookingForRating(booking)}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition shadow-lg shadow-amber-500/20 active:scale-95"
                      >
                        <Star className="w-4 h-4 fill-slate-950" />
                        <span>Rate & Review (5★)</span>
                      </button>
                    ) : (
                      <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Settled & Reviewed
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ─── Simulated UPI Payment Modal (Section 20) ──────────────── */}
      {selectedBookingForPayment && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-5 animate-scale-up">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-white font-black text-base flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  Simulated UPI Payment
                </h3>
                <p className="text-slate-400 text-xs mt-0.5">
                  Cooperative Escrow Protection: Funds held securely until field work is inspected.
                </p>
              </div>
              <button
                onClick={() => setSelectedBookingForPayment(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            {/* QR Simulation Card */}
            <div className="bg-slate-800 rounded-2xl p-4 flex items-center gap-4 border border-slate-700">
              <div className="w-20 h-20 bg-white rounded-xl flex items-center justify-center text-slate-950 p-1 flex-shrink-0">
                <QrCode className="w-16 h-16" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">{selectedBookingForPayment.title}</p>
                <p className="text-xs text-slate-400 mt-0.5">UPI ID: tumakuru.coop@sbi</p>
                <p className="text-xl font-black text-emerald-400 mt-1">
                  ₹{selectedBookingForPayment.finalCost || selectedBookingForPayment.estimatedCost}
                </p>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2 text-xs">
              <label className="block text-slate-400 font-bold">Select Payment Channel</label>
              {[
                { id: 'UPI (BHIM / GPay / PhonePe)', icon: '📱', desc: 'Instant UPI settlement via Virtual Payment Address' },
                { id: 'Cooperative Farmer Credit', icon: '🤝', desc: 'Debited from Tumakuru Society member credit line' },
                { id: 'Cash on Delivery / Field Handover', icon: '💵', desc: 'Direct cash handover to machine operator' }
              ].map((m) => (
                <div
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id)}
                  className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition ${
                    paymentMethod === m.id
                      ? 'bg-emerald-950/70 border-emerald-500 text-white'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="text-xl">{m.icon}</span>
                  <div>
                    <p className="font-bold">{m.id}</p>
                    <p className="text-[10px] text-slate-400">{m.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedBookingForPayment(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessingPayment}
                onClick={handleConfirmPayment}
                className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 disabled:opacity-50"
              >
                {isProcessingPayment ? (
                  <span>Processing UPI Escrow...</span>
                ) : (
                  <>
                    <span>Confirm & Pay ₹{selectedBookingForPayment.finalCost || selectedBookingForPayment.estimatedCost}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Rating & Review Modal (Section 21) ─────────────────────── */}
      {selectedBookingForRating && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 space-y-5 animate-scale-up">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-white font-black text-base flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  Rate Booking & Service Quality
                </h3>
                <p className="text-slate-400 text-xs mt-0.5">
                  {selectedBookingForRating.title} (#{selectedBookingForRating.id})
                </p>
              </div>
              <button
                onClick={() => setSelectedBookingForRating(null)}
                className="text-slate-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            {/* Star selector */}
            <div className="flex flex-col items-center py-2 space-y-2">
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRatingScore(star)}
                    className="p-1 hover:scale-125 transition"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= ratingScore
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-xs font-bold text-amber-400">
                {ratingScore === 5 ? '5 Stars — Outstanding Service!' : `${ratingScore} Stars`}
              </span>
            </div>

            {/* Praise Tag Pills */}
            <div className="space-y-1.5">
              <span className="block text-xs font-bold text-slate-400">Highlights</span>
              <div className="flex flex-wrap gap-1.5">
                {PRAISE_TAGS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-2.5 py-1 rounded-full text-xs font-semibold transition ${
                      selectedTags.includes(tag)
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Feedback textarea */}
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1">
                Feedback Notes
              </label>
              <textarea
                rows="3"
                value={ratingNotes}
                onChange={(e) => setRatingNotes(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedBookingForRating(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Skip
              </button>
              <button
                type="button"
                onClick={handleConfirmRating}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 active:scale-95"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
