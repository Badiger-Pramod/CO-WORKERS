import React, { useState } from 'react';
import { useCoop, TRADE_DEFINITIONS, getTradeIcon } from '../../context/CoopContext';
import {
  LayoutDashboard,
  Inbox,
  ClipboardList,
  Calendar,
  DollarSign,
  Gift,
  Star,
  Vote,
  MapPin,
  ShieldCheck,
  Megaphone,
  User,
  Settings,
  Bell,
  LogOut,
  CheckCircle2,
  XCircle,
  Clock,
  Phone,
  ArrowRight,
  TrendingUp,
  Percent,
  Award,
  ChevronRight,
  Menu,
  X,
  AlertCircle,
  Check,
  Sliders,
  Sparkles,
  Edit3,
  Save,
  GraduationCap,
  MoreHorizontal,
  ChevronDown
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import WorkerSkillExchange from './WorkerSkillExchange';

export const WorkerDashboard = ({ onLogout }) => {
  const {
    currentUser,
    workerActiveTab,
    setWorkerActiveTab,
    isWorkerAvailable,
    workerToggleAvailability,
    notifications,
    bookings,
    jobRequests,
    workerStats,
    proposals,
    selectedAreas,
    workerToggleArea,
    workingRadiusKm,
    setWorkingRadiusKm,
    reviews,
    updateWorkerProfile,
    workerAcceptJob,
    workerDeclineJob,
    workerUpdateJobStatus,
    workerVoteProposal,
    showToast,
    t
  } = useCoop();

  // Dynamic Worker Trade details
  const workerName = currentUser?.fullName || currentUser?.name || 'Bhuvan Bhuvi';
  const workerTrade = currentUser?.primaryTrade || currentUser?.trade || 'Electrician';
  const workerIcon = getTradeIcon(workerTrade);
  const workerSkills = currentUser?.additionalSkills || ['Wiring', 'Switchboard Repair', 'Fan Repair'];
  const workerExp = currentUser?.experience || 5;
  const workerLocation = currentUser?.location || currentUser?.serviceLocation || 'Tumakuru';
  const workerRadius = currentUser?.serviceRadius || workingRadiusKm || 10;

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState(workerName);
  const [profileTrade, setProfileTrade] = useState(workerTrade);
  const [profileOtherTrade, setProfileOtherTrade] = useState('');
  const [profileExp, setProfileExp] = useState(workerExp);
  const [profileLoc, setProfileLoc] = useState(workerLocation);
  const [profileRadius, setProfileRadius] = useState(workerRadius);
  const [profileSkills, setProfileSkills] = useState(workerSkills);

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [activeJobsFilter, setActiveJobsFilter] = useState('All');
  const [earningsViewPeriod, setEarningsViewPeriod] = useState('weekly');
  const [contactCustomerModal, setContactCustomerModal] = useState(null);

  // Filter incoming job requests matching worker's trade
  const matchingJobRequests = jobRequests.filter((req) => {
    if (!req.targetTrade && !req.service) return true;
    const reqTrade = (req.targetTrade || req.service || '').toLowerCase();
    const myTrade = workerTrade.toLowerCase();
    return reqTrade.includes(myTrade) || myTrade.includes(reqTrade) || req.targetTrade === 'All';
  });

  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  // Minimalist Primary Navigation (Section 9: Home | Jobs | Skills | Earnings | Profile)
  const primaryNavItems = [
    { id: 'dashboard', label: t('dashboard', 'Home'), icon: LayoutDashboard },
    { id: 'jobs', label: t('myJobs', 'Jobs'), icon: ClipboardList, badge: matchingJobRequests.length },
    { id: 'skill-exchange', label: t('skillExchange', 'Skills'), icon: GraduationCap },
    { id: 'earnings', label: t('earnings', 'Earnings'), icon: DollarSign },
    { id: 'profile', label: t('myProfile', 'Profile'), icon: User }
  ];

  // Secondary Tools under 'More'
  const secondaryNavItems = [
    { id: 'requests', label: t('jobRequests', 'Job Requests'), icon: Inbox, badge: matchingJobRequests.length },
    { id: 'schedule', label: t('schedule', 'Schedule'), icon: Calendar },
    { id: 'dividends', label: t('coopDividends', 'Co-op Dividends'), icon: Gift },
    { id: 'ratings', label: t('ratingsPerformance', 'Ratings & Performance'), icon: Star },
    { id: 'voting', label: t('votingPolls', 'Voting & Polls'), icon: Vote },
    { id: 'service-area', label: t('serviceArea', 'Service Area'), icon: MapPin },
    { id: 'verification', label: t('verification', 'Verification'), icon: ShieldCheck },
    { id: 'announcements', label: t('announcements', 'Announcements'), icon: Megaphone },
    { id: 'settings', label: t('settings', 'Settings'), icon: Settings }
  ];

  const navItems = [...primaryNavItems, ...secondaryNavItems];

  // Recharts Chart Data
  const weeklyEarningsData = [
    { name: 'Mon', gross: 2400, net: 2208 },
    { name: 'Tue', gross: 3200, net: 2944 },
    { name: 'Wed', gross: 2800, net: 2576 },
    { name: 'Thu', gross: 4100, net: 3772 },
    { name: 'Fri', gross: 3900, net: 3588 },
    { name: 'Sat', gross: 5400, net: 4968 },
    { name: 'Sun', gross: 4200, net: 3864 }
  ];

  const monthlyEarningsData = [
    { name: 'May', gross: 22000, net: 20240 },
    { name: 'Jun', gross: 25400, net: 23368 },
    { name: 'Jul', gross: 29000, net: 26680 },
    { name: 'Aug', gross: 31200, net: 28704 },
    { name: 'Sep (MTD)', gross: 30000, net: 27600 }
  ];

  // Save Profile Changes
  const handleSaveProfile = (e) => {
    e.preventDefault();
    const finalTrade = profileTrade === 'Other' && profileOtherTrade.trim() ? profileOtherTrade.trim() : profileTrade;

    updateWorkerProfile({
      fullName: profileName.trim(),
      name: profileName.trim(),
      primaryTrade: finalTrade,
      trade: finalTrade,
      experience: parseInt(profileExp) || 5,
      experienceText: `${profileExp} years experience`,
      location: profileLoc.trim(),
      serviceLocation: profileLoc.trim(),
      serviceRadius: parseInt(profileRadius) || 10,
      additionalSkills: profileSkills,
      avatar: getTradeIcon(finalTrade)
    });

    setIsEditingProfile(false);
  };

  const handleToggleSkillEdit = (skill) => {
    setProfileSkills((prev) =>
      prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]
    );
  };

  const currentTradeDef = TRADE_DEFINITIONS.find((t) => t.id === profileTrade) || TRADE_DEFINITIONS[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {/* ==================================================== */}
      {/* TOP HEADER: WORKER CO-OWNER PORTAL                   */}
      {/* ==================================================== */}
      <header className="bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Logo & Worker Identity */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100"
            >
              {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div
              onClick={() => setWorkerActiveTab('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer select-none"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-800 text-white flex items-center justify-center text-lg shadow-xs">
                {workerIcon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-slate-900 text-lg tracking-tight">
                    CoWork <span className="text-emerald-800">Connect</span>
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span>{workerIcon}</span>
                    <span>{workerTrade}</span>
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Worker Co-owner Hub • {workerLocation}
                </p>
              </div>
            </div>
          </div>

          {/* LARGE AVAILABILITY SWITCH */}
          <div className="flex items-center gap-3">
            <button
              onClick={workerToggleAvailability}
              className={`flex items-center gap-2 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-xl border font-bold text-xs tracking-wide transition-all shadow-2xs cursor-pointer ${
                isWorkerAvailable
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-slate-100 border-slate-200 text-slate-600'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isWorkerAvailable ? 'bg-emerald-800 animate-pulse' : 'bg-slate-400'
                }`}
              ></span>
              <span className="hidden sm:inline">
                {isWorkerAvailable ? '🟢 AVAILABLE — Accepting Jobs' : '⚫ OFFLINE'}
              </span>
              <span className="sm:hidden">{isWorkerAvailable ? 'Available' : 'Offline'}</span>
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl relative transition"
              >
                <Bell className="w-5 h-5" />
                {notifications.filter((n) => !n.read && n.forRole === 'Worker').length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-emerald-800 rounded-full ring-2 ring-white"></span>
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Worker Dispatch Alerts</span>
                    <span className="text-[11px] text-emerald-700 font-semibold cursor-pointer">
                      Mark read
                    </span>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.filter((n) => n.forRole === 'Worker').length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400">No active alerts</div>
                    ) : (
                      notifications
                        .filter((n) => n.forRole === 'Worker')
                        .map((n) => (
                          <div key={n.id} className="p-3 hover:bg-slate-50 transition text-left">
                            <p className="text-xs font-bold text-slate-800">{n.title}</p>
                            <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                            <span className="text-[10px] text-slate-400 mt-1 block">{n.time}</span>
                          </div>
                        ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Worker Profile Header */}
            <div
              onClick={() => setWorkerActiveTab('profile')}
              className="flex items-center gap-2 cursor-pointer p-1.5 rounded-xl hover:bg-slate-100 transition"
            >
              <div className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 font-bold text-sm flex items-center justify-center">
                {workerIcon}
              </div>
              <div className="hidden md:block text-left text-xs leading-tight">
                <div className="font-bold text-slate-900">{workerName}</div>
                <div className="text-[10px] text-emerald-700 font-semibold">{workerTrade}</div>
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={onLogout}
              title="Logout"
              className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-xl transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* ==================================================== */}
      {/* MAIN CONTAINER: SIDEBAR + CONTENT                    */}
      {/* ==================================================== */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex gap-6">
        {/* LEFT WORKER SIDEBAR */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-3 sticky top-22 space-y-4">
            {/* Primary Minimalist Navigation */}
            <div>
              <div className="px-3 py-1 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Primary Menu
                </span>
              </div>
              <div className="space-y-1">
                {primaryNavItems.map((item) => {
                  const IconComp = item.icon;
                  const isActive = workerActiveTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setWorkerActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <IconComp
                          className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`}
                        />
                        <span>{item.label}</span>
                      </div>
                      {item.badge > 0 && (
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isActive ? 'bg-emerald-900 text-white' : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Secondary Tools */}
            <div>
              <div className="px-3 py-1 mb-1 border-t border-slate-100 pt-3">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  More Operations
                </span>
              </div>
              <div className="space-y-1">
                {secondaryNavItems.map((item) => {
                  const IconComp = item.icon;
                  const isActive = workerActiveTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setWorkerActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <IconComp
                          className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`}
                        />
                        <span>{item.label}</span>
                      </div>
                      {item.badge > 0 && (
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isActive ? 'bg-emerald-900 text-white' : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-2 pt-3 border-t border-slate-100 px-3 py-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-800">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Co-owner Class A</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">1 Worker = 1 Vote Active</p>
            </div>
          </div>
        </aside>

        {/* MOBILE SLIDE-OUT MENU */}
        {mobileNavOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-slate-50/60 backdrop-blur-xs flex">
            <div className="w-72 bg-white h-full p-4 flex flex-col shadow-2xl animate-in slide-in-from-left duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{workerIcon}</span>
                  <span className="font-bold text-slate-900 text-sm">{workerTrade} Portal</span>
                </div>
                <button
                  onClick={() => setMobileNavOpen(false)}
                  className="p-1 text-slate-500 hover:bg-slate-100 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto py-3 space-y-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 block mb-1">
                    Primary
                  </span>
                  <div className="space-y-1">
                    {primaryNavItems.map((item) => {
                      const IconComp = item.icon;
                      const isActive = workerActiveTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setWorkerActiveTab(item.id);
                            setMobileNavOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                            isActive
                              ? 'bg-emerald-800 text-white'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className="w-4 h-4" />
                            <span>{item.label}</span>
                          </div>
                          {item.badge > 0 && (
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                              {item.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 block mb-1 border-t border-slate-100 pt-3">
                    More Operations
                  </span>
                  <div className="space-y-1">
                    {secondaryNavItems.map((item) => {
                      const IconComp = item.icon;
                      const isActive = workerActiveTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setWorkerActiveTab(item.id);
                            setMobileNavOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
                            isActive
                              ? 'bg-emerald-800 text-white'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className="w-4 h-4" />
                            <span>{item.label}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800 block">{workerName}</span>
                  <span className="text-[10px] text-emerald-700">{workerTrade}</span>
                </div>
                <button onClick={onLogout} className="text-red-600 hover:underline font-bold">
                  Logout
                </button>
              </div>
            </div>
            <div className="flex-1" onClick={() => setMobileNavOpen(false)}></div>
          </div>
        )}

        {/* MAIN WORKER CONTENT */}
        <main className="flex-1 min-w-0">
          {/* Minimalist Top Nav Header on Desktop */}
          <div className="mb-6 bg-white border border-slate-200/90 rounded-2xl p-2 shadow-2xs flex items-center justify-between gap-2 overflow-x-auto">
            <div className="flex items-center gap-1">
              {primaryNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = workerActiveTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setWorkerActiveTab(item.id)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                      isActive
                        ? 'bg-emerald-800 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.label}</span>
                    {item.badge > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${isActive ? 'bg-emerald-900 text-white' : 'bg-emerald-100 text-emerald-800'}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* More Menu Dropdown */}
            <div className="relative">
              <button
                onClick={() => setMoreMenuOpen(!moreMenuOpen)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition ${
                  secondaryNavItems.some(i => i.id === workerActiveTab)
                    ? 'border-emerald-700 bg-emerald-50 text-emerald-800'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <MoreHorizontal className="w-4 h-4" />
                <span>More</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {moreMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Additional Operations
                  </div>
                  {secondaryNavItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = workerActiveTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setWorkerActiveTab(item.id);
                          setMoreMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3.5 py-2 text-xs font-semibold text-left transition ${
                          isActive
                            ? 'bg-emerald-50 text-emerald-800 font-bold'
                            : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className="w-4 h-4 text-slate-500" />
                          <span>{item.label}</span>
                        </div>
                        {item.badge > 0 && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* ==================================================== */}
          {/* TAB 1: DASHBOARD HOME                                */}
          {/* ==================================================== */}
          {workerActiveTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Dynamic Minimalist Welcome Card */}
              <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-2xs relative">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-[11px] font-bold text-emerald-800 mb-2">
                      <span>⚡ Democratic Gig Cooperative</span>
                      <span>•</span>
                      <span>Primary Trade: {workerTrade}</span>
                    </div>
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-snug">
                      {t('welcomeBack', 'Welcome back')}, {workerName} 👋
                    </h1>
                    <p className="text-slate-500 text-xs sm:text-sm mt-1">
                      {t('heroHeading', 'Your skills. Your work. Your cooperative.')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setWorkerActiveTab('jobs')}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <ClipboardList className="w-3.5 h-3.5" />
                      <span>View Active Jobs</span>
                    </button>
                  </div>
                </div>

                {/* Trust Badges matching Trade */}
                <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-600">
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('verifiedWorkers', 'Verified Worker')}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('workerOwnership', 'Cooperative Member')}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <span>{workerIcon}</span>
                    <span>{workerTrade} Specialist</span>
                  </span>
                </div>
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {t('todaysEarnings', "Today's Earnings")}
                  </span>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-emerald-800">
                    ₹{workerStats.todayEarnings.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">Capped 8% fee</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {t('earnings', 'This Month')}
                  </span>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-900">
                    ₹{workerStats.thisMonth.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-700 font-semibold mt-1 block">
                    +18% vs last month
                  </span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {t('completedJobs', 'Jobs Completed')}
                  </span>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-900">
                    {workerStats.jobsCompleted}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">100% verified</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {t('averageRating', 'Average Rating')}
                  </span>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-amber-600">
                    {workerStats.averageRating}
                  </div>
                  <span className="text-[10px] text-amber-600 mt-1 block">⭐ 32 Reviews</span>
                </div>

                <div className="col-span-2 lg:col-span-1 bg-white p-5 rounded-2xl border border-emerald-200/90 shadow-2xs">
                  <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                    {t('coopDividends', 'Co-op Dividend')}
                  </span>
                  <div className="mt-2 text-2xl sm:text-3xl font-black text-emerald-800">
                    ₹{workerStats.coopDividend.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-emerald-700 mt-1 block">Surplus Share</span>
                </div>
              </div>

              {/* Incoming Job Requests Alert Banner */}
              {matchingJobRequests.length > 0 && (
                <div className="bg-white rounded-2xl border border-emerald-200/90 p-5 shadow-2xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-800 animate-pulse"></span>
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                        Incoming {workerTrade} Job Requests ({matchingJobRequests.length})
                      </span>
                    </div>
                    <span
                      onClick={() => setWorkerActiveTab('requests')}
                      className="text-xs text-emerald-800 hover:underline cursor-pointer font-bold"
                    >
                      View All Requests →
                    </span>
                  </div>

                  <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
                        <span>{matchingJobRequests[0].service}</span>
                        <span className="text-xs text-slate-500 font-normal">
                          for {matchingJobRequests[0].customer}
                        </span>
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {matchingJobRequests[0].issue} • {matchingJobRequests[0].location} ({matchingJobRequests[0].distance})
                      </p>
                      <span className="text-xs text-emerald-800 font-bold mt-1 block">
                        Estimated Payout: ₹{matchingJobRequests[0].estimatedPayment}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => workerAcceptJob(matchingJobRequests[0].id)}
                        className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
                      >
                        ✓ ACCEPT
                      </button>
                      <button
                        onClick={() => workerDeclineJob(matchingJobRequests[0].id)}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                      >
                        ✕ DECLINE
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Quick Profile & Skills Summary Card */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center text-xl font-bold border border-emerald-200">
                      {workerIcon}
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{workerTrade} Co-owner Profile</h3>
                      <p className="text-xs text-slate-500">
                        {workerExp} years experience • Serving {workerLocation} ({workerRadius} km radius)
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setIsEditingProfile(true);
                      setWorkerActiveTab('profile');
                    }}
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Change Trade</span>
                  </button>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Active Skills:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {workerSkills.map((sk) => (
                      <span
                        key={sk}
                        className="px-3 py-1 rounded-xl bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-semibold"
                      >
                        ✓ {sk}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 2: JOB REQUESTS (FILTERED BY TRADE)              */}
          {/* ==================================================== */}
          {workerActiveTab === 'requests' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                    {workerTrade} Job Requests
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Jobs dispatched specifically matching your trade ({workerTrade}) within {workerRadius} km.
                  </p>
                </div>
              </div>

              {matchingJobRequests.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
                  <h3 className="text-base font-bold text-white">All caught up!</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    No pending {workerTrade} job requests in your queue right now. Keep your status as AVAILABLE to receive instant dispatches.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {matchingJobRequests.map((req) => (
                    <div
                      key={req.id}
                      className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-md hover:border-slate-200 transition"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/90">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-500 uppercase">
                              Request #{req.id}
                            </span>
                            <span className="text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-700 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                              <span>{workerIcon}</span>
                              <span>{req.service}</span>
                            </span>
                          </div>
                          <h3 className="text-lg font-black text-white mt-1">
                            Customer: {req.customer}
                          </h3>
                          <p className="text-xs text-slate-400 mt-0.5">
                            Customer Rating: ⭐ {req.customerRating} • {req.location} ({req.distance})
                          </p>
                        </div>

                        <div className="text-left sm:text-right">
                          <span className="text-2xl font-black text-emerald-700">
                            ₹{req.estimatedPayment}
                          </span>
                          <span className="text-xs text-slate-500 block">
                            Estimated Net Take-home
                          </span>
                        </div>
                      </div>

                      <div className="py-4 text-xs text-slate-300">
                        <span className="font-bold text-slate-400 block mb-1">Issue Reported:</span>
                        <p className="bg-slate-50 p-3 rounded-xl border border-slate-200/90">
                          {req.issue}
                        </p>
                        <span className="text-slate-500 mt-2 block">Scheduled For: {req.time}</span>
                      </div>

                      <div className="pt-4 border-t border-slate-200/90 flex items-center justify-end gap-3">
                        <button
                          onClick={() => workerDeclineJob(req.id)}
                          className="px-5 py-2.5 bg-slate-50 hover:bg-slate-800 text-slate-400 hover:text-slate-900 font-bold text-xs rounded-xl transition"
                        >
                          ✕ DECLINE
                        </button>
                        <button
                          onClick={() => workerAcceptJob(req.id)}
                          className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs rounded-xl shadow-md transition"
                        >
                          ✓ ACCEPT & DISPATCH
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 3: MY JOBS                                       */}
          {/* ==================================================== */}
          {workerActiveTab === 'jobs' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">My Jobs</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Advance your service status in real time so customer tracking updates instantly.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {['All', 'In Progress', 'Completed'].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveJobsFilter(tab)}
                      className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition ${
                        activeJobsFilter === tab
                          ? 'bg-emerald-800 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                {bookings
                  .filter((b) => {
                    if (activeJobsFilter === 'In Progress') {
                      return ['Worker Assigned', 'On the Way', 'Work in Progress'].includes(b.status);
                    }
                    if (activeJobsFilter === 'Completed') {
                      return b.status === 'Completed';
                    }
                    return true;
                  })
                  .map((job) => (
                    <div
                      key={job.id}
                      className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-md"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/90">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-500">{job.id}</span>
                            <span
                              className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                                job.status === 'Completed'
                                  ? 'bg-slate-800 text-slate-300'
                                  : 'bg-emerald-50 text-emerald-800 border border-emerald-700'
                              }`}
                            >
                              {job.status}
                            </span>
                          </div>
                          <h3 className="text-lg font-black text-white mt-1">
                            {job.service} for {job.customer}
                          </h3>
                          <p className="text-xs text-slate-400">{job.location}</p>
                        </div>

                        <div className="text-left sm:text-right">
                          <span className="text-xl font-black text-emerald-700">₹{job.price}</span>
                          <span className="text-[11px] text-slate-500 block">
                            Payment: {job.paymentStatus}
                          </span>
                        </div>
                      </div>

                      <div className="pt-4 flex flex-wrap items-center justify-between gap-3">
                        <button
                          onClick={() => setContactCustomerModal(job)}
                          className="px-3.5 py-2 bg-slate-50 hover:bg-slate-800 text-slate-300 font-bold text-xs rounded-xl transition flex items-center gap-1.5"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Contact Customer</span>
                        </button>

                        {job.status !== 'Completed' && (
                          <div className="flex items-center gap-2">
                            {job.status === 'Confirmed' || job.status === 'Worker Assigned' ? (
                              <button
                                onClick={() => workerUpdateJobStatus(job.id, 'On the Way')}
                                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition"
                              >
                                ➔ Mark "On the Way"
                              </button>
                            ) : job.status === 'On the Way' ? (
                              <button
                                onClick={() => workerUpdateJobStatus(job.id, 'Arrived')}
                                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition"
                              >
                                ➔ Mark "Arrived"
                              </button>
                            ) : job.status === 'Arrived' ? (
                              <button
                                onClick={() => workerUpdateJobStatus(job.id, 'Work Started')}
                                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition"
                              >
                                ➔ Mark "Work Started"
                              </button>
                            ) : (
                              <button
                                onClick={() => workerUpdateJobStatus(job.id, 'Completed')}
                                className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs rounded-xl shadow-md transition"
                              >
                                ✓ Complete Job
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 4: SCHEDULE                                      */}
          {/* ==================================================== */}
          {workerActiveTab === 'schedule' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Worker Schedule</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Plan your shifts, appointments, and custom offline slots.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-200/90">
                  <h3 className="text-sm font-black text-white mb-3">Today's Jobs</h3>
                  <div className="space-y-2.5 text-xs">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/90">
                      <div className="flex justify-between font-bold text-white">
                        <span>11:00 AM</span>
                        <span className="text-emerald-700">Ananya Sharma</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{workerTrade} • Siddaganga Ext</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/90">
                  <h3 className="text-sm font-black text-white mb-3">Tomorrow's Jobs</h3>
                  <div className="space-y-2.5 text-xs">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/90">
                      <div className="flex justify-between font-bold text-white">
                        <span>2:30 PM</span>
                        <span className="text-slate-300">Tumakuru Co-op Ward 4</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{workerTrade} Inspection</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/90">
                  <h3 className="text-sm font-black text-white mb-3">Shift Availability</h3>
                  <p className="text-xs text-slate-400 mb-4">
                    Current Dispatch Mode: {isWorkerAvailable ? '🟢 Accepting' : '⚫ Paused'}
                  </p>
                  <button
                    onClick={workerToggleAvailability}
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-slate-900 font-bold text-xs rounded-xl transition"
                  >
                    Toggle Shift Status
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 5: EARNINGS                                      */}
          {/* ==================================================== */}
          {workerActiveTab === 'earnings' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Earnings Dashboard</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Transparent earnings statement with standard capped 8% cooperative deduction.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-200/90">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Gross Earnings
                  </span>
                  <div className="mt-2 text-3xl font-black text-white">
                    ₹{workerStats.grossEarnings.toLocaleString()}
                  </div>
                  <span className="text-xs text-slate-500 mt-1 block">Total billed to customers</span>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/90">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Co-op Fee (8%)
                  </span>
                  <div className="mt-2 text-3xl font-black text-emerald-700">
                    ₹{workerStats.coopFee.toLocaleString()}
                  </div>
                  <span className="text-xs text-slate-500 mt-1 block">Platform & welfare fund</span>
                </div>

                <div className="bg-gradient-to-br from-emerald-950 to-slate-950 p-6 rounded-2xl border border-emerald-700">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">
                    Net Earnings
                  </span>
                  <div className="mt-2 text-3xl font-black text-emerald-800">
                    ₹{workerStats.netEarnings.toLocaleString()}
                  </div>
                  <span className="text-xs text-emerald-700/80 mt-1 block">Credited to bank account</span>
                </div>
              </div>

              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-base font-extrabold text-white">Earnings Analytics</h3>
                    <p className="text-xs text-slate-400">Daily gross vs net earnings comparison</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setEarningsViewPeriod('weekly')}
                      className={`px-3 py-1 text-xs font-bold rounded-lg ${
                        earningsViewPeriod === 'weekly' ? 'bg-emerald-800 text-white' : 'bg-slate-50 text-slate-400'
                      }`}
                    >
                      Weekly
                    </button>
                    <button
                      onClick={() => setEarningsViewPeriod('monthly')}
                      className={`px-3 py-1 text-xs font-bold rounded-lg ${
                        earningsViewPeriod === 'monthly' ? 'bg-emerald-800 text-white' : 'bg-slate-50 text-slate-400'
                      }`}
                    >
                      Monthly
                    </button>
                  </div>
                </div>

                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={earningsViewPeriod === 'weekly' ? weeklyEarningsData : monthlyEarningsData}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={11} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0f172a',
                          borderColor: '#334155',
                          borderRadius: '12px',
                          color: '#fff'
                        }}
                      />
                      <Bar dataKey="gross" fill="#059669" name="Gross (₹)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="net" fill="#10b981" name="Net (₹)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 6: CO-OP DIVIDENDS                               */}
          {/* ==================================================== */}
          {workerActiveTab === 'dividends' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Patronage Dividend</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  As a cooperative co-owner, you participate in annual surplus redistribution.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-emerald-700/60 p-6 sm:p-8 shadow-xl">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pb-6 border-b border-slate-200/90">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase block">
                      Current Dividend Balance
                    </span>
                    <span className="text-3xl font-black text-emerald-700 mt-1 block">
                      ₹{workerStats.coopDividend.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-slate-500 mt-0.5 block">
                      Accrued from 2026 surplus
                    </span>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase block">
                      Eligible Share
                    </span>
                    <span className="text-3xl font-black text-white mt-1 block">
                      ₹{workerStats.coopDividend.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-slate-500 mt-0.5 block">
                      100% attendance & rating
                    </span>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase block">
                      Previous Distribution
                    </span>
                    <span className="text-3xl font-black text-slate-300 mt-1 block">
                      ₹1,800
                    </span>
                    <span className="text-[11px] text-emerald-700 mt-0.5 block">
                      Paid on Nov 2025 ✓
                    </span>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="text-sm font-extrabold text-white mb-2">Next Distribution</h4>
                  <p className="text-xs text-slate-300 font-semibold">
                    Scheduled for: <span className="text-emerald-700">November 01, 2026</span>
                  </p>
                  <p className="text-xs text-slate-400 mt-3 leading-relaxed">
                    Your cooperative surplus share is calculated based on cooperative rules and member participation.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 7: RATINGS                                       */}
          {/* ==================================================== */}
          {workerActiveTab === 'ratings' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                  Ratings & Performance
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Customer feedback and performance metrics for {workerName} ({workerTrade}).
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">Avg Rating</span>
                  <span className="text-2xl font-black text-amber-400 mt-1 block">4.8 / 5</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">Total Reviews</span>
                  <span className="text-2xl font-black text-white mt-1 block">32</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">Completed Jobs</span>
                  <span className="text-2xl font-black text-white mt-1 block">125</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">On-time Rate</span>
                  <span className="text-2xl font-black text-emerald-700 mt-1 block">96%</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200/90 col-span-2 sm:col-span-1">
                  <span className="text-[11px] text-slate-400 font-bold uppercase block">Satisfaction</span>
                  <span className="text-2xl font-black text-emerald-700 mt-1 block">94%</span>
                </div>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8">
                <h3 className="text-base font-black text-white mb-4">Customer Reviews</h3>
                <div className="space-y-4">
                  {reviews.map((rev) => (
                    <div key={rev.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200/90">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-extrabold text-xs text-white">{rev.customer}</span>
                        <span className="text-xs font-bold text-amber-400">
                          {'⭐'.repeat(Math.round(rev.rating))}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 8: VOTING                                        */}
          {/* ==================================================== */}
          {workerActiveTab === 'voting' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-gradient-to-r from-emerald-950 to-slate-950 rounded-3xl p-6 sm:p-8 border border-emerald-700/60">
                <div className="flex items-center gap-2 text-emerald-700 text-xs font-bold uppercase mb-2">
                  <Vote className="w-4 h-4" />
                  <span>Democratic Co-op Platform</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  One Worker = One Vote
                </h2>
                <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                  Participate directly in cooperative governance. Vote on tariffs, safety funds, tool subsidies, and territorial expansion.
                </p>
              </div>

              <div className="space-y-4">
                {proposals.map((prop) => (
                  <div
                    key={prop.id}
                    className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-md"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/90">
                      <h3 className="text-base font-black text-white">{prop.title}</h3>
                      <span className="text-xs text-slate-400">Deadline: {prop.deadline}</span>
                    </div>

                    <p className="text-xs text-slate-300 my-4 leading-relaxed">
                      {prop.description}
                    </p>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 border-t border-slate-200/90">
                      <div className="flex items-center gap-4 text-xs">
                        <span className="text-emerald-700 font-bold">Yes: {prop.totalYes}</span>
                        <span className="text-red-400 font-bold">No: {prop.totalNo}</span>
                        {prop.userVote && (
                          <span className="text-xs bg-emerald-900/60 border border-emerald-600 text-emerald-800 px-2.5 py-0.5 rounded-full font-bold">
                            Your vote: {prop.userVote}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => workerVoteProposal(prop.id, 'YES')}
                          className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer ${
                            prop.userVote === 'YES'
                              ? 'bg-emerald-800 text-white ring-2 ring-emerald-400'
                              : 'bg-slate-50 hover:bg-emerald-900/50 text-emerald-700 border border-emerald-700'
                          }`}
                        >
                          YES
                        </button>
                        <button
                          onClick={() => workerVoteProposal(prop.id, 'NO')}
                          className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer ${
                            prop.userVote === 'NO'
                              ? 'bg-red-600 text-white ring-2 ring-red-400'
                              : 'bg-slate-50 hover:bg-red-900/50 text-red-400 border border-red-700'
                          }`}
                        >
                          NO
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 9: SERVICE AREA                                  */}
          {/* ==================================================== */}
          {workerActiveTab === 'service-area' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Service Area</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Configure the areas where you provide {workerTrade} services.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 space-y-6">
                <div>
                  <h3 className="text-sm font-extrabold text-white mb-3">Select Active Service Areas</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                    {['Tumakuru', 'Kunigal', 'Sira', 'Gubbi', 'Bengaluru'].map((area) => {
                      const isSelected = selectedAreas.includes(area);
                      return (
                        <button
                          key={area}
                          onClick={() => workerToggleArea(area)}
                          className={`p-4 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-1 ring-emerald-500'
                              : 'bg-slate-50 border-slate-200/90 text-slate-400 hover:border-slate-200'
                          }`}
                        >
                          <span className="text-xl block mb-1">📍</span>
                          <span>{area}</span>
                          <span className="text-[10px] block mt-1 text-slate-500">
                            {isSelected ? '✓ Active' : '+ Add'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200/90">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-white uppercase">Preferred Working Radius</span>
                    <span className="text-sm font-black text-emerald-700">{workerRadius} km</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="30"
                    value={workerRadius}
                    onChange={(e) => setWorkingRadiusKm(Number(e.target.value))}
                    className="w-full accent-emerald-500"
                  />
                  <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                    <span>5 km (Local Ward)</span>
                    <span>15 km (Town Area)</span>
                    <span>30 km (District Level)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 10: VERIFICATION                                 */}
          {/* ==================================================== */}
          {workerActiveTab === 'verification' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Verification Status</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Cooperative audit credentials verifying {workerName} as a qualified {workerTrade}.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 space-y-4">
                {[
                  { title: 'Identity Verification', status: 'Verified ✓', date: 'Audited July 2026', desc: 'Aadhaar e-KYC & Police Clearance verified with Tumakuru Co-op Registry.' },
                  { title: `Skill Verification (${workerTrade})`, status: 'Certified Class A', date: 'Karnataka State Apprenticeship', desc: `Certified vocational mastery in ${workerTrade} and related field standards.` },
                  { title: 'Cooperative Membership', status: 'Verified ✓', date: 'Shareholder Member', desc: 'Full equity co-owner member under Karnataka Cooperative Societies Act.' }
                ].map((item, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 rounded-2xl border border-slate-200/90 flex items-start justify-between gap-4">
                    <div>
                      <h4 className="text-sm font-extrabold text-white flex items-center gap-2">
                        <span>{item.title}</span>
                        <span className="text-[10px] bg-emerald-50 border border-emerald-600 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                          {item.status}
                        </span>
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
                      <span className="text-[10px] text-slate-500 mt-1 block">{item.date}</span>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-1" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 11: ANNOUNCEMENTS                                */}
          {/* ==================================================== */}
          {workerActiveTab === 'announcements' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Co-op Announcements</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Official notices from the Tumakuru District Cooperative Executive Board.
                </p>
              </div>

              <div className="space-y-4">
                {[
                  { title: 'Monthly Cooperative General Body Meeting', date: 'October 05, 2026 • 5:30 PM', desc: 'Agenda: Quarterly financial audit, tool subsidy distributions, and ward safety representatives.', category: 'Governance' },
                  { title: `Professional ${workerTrade} Safety & Equipment Workshop`, date: 'October 12, 2026 • 10:00 AM', desc: `Sponsored hands-on training for all active ${workerTrade} cooperative members. Free safety gear issued.`, category: 'Training' },
                  { title: 'Annual Patronage Dividend Distribution', date: 'November 01, 2026', desc: 'Surplus net revenue after platform operations will be distributed to member bank accounts.', category: 'Dividends' }
                ].map((ann, idx) => (
                  <div key={idx} className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-md">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] uppercase font-bold bg-emerald-50 text-emerald-800 border border-emerald-700 px-2.5 py-0.5 rounded-full">
                        {ann.category}
                      </span>
                      <span className="text-xs text-slate-400">{ann.date}</span>
                    </div>
                    <h3 className="text-base font-extrabold text-white">{ann.title}</h3>
                    <p className="text-xs text-slate-300 mt-2 leading-relaxed">{ann.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB 12: MY PROFILE (DYNAMIC PROFESSION EDITING)      */}
          {/* ==================================================== */}
          {workerActiveTab === 'profile' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">Worker Profile</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    View or edit your profession, trade skills, and service radius.
                  </p>
                </div>

                {!isEditingProfile && (
                  <button
                    onClick={() => {
                      setProfileName(workerName);
                      setProfileTrade(workerTrade);
                      setProfileExp(workerExp);
                      setProfileLoc(workerLocation);
                      setProfileRadius(workerRadius);
                      setProfileSkills(workerSkills);
                      setIsEditingProfile(true);
                    }}
                    className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Trade & Profile</span>
                  </button>
                )}
              </div>

              {/* View / Edit Mode */}
              {!isEditingProfile ? (
                <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 space-y-6">
                  <div className="flex items-center gap-4 pb-6 border-b border-slate-200/90">
                    <div className="w-16 h-16 rounded-2xl bg-emerald-900 border-2 border-emerald-500 text-slate-900 font-black text-2xl flex items-center justify-center shadow-md">
                      {workerIcon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xl font-black text-white">{workerName}</h3>
                        <span className="text-[10px] bg-emerald-900 text-emerald-800 border border-emerald-700 px-2 py-0.5 rounded-full font-bold">
                          ✓ Verified Co-owner
                        </span>
                      </div>
                      <p className="text-xs text-emerald-700 font-extrabold mt-0.5 flex items-center gap-1.5">
                        <span>{workerIcon}</span>
                        <span>{workerTrade}</span>
                      </p>
                      <span className="text-[11px] text-slate-500">
                        Login ID: <code className="text-slate-300 font-bold">{currentUser?.loginId || 'bhuvan01'}</code>
                      </span>
                    </div>
                  </div>

                  {/* Profile Details List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Primary Trade
                      </span>
                      <span className="text-base font-extrabold text-white mt-1 flex items-center gap-2">
                        <span>{workerIcon}</span>
                        <span>{workerTrade}</span>
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Experience
                      </span>
                      <span className="text-base font-extrabold text-white mt-1 block">
                        {workerExp} years
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Service Location
                      </span>
                      <span className="text-base font-extrabold text-white mt-1 block">
                        {workerLocation}
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Service Radius
                      </span>
                      <span className="text-base font-extrabold text-emerald-700 mt-1 block">
                        {workerRadius} km radius
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Verification Status
                      </span>
                      <span className="text-sm font-extrabold text-emerald-700 mt-1 block">
                        ✓ Aadhaar e-KYC & Trade Certified
                      </span>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/90">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">
                        Cooperative Membership
                      </span>
                      <span className="text-sm font-extrabold text-white mt-1 block">
                        Class A Co-owner (Tumakuru Unit)
                      </span>
                    </div>
                  </div>

                  {/* Additional Skills */}
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Additional Skills:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {workerSkills.map((sk) => (
                        <span
                          key={sk}
                          className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200/90 text-emerald-800 text-xs font-semibold"
                        >
                          ✓ {sk}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* EDIT PROFILE FORM */
                <form
                  onSubmit={handleSaveProfile}
                  className="bg-white rounded-3xl border border-emerald-600/60 p-6 sm:p-8 space-y-6 animate-in zoom-in-95 duration-150"
                >
                  <div className="flex items-center justify-between pb-4 border-b border-slate-200/90">
                    <h3 className="text-base font-black text-white flex items-center gap-2">
                      <Edit3 className="w-4 h-4 text-emerald-700" />
                      <span>Edit Your Trade & Profile</span>
                    </h3>
                    <button
                      type="button"
                      onClick={() => setIsEditingProfile(false)}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block font-bold text-slate-400 uppercase mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-white focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-400 uppercase mb-1">
                        Primary Service / Trade *
                      </label>
                      <select
                        value={profileTrade}
                        onChange={(e) => {
                          setProfileTrade(e.target.value);
                          const found = TRADE_DEFINITIONS.find((t) => t.id === e.target.value);
                          if (found && found.skills) {
                            setProfileSkills(found.skills.slice(0, 3));
                          }
                        }}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="Electrician">⚡ Electrician</option>
                        <option value="Plumber">🔧 Plumber</option>
                        <option value="Carpenter">🪚 Carpenter</option>
                        <option value="Painter">🎨 Painter</option>
                        <option value="Cleaning Professional">🧹 Cleaning Professional</option>
                        <option value="Appliance / AC Technician">❄️ Appliance / AC Technician</option>
                        <option value="Vehicle Mechanic">🚗 Vehicle Mechanic</option>
                        <option value="Gardener">🌱 Gardener</option>
                        <option value="Home Maintenance">🏠 Home Maintenance</option>
                        <option value="Community Service">🤝 Community Service</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  {profileTrade === 'Other' && (
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">
                        Enter your custom service/trade name *
                      </label>
                      <input
                        type="text"
                        value={profileOtherTrade}
                        onChange={(e) => setProfileOtherTrade(e.target.value)}
                        placeholder="e.g. Solar Panel Technician"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-white"
                      />
                    </div>
                  )}

                  {/* Skills Checklist for this trade */}
                  {currentTradeDef?.skills && (
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-2">
                        Select Skills for {profileTrade}:
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {currentTradeDef.skills.map((skill) => {
                          const isSelected = profileSkills.includes(skill);
                          return (
                            <button
                              key={skill}
                              type="button"
                              onClick={() => handleToggleSkillEdit(skill)}
                              className={`text-xs px-3 py-1.5 rounded-xl border font-semibold transition ${
                                isSelected
                                  ? 'bg-emerald-800 text-white border-emerald-500'
                                  : 'bg-slate-50 text-slate-400 border-slate-200/90 hover:border-slate-200'
                              }`}
                            >
                              {isSelected ? '✓ ' : '+ '}
                              {skill}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                    <div>
                      <label className="block font-bold text-slate-400 uppercase mb-1">
                        Experience (Years)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="40"
                        value={profileExp}
                        onChange={(e) => setProfileExp(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-400 uppercase mb-1">
                        Service Location
                      </label>
                      <input
                        type="text"
                        value={profileLoc}
                        onChange={(e) => setProfileLoc(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-400 uppercase mb-1">
                        Preferred Radius
                      </label>
                      <select
                        value={profileRadius}
                        onChange={(e) => setProfileRadius(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200/90 rounded-xl text-white"
                      >
                        <option value="5">5 km</option>
                        <option value="10">10 km</option>
                        <option value="20">20 km</option>
                        <option value="30">30 km</option>
                      </select>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-200/90 flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setIsEditingProfile(false)}
                      className="px-4 py-2 bg-slate-50 text-slate-400 hover:text-slate-900 font-bold text-xs rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save & Apply Trade</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* TAB: SKILL EXCHANGE                                  */}
          {/* ==================================================== */}
          {workerActiveTab === 'skill-exchange' && (
            <WorkerSkillExchange />
          )}

          {/* ==================================================== */}
          {/* TAB 13: SETTINGS                                     */}
          {/* ==================================================== */}
          {workerActiveTab === 'settings' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">Worker Settings</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Notification alerts, shift preferences, and bank payout configuration.
                </p>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 space-y-5 text-xs">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200/90">
                  <div>
                    <span className="font-extrabold text-sm text-white block">
                      Audio Chime for New {workerTrade} Job Dispatches
                    </span>
                    <span className="text-slate-400">Play alert sound when customer requests arrive</span>
                  </div>
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-5 h-5 accent-emerald-500 rounded"
                  />
                </div>

                <div className="flex items-center justify-between pb-4 border-b border-slate-200/90">
                  <div>
                    <span className="font-extrabold text-sm text-white block">
                      Direct Escrow Bank Payout
                    </span>
                    <span className="text-slate-400">SBI A/C •••• 4912 (Auto-settled daily at 8 PM)</span>
                  </div>
                  <span className="text-emerald-700 font-bold">✓ Active</span>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => showToast('Worker preferences saved.', 'success')}
                    className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-slate-900 font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: CONTACT CUSTOMER */}
      {contactCustomerModal && (
        <div className="fixed inset-0 z-50 bg-slate-50/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl border border-slate-200/90 p-6 text-center animate-in zoom-in-95 duration-150">
            <h3 className="text-lg font-black text-white">{contactCustomerModal.customer}</h3>
            <p className="text-xs text-emerald-700 font-semibold">{contactCustomerModal.service} Booking</p>
            <p className="text-xs text-slate-400 mt-1">{contactCustomerModal.location}</p>

            <div className="mt-6 space-y-2 text-xs font-bold">
              <a
                href={`tel:${contactCustomerModal.customerPhone || '+919886044210'}`}
                className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl shadow-xs flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                <span>Call {contactCustomerModal.customerPhone || '+91 98860 44210'}</span>
              </a>
              <button
                onClick={() => {
                  showToast('Customer notified via SMS.', 'info');
                  setContactCustomerModal(null);
                }}
                className="w-full py-2.5 bg-slate-50 hover:bg-slate-800 text-slate-300 rounded-xl"
              >
                Send Quick ETA SMS
              </button>
              <button
                onClick={() => setContactCustomerModal(null)}
                className="w-full py-2 text-slate-500 hover:text-slate-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
