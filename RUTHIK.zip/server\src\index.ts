/**
 * CoWork Connect — Express + Socket.io Server Entry Point
 * Cooperative Gig & Agricultural Services Platform
 *
 * Real-time WebSocket synchronization, JWT Role-based Authorization,
 * PostgreSQL + Persistent JSON Database fallback.
 */

import http from 'http';
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Server as SocketIOServer } from 'socket.io';

import { initDatabase } from './config/db';
import { initSocket } from './services/socketService';

import authRouter from './routes/authRoutes';
import bookingRouter from './routes/bookingRoutes';
import workerRouter from './routes/workerRoutes';
import farmerRouter from './routes/farmerRoutes';
import equipmentRouter from './routes/equipmentRoutes';
import notificationRouter from './routes/notificationRoutes';
import complaintRouter from './routes/complaintRoutes';
import adminRouter from './routes/adminRoutes';
import voiceSevaRouter from './routes/voiceSeva';
import cropSharingRouter from './routes/cropSharing';

dotenv.config();

const app = express();
const httpServer = http.createServer(app);

const PORT = Number(process.env.PORT) || 5000;
const APP_URL = process.env.APP_URL || 'http://localhost:5173';

// ─── Socket.io Setup ───────────────────────────────────────────────────────────
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: [APP_URL, 'http://localhost:5173', 'http://localhost:5174', 'http://127.0.0.1:5173'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
  }
});
initSocket(io);

// ─── Middleware ──────────────────────────────────────────────────────────────
app.use(cors({
  origin: [APP_URL, 'http://localhost:5173', 'http://localhost:5174', 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));
app.use(express.json({ limit: '15mb' }));

// ─── API Routes ──────────────────────────────────────────────────────────────
app.use('/api/auth', authRouter);
app.use('/api/bookings', bookingRouter);
app.use('/api/workers', workerRouter);
app.use('/api/farmers', farmerRouter);
app.use('/api/equipment', equipmentRouter);
app.use('/api/notifications', notificationRouter);
app.use('/api/complaints', complaintRouter);
app.use('/api/admin', adminRouter);
app.use('/api/voice-seva', voiceSevaRouter);
app.use('/api/crop-sharing', cropSharingRouter);

// Health check
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'CoWork Connect Production API',
    version: '2.0.0',
    timestamp: new Date().toISOString()
  });
});

// ─── Initialize DB & Start HTTP/WebSocket Server ──────────────────────────────
initDatabase().then(() => {
  httpServer.listen(PORT, () => {
    console.log(`🚀 CoWork Connect Server & WebSockets running on http://localhost:${PORT}`);
    console.log(`   Realtime API: http://localhost:${PORT}/api/bookings`);
    console.log(`   Health check: http://localhost:${PORT}/health`);
  });
}).catch((err) => {
  console.error('Fatal error during database startup:', err);
  process.exit(1);
});

export default app;
